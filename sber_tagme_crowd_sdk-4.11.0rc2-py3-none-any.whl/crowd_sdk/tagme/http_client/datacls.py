# pylint: disable=too-many-lines
import json
import logging
from dataclasses import dataclass, field, fields
from datetime import date, datetime
from enum import Enum
from mimetypes import guess_extension
from pathlib import Path
from typing import Any, DefaultDict, Dict, List, Literal, Optional, Set, Union

import aiofiles
import pytz
from aiohttp import StreamReader
from dacite.types import is_instance

from crowd_sdk.core.utils.common import DATE_TIME_UTC_FORMATS, dataclass_to_dict, md5_str, parse_date

logger = logging.getLogger(__name__)

# -----------------------------------------------------------------------------
#                                  PROJECT
# -----------------------------------------------------------------------------


class ExportFormat(Enum):
    CSV = 'csv'
    JSON = 'json'
    XLS = 'xls'
    TSV = 'tsv'


EXPORT_SUFFIX = {
    ExportFormat.CSV: '.csv',
    ExportFormat.JSON: '.json',
    ExportFormat.XLS: '.xlsx',
    ExportFormat.TSV: '.tsv',
}

utctz = pytz.timezone("UTC")


def fmt_date(d: Optional[datetime]) -> Optional[str]:
    if not d:
        return None
    return d.astimezone(utctz).isoformat().replace("+00:00", "Z")


class ExportTypes(Enum):
    MARKERS = 'MARKERS'
    TASKS = 'TASKS'


@dataclass
class Project:
    organization_id: str
    name: str
    description: str
    inner_comment: str
    pools: List[str]
    uid: str
    method_id: str
    person_id: str
    created_date: Optional[datetime]
    update_date: Optional[datetime]
    running_tasks_count: Optional[int]
    tasks_count: Optional[int]
    is_archived: bool = False
    method: Optional['MethodData'] = None
    is_bookmarked: bool = False
    pipeline: Optional[dict] = None
    is_pipeline_enabled: Optional[bool] = False
    template_id: Optional[str] = None
    is_brief_autoupdate: Optional[bool] = False
    is_forms_autoupdate: Optional[bool] = False
    is_config_autoupdate: Optional[bool] = False
    is_specification_autoupdate: Optional[bool] = False
    markers_count_plan: Optional[int] = None
    pipeline_errors: Optional[str] = None
    contacts: Optional[str] = None


@dataclass
class ProjectStatistic:
    project_id: str
    markers_count: Optional[int] = None
    validators_count: Optional[int] = None
    pools_count: Optional[int] = None
    markers_pools_count: Optional[int] = None
    validators_pools_count: Optional[int] = None
    objects_count: Optional[int] = None
    marked_count: Optional[int] = None
    status: Optional[str] = None
    tasks_count: Optional[int] = None
    active_marker_count: Optional[int] = None


@dataclass
class OrganizationStatistic:
    projects_count: Optional[int] = None
    projects_with_active_tasks: Optional[int] = None
    opened_tasks: Optional[int] = None
    done_tasks: Optional[int] = None
    marked_count: Optional[int] = None
    unmarked_count: Optional[int] = None
    pools_count: Optional[int] = None
    markers_pools_count: Optional[int] = None
    validators_pools_count: Optional[int] = None
    markers_count: Optional[int] = None
    validators_count: Optional[int] = None


@dataclass
class TypeCasting:
    def __post_init__(self) -> None:
        for dataclass_field in fields(self):
            field_type = dataclass_field.type
            value = getattr(self, dataclass_field.name)

            if not is_instance(value, field_type):
                try:
                    if is_instance(0.5, field_type) and isinstance(value, str):
                        setattr(self, dataclass_field.name, float(value))
                    elif is_instance(1, field_type) and isinstance(value, str):
                        # TODO: (cerikoff) remove after TAGME-6694
                        try:
                            attr_value = int(value)
                        except ValueError:
                            attr_value = int(float(value))
                        setattr(self, dataclass_field.name, attr_value)
                    elif str(field_type) in (
                        "datetime.datetime",
                        "typing.Optional[datetime.datetime]",
                    ) and isinstance(value, str):
                        setattr(self, dataclass_field.name, parse_date(value))
                    else:
                        setattr(self, dataclass_field.name, field_type(value))
                except TypeError:
                    setattr(self, dataclass_field.name, None)


@dataclass
class MarkersStatistic(TypeCasting):
    date: str
    organization: str
    project: str
    project_id: str
    task: str
    task_id: str
    marker_id: str
    avg_time: float
    overall_time: float
    blocked_price: Optional[float] = None
    sum_price: Optional[float] = None
    fio: Optional[str] = None
    email: Optional[str] = None
    begin: Optional[datetime] = None
    end: Optional[datetime] = None
    marked: int = 0
    skipped: int = 0
    accepted: int = 0
    rejected: int = 0
    submitted: int = 0
    expired: int = 0
    avg_quality: Optional[float] = None
    avg_consistency: Optional[float] = None
    rejected_price: Optional[float] = None
    bonus_plus_penalty: Optional[float] = None
    count_quality: Optional[int] = None


@dataclass
class TasksStatistic(TypeCasting):
    date: str
    organization: str
    project: str
    project_id: str
    task: str
    task_id: str
    overlap: int
    avg_time: float
    overall_time: float
    count_assignments: int = 0
    count_items: int = 0
    completed_items: int = 0
    completed_assignments: int = 0
    accepted_assignments: int = 0
    rejected_assignments: int = 0
    submitted_assignments: int = 0
    skipped_assignments: int = 0
    expired_assignments: int = 0
    sum_price: Optional[float] = None
    blocked_price: Optional[float] = None
    avg_consistency: Optional[float] = None
    avg_quality: Optional[float] = None
    task_type: Optional[str] = None
    rejected_price: Optional[float] = None
    bonus_plus_penalty: Optional[float] = None
    count_quality: Optional[int] = None


@dataclass
class Contacts:
    contacts: Optional[str]


# -----------------------------------------------------------------------------
#                                    METHOD
# -----------------------------------------------------------------------------


@dataclass
class MethodFileType(Enum):
    BRIEF = "brief"


@dataclass
class ExampleData:
    filename: Union[str, Dict, None] = ''
    explanation: Optional[str] = None
    control: Optional[Dict[str, Any]] = None
    premarkup: Optional[Dict[str, Any]] = None


@dataclass
class MethodForms:
    example: dict = field(default_factory=dict)
    config: dict = field(default_factory=dict)
    specification: dict = field(default_factory=dict)
    html: Optional[str] = ''
    css: Optional[str] = ''
    js: Optional[str] = ''


@dataclass
class MethodFormsRequest:
    example: Optional[dict] = None
    config: Optional[dict] = None
    specification: Optional[dict] = None
    html: Optional[str] = None
    css: Optional[str] = None
    js: Optional[str] = None


@dataclass
class MethodData:
    uid: str
    name: Optional[str] = None
    forms: Optional[MethodForms] = None
    marker_brief: Optional[str] = None

    organization_id: Optional[str] = None
    person_id: Optional[str] = None
    modification_date: Optional[str] = None

    is_brief_as_url: Optional[bool] = None

    brief_update_date: Optional[str] = None
    forms_update_date: Optional[str] = None
    config_update_date: Optional[str] = None


@dataclass
class MethodDataRequest:
    uid: str
    name: Optional[str] = None
    forms: Optional[MethodFormsRequest] = None
    marker_brief: Optional[str] = None

    organization_id: Optional[str] = None
    person_id: Optional[str] = None
    modification_date: Optional[str] = None

    is_brief_as_url: Optional[bool] = None

    brief_update_date: Optional[str] = None
    forms_update_date: Optional[str] = None
    config_update_date: Optional[str] = None


@dataclass
class BriefReadStatusData:
    read_at: str
    is_new_version: bool


# -----------------------------------------------------------------------------
#                                    INTERFACE VERSIONS
# -----------------------------------------------------------------------------


@dataclass
class InterfaceVersionInfo:
    method_id: str
    version: int
    created_at: datetime
    person_id: Optional[str] = None
    is_autoupdate: Optional[bool] = False
    updated_keys: Optional[List[str]] = None
    person: Optional[dict] = None

    config_content: Optional[dict] = None
    config_base_version: Optional[int] = None
    specification_content: Optional[dict] = None
    specification_base_version: Optional[int] = None
    html_content: Optional[str] = None
    html_base_version: Optional[int] = None
    css_content: Optional[str] = None
    css_base_version: Optional[int] = None
    js_content: Optional[str] = None
    js_base_version: Optional[int] = None
    example_content: Optional[dict] = None
    example_base_version: Optional[int] = None


# -----------------------------------------------------------------------------
#                                    BRIEF VERSIONS
# -----------------------------------------------------------------------------


@dataclass
class BriefVersionInfo:
    method_id: str
    created_at: datetime
    file_id: Optional[str] = None
    dataset_id: Optional[str] = None
    version: Optional[int] = None
    person: Optional[dict] = None
    person_id: Optional[str] = None
    is_autoupdate: bool = False


# -----------------------------------------------------------------------------
#                                    TASKS
# -----------------------------------------------------------------------------


class TaskType(Enum):
    STUDY = 'STUDY'
    PROD = 'PROD'
    EXAM = 'EXAM'
    RETRY = 'RETRY'
    HONEYPOT = 'HONEYPOT'


class TaskSkipStrategy(Enum):
    COUNT_AS_MARKUP = 'COUNT_AS_MARKUP'
    IGNORE = 'IGNORE'
    NON_SKIPPABLE = 'NON_SKIPPABLE'


class TaskStatus(Enum):
    RUN = "RUN"
    STOP = "STOP"
    ARCHIVE = "ARCHIVE"


class TaskState(Enum):
    INITIAL = 'INITIAL'
    RUNNING = 'RUNNING'
    STOPPED = 'STOPPED'
    DONE = 'DONE'
    ARCHIVE = 'ARCHIVE'


@dataclass
class ProjectStatistics:
    min_price: Optional[float] = None
    max_price: Optional[float] = None
    min_study_price: Optional[float] = None
    max_study_price: Optional[float] = None
    min_exam_price: Optional[float] = None
    max_exam_price: Optional[float] = None
    min_retry_price: Optional[float] = None
    max_retry_price: Optional[float] = None


@dataclass
class ProjectTask:
    """
    Project-task entity
    """

    id: str
    status: TaskStatus
    description: str
    form_url: str
    brief_url: str
    is_favourite_project: bool
    project_name: str
    project_id: str
    price: float
    type: TaskType
    project_stat: ProjectStatistics
    is_auto_accept: bool
    method_id: Optional[str] = None
    started_at: Optional[datetime] = None
    min_expired_after: Optional[datetime] = None
    priority: Optional[int] = None
    max_income: Optional[float] = None
    avg_time: Optional[float] = None
    project_description: Optional[str] = None


@dataclass
class ProjectTaskPaginated:
    items: List[ProjectTask]
    has_next: bool


@dataclass
class TaskDataRequest:
    project_id: str
    organization_id: str
    name: str
    overlap: int = 1
    type: TaskType = TaskType.PROD
    skip_strategy: TaskSkipStrategy = TaskSkipStrategy.NON_SKIPPABLE
    description: Optional[str] = ''  # HOTFIX for https://jira.sberbank.ru/browse/TAGME-4166
    price: Optional[float] = None
    priority: Optional[int] = None
    data_classification_level: Optional[str] = None
    data_source: Optional[str] = None
    control_count: Optional[int] = None
    control_fraction: Optional[int] = None
    item_timeout_seconds: Optional[int] = None
    out_skill_id: Optional[str] = None
    depersonalize: Optional[bool] = None
    deadline: Optional[date] = None
    expected_consistency: Optional[float] = None
    expected_quality: Optional[float] = None
    expected_sum: Optional[float] = None
    filter: Optional[dict] = None
    is_auto_accept: bool = True
    auto_accept_period_day: Optional[int] = None
    auto_accept_threshold: Optional[float] = None
    is_straight_order: bool = False
    max_items_per_day: Optional[int] = None
    attachments_access: Optional[str] = None
    attachments_acl: Optional[List[str]] = None
    markers_count_plan: Optional[int] = None

    @classmethod
    def from_task_data(cls, task_data: 'TaskData', ignore_fields: Optional[Set[str]] = None) -> 'TaskDataRequest':
        request_fields = {f.name for f in fields(cls)}

        data = {
            field_name: getattr(task_data, field_name)
            for field_name in request_fields
            if hasattr(task_data, field_name) and ((ignore_fields is None) or (field_name not in ignore_fields))
        }
        return cls(**data)


@dataclass
class DatasetRequest:
    name: str
    data_classification_level: Optional[str] = None
    data_source: Optional[str] = None


class DatasetType(Enum):
    DATASET = "DATASET"
    BUCKET = "BUCKET"
    TEMPLATE = "TEMPLATE"
    METHODICS = "METHODICS"
    BUNDLE = "BUNDLE"
    LORA_LEARNING = "LORA_LEARNING"


@dataclass
class Dataset:
    id: str
    access: str
    owner_id: str
    created_date: datetime
    files_count: int
    name: str
    data_classification_level: Optional[str] = None
    data_source: Optional[str] = None
    acl: Optional[List[str]] = None
    attachments_access: Optional[str] = None
    attachments_acl: Optional[List[str]] = None
    author: Optional[dict] = None


@dataclass
class TaskInfo:
    """
    Minified task entity
    """

    id: str
    status: TaskStatus
    started_at: Optional[datetime] = None


@dataclass
class TaskData:  # pylint: disable=too-many-instance-attributes
    project_id: str
    organization_id: Optional[str]
    name: str
    uid: str
    person_id: str
    estimated_files_count: Optional[int]
    storage_id: Optional[str]
    item_timeout_seconds: Optional[int]
    use_project_method: Optional[bool]
    payload: Optional[dict]
    data_classification_level: Optional[str]
    data_source: Optional[str]
    control_count: Optional[int]
    control_fraction: Optional[int]
    created_date: Optional[datetime]
    update_date: Optional[datetime]
    start_date: Optional[datetime]
    finished_date: Optional[datetime]
    out_skill_id: Optional[str]
    deadline: Optional[date]
    expected_consistency: Optional[float]
    expected_quality: Optional[float]
    expected_sum: Optional[float]
    filter: Optional[dict]
    type: TaskType = TaskType.PROD
    state: TaskState = TaskState.INITIAL
    is_active: bool = False
    overlap: int = 1
    skip_strategy: TaskSkipStrategy = TaskSkipStrategy.NON_SKIPPABLE
    deleted: bool = False
    description: Optional[str] = ''
    depersonalize: bool = False
    price: float = 0
    priority: int = 0
    is_auto_accept: bool = True
    auto_accept_period_day: Optional[int] = None
    auto_accept_threshold: Optional[float] = None
    is_straight_order: bool = False
    max_items_per_day: Optional[int] = None
    attachments_access: Optional[str] = None
    attachments_acl: Optional[List[str]] = None
    markers_count_plan: Optional[int] = None

    def gen_url(self, base_url: str) -> str:
        return f'{base_url}/company/{self.organization_id}/project/{self.project_id}/task/{self.uid}/overview'


@dataclass
class TaskHierarchy:
    project_id: str
    organization_id: str
    template_id: Optional[str]


class CheckStatus(Enum):
    OK = "OK"
    WARNING = "WARNING"
    ERROR = "ERROR"


@dataclass
class CheckResult:
    status: CheckStatus
    message: Optional[str] = None


@dataclass
class SkillCheckResult(CheckResult):
    uid: Optional[str] = None


@dataclass
class CheckTaskResult:
    brief: Optional[CheckResult] = None
    form: Optional[CheckResult] = None
    markers: Optional[CheckResult] = None
    price: Optional[CheckResult] = None
    data_count: Optional[CheckResult] = None
    filter: Optional[CheckResult] = None
    control_count: Optional[CheckResult] = None
    out_skill: Optional[SkillCheckResult] = None
    data_classification_level: Optional[CheckResult] = None
    data_source: Optional[CheckResult] = None
    control_fraction: Optional[CheckResult] = None


@dataclass  # pylint: disable=R0902
class TaskStats:
    task_id: str
    total_marked_time: float
    objects_count: int
    marked_count: int
    total_skipped_objects_count: int
    total_marked_objects_count: int
    total_accepted_objects_count: int
    total_rejected_objects_count: int
    current_overlap: int
    total_objects_count: int
    avg_object_count_marker: float
    status: TaskState
    one_object_avg_time: float
    active_markers: int
    total_markers: int
    finished_marker: Optional[int]
    pretending_marker: Optional[int]
    cost: Optional[float]
    avg_quality: Optional[float]
    avg_consistency: Optional[float]
    avg_hour_profit: Optional[float]
    avg_accepted_price: Optional[float]
    avg_rejected_price: Optional[float]


@dataclass
class TaskStatsAdvanced:
    estimation_date: Optional[date]
    in_progress_count: int


@dataclass
class TaskStatisticsItem:
    task_id: str
    objects_count: int
    marked_count: int
    total_marked_objects_count: int
    total_skipped_objects_count: int
    total_expired_objects_count: int
    total_accepted_objects_count: int
    total_rejected_objects_count: int
    total_submitted_objects_count: int
    total_marked_time: float
    current_overlap: float
    total_objects_count: float
    overlap_marked_stats: Dict[str, Any]
    updated_date: Optional[datetime]


@dataclass
class TaskMarkup:
    pools: List[str]
    pick_date: datetime
    submit_date: datetime
    result: Dict[str, Any]


@dataclass  # pylint: disable=R0902
class TaskResult:
    uid: str
    entity_id: str
    task_id: str
    organization_id: str
    person_id: str
    storage_id: Optional[str]
    file_name: str
    entity_type: Optional[str]
    price: Optional[float]

    skip: Dict[str, Any] = field(default_factory=dict)
    result: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    consistency_percentage: Optional[float] = None
    consistent_result: Optional[bool] = None
    consistent_skip: Optional[bool] = None

    def to_dict(self) -> dict:
        return dataclass_to_dict(self)

    def append_assignment(self, assignment: 'Assignment') -> None:
        if assignment.status.lower() == 'skipped':
            if assignment.marker_id in self.skip:
                logger.debug(f'Duplicated skip {assignment.marker_id}')
            self.skip[assignment.marker_id] = assignment.to_skip_data()
        elif assignment.status.lower() == 'accepted':
            if assignment.marker_id in self.result:
                logger.debug(f'Duplicated result {assignment.marker_id}')
            self.result[assignment.marker_id] = assignment.to_result_data()
        else:
            logger.debug(f'Pass unhandled status {assignment.status.lower()}')

    @classmethod
    def from_assignments(cls, item_id: str, assignments: List['Assignment']) -> 'TaskResult':
        result = cls(
            uid=item_id,
            entity_id=item_id,
            task_id=assignments[0].task_id,
            organization_id=assignments[0].organization_id,
            person_id=assignments[0].person_id,
            storage_id=assignments[0].task_id,
            file_name=assignments[0].file_name,
            entity_type=assignments[0].item_type,
            price=assignments[0].price,
        )

        for assignment in assignments:
            result.append_assignment(assignment)

        return result


class TaskUnavailabilityReasonCode(Enum):
    UNDEFINED = 'UNDEFINED'
    AVAILABLE = 'AVAILABLE'
    NO_TASK = 'NO_TASK'
    INACTIVE_TASK = 'INACTIVE_TASK'
    NOT_IN_POOL = 'NOT_IN_POOL'
    ALREADY_MARKED = 'ALREADY_MARKED'
    DAILY_LIMIT_REACHED = 'DAILY_LIMIT_REACHED'
    UNSUITABLE_SKILL_LEVEL = 'UNSUITABLE_SKILL_LEVEL'
    LOW_POOL_PRIORITY_LEVEL = 'LOW_POOL_PRIORITY_LEVEL'
    MORE_IMPORTANT_TASK_AVAILABLE = 'MORE_IMPORTANT_TASK_AVAILABLE'


@dataclass
class TaskUnavailabilityReason:
    reason_code: TaskUnavailabilityReasonCode
    reason_description: str


@dataclass
class AvailableProjectTask:
    task_id: str
    task_name: str
    project_id: str
    project_name: str
    organization_id: str
    pool_ids: List[str]


@dataclass
class AvailableProjectTaskResponse:
    has_next: bool
    items: List[AvailableProjectTask]


@dataclass
class ActiveAssignment:
    assignment_id: str
    task_id: str
    task_name: str
    project_id: str
    project_name: str
    organization_id: str
    item_type: str
    assignment_started: datetime
    price: float


@dataclass
class MarkerActiveAssignmentResponse:
    assignments: List[ActiveAssignment]


# -----------------------------------------------------------------------------
#                                    POOLS
# -----------------------------------------------------------------------------


@dataclass
class Member:
    uid: str
    person: 'Person'
    priority: Optional[int] = None


@dataclass
class PoolOrganization:
    uid: str
    name: str


@dataclass
class Pool:
    name: str
    uid: str
    person_id: str
    person: Optional['Person'] = None
    members_count: Optional[int] = 0
    members: List[Member] = field(default_factory=list)
    organization_id: Optional[str] = None
    organization: Optional[PoolOrganization] = None
    access: Optional[Literal["public", "organization", "private"]] = None
    acl: Optional[List[str]] = None
    group_type: Literal["MARKERS", "VALIDATORS"] = "MARKERS"


@dataclass
class MarkerPool:
    marker_id: str
    pool_id: str
    priority: Optional[int] = None


@dataclass
class InvitePerson:
    email: str
    first_name: str
    last_name: str
    middle_name: Optional[str]
    phone_number: Optional[str]
    source_platform: Optional[str]


@dataclass
class InviteApplication:
    state: str
    invite_id: str
    created_date: datetime
    person_id: str
    uid: str
    invite_name: Optional[str]
    person: Optional[InvitePerson]


@dataclass
class InviteData:
    state: str
    current_new_requests_count: int
    acceptance_strategy: str
    organization_id: str
    expired_date: Optional[datetime]
    uid: str
    current_requests_count: int
    invite_name: str
    max_requests_count: Optional[int]
    created_date: datetime
    author_id: str
    pools_to_assign: Optional[List[str]]
    auto_accept_emails: Optional[str]


@dataclass
class InviteRequest:
    acceptance_strategy: str
    organization_id: str
    invite_name: str
    state: Optional[str] = None
    max_requests_count: Optional[int] = None
    expired_date: Optional[datetime] = None
    pools_to_assign: Optional[List[str]] = None
    auto_accept_emails: Optional[str] = None


@dataclass
class MarkersError:
    email_list: List[str]
    error_message: str


@dataclass
class ErrorMarkersResponse:
    status: int
    errors: List[MarkersError]


@dataclass
class VendorChangeRecord:
    person_id: str
    created_at: datetime
    source_platform: Optional[str] = None
    partner_id: Optional[str] = None
    utm_referral: Optional[str] = None
    active_from: Optional[datetime] = None
    prev_source_platform: Optional[str] = None
    prev_partner_id: Optional[str] = None
    prev_utm_referral: Optional[str] = None
    error: Optional[str] = None


# -----------------------------------------------------------------------------
#                                    PERSON
# -----------------------------------------------------------------------------


@dataclass
class Organization:
    uid: str
    name: str
    employ_date: Optional[datetime]
    employee_id: str
    roles: List[str] = field(default_factory=list)
    profile: Dict[str, Any] = field(default_factory=dict)
    report: Dict[str, Any] = field(default_factory=dict)
    config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Person:
    email: str
    first_name: str
    last_name: str
    uid: str
    middle_name: Optional[str] = None
    organizations: Optional[List[Organization]] = None
    phone_number: Optional[str] = None
    source_platform: Optional[str] = None
    partner_id: Optional[str] = None
    utm_referral: Optional[str] = None

    def get_organization(self, organization: str) -> Optional[Organization]:
        assert self.organizations
        for org in self.organizations:
            if organization in (org.uid, org.name):
                return org
        return None

    def get_fio(self) -> str:
        if self.middle_name:
            return self.first_name + ' ' + self.middle_name + ' ' + self.last_name
        else:
            return self.first_name + ' ' + self.last_name

    def get_roles(self, organization: str) -> Optional[List[str]]:
        org = self.get_organization(organization)
        return org.roles if org else None

    def get_config(self, organization: str) -> Optional[Dict[str, Any]]:
        org = self.get_organization(organization)
        return org.config if org else None

    def get_report(self, organization: str) -> Optional[Dict[str, Any]]:
        org = self.get_organization(organization)
        return org.report if org else None

    def get_profile(self, organization: str) -> Optional[Dict[str, Any]]:
        org = self.get_organization(organization)
        return org.profile if org else None


# -----------------------------------------------------------------------------
#                               MARKUP TASKS
# -----------------------------------------------------------------------------


@dataclass
class MarkupTask:
    id: str
    project_name: str
    assignment_timeout_seconds: float
    skippable: bool
    brief_url: str
    file_url: str
    form_url: str
    premarkup_url: str
    price: float
    item_id: str
    empty: bool = False
    started_at: Optional[datetime] = None

    @staticmethod
    def build_empty_task() -> 'MarkupTask':
        return MarkupTask(
            id='',
            project_name='',
            assignment_timeout_seconds=0,
            skippable=False,
            brief_url='',
            file_url='',
            form_url='',
            premarkup_url='',
            price=0,
            item_id='',
            empty=True,
            started_at=None,
        )


@dataclass
class MarkupReview:
    assignment_id: str
    status: Optional[str] = None
    comment: Optional[str] = None
    is_review_public: Optional[bool] = None
    quality: Optional[float] = None
    is_delete_quality_when_empty: Optional[bool] = None
    is_delete_comment_when_empty: Optional[bool] = None


@dataclass
class AssignAssignmentRequest:
    task_id: str
    item_id: str
    marker_id: str
    expired_after: datetime
    original_assignment_id: Optional[str] = None
    price: Optional[float] = None
    is_increase_overlap: Optional[bool] = None
    is_release_to_pool_on_expire: Optional[bool] = None


@dataclass
class MarkerAssignment:
    marker_id: str
    original_assignment_id: Optional[str] = None


@dataclass
class AssignMultipleAssignmentRequest:
    task_id: str
    item_id: str
    markers: List[MarkerAssignment]
    expired_after: Union[datetime, str]
    price: Optional[float] = None
    is_increase_overlap: Optional[bool] = None
    is_release_to_pool_on_expire: Optional[bool] = None

    def __post_init__(self) -> None:
        if isinstance(self.expired_after, datetime):
            self.expired_after = self.expired_after.strftime("%Y-%m-%dT%H:%M:%SZ")


@dataclass
class MarkupResultItem:
    id: str
    type: str
    file_name: str
    control: Optional[Dict]


@dataclass
class MarkupResult:
    id: str
    project_id: str
    task_id: str
    marker_id: str
    items: List[MarkupResultItem]
    status: str
    start_date: datetime
    end_date: Optional[datetime]
    quality: Optional[float]
    consistency: Optional[float]
    result: Optional[dict]
    submitted_at: Optional[datetime]
    accepted_at: Optional[datetime]
    skipped_at: Optional[datetime]
    expired_at: Optional[datetime]
    rejected_at: Optional[datetime]
    reviewer_id: Optional[str]
    reviewer_comment: Optional[str]
    original_assignment_id: Optional[str]
    is_review_public: Optional[bool]


@dataclass
class MarkupResults:
    items: List[MarkupResult]
    has_next: bool


class MarkupResultSortField(Enum):
    ACCEPTED = 'accepted'
    CONSISTENCY = 'consistency'
    EXPIRED = 'expired'
    ITEM_ID = 'item_id'
    ITEM_TYPE = 'item_type'
    MARKUP_DURATION = 'markup_duration'
    QUALITY = 'quality'
    REJECTED = 'rejected'
    SKIPPED = 'skipped'
    STATUS = 'status'
    SUBMITTED = 'submitted'


class SortOrder(Enum):
    ASC = 'asc'
    DESC = 'desc'


@dataclass
class MarkupMarkerStatisticSkill:
    id: str
    name: str
    level: int


@dataclass
class MarkupMarkerStatistic:
    stat_at: date
    task_type: TaskType
    marking_duration: int
    marked: int
    accepted: int
    accepted_money: float
    frozen: int
    frozen_money: float
    project_id: str
    project_name: str
    skills: List[MarkupMarkerStatisticSkill]


@dataclass
class MarkupMarkerStatistics:
    items: List[MarkupMarkerStatistic]
    has_next: bool


class MarkupMarkerStatisticsSortField(Enum):
    STAT_AT = 'stat_at'


@dataclass
class MarkupReviewResult:
    failed_assignment_ids: Optional[Dict[str, str]]


@dataclass
class AssignAssignmentsError:
    task_id: str
    marker_id: str
    message: str


@dataclass
class AssignAssignmentsResult:
    failed_assign_requests: Optional[List[AssignAssignmentsError]]


@dataclass
class MarkupTaskFile:
    name: str
    content_type: str
    content: StreamReader
    __bytes: Optional[bytes] = None

    async def read(self) -> bytes:
        if self.__bytes is None:
            self.__bytes = await self.content.read()

        return self.__bytes

    async def as_dict(self) -> Any:
        res = await self.read()
        return json.loads(res)

    async def save(self, path: Union[Path, str]) -> Path:
        path = Path(path)
        if path.is_dir():
            file_ext = guess_extension(self.content_type)
            path = path / f'{self.name}.{file_ext}'

        async with aiofiles.open(path, 'wb') as f:
            await f.write(await self.read())

        return path


@dataclass
class ProjectStat:
    avg_income: Optional[float]
    min_price: Optional[float]
    max_price: Optional[float]
    study_price: Optional[float]
    exam_price: Optional[float]


@dataclass
class TaskflowTaskData:
    id: str
    brief_url: str
    project_name: str
    description: str
    project_description: Optional[str]
    form_url: str
    price: float
    status: str
    type: str
    project_stat: ProjectStat
    is_auto_accept: bool


# -----------------------------------------------------------------------------
#                               MARKERS
# -----------------------------------------------------------------------------


@dataclass
class EmployeePool:
    name: str
    uid: str


AssignmentStatusType = Literal["ACCEPTED", "ASSIGNED", "SKIPPED", "EXPIRED", "SUBMITTED", "REJECTED"]


@dataclass
class Assignment:
    file_name: str
    item_id: str
    marker_id: str
    organization_id: str
    person_id: str
    price: Optional[float]
    result: Optional[dict]
    status: AssignmentStatusType
    task_id: str
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    submitted_at: Optional[datetime] = None
    expired_at: Optional[datetime] = None
    skipped_at: Optional[datetime] = None
    accepted_at: Optional[datetime] = None
    rejected_at: Optional[datetime] = None
    updated_date: Optional[datetime] = None
    item_type: Optional[str] = None
    control: Optional[dict] = None
    control_passed: Optional[Union[bool, float, int]] = None
    consistency: Optional[float] = None
    quality: Optional[float] = None
    assignment_id: Optional[str] = None
    time_spent: Optional[float] = None
    email: Optional[str] = None
    input_data: Optional[dict] = None
    enabled: Optional[bool] = True
    assignment_link: Optional[str] = None
    reviewer_comment: Optional[str] = None
    is_review_public: Optional[bool] = None

    def get_safe_result_field(self, key: str) -> Any:
        if isinstance(self.result, dict):
            return self.result.get(key)
        return None

    def get_quality(self) -> Optional[float]:
        if self.quality is not None:
            return self.quality

        if self.control_passed is None:
            return None

        return 1 if self.control_passed else 0

    def to_skip_data(self) -> Dict[str, Any]:
        return {
            'pick_date': fmt_date(self.start_date),
            'submit_date': fmt_date(self.end_date),
            'price': self.price,
            'control': self.control,
            'control_passed': self.control_passed,
            'quality': self.get_quality(),
            'assignment_id': self.assignment_id,
            'pools': [],
        }

    def to_result_data(self) -> Dict[str, Any]:
        return {
            'pools': [],
            'pick_date': fmt_date(self.start_date),
            'submit_date': fmt_date(self.end_date),
            'price': self.price,
            'control': self.control,
            'control_passed': self.control_passed,
            'quality': self.get_quality(),
            'consistency': self.consistency,
            'result': self.result,
            'assignment_id': self.assignment_id,
        }

    def __post_init__(self) -> None:
        if not self.end_date:
            self.end_date = (
                self.submitted_at or self.accepted_at or self.expired_at or self.rejected_at or self.skipped_at
            )

        if isinstance(self.end_date, str):
            self.end_date = parse_date(self.end_date, datetime_formats=DATE_TIME_UTC_FORMATS)

    @staticmethod
    def from_assignment_data(
        user_id: str,
        item_data: TaskResult,
        assignment_data: dict,
        status: AssignmentStatusType,
    ) -> 'Assignment':
        item_id = item_data.entity_id
        task_id = item_data.task_id
        file_name = item_data.file_name
        item_type = item_data.entity_type
        person_id = item_data.person_id
        price = item_data.price
        organization_id = item_data.organization_id

        start_date = parse_date(assignment_data['pick_date'], datetime_formats=DATE_TIME_UTC_FORMATS)
        end_date = parse_date(assignment_data['submit_date'], datetime_formats=DATE_TIME_UTC_FORMATS)
        time_spent = round(float((end_date - start_date).total_seconds()), 2)

        if 'price' in assignment_data:
            price = assignment_data['price']

        if 'status' in assignment_data:
            status = assignment_data['status']

        if 'user_id' in assignment_data:
            user_id = assignment_data['user_id']

        assignment_id = md5_str(item_id + user_id)

        consistency = None
        quality: Optional[float] = None
        control = None
        if status.lower() == 'accepted':
            if 'control' in assignment_data:
                control = assignment_data['control']
            if 'assignment_id' in assignment_data:
                assignment_id = assignment_data['assignment_id']
            if 'control_passed' in assignment_data:
                if isinstance(assignment_data['control_passed'], bool):
                    quality = 1 if assignment_data['control_passed'] else 0
                if isinstance(assignment_data['control_passed'], float):
                    quality = assignment_data['control_passed']
                if isinstance(assignment_data['control_passed'], int):
                    quality = float(assignment_data['control_passed'])

            if 'consistency' in assignment_data:
                consistency = assignment_data['consistency']

        return Assignment(
            organization_id=organization_id,
            item_id=item_id,
            file_name=file_name,
            start_date=start_date,
            end_date=end_date,
            marker_id=user_id,
            person_id=person_id,
            status=status,
            price=price or 0,
            result=assignment_data['result'],
            consistency=consistency,
            control=control,
            control_passed=quality,
            quality=assignment_data.get('quality', quality),
            item_type=item_type,
            task_id=task_id,
            assignment_id=assignment_id,
            time_spent=time_spent,
            reviewer_comment=assignment_data.get('reviewer_comment'),
            is_review_public=assignment_data.get('is_review_public'),
        )


class PluginTypes(Enum):
    CUSTOMER = 'CUSTOMER'
    MARKER = 'MARKER'


@dataclass
class Plugin:
    type: PluginTypes
    route: str
    icon: str
    title: str
    bundle: str
    data: Optional[dict]


@dataclass
class Employee:
    person_id: str
    organization_id: str
    uid: str
    employ_date: Optional[datetime]
    active: bool
    roles: Optional[List[str]] = None
    profile: Dict[str, Any] = field(default_factory=dict)
    report: Dict[str, Any] = field(default_factory=dict)
    config: Dict[str, Any] = field(default_factory=dict)
    person: Optional[Person] = None
    pools: Optional[List[EmployeePool]] = None


@dataclass
class HourlyTaskMarkerStatistics:
    datetime: datetime
    period_started_at: datetime  # type: ignore # pylint: disable=undefined-variable
    task_id: str
    marker_id: str
    expired_count: int
    skipped_count: int
    accepted_count: int
    rejected_count: int
    submitted_count: int
    markup_duration_sec: float
    consistency_sum: float
    consistency_count: int
    quality_sum: float
    quality_count: int
    payed_money_sum: float
    payed_money_count: int
    frozen_money_sum: float
    rejected_money_sum: float


@dataclass
class HourlyTaskConsistencyStatistics:
    datetime: datetime
    period_started_at: datetime  # type: ignore # pylint: disable=undefined-variable
    task_id: str
    item_consistency_sum: float
    item_consistency_count: int


# -----------------------------------------------------------------------------
#                               UI
# -----------------------------------------------------------------------------


class FileType(Enum):
    CONTROL = 'CONTROL'
    STUDY = 'STUDY'
    DATA = 'DATA'


class MetaType(Enum):
    CONTROL = 'control'
    PREMARKUP = 'premarkup'
    EXPLANATION = 'explanation'


@dataclass
class TaskFile:
    content_type: str
    name: str
    size: int
    metadata: List[MetaType]
    bucket: str
    hashsum: Optional[str]
    data: Optional[str]
    uid: str
    file_type: FileType
    enabled: Optional[bool]


@dataclass
class TaskFilesCount:
    all: Optional[int] = None
    control: Optional[int] = None
    study: Optional[int] = None
    data: Optional[int] = None


@dataclass
class DatasetFile:
    url: str
    name: str
    id: str
    dataset_id: Optional[str] = None
    author: Optional[dict] = None


@dataclass
class SPInfo:
    report_url: str
    checking_files_count: int
    rejected_files_count: int
    error_files_count: int


@dataclass
class MetaData:
    control: Optional[dict] = None
    premarkup: Optional[dict] = None
    explanation: Optional[Any] = None


@dataclass
class FileMetaData:
    file_id: str
    filehash: Optional[str] = None
    premarkup: Optional[dict] = None
    control: Optional[dict] = None
    explanation: Optional[Any] = None


@dataclass
class UpdateMetaDataRequest:
    data: MetaData
    fileId: Optional[str] = None
    filename: Optional[str] = None


@dataclass
class File:
    filename: str
    uid: str


@dataclass
class FileError:
    filename: str
    status: int
    error: str


@dataclass
class UploadFilesResult:
    created_files: List[File] = field(default_factory=list)
    errors: List[Union[FileError, str]] = field(default_factory=list)

    def extend(self, other: "UploadFilesResult") -> None:
        self.created_files.extend(other.created_files)
        self.errors.extend(other.errors)

    @staticmethod
    def merge(*results: Any) -> "UploadFilesResult":
        result = UploadFilesResult()
        for r in results:
            result.extend(r)
        return result


@dataclass
class DeleteSomeFilesResult:
    errors: List[dict]
    deleted_files: List[str]
    message: str


@dataclass
class DeleteAllFilesrResult:
    count: int
    message: str
    status: str


# -----------------------------------------------------------------------------
#                               SKILLS
# -----------------------------------------------------------------------------


@dataclass
class Skill:
    uid: str
    name: str
    person_id: str
    window_size: Optional[int] = 64
    enabled: bool = True
    organization_id: Optional[str] = None
    marker_count: Optional[int] = None
    created_date: Optional[datetime] = None
    is_public: bool = False


@dataclass
class MarkerSkill:
    uid: str
    name: str
    person_id: str
    organization_id: str
    value: int
    created_date: Optional[datetime]
    person: Optional[Person]


@dataclass
class PublicSkill:
    id: str
    value: int
    count: int


@dataclass
class SetMarkerSkillResponse:
    value: int
    person_id: str
    skill_id: str


@dataclass
class MarkerSkillDataError:
    code: str
    message: str
    value: Optional[Any]
    row: int


@dataclass
class MarkerSkillUpdated:
    person: str
    skill: str
    row: int


@dataclass
class SetMarkersSkillsResponse:
    data_errors: Optional[List[MarkerSkillDataError]]
    updated_skills: List[MarkerSkillUpdated]


@dataclass
class AssignmentResultByMarker:
    id: str
    task_id: str
    project_name: str
    brief_url: str
    file_url: str
    form_url: str
    result: Dict[str, Any]
    reviewer_comment: Optional[str]
    status: str
    method_id: Optional[str] = None
    started_at: Optional[datetime] = None
    submitted_at: Optional[datetime] = None


class ReviewStatus(str, Enum):
    ACCEPTED = "ACCEPTED"
    SUBMITTED = "SUBMITTED"
    REJECTED = "REJECTED"


@dataclass
class PublicAssignmentItem:
    id: str
    task_id: str
    status: ReviewStatus
    updated_at: datetime
    reviewer_comment: Optional[str] = None
    reviewer_id: Optional[str] = None


@dataclass
class GetProjectPublicAssignmentsResponse:
    project_id: str
    project_name: str
    assignments: List[PublicAssignmentItem]


@dataclass
class ProjectsWithPublicAssignment:
    project_id: str
    project_name: str
    last_updated_at: datetime


# -----------------------------------------------------------------------------
#                               ORGANIZATIONS
# -----------------------------------------------------------------------------


@dataclass
class OrganizationConfig:
    help_center_url: Optional[str]
    marker_faq_url: Optional[str]
    price_instruction_lnk: Optional[str]


@dataclass
class OrganizationEmployee:
    first_name: str
    last_name: str
    uid: str


@dataclass
class FullOrganization:
    uid: str
    name: str
    creation_date: Optional[datetime] = None
    config: Optional[OrganizationConfig] = None
    active_employees_cnt: Optional[int] = None
    all_employees_cnt: Optional[int] = None
    employees: Optional[List[OrganizationEmployee]] = None
    is_demo: Optional[bool] = None
    contacts: Optional[str] = None


# -----------------------------------------------------------------------------
#                               ITEMS
# -----------------------------------------------------------------------------


@dataclass
class ItemStat:
    task_overlap: int
    in_progress: int
    in_review: int
    rejected: int
    accepted: int
    overlap: Optional[int] = None


@dataclass
class Item:
    stat: ItemStat


class OverlapSource(str, Enum):
    FROM_TASK = "FROM_TASK"
    USER_DEFINED = "USER_DEFINED"


@dataclass
class TaskTabItemStats:
    item_id: str
    task_overlap: int
    overlap: int
    in_progress: int
    in_review: int
    rejected: int
    accepted: int
    assigned: int
    queue: int
    overlap_source: OverlapSource


# -----------------------------------------------------------------------------
#                               TEMPLATES
# -----------------------------------------------------------------------------


@dataclass
class Template:
    uid: str
    name: str
    person_id: str
    organization_id: str
    status: str
    method_id: str
    preview_file_id: Optional[str] = ""
    description: Optional[str] = ""
    categories: Optional[List[str]] = None
    gallery_ids: Optional[List[str]] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    documentation: Optional[str] = ""
    dataset_id: Optional[str] = None
    contacts: Optional[str] = None
    projects_count: Optional[int] = 0
    access: Optional[str] = None
    acl: Optional[List[str]] = None


@dataclass
class CheckTemplateResult:
    brief: Optional[CheckResult] = None
    form: Optional[CheckResult] = None
    documentation: Optional[CheckResult] = None
    categories: Optional[CheckResult] = None
    contacts: Optional[CheckResult] = None


@dataclass
class ImageResult:
    uid: str
    file_name: str
    file_size_bytes: int


@dataclass
class SimpleImagesListResult:
    images: List[ImageResult]


@dataclass
class PreviewFileResult:
    preview_file_id: str


@dataclass
class PluginTemplateFileResult:
    template_file_id: str


# -----------------------------------------------------------------------------
#                                  VALIDATORS
# -----------------------------------------------------------------------------
@dataclass
class ValidationPipelineResult:
    status: str
    validators_total: int
    validators: List[dict]
    items_total: Optional[int] = None
    validated_file_id: Optional[str] = None
    errors_file_id: Optional[str] = None


@dataclass
class ValidationRequestItem:
    source: str
    options: Dict[str, Any] = field(default_factory=dict)


class ValidatorType(Enum):
    dataset_frontend = "dataset/frontend"
    dataset_backend = "dataset/backend"
    artifact = "artifact"
    base = "base"


@dataclass
class ValidatorDetail:
    source: str  # works as uid
    type: ValidatorType
    title: str
    enabled: bool
    stage: str
    description: str
    tags: List[str]
    options: dict


@dataclass
class ValidatorProject:
    project_id: str
    project_name: str
    project_description: str
    available_task_count: int


@dataclass
class ValidatorTask:
    task_id: str
    task_status: TaskStatus
    task_name: str
    task_type: TaskType
    task_description: str
    num_of_submitted_assignments: int
    items_completed: int
    items_total: int
    priority: int
    created_at: datetime
    author_id: Optional[str] = None
    auto_accept_threshold: Optional[float] = None
    method_id: Optional[str] = None


@dataclass
class ValidatorInfo:
    is_validator: bool


@dataclass
class AssignmentIndex:
    prev_assignment_id: Optional[str] = None
    next_assignment_id: Optional[str] = None


@dataclass
class TaskStatistics:
    assigned: int
    submitted: int
    accepted: int
    rejected: int


@dataclass
class ValidateTimeStatistic:
    created_at: datetime
    date: date
    duration_sec: int
    task_id: str
    updated_at: datetime
    validator_id: str


@dataclass
class ValidateTimeStatistics:
    items: List[ValidateTimeStatistic]
    has_next: bool


# -----------------------------------------------------------------------------
#                               LORA-MODELS
# -----------------------------------------------------------------------------
@dataclass
class Model:
    uid: str
    created_at: datetime
    name: str
    description: str
    project_id: str
    dataset_id: str
    author_id: str
    organization_id: str
    train_id: Optional[str] = None
    test_id: Optional[str] = None


@dataclass
class ModelCreateRequest:
    name: str
    description: str
    project_id: str
    dataset_id: str
    train_id: Optional[str] = None
    test_id: Optional[str] = None


# -----------------------------------------------------------------------------
#                                  ML_STORAGE
# -----------------------------------------------------------------------------


@dataclass
class OrganizationConfiguration:
    mms_business_task_id: str
    mms_model_version_id: str
    business_task_name: Optional[str] = None
    model_name: Optional[str] = None
    model_version_confidentional_category: Optional[str] = None
    organization_id: Optional[str] = None


@dataclass
class CreateOrganizationConfiguration:
    mms_business_task_id: str
    mms_model_version_id: str


@dataclass
class VerifyLoraConfiguration:
    allowed: bool
    business_task_name: Optional[str]
    model_version_confidentional_category: Optional[str]


# -----------------------------------------------------------------------------
#                               PIPELINE TASKS ADVANCED
# -----------------------------------------------------------------------------


ProjectErrors = Union[Dict[str, List[str]], DefaultDict[str, List[str]]]

TaskErrors = Dict[str, str]


@dataclass
class AdvancedTaskDataWithErrors:
    tasks: List[TaskData]
    project_errors: ProjectErrors
    task_errors: TaskErrors


# -----------------------------------------------------------------------------
#                                  RESULTS VALIDATION
# -----------------------------------------------------------------------------
@dataclass
class ValidationTaskStatus:
    algorithm: str
    status: str
    updated_at: datetime
    message: Optional[str] = None


@dataclass
class ValidationTaskResult:
    algorithm: str
    params: dict
    result_file_id: str
    created_at: datetime
    errors_file_id: Optional[str] = None
    mean_result: Optional[float] = None


@dataclass
class TaskResultsValidationInfo:
    latest_results: List[ValidationTaskResult]
    latest_statuses: List[ValidationTaskStatus]


# -----------------------------------------------------------------------------
#                                  PLUGINS MARKETPLACE
# -----------------------------------------------------------------------------


@dataclass
class PluginTemplate:
    uid: str
    name: str
    person_id: str
    organization_id: str
    access: Literal["public", "organization", "private"]
    acl: Optional[List[str]]
    status: Literal["DRAFT", "PUBLISHED", "ARCHIVED"]
    scope: Literal["SIDEBAR"]
    roles: List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]
    description: Optional[str]
    contacts: Optional[str]
    title: Optional[str]
    icon_file_id: str
    bundle_file_id: str
    preview_file_id: str
    installations_count: int
    created_at: datetime
    updated_at: datetime

    # Fields not included in the list of plugins
    documentation: Optional[str] = None
    config: Optional[dict] = None


@dataclass
class PluginAssignment:
    uid: str
    plugin_template_id: str
    organization_id: str
    roles: List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]
    enabled: bool
    route: str
    icon_file_id: str
    created_at: datetime


@dataclass
class InstalledPlugin:
    plugin_template_id: str
    plugin_assignment_id: str
    template_roles: List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]
    roles: List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]
    enabled: bool
    route: str
    name: str
    template_organization_id: str
    scope: Literal["SIDEBAR"]
    created_at: datetime
    description: str


@dataclass
class PluginInstallation:
    plugin_assignment_id: str
    organization_id: str
    organization_name: str
    roles: List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]


@dataclass
class UserPlugin:
    title: str
    route: str
    icon_file_id: str


@dataclass
class CheckPluginTemplateResult:
    bundle: Optional[CheckResult] = None
    status: Optional[CheckResult] = None
    documentation: Optional[CheckResult] = None
    description: Optional[CheckResult] = None
    contacts: Optional[CheckResult] = None
    title: Optional[CheckResult] = None


# -----------------------------------------------------------------------------
#                                    BONUSES
# -----------------------------------------------------------------------------
@dataclass
class TaskBonus:
    author_id: str
    bonus: float
    bonus_at: date
    comment: str
    id: str
    marker_id: str
    task_id: str
    average_quality: Optional[float] = None
    marked_count: Optional[int] = None
    marking_duration_secs: Optional[float] = None


@dataclass
class TaskBonuses:
    items: List[TaskBonus]
    has_next: bool


@dataclass
class AddBonusesResponse:
    failed_marker_ids: Dict[str, str] = field(default_factory=dict)


@dataclass
class MarkerStatInProject:
    marker_id: str
    total_money: float
    marking_duration_secs: int


@dataclass
class MarkerStats:
    items: List[MarkerStatInProject]


@dataclass
class TaskBonusesSummary:
    bonus_summary: float
    penalty_summary: float


# -----------------------------------------------------------------------------
#                                  DATA GALAXY
# -----------------------------------------------------------------------------


@dataclass
class DataGalaxyDatasetInfo:
    id: str
    created_at: datetime
    updated_at: datetime
    title: str
    records_count: int


@dataclass
class DataGalaxyDatasetsList:
    items: List[DataGalaxyDatasetInfo]
    next_offset: int
    total_count: int


@dataclass
class DataGalaxyDatasetData:
    dataset: DataGalaxyDatasetInfo
    data: List[Dict[str, Any]]
