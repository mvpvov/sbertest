# pylint: disable=C0302
import asyncio
import io
import itertools
import json
import logging
import shutil
import sys
import tempfile
import warnings
import zipfile
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
from functools import partial
from itertools import chain
from json.decoder import JSONDecodeError
from os import path
from pathlib import Path
from typing import (
    IO,
    Any,
    AsyncGenerator,
    Callable,
    Collection,
    Coroutine,
    Dict,
    Generator,
    Iterable,
    List,
    Literal,
    Optional,
    Sequence,
    Set,
    Tuple,
    Union,
)
from uuid import uuid4

import aiofiles
import pytz
import yaml
from aiohttp.client_exceptions import ClientConnectionError, ClientResponseError
from aiohttp.web_exceptions import HTTPForbidden
from dacite import from_dict
from tqdm import tqdm

from crowd_sdk.core.utils import autodoc
from crowd_sdk.core.utils.common import chunks, dataclass_to_dict, merge, use_semaphore
from crowd_sdk.core.utils.http_client import APIResponseError, HttpMethod, HttpWrapper
from crowd_sdk.core.utils.os import TempDir
from crowd_sdk.core.utils.table import results_as_df, tsv_load
from crowd_sdk.tagme.config import DEFAULT_CONFIG, CrowdConfig, TagmeConfig
from crowd_sdk.tagme.http_client.base_client import BATCH_SIZE, TagmeClient, row_to_task
from crowd_sdk.tagme.http_client.datacls import (
    AdvancedTaskDataWithErrors,
    AssignAssignmentRequest,
    AssignAssignmentsResult,
    AssignmentIndex,
    AssignmentResultByMarker,
    AssignMultipleAssignmentRequest,
    BriefReadStatusData,
    BriefVersionInfo,
    CheckPluginTemplateResult,
    CheckTaskResult,
    CheckTemplateResult,
    CreateOrganizationConfiguration,
    DataGalaxyDatasetData,
    DataGalaxyDatasetsList,
    DatasetType,
    ErrorMarkersResponse,
    ExampleData,
    GetProjectPublicAssignmentsResponse,
    InstalledPlugin,
    InterfaceVersionInfo,
    MethodDataRequest,
    MethodFileType,
    Model,
    ModelCreateRequest,
    OrganizationConfiguration,
    OrganizationStatistic,
    PluginAssignment,
    PluginInstallation,
    PluginTemplate,
    PluginTemplateFileResult,
    PreviewFileResult,
    ProjectErrors,
    ProjectsWithPublicAssignment,
    SimpleImagesListResult,
    TaskFilesCount,
    TaskflowTaskData,
    TaskInfo,
    TaskResultsValidationInfo,
    TaskStatistics,
    TaskStatisticsItem,
    TaskTabItemStats,
    Template,
    UserPlugin,
    ValidateTimeStatistics,
    ValidationPipelineResult,
    ValidationRequestItem,
    ValidatorDetail,
    ValidatorInfo,
    ValidatorProject,
    ValidatorTask,
    VendorChangeRecord,
    VerifyLoraConfiguration,
)
from crowd_sdk.tagme.types import (
    AddBonusesResponse,
    Assignment,
    Contacts,
    Dataset,
    DatasetFile,
    DeleteAllFilesrResult,
    DeleteSomeFilesResult,
    Employee,
    ExportFormat,
    ExportTypes,
    FileMetaData,
    FileType,
    FullOrganization,
    InviteApplication,
    InviteData,
    InviteRequest,
    Item,
    ItemQuality,
    MarkerSkill,
    MarkersStatistic,
    MarkerStats,
    MarkupMarkerStatistics,
    MarkupMarkerStatisticsSortField,
    MarkupResult,
    MarkupResults,
    MarkupResultSortField,
    MarkupReview,
    MarkupReviewResult,
    MarkupTask,
    MarkupTaskFile,
    MetaData,
    MetaType,
    MethodData,
    MethodForms,
    Organization,
    OrganizationConfig,
    Person,
    Plugin,
    PluginTypes,
    Pool,
    Project,
    ProjectStatistic,
    ProjectTaskPaginated,
    PublicSkill,
    SetMarkerSkillResponse,
    SetMarkersSkillsResponse,
    Skill,
    SortOrder,
    StatsOutputType,
    TaskBonuses,
    TaskBonusesSummary,
    TaskData,
    TaskDataRequest,
    TaskFile,
    TaskHierarchy,
    TaskQuality,
    TaskResult,
    TasksStatistic,
    TaskState,
    TaskStats,
    TaskStatsAdvanced,
    UpdateMetaDataRequest,
    UploadFilesResult,
)
from crowd_sdk.tagme.utils.datacls import PipelineInitialConfig, SyncSettings
from crowd_sdk.tagme.utils.pagination import run_with_has_next_pagination, run_with_pagination
from crowd_sdk.tagme.utils.quality import get_items_quality, get_task_quality

CrowdTagmeConfig = TagmeConfig
logger = logging.getLogger(__name__)

TASK_NAMES_TO_IGNORE_CLONING = ('Обучение', 'Экзамен')
CHUNK_SIZE = 50
DATE_PATTERN = '%Y-%m-%d'


def download_extract_zip(content: bytes) -> Generator[Tuple[str, IO], None, None]:
    with zipfile.ZipFile(io.BytesIO(content)) as thezip:
        for zipinfo in thezip.infolist():
            with thezip.open(zipinfo) as thefile:
                yield zipinfo.filename, thefile


def filter_control(marker_value: dict, control: dict) -> dict:
    """Filter fields checked in quality control"""
    if isinstance(marker_value, dict) and isinstance(control, dict):
        return {k: v for k, v in marker_value.items() if k in control}
    else:
        return marker_value


@dataclass
class ProjectConfig:
    css: str
    html: str
    javascript: str
    example: Union[ExampleData, Dict[str, Any], str]
    instruction: str
    overlap: int
    data_dir: Union[str, Path]
    pools: Sequence[str] = ()
    project_name: str = ""  # will be set in post_init from data_dir if no value specified
    config: Optional[dict] = field(default_factory=dict)
    specification: Optional[dict] = field(default_factory=dict)
    description: Optional[str] = None
    inner_comment: Optional[str] = None
    task_name: str = ""  # will be set in post_init from data_dir if no value specified
    base_path: Union[None, str, Path] = None
    control_task: Optional[Union[str, Path]] = None
    data_classification_level: Optional[str] = None
    data_source: Optional[str] = None

    def try_read_base_path(self, item: str, ext: str) -> str:
        if item.lower().endswith(ext):
            if self.base_path:
                self.base_path = Path(self.base_path)
                file_path = self.base_path / item
            else:
                file_path = Path(item)
            with open(file_path) as f:
                return f.read()
        return item

    def __post_init__(self) -> None:
        self.data_dir = Path(self.data_dir)

        if isinstance(self.example, str):
            try:
                self.example = json.loads(self.try_read_base_path(self.example, '.json'))
            except Exception as exc:
                raise ValueError(f'incorrect data in project config: {exc}') from exc

        if not isinstance(self.example, ExampleData):
            self.example = from_dict(data_class=ExampleData, data=self.example)

        self.css = self.try_read_base_path(self.css, '.css')
        self.html = self.try_read_base_path(self.html, '.html')
        self.javascript = self.try_read_base_path(self.javascript, '.js')
        self.instruction = self.try_read_base_path(self.instruction, '.txt')
        self.project_name = self.project_name or self.data_dir.name
        self.task_name = self.task_name or self.data_dir.name

    @staticmethod
    def load(configpath: Union[str, Path]) -> 'ProjectConfig':
        configpath = Path(configpath)
        with open(configpath) as f:
            config_ = yaml.safe_load(f)
        return ProjectConfig(base_path=configpath.parent, **config_)


class TagmeClientAdvanced:  # pylint: disable=too-many-public-methods
    def __init__(
        self,
        config: Union[str, Path, CrowdConfig, TagmeConfig] = DEFAULT_CONFIG,
        http: Optional[HttpWrapper] = None,
    ):
        self.client = TagmeClient(config=config, http=http)
        self.url = self.client.url

    @autodoc.section("project")
    async def get_projects_by_name(
        self,
        project_name: str,
        archived: bool = False,
        organization_id: Optional[str] = None,
        with_tasks_count: bool = False,
    ) -> List[Project]:
        """Get projects by text query.

        Args:
            project_name: project name
            archived: return archived projects. Defaults to False.
            organization_id: optional organization identifier. Defaults to None.
            with_tasks_count: return task count for project. Defaults to False.

        Returns:
            list of projects matched.
        """
        projects = await self.get_projects(
            archived=archived,
            organization_id=organization_id,
            query=project_name,
            with_tasks_count=with_tasks_count,
        )
        return [project for project in projects if project.name == project_name]

    @autodoc.section("project")
    async def get_taskflow_projects(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        only_favourite: Optional[bool] = None,
        project_id: Optional[str] = None,
    ) -> ProjectTaskPaginated:
        """Retrieves project-tasks available to the marker from the taskflow service.

        Args:
            page: pagination page. Defaults to None.
            size: pagination max size of requesting page. Defaults to None.
            query: look up project-tasks by query. Defaults to None.
            only_favourite: return only pinned projects. Defaults to None.
            project_id: return only specified project. Defaults to None.
        Returns:
            list of project-tasks matched.
        """
        return await self.client.get_taskflow_projects(
            query=query,
            page=page,
            size=size,
            only_favourite=only_favourite,
            project_id=project_id,
        )

    async def __aenter__(self) -> 'TagmeClientAdvanced':
        await self.client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.client.__aexit__(self, *args)

    @autodoc.section("project")
    # pylint: disable=too-many-arguments
    async def get_projects(
        self,
        with_tasks_count: bool = False,
        archived: Optional[bool] = False,
        with_pipeline: Optional[bool] = False,
        organization_id: Optional[str] = None,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        is_bookmarked: Optional[bool] = None,
        is_pipelined: Optional[bool] = None,
        update_date_from: Optional[str] = None,
    ) -> List[Project]:
        """Get organization projects.

        Args:
            with_tasks_count: return task count for project. Defaults to False.
            archived: return archived projects. Defaults to False.
            organization_id: optional organization identifier. Defaults to None.
            with_pipeline: return projects with pipeline config. Defaults to False.
            query: text query to search by name. Defaults to None.
            page: number of page for pagination. Defaults to None.
            is_bookmarked: return only bookmarked projects. Defaults to None.
            is_pipelined: return only pipelined projects. Defaults to None.
            update_date_from: return projects whose settings changed on or after that day

        Returns:
            list of projects matched.
        """
        return await run_with_pagination(
            func=self.client.get_projects,
            with_tasks_count=with_tasks_count,
            archived=archived,
            organization_id=organization_id,
            with_pipeline=with_pipeline,
            query=query,
            is_bookmarked=is_bookmarked,
            is_pipelined=is_pipelined,
            update_date_from=update_date_from,
            page=page,
            size=size,
        )

    @autodoc.section("project")
    async def get_project_results(
        self,
        project_name: str,
        task_name: str,
        is_archived: Optional[bool] = None,
        organization_id: Optional[str] = None,
    ) -> List[TaskResult]:
        """Get results for task matched by name.

        Args:
            project_name: name of project to get results from.
            task_name: name of project's task to get results from.
            is_archived: search in archived projects. Defaults to None.

        Returns:
            list of task results.
        """
        # Get project_id
        projects = await self.get_projects(
            archived=is_archived, query=f'{project_name}', organization_id=organization_id
        )
        # TODO: [TAGME-3565] fix set of result. You can have 1 or more pools with same names.
        # We always need the last one.
        # projects_id = {project.uid for project in projects if project.name == project_name}

        # For each project looking for pool_name we need
        task_id = ''
        for project in projects:
            # Get task_id
            get_tasks_resp = await self.get_tasks(project_id=project.uid, organization_id=organization_id)
            for task in get_tasks_resp:
                if task.name == task_name:
                    task_id = task.uid
                    break

        # Get task markup result
        get_task_resp = await self.client.get_task_results(task_id=task_id, organization_id=organization_id)

        return get_task_resp

    @autodoc.section("project")
    async def create_project(
        self,
        name: str,
        description: Optional[str] = None,
        organization_id: Optional[str] = None,
        inner_comment: Optional[str] = None,
        template_id: Optional[str] = None,
        is_brief_autoupdate: Optional[bool] = None,
        is_forms_autoupdate: Optional[bool] = None,
        is_config_autoupdate: Optional[bool] = None,
        is_specification_autoupdate: Optional[bool] = None,
    ) -> Project:
        """Create new project.

        Args:
            name: name of new project.
            description: project's description.
            organization_id: optional organization identifier. Defaults to None.
            inner_comment: inner comment for customers. Defaults to None.
            template_id: template id for project. Defaults to None.
            is_brief_autoupdate: whether to enable brief autoupdate. Defaults to None.
            is_forms_autoupdate: whether to enable forms autoupdate. Defaults to None.
            is_config_autoupdate: whether to enable config autoupdate. Defaults to None.
            is_specification_autoupdate: whether to enable specification autoupdate. Defaults to None.

        Returns:
            created project.
        """
        return await self.client.create_project(
            name=name,
            description=description,
            organization_id=organization_id,
            inner_comment=inner_comment,
            template_id=template_id,
            is_brief_autoupdate=is_brief_autoupdate,
            is_forms_autoupdate=is_forms_autoupdate,
            is_config_autoupdate=is_config_autoupdate,
            is_specification_autoupdate=is_specification_autoupdate,
        )

    @autodoc.section("project")
    async def update_project(  # pylint: disable=R0913
        self,
        project_id: str,
        name: Optional[str] = None,
        organization_id: Optional[str] = None,
        description: Optional[str] = None,
        inner_comment: Optional[str] = None,
        pipeline: Optional[Union[SyncSettings, dict]] = None,
        is_pipeline_enabled: Optional[bool] = None,
        is_brief_autoupdate: Optional[bool] = None,
        is_forms_autoupdate: Optional[bool] = None,
        is_config_autoupdate: Optional[bool] = None,
        is_specification_autoupdate: Optional[bool] = None,
        pipeline_errors: Optional[str] = None,
    ) -> Project:
        """Update project info.

        Args:
            project_id: id of project to update.
            name: new name of project.
            organization_id: optional organization identifier. Defaults to None.
            description: new description of project. Defaults to None.
            inner_comment: new inner comment for customers. Defaults to None.
            pipeline: new pipeline settings. Defaults to None.
            is_pipeline_enabled: whether to enable pipeline. Defaults to None.
            is_brief_autoupdate: whether to enable brief autoupdate. Defaults to None.
            is_forms_autoupdate: whether to enable forms autoupdate. Defaults to None.
            is_config_autoupdate: whether to enable config autoupdate. Defaults to None.
            is_specification_autoupdate: whether to enable specification autoupdate. Defaults to None.

        Returns:
            updated project.
        """
        return await self.client.update_project(
            project_id=project_id,
            name=name,
            description=description,
            organization_id=organization_id,
            inner_comment=inner_comment,
            pipeline=pipeline,
            is_pipeline_enabled=is_pipeline_enabled,
            is_brief_autoupdate=is_brief_autoupdate,
            is_forms_autoupdate=is_forms_autoupdate,
            is_config_autoupdate=is_config_autoupdate,
            is_specification_autoupdate=is_specification_autoupdate,
            pipeline_errors=pipeline_errors,
        )

    @autodoc.section("project")
    async def update_project_errors(
        self,
        project_id: str,
        organization_id: str,
        need_to_stop_pipeline: bool = True,
        pipeline_errors: Optional[str] = None,
    ) -> None:
        """Update markup project's pipeline_errors field

        Args:
            project_id: Id of project, that is updated.
            pipeline_errors: value of error or None.
        """
        return await self.client.update_project_errors(
            project_id=project_id,
            pipeline_errors=pipeline_errors,
            organization_id=organization_id,
            need_to_stop_pipeline=need_to_stop_pipeline,
        )

    @autodoc.section("project")
    async def create_project_by_config(self, config: ProjectConfig, organization_id: Optional[str] = None) -> str:
        """Create new project.

        Args:
            config: full project data.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            created project id.
        """
        config.data_dir = Path(config.data_dir)
        project_name = config.project_name or config.data_dir.name

        # Create project
        create_project_resp = await self.create_project(
            name=project_name,
            organization_id=organization_id,
            description=(config.description or ''),
            inner_comment=config.inner_comment,
        )
        project_id = create_project_resp.uid
        logger.info('project_id = %s', project_id)

        await self.__update_project_methodic(config, create_project_resp.method_id)
        return project_id

    @autodoc.section("project")
    async def create_project_bookmark(
        self,
        project_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        """Add project to bookmarks.

        Args:
            project_id: project id to add bookmark.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.create_project_bookmark(project_id, organization_id)

    @autodoc.section("project")
    async def delete_project_bookmark(
        self,
        project_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        """Remove project from bookmarks.

        Args:
            project_id: project id to remove bookmark.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.delete_project_bookmark(project_id, organization_id)

    async def __update_project_methodic(
        self, config: ProjectConfig, method_id: str, organization_id: Optional[str] = None
    ) -> MethodData:
        if isinstance(config.example, ExampleData):
            example = dataclass_to_dict(config.example)
        elif isinstance(config.example, dict):
            example = config.example
        else:
            raise RuntimeError(f'config.data has not compatible type {type(config.example)}')

        method_data = MethodData(
            uid=method_id,
            name=config.task_name or 'test method',
            forms=MethodForms(
                html=config.html,
                css=config.css,
                js=config.javascript,
                config=config.config or {},
                specification=config.specification or {},
                example=example,
            ),
            marker_brief=config.instruction,
        )
        return await self.update_method(method=method_data, organization_id=organization_id)

    @autodoc.section("project")
    async def get_project_contacts(
        self,
        project_id: str,
        organization_id: Optional[str] = None,
    ) -> Contacts:
        """Get project or organization contacts.

        Args:
            project_id: project id.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.get_contacts(project_id, organization_id)

    @autodoc.section("task")
    async def create_project_and_task(
        self, config: ProjectConfig, start_task: bool = True, organization_id: Optional[str] = None
    ) -> Tuple[str, TaskData]:
        """(deprecated) Create project and task for it.
        Use 'create_task' and 'create_project' or 'create_project_by_config' instead.

        Args:
            config: full project data.
            start_task: start task after its creation. Defaults to True.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            project_id and created task.
        """
        warnings.warn(
            "Method 'create_project_and_task' is deprecated and will be removed soon. "
            "Use 'create_task' and 'create_project' or 'create_project_by_config' instead.",
            DeprecationWarning,
        )
        project_id = await self.create_project_by_config(config, organization_id=organization_id)
        config.data_dir = Path(config.data_dir)
        task_name = config.task_name or config.data_dir.name
        return project_id, await self.create_and_start_task(config, project_id, task_name, start_task=start_task)

    @autodoc.section("task")
    async def create_task_in_project(
        self,
        config: ProjectConfig,
        project_id: str,
        task_name: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> TaskData:
        """(deprecated) Create task inside project.
        Use 'create_task' instead.

        Args:
            config: data to create task.
            project_id: project id to add task to.
            task_name: name of task to create. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            created task.
        """
        organization_id = organization_id or await self.client.get_current_organization_id()
        warnings.warn(
            "Method 'create_task_in_project' is deprecated and will be removed soon. Use 'create_task' instead.",
            DeprecationWarning,
        )
        config.data_dir = Path(config.data_dir)
        task = TaskDataRequest(
            name=task_name or config.task_name or config.data_dir.name,
            organization_id=organization_id,
            project_id=project_id,
            description=config.description or '',
            overlap=config.overlap,
            data_classification_level=config.data_classification_level,
            data_source=config.data_source,
        )
        task_data = await self.client.create_task(task=task, organization_id=organization_id)
        return task_data

    @autodoc.section("task")
    async def create_and_start_task(
        self,
        config: ProjectConfig,
        project_id: str,
        task_name: Optional[str] = None,
        start_task: bool = True,
        organization_id: Optional[str] = None,
    ) -> TaskData:
        """(deprecated) Create task inside project and start it.
        Use separate methods instead.

        Args:
            config: data to create task.
            project_id: project id to add task.
            task_name: name of task to create. Defaults to None.
            start_task: start task after its creation. Defaults to True.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            created task.
        """
        warnings.warn(
            "Method 'create_and_start_task' is deprecated and will be removed soon. Use separate methods instead.",
            DeprecationWarning,
        )
        task = await self.create_task_in_project(config, project_id, task_name, organization_id=organization_id)
        logger.info('task_id = %s', task.uid)

        result = await self.upload_folder(task=task, folder=config.data_dir, organization_id=organization_id)
        if not result.created_files and not result.errors:
            raise ValueError('Upload failed: dir is empty')
        if len(result.errors) > len(result.created_files):
            raise ValueError(f'Upload failed: got a lot of exceptions: {result.errors}')
        if config.control_task is not None and Path(config.control_task).exists():
            with open(config.control_task) as f:
                metadata = json.load(f)
            await self.update_meta_data(task_id=task.uid, data=metadata, organization_id=organization_id)
        await self.add_pools(project_id=project_id, pools=config.pools, organization_id=organization_id)
        if start_task:
            await self.start_task(task.uid, organization_id=organization_id)
        return task

    @autodoc.section("task")
    async def create_task(
        self, task: Union[TaskDataRequest, TaskData, dict], organization_id: Optional[str] = None
    ) -> TaskData:
        """Create new task.

        Args:
            task: new task's data.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            created task.
        """
        return await self.client.create_task(task=task, organization_id=organization_id)

    @autodoc.section("task")
    async def duplicate_task(
        self,
        original_task: Union[TaskData, dict],
        task: dict = None,
        organization_id: Optional[str] = None,
    ) -> TaskData:
        """Create duplicate of task.

        Args:
            original_task: original task.
            task: new task data, different from the original task data.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            created task.
        """
        return await self.client.duplicate_task(task=task, original_task=original_task, organization_id=organization_id)

    @autodoc.section("task")
    async def update_task(self, task: Union[TaskData, dict], organization_id: Optional[str] = None) -> TaskData:
        """Update task.

        Args:
            task: new task's data.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            updated task.
        """
        return await self.client.update_task(task=task, organization_id=organization_id)

    @autodoc.section("task")
    async def upload_folder_pdf(
        self,
        task_id: str,
        folder: Union[str, Path],
        cloud_client: Optional[Any] = None,
        exclude_ext_filter: Optional[Set[str]] = None,
        organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
    ) -> UploadFilesResult:
        """Upload folder with pdf-files.
        Transforms pdf-files into png images before uploading.

        Args:
            task_id: task id to upload files to.
            folder: folder with pdf files.
            cloud_client: cloud client used to upload files.
            exclude_ext_filter: skip files of given extension. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            uploaded files and errors.
        """
        try:
            import fitz  # pylint: disable=C0415
        except ModuleNotFoundError:
            logging.error('Couldn\'t run upload_pdf without pymupdf module\nInstall:\npip install pymupdf==1.19.2\n')
            sys.exit(1)
        assert fitz.version[0] >= '1.19.2', 'pymupdf >= 1.19.2 required. Install: pip install pymupdf==1.19.2'

        folder = Path(folder)

        with TempDir() as task_data_dir:
            with TempDir() as images_dir:
                for file_path in folder.iterdir():
                    if not file_path.is_file():
                        continue
                    if exclude_ext_filter is not None and file_path.suffix in exclude_ext_filter:
                        continue

                    task_data: Dict[str, Any] = {"pages": []}

                    page_numbers = {}
                    filename = file_path.stem
                    logging.info(f'Splitting pdf {file_path} on to files')

                    imagepaths = []
                    doc = fitz.open(file_path)
                    for page_number, page in enumerate(doc, 1):
                        page_img_path = str(Path(images_dir) / (f'{filename}_{page_number}.png'))
                        pix = page.get_pixmap(dpi=300)
                        pix.save(page_img_path)
                        imagepaths.append(page_img_path)
                        page_numbers[f'{filename}_{page_number}.png'] = page_number

                    logger.debug(f'Uploading images {imagepaths}')

                    if cloud_client is None:
                        dataset = await self.create_dataset(f'pdf-{task_id}', organization_id=organization_id)
                        dataset_upload_result = await self.upload_dataset_files(
                            dataset.id, imagepaths, organization_id=organization_id, tqdm_on=tqdm_on
                        )
                        logger.info(
                            f'Succesfully uploaded {len(dataset_upload_result.created_files)}'
                            f' out of {len(imagepaths)} files'
                        )
                        dataset_files = await self.get_dataset_files(dataset.id, organization_id)
                        for item in dataset_files:
                            task_data['pages'].append(
                                {
                                    'page_number': page_numbers[item.name],
                                    'url': item.url,
                                }
                            )
                    else:
                        upload_results = cloud_client.upload_publish_validate(
                            src=imagepaths, bucket='tagme', dst=f'pdf/{task_id}', tqdm_off=True
                        )
                        for fname, new_url, status in upload_results:
                            assert status, f'File upload failed {fname}'
                            task_data['pages'].append(
                                {
                                    'page_number': page_numbers[fname],
                                    'url': new_url,
                                }
                            )
                    task_data['pages'] = sorted(task_data['pages'], key=lambda x: x['page_number'])

                    filepath = Path(task_data_dir) / (filename + '.json')
                    with open(filepath, 'w') as task_file:
                        json.dump(task_data, task_file, ensure_ascii=False, indent=2)

                return await self.upload_folder_to_task(
                    task_id, task_data_dir, organization_id=organization_id, tqdm_on=tqdm_on
                )

    @autodoc.section("files")
    async def upload_folder(
        self,
        task: TaskData,
        folder: Union[str, Path],
        organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
    ) -> UploadFilesResult:
        """Upload all files from folder to task.

        Args:
            task: task to upload files to.
            folder: folder with files to upload to task.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            uploaded files and errors.
        """
        while True:
            try:
                # Upload to bucket
                return await self.upload_folder_to_task(
                    task_id=task.uid,
                    folder=folder,
                    organization_id=organization_id,
                    tqdm_on=tqdm_on,
                )
            except (ClientResponseError, ClientConnectionError) as exc:
                # Retry connection
                # Delete uploaded files from task
                await self.delete_items_from_task(task.uid)
                raise RuntimeError('Failed to upload') from exc

    @autodoc.section("files")
    async def upload_table(
        self,
        task_id: str,
        file: Path,
        delimeter: Optional[str] = None,
        quotechar: Optional[str] = None,
        escapechar: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        """Upload task data table.
        See more information at https://tagme.sberdevices.ru/docs/customer/uploading-data.html

        Args:
            task_id: task id to upload table to.
            file: path to table to upload (.csv,.tsv,.xlsx).
            delimeter: table delimiter.
            quotechar: table quotechar.
            escapechar: table escapechar.
            organization_id: optional organization identifier. Defaults to None.
        """
        await self.client.upload_table(
            task_id=task_id,
            file=file,
            delimeter=delimeter,
            quotechar=quotechar,
            escapechar=escapechar,
            organization_id=organization_id,
        )
        await self.client.wait_until_sdct_done(task_id=task_id, organization_id=organization_id)

    @autodoc.section("pool")
    async def add_pools(self, project_id: str, pools: Sequence[str], organization_id: Optional[str] = None) -> None:
        """Add pools of users to project.

        Args:
            project_id: project id to add pools to
            pools: pools ids to add to project
            organization_id: optional organization identifier. Defaults to None.
        """
        for pool in pools:
            await self.add_users_to_project(project_id=project_id, pool_id=pool, organization_id=organization_id)

    @autodoc.section("pool")
    async def set_marker_priority(
        self, marker_id: str, pool_id: str, priority: int, organization_id: Optional[str] = None
    ) -> None:
        """Set priority of marker in pool.

        Args:
            marker_id: marker id to set priority.
            pool_id: pool id to set priority.
            priority: priority to set.
            organization_id: optional organization identifier. Defaults to None.
        """

        await self.client.update_marker_in_pool(
            marker_id=marker_id,
            pool_id=pool_id,
            data={
                "priority": priority,
            },
            organization_id=organization_id,
        )

    @autodoc.section("project")
    async def archive_project(self, project_name: str, organization_id: Optional[str] = None) -> None:
        """(deprecated) Archive all projects with given name.
        Use 'archive_project_by_name' instead.

        Args:
            project_name: name of projects to archive.
            organization_id: optional organization identifier. Defaults to None.
        """
        warnings.warn(
            "Method 'archive_project' is deprecated and will be removed soon. "
            "Use 'archive_project_by_name' instead.",
            DeprecationWarning,
        )
        return await self.archive_project_by_name(project_name=project_name, organization_id=organization_id)

    @autodoc.section("project")
    async def archive_project_by_name(
        self,
        project_name: str,
        organization_id: Optional[str] = None,
        raise_when_not_found: bool = True,
    ) -> None:
        """Archive all projects with given name.

        Args:
            project_name: name of projects to archive.
            organization_id: optional organization identifier. Defaults to None.
            raise_when_not_found: raise exception if no project with given name found. Defaults to True.
        """
        logger.info('Archiving projects with name %s', project_name)

        # Get project_id
        get_project_resp = await self.get_projects(query=f'{project_name}', organization_id=organization_id)
        projects_id = []
        for project in get_project_resp:
            if project.name == project_name:
                project_id = project.uid
                projects_id.append(project_id)

        if not projects_id:
            if raise_when_not_found:
                raise RuntimeError(f"ERROR: No projects were found by name '{project_name}'")
            return

        await self.client.archive_projects(projects_id)

        logger.info('Projects_id %s was archived.', ', '.join(projects_id))

    @autodoc.section("results")
    async def get_task_results(self, task_id: str, organization_id: Optional[str] = None) -> List[TaskResult]:
        """(deprecated) Get markup result for task.
        Use 'get_task_assignments' instead.

        Args:
            task_id: task id to get results for.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of task assignments' results.
        """
        warnings.warn("get_task_results is deprecated, use 'get_task_assignments' instead", DeprecationWarning)
        return await self.client.get_task_results(task_id=task_id, organization_id=organization_id)

    @staticmethod
    @autodoc.exclude
    def iterate_item_rows(item_data: TaskResult) -> Generator[Assignment, None, None]:
        for user_id, assignment_data in (item_data.result or {}).items():
            yield Assignment.from_assignment_data(user_id, item_data, assignment_data, "ACCEPTED")
        for user_id, assignment_data in (item_data.skip or {}).items():
            yield Assignment.from_assignment_data(user_id, item_data, assignment_data, "SKIPPED")

    @autodoc.section("results")
    async def get_task_results_flat(
        self, task_id: str, join_markers: bool = False, organization_id: Optional[str] = None
    ) -> List[Assignment]:
        """(deprecated) Get markup result for task in new format.
        Use 'get_task_assignments' instead.

        Args:
            task_id: task_id to get results for.
            join_markers: add markers' emails to result. Defaults to False
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of task assignments' results.
        """
        warnings.warn("get_task_results is deprecated, use 'get_task_assignments' instead", DeprecationWarning)
        task_results = await self.client.get_task_results(task_id=task_id, organization_id=organization_id)
        marker_info_dict: Dict[str, Dict[str, Any]] = {}
        if join_markers:
            markers = await self.get_employees(with_info=True, organization_id=organization_id)
            marker_info_dict = {marker.person_id: asdict(marker.person) for marker in markers}

        results = []
        for item_data in task_results:
            for event_item in self.iterate_item_rows(item_data):
                marker = marker_info_dict.get(event_item.marker_id)
                if marker:
                    event_item.email = marker.get('email')
                results.append(event_item)
        return results

    @autodoc.section("results")
    async def get_task_src_flat(self, task_id: str, organization_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get rows of task data.
        Contains file data:

            - hints (HINT:<field name>)

            - premarkup (GOLDEN:<field name>)

            - premarkup (PREMARKUP:<field name>)

            - input data (INPUT:<field name>)

        Args:
            task_id: task id to get data from.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of rows with task data.
        """
        task = await self.client.get_task(task_id=task_id, organization_id=organization_id)
        task_files = await self.get_task_files(task_id=task.uid, organization_id=organization_id)

        result = []

        for item in task_files:
            row = {
                'enabled': item.enabled,
                'file_type': item.file_type.value,
                'name': item.name,
                'size': item.size,
                'content_type': item.content_type,
            }

            # decompose metadata:
            if item.metadata:
                metadata = await self.get_meta_data(
                    task_id=task_id, file_uid=item.uid, types=item.metadata, organization_id=organization_id
                )

                if metadata.explanation:
                    row['HINT'] = metadata.explanation

                if metadata.premarkup:
                    for k, v in metadata.premarkup.items():
                        row[f'PREMARKUP:{k}'] = v

                if metadata.control:
                    for k, v in metadata.control.items():
                        row[f'GOLDEN:{k}'] = v

            # decompose file content:
            try:
                bytes_file = await self.client.download_file(
                    task_id=task.uid,
                    file_id=item.uid,
                    organization_id=organization_id,
                )
                data = json.loads(bytes_file.decode('utf-8'))
                for k, v in data.items():
                    row[f'INPUT:{k}'] = v
            except JSONDecodeError:
                pass

            result.append(row)

        return result

    @staticmethod
    @autodoc.exclude
    def to_msk_date(d: Optional[str]) -> Optional[date]:
        if not d:
            return None
        return datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=pytz.timezone('Europe/Moscow')).date()

    @staticmethod
    @autodoc.exclude
    def check_dates(x: date, a: Optional[date], b: Optional[date]) -> bool:
        return (not a or a <= x) and (not b or x <= b)

    @autodoc.section("results")
    async def get_task_assignments_df(  # pylint: disable=R0913
        self,
        task_id: str,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        updated_date_from: Optional[str] = None,
        updated_date_to: Optional[str] = None,
        marker_ids: Optional[str] = None,
        item_types: Optional[List[Literal["data", "control", "study"]]] = None,
        statuses: Optional[List[Literal["ACCEPTED", "REJECTED", "EXPIRED", "SKIPPED", "SUBMITTED"]]] = None,
        consistency: Optional[float] = None,
        consistency_filter: Optional[Literal["lte", "gte", "gt", "lt", "eq"]] = None,
        with_input_data: bool = False,
        organization_id: Optional[str] = None,
        msk_time: bool = True,
        with_assignment_link: bool = False,
    ) -> Any:
        """Get pandas.DataFrame which contains task assignments.

        Args:
            task_id: task id to get assignments for.
            date_from: minimal date of assignment completion. Defaults to None.
            date_to: maximal date of assignment completion. Defaults to None.
            with_input_data: add input fields to result. Defaults to False.
            organization_id: optional organization identifier. Defaults to None.
            msk_time: use MSK time for date_from and date_to filter. Defaults to True.
            updated_date_from: begin date of updating asignment to filter by. Defaults to None.
            updated_date_to: end date of updating asignment to filter by. Defaults to None.
            item_types: list of file types to filter by. Defaults to None.
            statuses: list of statuses to filter by. Defaults to None.
            marker_ids: List of marker_ids to filter by. Defaults to None.
            consistency: consistency trashhold. Defaults to None.
            consistency_filter: ccomparison operators for consistency filtering. Defaults to None.

        Returns:
            pandas.DataFrame with task assignments.
        """
        assignments_results = await self.get_task_assignments(
            task_id=task_id,
            with_input_data=with_input_data,
            date_from=date_from,
            date_to=date_to,
            updated_date_from=updated_date_from,
            updated_date_to=updated_date_to,
            marker_ids=marker_ids,
            item_types=item_types,
            statuses=statuses,
            consistency=consistency,
            consistency_filter=consistency_filter,
            organization_id=organization_id,
            msk_time=msk_time,
            with_assignment_link=with_assignment_link,
        )
        results = [asdict(result) for result in assignments_results]

        return results_as_df(results)

    @autodoc.section("results")
    async def get_task_assignments(  # pylint: disable=R0912,R0913
        self,
        task_id: str,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        updated_date_from: Optional[str] = None,
        updated_date_to: Optional[str] = None,
        with_input_data: bool = False,
        join_markers: bool = False,
        control_only: bool = False,
        organization_id: Optional[str] = None,
        msk_time: bool = True,
        tqdm_on: bool = False,
        with_assignment_link: bool = False,
        marker_ids: Optional[str] = None,
        item_types: Optional[List[Literal["data", "control", "study"]]] = None,
        statuses: Optional[List[Literal["ACCEPTED", "REJECTED", "EXPIRED", "SKIPPED", "SUBMITTED"]]] = None,
        consistency: Optional[float] = None,
        consistency_filter: Optional[Literal["lte", "gte", "gt", "lt", "eq"]] = None,
    ) -> List[Assignment]:
        """Get list of task assignments.

        Args:
            task_id: task id to get assignments for.
            date_from: minimal date of assignment completion. Defaults to None.
            date_to: maximal date of assignment completion. Defaults to None.
            with_input_data: add input fields to result. Defaults to False.
            join_markers: add markers' emails to result. Defaults to False.
            control_only: return only control tasks. Defaults to False.
            organization_id: optional organization identifier. Defaults to None.
            msk_time: use MSK time for date_from and date_to filter. Defaults to True.
            tqdm_on: show progress bar while downloading results. Defaults to False.
            updated_date_from: begin date of updating asignment to filter by. Defaults to None.
            updated_date_to: end date of updating asignment to filter by. Defaults to None.
            item_types: list of file types to filter by. Defaults to None.
            statuses: list of statuses to filter by. Defaults to None.
            marker_ids: List of marker_ids to filter by. Defaults to None.
            consistency: consistency trashhold. Defaults to None.
            consistency_filter: ccomparison operators for consistency filtering. Defaults to None.

        Returns:
            list of assignments for task.
        """
        if msk_time:
            date_from_date = self.to_msk_date(date_from)
            date_to_date = self.to_msk_date(date_to)
            updated_date_from_date = self.to_msk_date(updated_date_from)
            updated_date_to_date = self.to_msk_date(updated_date_to)
            if date_from:
                date_from = (datetime.strptime(date_from, "%Y-%m-%d") - timedelta(days=1)).strftime(DATE_PATTERN)

            assignments = []
            for a in await self.client.get_task_assignments(
                task_id=task_id,
                date_from=date_from,
                date_to=date_to,
                updated_date_from=updated_date_from,
                updated_date_to=updated_date_to,
                organization_id=organization_id,
                marker_ids=marker_ids,
                item_types=item_types,
                statuses=statuses,
                consistency=consistency,
                consistency_filter=consistency_filter,
            ):
                dates_ok = a.updated_date is None or self.check_dates(
                    a.updated_date.date(), updated_date_from_date, updated_date_to_date
                )

                assert a.end_date
                if dates_ok and self.check_dates(a.end_date.date(), date_from_date, date_to_date):
                    assignments.append(a)
        else:
            assignments = await self.client.get_task_assignments(
                task_id=task_id,
                date_from=date_from,
                date_to=date_to,
                updated_date_from=updated_date_from,
                updated_date_to=updated_date_to,
                organization_id=organization_id,
                marker_ids=marker_ids,
                item_types=item_types,
                statuses=statuses,
                consistency=consistency,
                consistency_filter=consistency_filter,
            )

        if with_assignment_link:
            for assignment in assignments:
                if assignment.assignment_id is not None:
                    assignment.assignment_link = await self.gen_assignment_url(
                        assignment_id=assignment.assignment_id,
                        organization_id=organization_id,
                    )

        if with_input_data:
            files: Dict[str, TaskFile] = {}
            file_datas: Dict[str, dict] = {}
            with tqdm(
                total=len(assignments), desc='Downloading task files' if tqdm_on else None, disable=not tqdm_on
            ) as pbar:
                for assignment in assignments:
                    if control_only and assignment.control is None:
                        continue
                    if assignment.item_id in files:
                        file = files[assignment.item_id]
                    else:
                        file = await self.get_file(
                            task_id=task_id, file_uid=assignment.item_id, organization_id=organization_id
                        )
                        files[assignment.item_id] = file

                    if assignment.item_id in file_datas:
                        file_data = file_datas[assignment.item_id]
                    else:
                        file_data = json.loads(
                            await self.download_file(
                                task_id=task_id, file_id=assignment.item_id, organization_id=organization_id
                            )
                        )
                        file_datas[assignment.item_id] = file_data

                    assignment.enabled = file.enabled
                    assignment.input_data = file_data
                    pbar.update(1)

        if join_markers:
            markers = await self.get_employees(with_info=True, organization_id=organization_id)
            marker_info_dict = {marker.person_id: asdict(marker.person) for marker in markers}

            for assignment in assignments:
                marker = marker_info_dict.get(assignment.marker_id)
                if marker:
                    assignment.email = marker.get('email')

        return assignments

    @autodoc.section("other")
    async def get_bad_control_items(
        self,
        task: TaskData,
        rate_threshold: float = 0.5,
        count_threshold: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Get control items with low good answers ratio.

        Args:
            task: task to get bad control items from.
            rate_threshold: lowest accepted rate of good answers. Defaults to 0.5.
            count_threshold: lowest accepted number of of good answers. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            rows which contain bad control tasks info.
        """
        if not count_threshold:
            count_threshold = task.overlap
        assignments: List[Assignment] = await self.get_task_assignments(
            task_id=task.uid, with_input_data=True, control_only=True, organization_id=organization_id
        )

        result: List[Dict[str, Any]] = []
        for item_id, item_assignments_grouper in itertools.groupby(
            sorted(assignments, key=lambda x: x.item_id), key=lambda x: x.item_id
        ):
            item_assignments = list(item_assignments_grouper)
            if not item_assignments[0].enabled:
                continue

            enabled = item_assignments[0].enabled
            control = item_assignments[0].control
            input_data = item_assignments[0].input_data

            correct_answers = 0
            vals = []
            for assignment in item_assignments:
                if assignment.control_passed:
                    correct_answers += 1
                    vals.append(f'{(assignment.control_passed, assignment.control)}')
                elif assignment.control_passed is False:
                    checked_data = filter_control(assignment.result or {}, assignment.control or {})
                    vals.append(f'{(assignment.control_passed, checked_data)}')

            if len(vals) < count_threshold or not vals:
                continue

            correct_rate = correct_answers / (len(vals))
            if correct_rate > rate_threshold:
                continue

            result.append(
                {
                    'item_id': item_id,
                    'control': control,
                    'user_answers': Counter(vals),
                    'count': len(vals),
                    'input_data': input_data,
                    'rate': correct_rate,
                    'enabled': enabled,
                }
            )

        return result

    @autodoc.section("pool")
    async def clone_pool(
        self,
        pool_id: str,
        organization_id: Optional[str] = None,
        dst_organization_id: Optional[str] = None,
    ) -> Pool:
        """Clone pool with members.

        Args:
            pool_id: pool id to clone.
            organization_id: optional organization identifier. Defaults to None.
            dst_organization_id: optional organization id to clone pool to. Defaults to None.

        Returns:
            created pool.
        """
        if dst_organization_id is None:
            dst_organization_id = organization_id
        pool = await self.get_pool(pool_id=pool_id, with_markers=True, organization_id=organization_id)
        if dst_organization_id is not None and organization_id != dst_organization_id:
            for member in pool.members:
                person = await self.get_person(
                    person_id=member.person.uid,
                    with_organizations=True,
                    organization_id=organization_id,
                )
                try:
                    await self.get_person(person_id=member.person.uid, organization_id=dst_organization_id)
                except AssertionError:
                    roles = person.get_roles(pool.organization_id) if pool.organization_id is not None else None
                    await self.client.add_employee_to_organization(
                        person_id=member.person.uid,
                        organization_id=dst_organization_id,
                        roles=roles if roles is not None else [],
                    )
        marker_ids = [member.person.uid for member in pool.members]
        pool_name = pool.name if dst_organization_id != organization_id else pool.name + ' (копия)'
        return await self.create_pool(markers=marker_ids, name=pool_name, organization_id=dst_organization_id)

    @autodoc.section("project")
    async def get_project_task(
        self,
        project_id: str,
        ignore_tasks: Tuple[str, ...] = TASK_NAMES_TO_IGNORE_CLONING,
        organization_id: Optional[str] = None,
    ) -> TaskData:  # pylint: disable = R0915
        """(deprecated) Get first task for project.
        Use 'get_project_tasks' instead.

        Args:
            project_id: project id to get task from.
            ignore_tasks: names of tasks to ignore. Defaults to ('Обучение', 'Экзамен').
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            found task.
        """
        for task in await self.get_tasks(project_id=project_id, organization_id=organization_id):
            if task.name not in ignore_tasks:
                return task
        raise ValueError(f'Task for {project_id} not found')

    @autodoc.section("project")
    async def get_project_tasks(
        self,
        project_id: str,
        ignore_tasks: Tuple[str, ...] = TASK_NAMES_TO_IGNORE_CLONING,
        organization_id: Optional[str] = None,
    ) -> List[TaskData]:
        """Get tasks for project.

        Args:
            project_id: project id to get tasks from.
            ignore_tasks: names of tasks to ignore. Defaults to ('Обучение', 'Экзамен').
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            found tasks.
        """
        result: List[TaskData] = []
        for task in await self.get_tasks(project_id=project_id, organization_id=organization_id):
            if task.name not in ignore_tasks:
                result.append(task)
        return result

    @autodoc.section("project")
    async def clone_project(
        self,
        project_id: str,
        organization_id: Optional[str] = None,
        dst_organization_id: Optional[str] = None,
        name_suffix: Optional[str] = None,
        clone_task_payloads: bool = False,
    ) -> Tuple[List[Tuple[TaskData, TaskData]], Project]:  # pylint: disable = R0915
        """Clone project with all its tasks and users.

        Args:
            project_id: project id to clone.
            organization_id: optional organization identifier. Defaults to None.
            dst_organization_id: optional organization identifier to clone project to. Defaults to None.

        Returns:
            list of pairs of old tasks and new tasks, new project.
        """
        # old project
        logger.info('Acquiring old project data')
        project = await self.client.get_project(project_id=project_id, organization_id=organization_id)
        tasks = await self.get_project_tasks(project_id=project_id, organization_id=organization_id, ignore_tasks=())
        if clone_task_payloads:
            semaphore = asyncio.Semaphore(10)
            for tasks_ in chunks(tasks, CHUNK_SIZE):
                await asyncio.gather(*(use_semaphore(self.load_task_payload(t), semaphore) for t in tasks_))

        method = await self.get_method(
            method_id=project.method_id, organization_id=organization_id, download_brief=True
        )
        logger.info('Old project data acquired')

        if dst_organization_id is None:
            dst_organization_id = organization_id

        #  new project
        logger.info('Started duplication process')
        new_name = project.name if name_suffix is None else f'{project.name}{name_suffix}'
        new_project = await self.client.create_project(
            organization_id=dst_organization_id,
            name=new_name,
            description='Дубль с незавершенными задачами',
            inner_comment=project.inner_comment,
        )
        logger.info('New project "%s" created', new_project.name)

        new_method = MethodData(
            uid=new_project.method_id,
            name=method.name,
            forms=MethodForms(
                html=method.forms.html,  # type: ignore
                css=method.forms.css,  # type: ignore
                js=method.forms.js,  # type: ignore
                example=method.forms.example,  # type: ignore
                config=method.forms.config,  # type: ignore
            ),
            marker_brief=method.marker_brief,
        )
        await self.update_method(new_method, organization_id=dst_organization_id)

        if organization_id == dst_organization_id:
            for pool in project.pools:
                await self.client.add_users_to_project(
                    project_id=new_project.uid,
                    pool_id=pool,
                    organization_id=dst_organization_id,
                )
            logger.info('Added %s pools', len(project.pools))

        new_tasks: List[TaskData] = []

        task_copy_ignore_fields = None
        if organization_id != dst_organization_id:
            logger.info(
                "Skills, filters and control_fraction won't be copied: the target org does not match the source one"
            )
            task_copy_ignore_fields = {"out_skill_id", "filter", "control_fraction"}

        for task in tasks:
            new_task_data_request = TaskDataRequest.from_task_data(task, ignore_fields=task_copy_ignore_fields)
            new_task_data_request.project_id = new_project.uid
            new_task_data_request.organization_id = (
                dst_organization_id if dst_organization_id else project.organization_id
            )

            new_task = await self.client.create_task(new_task_data_request)

            if task.payload:
                await self.set_task_payload(new_task.uid, task.payload, new_task.organization_id)
                new_task.payload = task.payload

            new_tasks.append(new_task)

        logger.info('Tasks created')
        return list(zip(tasks, new_tasks)), new_project

    @autodoc.section("files")
    async def clone_task_files(
        self,
        src_task_id: str,
        dst_task_id: str,
        ignore_files_ids: Set[str],
        organization_id: Optional[str] = None,
        dst_organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
    ) -> int:
        """Clone task files from one task to another.

        Args:
            src_task_id: task id to clone files from.
            dst_task_id: task id to clone files to.
            ignore_files_ids: files ids to ignore while cloning.
            organization_id: optional organization identifier. Defaults to None.
            dst_organization_id: optional organization id of destination task. Defaults to None.

        Returns:
            number of files cloned successfully.
        """
        if dst_organization_id is None:
            dst_organization_id = organization_id

        task_files = await self.get_task_files(src_task_id, organization_id=organization_id)

        logger.info('Old project data acquired')

        task_file_ids_to_name = {file.uid: file.name for file in task_files}

        task_file_ids = set(task_file_ids_to_name.keys())
        files_ids_to_upload = task_file_ids.difference(ignore_files_ids)

        logger.info('Found %s unmarked files from %s', len(files_ids_to_upload), len(task_file_ids))

        metadata: List[UpdateMetaDataRequest] = []
        for file in task_files:
            meta = await self.get_meta_data(src_task_id, file.uid, file.metadata, organization_id)
            metadata.append(
                UpdateMetaDataRequest(
                    data=meta,
                    filename=file.name,
                )
            )
        logger.info('Found metadata for files')

        logger.info('Downloading unmarked dataset files')
        files_downloaded = 0
        with tempfile.TemporaryDirectory() as tmp_dir_name:
            for file_id in files_ids_to_upload:
                bytes_file = await self.client.download_file(
                    task_id=src_task_id,
                    file_id=file_id,
                    organization_id=organization_id,
                )
                async with aiofiles.open(path.join(tmp_dir_name, task_file_ids_to_name[file_id]), mode='wb') as f:
                    await f.write(bytes_file)
                files_downloaded += 1
                if files_downloaded % 100 == 0:
                    logger.info('Downloaded %s files', files_downloaded)

            logger.info('Uploading files...')

            await self.upload_folder_to_task(
                task_id=dst_task_id,
                folder=Path(tmp_dir_name),
                organization_id=dst_organization_id,
                tqdm_on=tqdm_on,
            )

        if metadata:
            await self.update_meta_data(dst_task_id, metadata, organization_id)

        logger.info('Files uploaded successfully')
        return files_downloaded

    @autodoc.section("project")
    async def clone_project_with_data(
        self,
        project_id: str,
        organization_id: Optional[str] = None,
        dst_organization_id: Optional[str] = None,
        clone_all_files: bool = False,
        clone_task_payloads: bool = False,
    ) -> str:
        """Clone project with all its tasks, pools and datasets.

        Args:
            project_id: project id to clone.
            organization_id: optional organization identifier. Defaults to None.
            dst_organization_id: optional organization id of destination project. Defaults to None.
            clone_all_files: clone files which are already marked. Defaults to False.

        Returns:
            id of cloned project.
        """
        tasks, new_project = await self.clone_project(
            project_id,
            organization_id=organization_id,
            dst_organization_id=dst_organization_id,
            clone_task_payloads=clone_task_payloads,
        )
        marked_file_ids: Dict[str, Set[str]] = {}
        for task, _ in tasks:
            task_results = await self.client.get_task_results(task_id=task.uid, organization_id=organization_id)
            marked_file_ids[task.uid] = (
                set(result.entity_id for result in task_results if len(result.result) == task.overlap)
                if not clone_all_files
                else set()
            )

        for task, new_task in tasks:
            files_cloned = await self.clone_task_files(
                task.uid, new_task.uid, marked_file_ids[task.uid], organization_id, dst_organization_id
            )
            logger.info('Copied %s files to task "%s"', files_cloned, new_task.name)
            await asyncio.sleep(1)

        logger.info('Cloned project with name "%s"', new_project.name)
        logger.info('Project link is "%s/markup_project/%s"', self.client.url, new_project.uid)
        logger.info('Tasks not started, run them manually')
        return new_project.uid

    @autodoc.section("files")
    async def download_task_data(
        self, task_id: str, destination_dir: Union[str, Path], organization_id: Optional[str] = None
    ) -> int:
        """Download all files from task.

        Args:
            task_id: task id to download files from.
            destination_dir: path to directory to download files to.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            number of files downloaded successfully.
        """
        destination_dir = Path(destination_dir)
        destination_dir.mkdir(parents=True, exist_ok=True)
        try:
            task = await self.client.get_task(task_id, organization_id=organization_id)
            task_files = await self.get_task_files(task.uid, organization_id=organization_id)
        except ClientResponseError as error:
            if error.status == HTTPForbidden.status_code:
                logger.error('Only task owner can download task data')
            return 0

        files_downloaded = 0
        for item in task_files:
            try:
                bytes_file = await self.client.download_file(
                    task_id=task.uid,
                    file_id=item.uid,
                    organization_id=organization_id,
                )
            except ClientResponseError:
                continue

            async with aiofiles.open(destination_dir / item.name, mode='wb') as file:
                await file.write(bytes_file)
            files_downloaded += 1

        return files_downloaded

    @autodoc.section("results")
    async def download_task_results(
        self, task_id: str, destination: Union[str, Path], organization_id: Optional[str] = None
    ) -> None:
        """Get task assignments' results and save to file.

        Args:
            task_id: task id to download results from.
            destination: path to file to save results to.
            organization_id: optional organization identifier. Defaults to None.
        """
        destination = Path(destination)

        task_results = await self.client.get_task_results(task_id=task_id, organization_id=organization_id)
        with open(destination, 'w') as f:
            json.dump([result.to_dict() for result in task_results], f, ensure_ascii=False, indent=2)

    @autodoc.section("project")
    async def get_project_names_by_status(self, is_archived: bool, organization_id: Optional[str] = None) -> Set[str]:
        """Get all archived or unarchived projects.

        Args:
            is_archived: status (archived or unarchived).
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            names of projects with matched status.
        """
        # get projests meta
        get_project_resp = await self.get_projects(archived=is_archived, organization_id=organization_id)
        return {project.name for project in get_project_resp if project.is_archived is is_archived}

    @autodoc.section("project")
    async def get_project_ids_by_status(self, is_archived: bool, organization_id: Optional[str] = None) -> Set[str]:
        """Get all archived or unarchived project ids.

        Args:
            is_archived: status (archived or unarchived).
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            ids of projects with matched status.
        """
        # get projests meta
        get_project_resp = await self.get_projects(archived=is_archived, organization_id=organization_id)
        return {project.uid for project in get_project_resp if project.is_archived is is_archived}

    # raw compatibility layer

    @autodoc.section("files")
    async def upload_folder_to_task(
        self,
        task_id: str,
        folder: Union[str, Path],
        exclude_ext_filter: Optional[Set[str]] = None,
        organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
    ) -> UploadFilesResult:
        """Upload all files from folder to task.

        Args:
            task_id: task id to upload files to.
            folder: path to folder to upload files from.
            exclude_ext_filter: file extensions to exclude. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object which contains uploaded files and errors.
        """
        uploaded_files = await self.client.upload_folder_to_task(
            task_id=task_id,
            folder=folder,
            exclude_ext_filter=exclude_ext_filter,
            organization_id=organization_id,
            tqdm_on=tqdm_on,
        )
        if uploaded_files:
            await self.client.wait_until_sdct_done(task_id=task_id, organization_id=organization_id)
        return uploaded_files

    @autodoc.section("files")
    async def upload_folders_to_task(
        self,
        upload_data: List[Tuple[str, Union[str, Path]]],
        exclude_ext_filter: Optional[Set[str]] = None,
        start: bool = False,
        organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
    ) -> Dict[str, Union[None, bool, TaskData]]:
        """Upload many folders to many tasks.

        Args:
            upload_data: pairs of task id and folder to upload.
            exclude_ext_filter: file extensions to exclude. Defaults
            start: start tasks after uploading. Defaults to False.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object which contains uploaded files and errors.

            - key: - task_id

            - value:

                - None - if the folder for the task is empty

                - TaskData - if the task was started

                - True - if the task didn't need to be started

                - False - if the task was not started due to the problems with task constraints or an exception.

        """
        task_with_errors_or_without_files: Dict[str, bool] = {}
        for task_id, folder in upload_data:
            uploaded_files = await self.client.upload_folder_to_task(
                task_id=task_id,
                folder=folder,
                exclude_ext_filter=exclude_ext_filter,
                organization_id=organization_id,
                tqdm_on=tqdm_on,
            )
            if len(uploaded_files.errors) + len(uploaded_files.created_files) == 0:
                logger.warning(f'Tried to upload empty folder={folder} for t    he task={task_id}')
            task_with_errors_or_without_files[task_id] = bool(uploaded_files.errors) or not bool(
                uploaded_files.created_files
            )

        result: Dict[str, Union[None, bool, TaskData]] = {}
        for task_id, _ in upload_data:
            result[task_id] = None
            if task_with_errors_or_without_files[task_id]:  # skip folders with errors: don't check, don't start
                result[task_id] = False
                continue
            try:
                await self.client.wait_until_sdct_done(task_id=task_id, organization_id=organization_id)
                if start:
                    task_data = await self.client.start_task(task_id=task_id, organization_id=organization_id)
                    result[task_id] = task_data
                else:
                    result[task_id] = True

            except ClientResponseError:
                result[task_id] = False

        return result

    @autodoc.section("files")
    async def upload_folders_to_task_and_start(
        self,
        upload_data: List[Tuple[str, Union[str, Path]]],
        exclude_ext_filter: Optional[Set[str]] = None,
        organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
    ) -> Dict[str, Union[None, bool, TaskData]]:
        """Upload many folders to many tasks and start them.

        Args:
            upload_data: pairs of task id and folder to upload.
            exclude_ext_filter: file extensions to exclude. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object which contains uploaded files and errors.

            - key: - task_id

            - value:

                - None - if the folder for the task is empty

                - TaskData - if the task was started

                - True - if the task didn't need to be started

                - False - if the task was not started due to the problems with task constraints or an exception.

        """
        return await self.upload_folders_to_task(
            upload_data,
            exclude_ext_filter,
            start=True,
            organization_id=organization_id,
            tqdm_on=tqdm_on,
        )

    @autodoc.section("files")
    async def delete_items_from_task(
        self, task_id: str, organization_id: Optional[str] = None
    ) -> DeleteAllFilesrResult:
        """Delete all files from tasks.
        (warning) May not work. Hope it will be fixed soon.

        Args:
            task_id: task id to delete files from.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.delete_items_from_task(task_id=task_id, organization_id=organization_id)

    @autodoc.section("files")
    async def delete_some_items_from_task(
        self, task_id: str, files: List[str], organization_id: Optional[str] = None
    ) -> DeleteSomeFilesResult:
        """Delete selected task files from task.

        Args:
            task_id: task_id to delete files from.
            files: file ids to delete from task.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.delete_some_items_from_task(task_id, files, organization_id)

    @autodoc.section("project")
    async def add_users_to_project(self, project_id: str, pool_id: str, organization_id: Optional[str] = None) -> None:
        """Add pool of users to project.

        Args:
            project_id: project id to add pool to.
            pool_id: pool id to add to project.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.add_users_to_project(
            project_id=project_id, pool_id=pool_id, organization_id=organization_id
        )

    @autodoc.section("project")
    async def delete_users_from_project(
        self, project_id: str, pool_id: str, organization_id: Optional[str] = None
    ) -> None:
        """Delete pool of users from project.

        Args:
            project_id: project id to delete pool from.
            pool_id: pool id to delete from project.
            organization_id: optional organization identifier. Defaults to None.
        """
        await self.client.delete_users_from_project(
            project_id=project_id, pool_id=pool_id, organization_id=organization_id
        )

    @autodoc.section("task")
    async def get_task(
        self,
        task_id: str,
        organization_id: Optional[str] = None,
        with_files_count: bool = False,
    ) -> TaskData:
        """Get task by id.

        Args:
            task_id: id of task to get.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            task data.
        """
        task = await self.client.get_task(task_id, organization_id=organization_id)
        if with_files_count:
            files_count = await self.client.get_task_files_count(
                task_id=task_id,
                types=["all"],
                organization_id=organization_id,
            )
            task.estimated_files_count = files_count.all
        return task

    @autodoc.section("task")
    async def get_task_hierarchy(self, task_id: str) -> TaskHierarchy:
        """Get project id and organization id for task.

        Args:
            task_id: id of task.

        Returns:
            Object which contains project_id and organization_id of task.
        """
        return await self.client.get_task_hierarchy(task_id)

    @autodoc.section("task")
    async def put_item_overlap(
        self,
        task_id: str,
        item_id: str,
        overlap: int,
        organization_id: Optional[str] = None,
    ) -> Item:
        """Change overlap of an item

        Args:
            task_id: id of task.
            item_id: id of item.
            overlap: target overlap value

        Returns:
            Item info.
        """
        return await self.client.put_item_overlap(task_id, item_id, overlap, organization_id=organization_id)

    @autodoc.section("task")
    async def increase_item_overlap(
        self,
        task_id: str,
        item_id: str,
        organization_id: Optional[str] = None,
    ) -> Item:
        """Increase overlap of an item

        Args:
            task_id: id of task.
            item_id: id of item.

        Returns:
            Item info.
        """
        return await self.client.increase_item_overlap(
            task_id=task_id, item_id=item_id, organization_id=organization_id
        )

    @autodoc.section("task")
    async def assign_assignment(
        self,
        task_id: str,
        item_id: str,
        marker_id: str,
        expired_after: datetime,
        original_assignment_id: Optional[str] = None,
        price: Optional[float] = None,
        is_increase_overlap: Optional[bool] = None,
        is_release_to_pool_on_expire: Optional[bool] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        """Assign an assignment in item

        Args:
            task_id: id of task.
            item_id: id of item.
            marker_id: id of marker.
            expired_after: time of expiring of assignment.
            original_assignment_id:  id of assignment for premarkup.
            price: price, if None, will be taken from task price.
            is_increase_overlap: if True, new assignment will be created.
            is_release_to_pool_on_expire: if True, new assignment won't be created after expiring this one.

        Returns:
            None.
        """
        await self.client.assign_assignment(
            task_id=task_id,
            item_id=item_id,
            marker_id=marker_id,
            expired_after=expired_after,
            original_assignment_id=original_assignment_id,
            price=price,
            is_increase_overlap=is_increase_overlap,
            is_release_to_pool_on_expire=is_release_to_pool_on_expire,
            organization_id=organization_id,
        )

    @autodoc.section("task")
    async def assign_assignments(
        self,
        assignments: List[AssignAssignmentRequest],
        organization_id: Optional[str] = None,
    ) -> None:
        """(deprecated) Assign multiple assignment.
        Use 'assign_multiple_assignments' instead.

        Args:
            assignments: rules on how to assign assignment.
            organization_id: optional organization identifier. Defaults to None.
        """
        await self.client.assign_assignments(
            assignments=assignments,
            organization_id=organization_id,
        )

    @autodoc.section("task")
    async def assign_multiple_assignments(
        self,
        items: List[AssignMultipleAssignmentRequest],
        organization_id: Optional[str] = None,
    ) -> AssignAssignmentsResult:
        """Assign multiple assignment

        Args:
            items: rules on how to assign assignment.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.assign_multiple_assignments(
            items=items,
            organization_id=organization_id,
        )

    @autodoc.section("task")
    async def unassign_assignment(
        self,
        task_id: str,
        assignment_id: str,
        is_keep_price: Optional[bool] = None,
        is_decrease_overlap: Optional[bool] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        """Unassign previously assigned assignment

        Args:
            task_id: id of task.
            assignment_id: id of assignment.
            is_keep_price: if True, price will be saved as a price of an unassigned assignment.
            is_decrease_overlap: if True, item overlap will decrement.

        Returns:
            None.
        """
        await self.client.unassign_assignment(
            task_id=task_id,
            assignment_id=assignment_id,
            is_keep_price=is_keep_price,
            organization_id=organization_id,
            is_decrease_overlap=is_decrease_overlap,
        )

    @autodoc.section("files")
    async def upload_files(
        self,
        task_id: str,
        filepaths: Sequence[Union[str, Path]],
        batch_size: int = BATCH_SIZE,
        organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
        preserve_order: bool = False,
        wait_until_sdct_done: bool = True,
    ) -> UploadFilesResult:
        """Upload files to task.

        Args:
            task_id: task id to upload files to.
            filepaths: paths to files to upload to task.
            batch_size: number of files downloading at once. Defaults to 16.
            organization_id: optional organization identifier. Defaults to None.
            tqdm_on: if True, tqdm will be used to show progress of uploading.
            preserve_order: if True, files will be uploaded in order. Defaults to False.
            wait_until_sdct_done: if True, will wait until sdct done. Defaults to True.

        Returns:
            object which contains uploaded files and errors.
        """
        res = await self.client.upload_files(
            task_id,
            filepaths,
            batch_size,
            organization_id=organization_id,
            tqdm_on=tqdm_on,
            preserve_order=preserve_order,
        )
        if wait_until_sdct_done:
            await self.client.wait_until_sdct_done(task_id=task_id, organization_id=organization_id)

        return res

    @autodoc.section("files")
    async def upload_methodics_file(
        self,
        method_id: str,
        filepath: Union[str, Path],
        file_type: MethodFileType,
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        """Upload methodics file for method.

        Args:
            method_id: id of method to upload file to.
            filepath: path to file to upload.
            file_type: type of file to upload.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            uid and url of file.
        """
        return await self.client.upload_methodics_file(
            method_id=method_id, filepath=filepath, file_type=file_type, organization_id=organization_id
        )

    @autodoc.section("files")
    async def replace_file(
        self,
        task_id: str,
        file_id: str,
        filepath: Union[str, Path],
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        """Replace file in task.

        Args:
            task_id: task id to upload file to.
            file_id: id of file to replace.
            filepath: path to new file.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object which contains uploaded files and errors.
        """
        return await self.client.replace_file(task_id, file_id, filepath, organization_id)

    @autodoc.section("files")
    async def update_meta_data(
        self, task_id: str, data: Union[List[Dict], List[UpdateMetaDataRequest]], organization_id: Optional[str] = None
    ) -> dict:
        """Update information about controls, premarkup and explanation.

        Args:
            task_id: task id to update meta data.
            data: data to update meta data.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            dict
        """
        return await self.client.update_meta_data(task_id=task_id, data=data, organization_id=organization_id)

    @autodoc.section("files")
    async def get_meta_data(
        self, task_id: str, file_uid: str, types: Optional[List[MetaType]] = None, organization_id: Optional[str] = None
    ) -> MetaData:
        """Get controls, premarkup and explanation for task file.

        Args:
            task_id: id of task to get meta data for file from.
            file_uid: id of file to get meta data from.
            types: types of metadata (:class:`~crowd_sdk.tagme.http_client.datacls.MetaType`). Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object which contains controls, premarkup and explanation.
        """
        return await self.client.get_meta_data(
            task_id=task_id, file_uid=file_uid, types=types, organization_id=organization_id
        )

    @autodoc.section("files")
    async def remove_control(self, task: TaskData, file_id: str, force_unassign: Optional[bool] = False) -> None:
        """Remove control item from task.

        Args:
            task: task to remove control from.
            file_id: id of control file to remove.
            force_unassign: forcibly unassign all assignments
        """
        flag = False
        try:
            if task.state.value == 'RUNNING':
                logger.info(f'Stoppnig task: {file_id}')
                await self.stop_task(task.uid, organization_id=task.organization_id)
                flag = True

            if force_unassign:
                assigned_items = await self.get_markup_results(
                    task_id=task.uid, organization_id=task.organization_id, file_ids=[file_id], statuses=['ASSIGNED']
                )
                for assigned in assigned_items.items:
                    await self.unassign_assignment(
                        task_id=task.uid,
                        assignment_id=assigned.id,
                        organization_id=task.organization_id,
                    )
            logger.info(f'Remove control item {file_id}')
            await self.disable_control_task(task.uid, file_id, organization_id=task.organization_id)
            file = await self.get_file(task.uid, file_id, organization_id=task.organization_id)
            assert file.enabled is False

        finally:
            if flag:
                logger.info(f'Run task {task.uid}')
                await self.start_task(task.uid)

    @autodoc.section("files")
    async def upload_json_data(
        self,
        task_id: str,
        json_data: Iterable[dict],
        base_path: Union[str, Path, None] = None,
        organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
    ) -> None:
        """Upload data in json format to task. Each json object can contain fields:

        - 'file_path': name of destination file (ends with .json).

        - 'file_id': name of destination file

        - 'task': dict which contains input data for task. Can also contain field 'id' for name of destination file.

        - 'upload_file': file with input data for task.

        - 'premarkup': premarkup for task.

        - 'control': control for task.

        - 'hint': explanation for task.

        Args:
            task_id: id of task to upload data to.
            json_data: data to upload.
            base_path: path to folder with json files. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.
        """
        metadata: List[Dict] = []
        with TempDir() as tmp_dir:
            for n, task in enumerate(json_data):
                filename = task.get('file_path')
                if not filename:
                    filename = task.get('file_id') or task.get('id') or f'task_{n}'
                    filename += '.json' if not filename.endswith('.json') else ''

                if task.get('task'):
                    filepath = Path(tmp_dir) / filename
                    with open(filepath, 'w') as task_file:
                        json.dump(task['task'], task_file)
                else:
                    if base_path is None:
                        raise ValueError('One of base_path or task inputs must be not none')

                    if 'upload_file' in task:
                        unique_filename = task['upload_file']
                        src_filepath = Path(base_path) / unique_filename
                        filepath = Path(tmp_dir) / filename
                        shutil.copyfile(src_filepath, filepath)

                    else:
                        filepath = Path(base_path) / filename

                meta_ = {}
                if 'premarkup' in task:
                    meta_['premarkup'] = task['premarkup']
                if 'control' in task:
                    meta_['control'] = task['control']
                if 'hint' in task:
                    meta_['explanation'] = task['hint']

                if meta_:
                    metadata.append(
                        {
                            'filename': filename,
                            'data': meta_,
                        }
                    )

            await self.upload_folder_to_task(
                task_id=task_id, folder=tmp_dir, organization_id=organization_id, tqdm_on=tqdm_on
            )

            if metadata:
                await self.update_meta_data(task_id=task_id, data=metadata, organization_id=organization_id)

    @autodoc.section("files")
    async def upload_tsv_data(
        self, task_id: str, filepath: Union[str, Path], organization_id: Optional[str] = None
    ) -> None:
        """Upload TSV data in toloka-format, INPUT:<input-fields> GOLDEN:<meta-fields>
        Read the doc: https://tagme.sberdevices.ru/docs/customer/uploading-data.html

        Args:
            task_id: id of task to upload data to.
            filepath: path to TSV file.
            organization_id: optional organization identifier. Defaults to None.
        """
        filepath = Path(filepath)
        json_data = [row_to_task(row) for row in tsv_load(filepath)]
        return await self.upload_json_data(
            task_id=task_id, json_data=json_data, base_path=filepath.parent, organization_id=organization_id
        )

    @autodoc.section("organization")
    async def get_organizations(self) -> List[Organization]:
        """Get available organizations.

        Returns:
            list of organizations.
        """
        return await self.client.get_organizations()

    @autodoc.section("statistics")
    async def export_project_stats(
        self,
        project_id: str,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        organization_id: Optional[str] = None,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        """Export project statistics to file.

        Args:
            project_id: id of project to export.
            from_date: start of statistics period.
            to_date: end of statistics period.
            types: types of data to export (MARKERS or TASKS).
            file_format: file format to export. Defaults to CSV.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of project statistics items.
        """
        return await self.client.export_project_stats(
            project_id=project_id,
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
            organization_id=organization_id,
        )

    @autodoc.section("statistics")
    async def export_org_stats(
        self,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        organization_id: Optional[str] = None,
        hourly: Optional[bool] = None,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        """Export organization statistics to file.

        Args:
            from_date: start of statistics period.
            to_date: end of statistics period.
            types: types of data to export (MARKERS or TASKS).
            file_format: file format to export. Defaults to CSV.
            organization_id: optional organization identifier. Defaults to None.
            hourly: if True, export hourly statistics. By default, exports daily statistics.

        Returns:
            list of organization statistics items.
        """
        return await self.client.export_org_stats(
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
            organization_id=organization_id,
            hourly=hourly,
        )

    @autodoc.section("statistics")
    async def get_quality_stats(
        self,
        organization_id: str,
        output: StatsOutputType,
        task_ids: Optional[Tuple[str]] = None,
        project_ids: Optional[Tuple[str]] = None,
    ) -> List[Union[TaskQuality, List[ItemQuality]]]:
        """Get quality statistics for tasks.

        Args:
            organization_id: organization identifier.
            output: type of statistics returned (TASK or ITEM).
            task_ids: optional task identifiers. Defaults to None.
            project_ids: optional project identifiers. Defaults to None.

        Returns:
            list of quality statistics items. If output is TASK, returns
            list of TaskQuality. If output is ITEM, returns list of ItemQuality.
        """
        tasks = await self.get_tasks_advanced(
            task_ids=task_ids,
            project_ids=project_ids,
            organization_id=organization_id,
            with_payload=True,
            with_empty=False,
        )
        # TODO filter by time

        quality_func: Union[
            Callable[[TaskData, TagmeClientAdvanced], Coroutine[Any, Any, TaskQuality]],
            Callable[[TaskData, TagmeClientAdvanced], Coroutine[Any, Any, List[ItemQuality]]],
        ]
        if output == StatsOutputType.TASK:
            quality_func = get_task_quality

        elif output == StatsOutputType.ITEM:
            quality_func = get_items_quality

        else:
            raise NotImplementedError

        result = [await quality_func(x, self) for x in list(reversed(tasks))]

        return result

    @autodoc.section("statistics")
    async def get_task_items_statistics(
        self,
        task_id: str,
        organization_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
        item_ids: Optional[List[str]] = None,
    ) -> List[TaskTabItemStats]:
        """
        Returns task items statistics by taskID
        """
        return await self.client.get_task_items_statistics(
            task_id=task_id,
            organization_id=organization_id,
            page=page,
            size=size,
            item_ids=item_ids,
        )

    @autodoc.section("statistics")
    async def get_task_item_statistics(
        self,
        organization_id: str,
        task_id: str,
        item_id: str,
    ) -> TaskTabItemStats:
        """
        Returns task item statistics by taskID
        """

        return await self.client.get_task_item_statistics(
            task_id=task_id,
            item_id=item_id,
            organization_id=organization_id,
        )

    @autodoc.section("organization")
    async def get_organization(self, org_key: Optional[str] = None) -> Organization:
        """Get organization by id or name. If organization_id is None, get current organization.

        Args:
            org_key: id or name of organization.

        Returns:
            organization found or current organization.
        """
        return await self.client.get_organization(org_key=org_key)

    @autodoc.section("files")
    async def get_task_files(
        self,
        task_id: str,
        query: Optional[str] = None,
        types: Optional[List[Union[FileType, str]]] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        enabled: Optional[bool] = True,
        organization_id: Optional[str] = None,
    ) -> List[TaskFile]:
        """Get information about files in task.

        Args:
            task_id: id of task.
            query: optional search query for file names.
            types: file types to get (CONTROL, STUDY, DATA)
            page: page number for pagination.
            size: number of items per page for pagination.
            enabled: optional flag to get only enabled files.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of task file objects.
        """
        if enabled:
            return await run_with_pagination(
                self.client.get_task_files,
                task_id=task_id,
                query=query,
                types=types,
                organization_id=organization_id,
                page=page,
                size=size,
            )

        files = await run_with_pagination(
            self.client.get_all_files,
            task_id=task_id,
            query=query,
            types=types,
            organization_id=organization_id,
            page=page,
            size=size,
        )
        if enabled is None:
            return files
        else:
            return [x for x in files if not x.enabled]

    @autodoc.section("task")
    async def get_task_files_count(
        self,
        task_id: str,
        types: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
    ) -> TaskFilesCount:
        """Get count of files in task by types.

        Args:
            task_id: id of task.
            types: file types to include (all, control, study, data)
            organizaton_id: optional organization identifier. Defaults to None.

        Returns:
            files count for requested types.
        """
        return await self.client.get_task_files_count(
            task_id=task_id,
            types=types,
            organization_id=organization_id,
        )

    @autodoc.section("task")
    async def get_tasks(  # pylint: disable=R0913
        self,
        project_id: Optional[str] = None,
        price_min: Optional[float] = None,
        price_max: Optional[float] = None,
        priority_min: Optional[int] = None,
        priority_max: Optional[int] = None,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        organization_id: Optional[str] = None,
        update_date_from: Optional[str] = None,
        states: Optional[List[TaskState]] = None,
        task_ids: Optional[List[str]] = None,
    ) -> List[TaskData]:
        """Get tasks matching by filter.

        Args:
            project_id: optional project identifier.
            price_max: optional maximum price for task.
            price_min: optional minimum price for task.
            priority_min: optional minimum priority for task.
            priority_max: optional maximum priority for task.
            query: optional search query for task names.
            page: page number for pagination.
            size: number of items per page for pagination.
            organization_id: optional organization identifier. Defaults to None.
            update_date_from: optional update date for tasks.
            states: optional task states.
            task_ids: optional task identifiers.

        Returns:
            list of tasks.
        """
        return await run_with_pagination(
            self.client.get_tasks,
            project_id=project_id,
            price_min=price_min,
            price_max=price_max,
            priority_min=priority_min,
            priority_max=priority_max,
            query=query,
            update_date_from=update_date_from,
            organization_id=organization_id,
            states=states,
            task_ids=task_ids,
            page=page,
            size=size,
        )

    @autodoc.section("project")
    async def get_projects_advanced(
        self,
        project_ids: Optional[Collection[str]] = None,  # pylint: disable=E1136
        organization_id: Optional[str] = None,
        with_method: bool = False,
        with_pipeline: Optional[bool] = False,
        archived: Optional[bool] = None,
        is_pipelined: Optional[bool] = None,
        tqdm_on: Union[bool, str] = False,
        max_concurrency: int = 10,
    ) -> List[Project]:
        """Get organization projects.

        Args:
            project_ids: optional project identifiers. If not set, all projects are returned.
            organization_id: optional organization identifier. Defaults to None.
            with_method: if set to True, methods for projects are loaded.
            with_pipeline: return projects with pipeline config. Defaults to False.
            archived: if set to True or False, only archived or not archived projects are returned.
            is_pipelined: return only pipelined projects. Defaults to None.
            tqdm_on: if set to True or some string progress bar is shown. Defaults to False.
            max_concurrency: controls the asyncio.Semaphore value for limiting concurrent operations. Defaults to 10.

        Returns:
            list of projects.
        """
        semaphore = asyncio.Semaphore(max_concurrency)
        if project_ids is not None:
            projects = await asyncio.gather(
                *(
                    use_semaphore(self.get_project(project_id=p, organization_id=organization_id), semaphore)
                    for p in project_ids
                )
            )

        else:
            projects = await self.get_projects(
                archived=archived,
                organization_id=organization_id,
                with_pipeline=with_pipeline,
                is_pipelined=is_pipelined,
            )

        if with_method:
            for projects_ in chunks(projects, CHUNK_SIZE, tqdm_on='getting methods for projects' if tqdm_on else False):
                await asyncio.gather(
                    *(use_semaphore(self.load_project_method(p), semaphore) for p in projects_),
                    return_exceptions=False,
                )

        return projects

    @autodoc.section("project")
    async def get_projects_advanced_with_errors(
        self,
        project_ids: Optional[Collection[str]] = None,
        organization_id: Optional[str] = None,
        with_method: bool = False,
        with_pipeline: Optional[bool] = False,
        archived: Optional[bool] = None,
        is_pipelined: Optional[bool] = None,
        tqdm_on: Union[bool, str] = False,
        errors: Optional[ProjectErrors] = None,
        max_concurrency: int = 10,
    ) -> Tuple[List[Project], ProjectErrors]:
        """Get organization projects.

        Args:
            project_ids: optional project identifiers. If not set, all projects are returned.
            organization_id: optional organization identifier. Defaults to None.
            with_method: if set to True, methods for projects are loaded.
            with_pipeline: return projects with pipeline config. Defaults to False.
            archived: if set to True or False, only archived or not archived projects are returned.
            is_pipelined: return only pipelined projects. Defaults to None.
            tqdm_on: if set to True or some string progress bar is shown. Defaults to False.
            errors: optional mapping project_id and list of errors.
            max_concurrency: controls the asyncio.Semaphore value for limiting concurrent operations. Defaults to 10.

        Returns:
            list of projects and occured errors with mapping.
        """
        semaphore = asyncio.Semaphore(max_concurrency)
        errors = errors or defaultdict(list)
        if project_ids is not None:
            project_ans = await asyncio.gather(
                *(
                    use_semaphore(self.get_project(project_id=p, organization_id=organization_id), semaphore)
                    for p in project_ids
                ),
                return_exceptions=True,
            )
            projects = []

            for project_id, ans in zip(project_ids, project_ans):
                if isinstance(ans, Project):
                    projects.append(ans)
                else:
                    errors[project_id].append(str(ans))

        else:
            projects = await self.get_projects(
                archived=archived,
                organization_id=organization_id,
                with_pipeline=with_pipeline,
                is_pipelined=is_pipelined,
            )

        if with_method:
            for projects_ in chunks(projects, CHUNK_SIZE, tqdm_on='getting methods for projects' if tqdm_on else False):
                res = await asyncio.gather(
                    *(use_semaphore(self.load_project_method(p), semaphore) for p in projects_), return_exceptions=True
                )
                for project, res_ in zip(projects, res):
                    if isinstance(res_, BaseException):
                        errors[project.uid].append(str(res_))

        return projects, errors

    @autodoc.section("task")
    async def get_tasks_advanced(
        self,
        task_ids: Optional[Sequence[str]] = None,
        project_ids: Optional[Sequence[str]] = None,
        organization_id: Optional[str] = None,
        with_empty: bool = True,
        with_payload: bool = False,
        with_project_pipeline: Union[bool, dict] = False,
        archived: Optional[bool] = None,
        tqdm_on: bool = False,
        max_concurrency: int = 10,
    ) -> List[TaskData]:
        """Get tasks matching by filter.

        Args:
            task_ids: optional task identifiers. If not set, all tasks are returned.
            project_ids: optional project identifiers. If not set, tasks from all the projects are returned.
            organization_id: optional organization identifier. Defaults to None.
            with_empty: if set to True, tasks with no files are returned. Defaults to True.
            with_payload: if set to True, tasks payload is added. Defaults to False.
            with_project_config: add project config to tasks payload. Defaults to False.
            archived: if set to True or False, only archived or not archived tasks are returned. Defaults to None.
            tqdm_on: if set to True or some string progress bar is shown. Defaults to False.
            max_concurrency: controls the asyncio.Semaphore value for limiting concurrent operations. Defaults to 10.

        Returns:
            list of tasks.
        """
        semaphore = asyncio.Semaphore(max_concurrency)

        tasks: List[TaskData] = []

        if project_ids is not None:
            for project_ids_ in chunks(
                project_ids, CHUNK_SIZE, tqdm_on='getting tasks from projects' if tqdm_on else False
            ):
                tasks.extend(
                    chain(
                        *(
                            await asyncio.gather(
                                *(
                                    use_semaphore(
                                        self.get_tasks(project_id=p, organization_id=organization_id), semaphore
                                    )
                                    for p in project_ids_
                                )
                            )
                        )
                    )
                )

        if task_ids is not None:
            ids_ = {x.uid for x in tasks}
            for task_ids_ in chunks(task_ids, CHUNK_SIZE, tqdm_on='getting tasks by ids' if tqdm_on else False):
                tasks.extend(
                    await asyncio.gather(
                        *(
                            use_semaphore(self.get_task(task_id=t, organization_id=organization_id), semaphore)
                            for t in task_ids_
                            if t not in ids_
                        )
                    )
                )

        if project_ids is None and task_ids is None:
            projects = await self.get_projects_advanced(
                organization_id=organization_id,
                archived=archived,
                with_pipeline=bool(with_project_pipeline),
                tqdm_on=tqdm_on,
            )
            project_pipelines = with_project_pipeline and {
                p.uid: {"pipeline": p.pipeline} for p in projects if p.pipeline and p.is_pipeline_enabled
            }  # type: ignore[union-attr]
            return await self.get_tasks_advanced(
                project_ids=[p.uid for p in projects],
                with_empty=with_empty,
                with_payload=with_payload,
                with_project_pipeline=project_pipelines,
                organization_id=organization_id,
                tqdm_on=tqdm_on,
            )

        return await self._post_process_tasks(
            tasks,
            with_empty=with_empty,
            with_payload=with_payload,
            with_project_pipeline=with_project_pipeline,
            archived=archived,
            organization_id=organization_id,
            tqdm_on=tqdm_on,
        )

    @autodoc.section("task")
    async def get_tasks_advanced_with_errors(  # pylint: disable=too-many-arguments
        self,
        task_ids: Optional[Sequence[str]] = None,
        project_ids: Optional[Sequence[str]] = None,
        organization_id: Optional[str] = None,
        with_empty: bool = True,
        with_payload: bool = False,
        with_project_pipeline: Union[bool, dict] = False,
        archived: Optional[bool] = None,
        project_errors: Optional[ProjectErrors] = None,
        task_errors: Optional[Dict[str, str]] = None,
        tqdm_on: bool = False,
        max_concurrency: int = 10,
    ) -> AdvancedTaskDataWithErrors:
        """Get tasks matching by filter.

        Args:
            task_ids: optional task identifiers. If not set, all tasks are returned.
            project_ids: optional project identifiers. If not set, tasks from all the projects are returned.
            organization_id: optional organization identifier. Defaults to None.
            with_empty: if set to True, tasks with no files are returned. Defaults to True.
            with_payload: if set to True, tasks payload is added. Defaults to False.
            with_project_config: add project config to tasks payload. Defaults to False.
            archived: if set to True or False, only archived or not archived tasks are returned. Defaults to None.
            project_errors: optional mapping project_ids and list of errors.
            task_errors: optional mapping task_ids and its errors.
            tqdm_on: if set to True or some string progress bar is shown. Defaults to False.
            max_concurrency: controls the asyncio.Semaphore value for limiting concurrent operations. Defaults to 10.

        Returns:
            list of tasks and occured errors with mapping.
        """
        semaphore = asyncio.Semaphore(max_concurrency)
        tasks: List[TaskData] = []
        project_errors = project_errors or defaultdict(list)
        task_errors = task_errors or {}

        if project_ids is not None:
            for project_ids_ in chunks(
                project_ids, CHUNK_SIZE, tqdm_on='getting tasks from projects' if tqdm_on else False
            ):
                tasks_ans = await asyncio.gather(
                    *(
                        use_semaphore(self.get_tasks(project_id=p, organization_id=organization_id), semaphore)
                        for p in project_ids_
                    ),
                    return_exceptions=True,
                )
                for project_id, task_ans in zip(project_ids_, tasks_ans):
                    if isinstance(task_ans, list):
                        tasks += task_ans
                    else:
                        project_errors[project_id].append(str(task_ans))

        if task_ids is not None:
            ids_ = {x.uid for x in tasks}
            for task_ids_ in chunks(task_ids, CHUNK_SIZE, tqdm_on='getting tasks by ids' if tqdm_on else False):
                tasks_ans = await asyncio.gather(
                    *(
                        use_semaphore(self.get_task(task_id=t, organization_id=organization_id), semaphore)
                        for t in task_ids_
                        if (t not in ids_) and t not in project_errors
                    ),
                    return_exceptions=True,
                )
                for task_id, task_ans in zip(task_ids_, tasks_ans):
                    if isinstance(task_ans, TaskData):
                        tasks.append(task_ans)
                    else:
                        task_errors[task_id] = str(tasks_ans)

        if project_ids is None and task_ids is None:
            projects, project_errors = await self.get_projects_advanced_with_errors(
                organization_id=organization_id,
                archived=archived,
                with_pipeline=bool(with_project_pipeline),
                errors=project_errors,
                tqdm_on=tqdm_on,
            )
            project_pipelines = with_project_pipeline and {
                p.uid: {"pipeline": p.pipeline} for p in projects if p.pipeline and p.is_pipeline_enabled
            }
            return await self.get_tasks_advanced_with_errors(
                project_ids=[p.uid for p in projects],
                with_empty=with_empty,
                with_payload=with_payload,
                with_project_pipeline=project_pipelines,
                organization_id=organization_id,
                project_errors=project_errors,
                task_errors=task_errors,
                tqdm_on=tqdm_on,
            )

        return await self._post_process_tasks_with_errors(
            tasks,
            with_empty=with_empty,
            with_payload=with_payload,
            with_project_pipeline=with_project_pipeline,
            archived=archived,
            organization_id=organization_id,
            project_errors=project_errors,
            task_errors=task_errors,
            tqdm_on=tqdm_on,
        )

    async def _post_process_tasks(
        self,
        tasks: List[TaskData],
        with_empty: bool = True,
        with_payload: bool = False,
        with_project_pipeline: Union[bool, dict] = False,
        archived: Optional[bool] = None,
        organization_id: Optional[str] = None,
        tqdm_on: bool = False,
        max_concurrency: int = 10,
    ) -> List[TaskData]:
        semaphore = asyncio.Semaphore(max_concurrency)

        for t in tasks:
            if organization_id and organization_id != t.organization_id:
                raise ValueError(f"Provided organization_id does not match with task's ({t.uid}) organization")

        if not with_empty:
            tasks = [t for t in tasks if t.estimated_files_count != 0]

        if with_payload:
            for tasks_ in chunks(tasks, CHUNK_SIZE, tqdm_on='getting tasks payload' if tqdm_on else False):
                await asyncio.gather(*(use_semaphore(self.load_task_payload(t), semaphore) for t in tasks_))

        if with_project_pipeline:
            if isinstance(with_project_pipeline, bool):
                projects = await self.get_projects_advanced(
                    project_ids={t.project_id for t in tasks},
                    archived=archived,
                    with_pipeline=True,
                    organization_id=organization_id,
                    tqdm_on=tqdm_on,
                )
                project_pipelines = {
                    p.uid: {"pipeline": p.pipeline} for p in projects if p.pipeline and p.is_pipeline_enabled
                }  # type: ignore[union-attr]
            else:
                project_pipelines = with_project_pipeline

            for task in tasks:
                pc = project_pipelines.get(task.project_id)
                if pc:
                    if task.payload is None:
                        raise ValueError(f"Task {task.uid} has no payload")
                    merge(task.payload, pc, override=False)

        return tasks

    async def _post_process_tasks_with_errors(  # pylint: disable=too-many-arguments
        self,
        tasks: List[TaskData],
        with_empty: bool = True,
        with_payload: bool = False,
        with_project_pipeline: Union[bool, dict] = False,
        archived: Optional[bool] = None,
        organization_id: Optional[str] = None,
        project_errors: Optional[ProjectErrors] = None,
        task_errors: Optional[Dict[str, str]] = None,
        tqdm_on: bool = False,
        max_concurrency: int = 10,
    ) -> AdvancedTaskDataWithErrors:
        semaphore = asyncio.Semaphore(max_concurrency)

        project_errors = project_errors or defaultdict(list)
        task_errors = task_errors or {}  # FIXME unused?
        for t in tasks:
            if organization_id and organization_id != t.organization_id:
                raise ValueError(f"Provided organization_id does not match with task's ({t.uid}) organization")

        if not with_empty:
            tasks = [t for t in tasks if t.estimated_files_count != 0]

        if with_payload:
            for tasks_ in chunks(tasks, CHUNK_SIZE, tqdm_on='getting tasks payload' if tqdm_on else False):
                await asyncio.gather(*(use_semaphore(self.load_task_payload(t), semaphore) for t in tasks_))

        if with_project_pipeline:
            if isinstance(with_project_pipeline, bool):
                projects, project_errors = await self.get_projects_advanced_with_errors(
                    project_ids={t.project_id for t in tasks},
                    archived=archived,
                    with_pipeline=True,
                    organization_id=organization_id,
                    errors=project_errors,
                    tqdm_on=tqdm_on,
                )
                project_pipelines = {
                    p.uid: {"pipeline": p.pipeline} for p in projects if p.pipeline and p.is_pipeline_enabled
                }
            else:
                project_pipelines = with_project_pipeline

            for task in tasks:
                pc = project_pipelines.get(task.project_id)
                if pc:
                    if task.payload is None:
                        raise ValueError(f"Task {task.uid} has no payload")
                    merge(task.payload, pc, override=False)

        if project_errors is None:
            raise ValueError("Must be unreachable, but mypy==0.931 doesn't think so")
        return AdvancedTaskDataWithErrors(tasks=tasks, project_errors=project_errors, task_errors=task_errors)

    @autodoc.section("pool")
    async def get_pools(self, project_id: str, organization_id: Optional[str] = None) -> List[str]:
        """Get pools added to project.

        Args:
            project_id: project id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of pools.
        """
        return await self.client.get_pools(project_id=project_id, organization_id=organization_id)

    @autodoc.section("urls")
    async def gen_assignment_url(
        self,
        assignment_id: str,
        organization_id: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> str:
        """Generate assignment url

        Args:
            task_id: task id.
            assignment_id: assignment id.
            organization_id: optional organization identifier. Defaults to None.
            base_url: optional url prefix.

        Returns:
            link to assignment.
        """
        return await self.client.gen_assignment_url(
            assignment_id=assignment_id, organization_id=organization_id, base_url=base_url
        )

    @autodoc.section("urls")
    async def gen_task_url(
        self, project_id: str, task_id: str, organization_id: Optional[str] = None, base_url: Optional[str] = None
    ) -> str:
        """Generate task url.

        Args:
            project_id: project id.
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.
            base_url: optional url prefix.

        Returns:
            link to task.
        """
        return await self.client.gen_task_url(
            project_id=project_id, task_id=task_id, organization_id=organization_id, base_url=base_url
        )

    @autodoc.section("urls")
    def gen_file_url(self, file_id: str, base_url: Optional[str] = None) -> str:
        """Generate file url.

        Args:
            file_id: file id.
            base_url: optional url prefix.

        Returns:
            link to file.
        """
        return self.client.gen_file_url(file_id=file_id, base_url=base_url)

    @autodoc.section("urls")
    async def gen_project_url(
        self, project_id: str, organization_id: Optional[str] = None, base_url: Optional[str] = None
    ) -> str:
        """Generate project url.

        Args:
            project_id: project id.
            organization_id: optional organization identifier. Defaults to None.
            base_url: optional url prefix.

        Returns:
            link to project.
        """
        return await self.client.gen_project_url(
            project_id=project_id, organization_id=organization_id, base_url=base_url
        )

    @autodoc.exclude
    async def wait_for_blocked(self, task_id: str, blocked: bool, organization_id: Optional[str] = None) -> None:
        for _ in range(10):
            res = await self.get_task_info(task_id=task_id, organization_id=organization_id)
            if res['is_blocked'] is blocked:
                break
            logger.info(f'Task {task_id} is not blocked yet, retrying 10x2sec')
            await asyncio.sleep(2)
        else:
            raise RuntimeError(f'Task status is broken (not is_blocked={blocked}) for {task_id}.')

    @autodoc.section("task")
    async def unarchive_task(self, task_id: str, organization_id: Optional[str] = None) -> None:
        """Unarchive task.

        Args:
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.


        """
        await self.client.unarchive_task(task_id=task_id, organization_id=organization_id)

    @autodoc.section("task")
    async def archive_task(self, task_id: str, organization_id: Optional[str] = None) -> None:
        """Archive task.

        Args:
            task_id: task id.
            organization_id: optional organization identifier.
        """
        await self.client.archive_task(task_id=task_id, organization_id=organization_id)

    @autodoc.section("task")
    async def start_task(
        self,
        task_id: str,
        organization_id: Optional[str] = None,
        retry_amount: int = 15,  # pylint: disable=unused-argument
        wait_seconds: float = 3,  # pylint: disable=unused-argument
    ) -> TaskData:
        """Start task.

        Args:
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.
            retry_amount: (deprecated) number of retries of starting task. Defaults to 15.
            wait_seconds: (deprecated) seconds to wait between retries. Defaults to 3.
        Returns:
            task data.

        """
        if retry_amount != 15 or wait_seconds != 3:
            warnings.warn("parameters 'retry_amount' and 'wait_seconds' are deprecated", DeprecationWarning)

        return await self.client.start_task(task_id=task_id, organization_id=organization_id)

    @autodoc.section("task")
    async def check_task(self, task_id: str, organization_id: Optional[str] = None) -> CheckTaskResult:
        """Check task settings before start.

        Args:
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            current task settings.
        """
        return await self.client.check_task(task_id=task_id, organization_id=organization_id)

    @autodoc.section("task")
    async def stop_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        """Stop task and wait for it to stop.

        Args:
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            task data.
        """
        task_data = await self.client.stop_task(task_id=task_id, organization_id=organization_id)
        await self.wait_for_blocked(task_id=task_id, blocked=False, organization_id=organization_id)
        return task_data

    @autodoc.section("task")
    async def get_task_info(self, task_id: str, organization_id: Optional[str] = None) -> Dict:
        """Get information about task bucket in cloud.

        Args:
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            bucket information.
        """
        return await self.client.get_task_info(task_id=task_id, organization_id=organization_id)

    @autodoc.section("task")
    async def get_task_information(self, task_id: str, organization_id: Optional[str] = None) -> TaskInfo:
        """Get information about task.

        Args:
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            task information.
        """
        return await self.client.get_task_information(task_id=task_id, organization_id=organization_id)

    @autodoc.section("task")
    async def complete_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        """Complete task.

        Args:
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            task data.
        """
        return await self.client.complete_task(task_id=task_id, organization_id=organization_id)

    @autodoc.section("task")
    async def remove_task(self, task_id: str, organization_id: Optional[str] = None) -> None:
        """Remove task

        Args:
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.remove_task(task_id=task_id, organization_id=organization_id)

    @autodoc.section("project")
    async def get_project(
        self, project_id: str, with_tasks_count: bool = False, organization_id: Optional[str] = None
    ) -> Project:
        """Get project by id.

        Args:
            project_id: project id.
            with_tasks_count: if set, return project with tasks count. Defaults to False.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            project data.
        """
        return await self.client.get_project(
            project_id=project_id, with_tasks_count=with_tasks_count, organization_id=organization_id
        )

    @autodoc.section("pool")
    async def add_marker(
        self, marker_email: str, pools: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        """Add marker to pools.

        Args:
            marker_email: marker email.
            pools: pools to add marker to.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object with errors while adding marker to pools.
        """
        return await self.client.add_marker(marker_email=marker_email, pools=pools, organization_id=organization_id)

    @autodoc.section("pool")
    async def add_markers(
        self, emails: List[str], pools: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        """Add markers to pools.

        Args:
            emails: emails of markers.
            pools: pools to add markers to.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object with errors while adding markers to pools.
        """
        return await self.client.add_markers(emails=emails, pools=pools, organization_id=organization_id)

    @autodoc.section("employee")
    async def get_marker_info(
        self, marker_id: str, with_pools: bool, with_info: bool, organization_id: Optional[str] = None
    ) -> Employee:
        """Get full information about organization employee.

        Args:
            marker_id: marker id.
            with_pools: if set, return information about marker pools.
            with_info: if set, return person info about marker.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            full information about marker.
        """
        return await self.client.get_marker_info(
            marker_id=marker_id, with_pools=with_pools, with_info=with_info, organization_id=organization_id
        )

    @autodoc.section("employee")
    async def add_employee_to_organization(
        self, person_id: str, roles: List[str] = None, organization_id: Optional[str] = None
    ) -> Employee:
        """Add new employee to organization.

        Args:
            person_id: person id to add to organization.
            roles: roles to add to person (CUSTOMER, ORGANIZATION_ADMIN).
                If set to None or [], person will be added as marker.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            :class:`~crowd_sdk.tagme.http_client.datacls.Employee`:
            employee information.
        """
        return await self.client.add_employee_to_organization(
            person_id=person_id, roles=roles, organization_id=organization_id
        )

    @autodoc.section("employee")
    async def get_employee(self, user_id: str, organization_id: Optional[str] = None) -> Employee:
        """Get information about organization's employee.

        Args:
            user_id: user id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            :class:`~crowd_sdk.tagme.http_client.datacls.Employee`:
            employee information.
        """
        organization_id = organization_id or await self.get_current_organization_id()
        employees = await self.get_employees(person_ids=[user_id], organization_id=organization_id)
        if not employees:
            raise ValueError(f'Roles for {user_id} {organization_id} not found')
        if len(employees) > 1:
            raise ValueError(f'too many roles for {user_id} {organization_id}')
        return employees[0]

    # config
    @autodoc.section("employee")
    async def set_user_config(
        self, user_id: str, config: Dict[str, Any], organization_id: Optional[str] = None
    ) -> None:
        """Set employee config.

        Args:
            user_id: user id.
            config: employee config.
            organization_id: optional organization identifier. Defaults to None.
        """
        employee = await self.get_employee(user_id, organization_id)
        await self.client.set_employee_info(employee.uid, config=config, organization_id=organization_id)

    @autodoc.section("employee")
    async def get_user_config(self, user_id: str, organization_id: Optional[str] = None) -> Dict[str, Any]:
        """Get employee config.

        Args:
            user_id: user id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            employee config.
        """
        employee = await self.get_employee(user_id, organization_id)
        return employee.config

    @autodoc.section("employee")
    async def update_user_config(
        self, user_id: str, config: Dict[str, Any], organization_id: Optional[str] = None
    ) -> None:
        """Update employee config.

        Args:
            user_id: user id.
            config: employee config.
            organization_id: optional organization identifier. Defaults to None.
        """
        employee = await self.get_employee(user_id, organization_id)
        await self.client.update_employee_info(employee.uid, config=config, organization_id=organization_id)

    # profile
    @autodoc.section("employee")
    async def set_user_profile(
        self, user_id: str, profile: Dict[str, Any], organization_id: Optional[str] = None
    ) -> None:
        """Set user profile.

        Args:
            user_id: user id.
            profile: user profile.
            organization_id: optional organization identifier. Defaults to None.
        """
        employee = await self.get_employee(user_id, organization_id)
        await self.client.set_employee_info(employee.uid, profile=profile, organization_id=organization_id)

    @autodoc.section("employee")
    async def get_user_profile(self, user_id: str, organization_id: Optional[str] = None) -> Dict[str, Any]:
        """Get user profile.

        Args:
            user_id: user id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            user profile.
        """
        employee = await self.get_employee(user_id=user_id, organization_id=organization_id)
        return employee.profile

    @autodoc.section("employee")
    async def update_user_profile(
        self, user_id: str, profile: Dict[str, Any], organization_id: Optional[str] = None
    ) -> None:
        """Update user profile.

        Args:
            user_id: user id.
            profile: user profile.
            organization_id: optional organization identifier. Defaults to None.
        """
        employee = await self.get_employee(user_id=user_id, organization_id=organization_id)
        await self.client.update_employee_info(employee.uid, profile=profile, organization_id=organization_id)

    @autodoc.section("plugin")
    async def add_plugin(self, user_id: str, plugin: Plugin, organization_id: Optional[str] = None) -> None:
        """Add new plugin to user. If it has same route as another plugin, it would be replaced.

        Args:
            user_id: user id.
            plugin: plugin data.
            organization_id: optional organization identifier. Defaults to None.
        """
        profile = await self.get_user_profile(user_id=user_id, organization_id=organization_id)
        plugin_json = dataclass_to_dict(plugin, exclude=('type',))
        key = 'customer_plugins' if plugin.type == PluginTypes.CUSTOMER else 'marker_plugins'

        if key not in profile:
            profile[key] = []

        index = None
        for idx, item in enumerate(profile[key]):
            if 'route' not in item:
                continue
            if item['route'] == plugin.route:
                index = idx
                break

        if index is None:
            profile[key].append(plugin_json)
        else:
            profile[key][index] = plugin_json

        await self.update_user_profile(
            user_id=user_id,
            organization_id=organization_id,
            profile=profile,
        )

    @autodoc.section("plugin")
    async def remove_plugin(
        self, user_id: str, route: str, plugin_type: PluginTypes, organization_id: Optional[str] = None
    ) -> None:
        """Remove plugin from user by its route.

        Args:
            user_id: user id.
            route: route of plugin to remove.
            plugin_type: plugin type (CUSTOMER or MARKER).
            organization_id: optional organization identifier. Defaults to None.
        """

        profile = await self.get_user_profile(user_id=user_id, organization_id=organization_id)
        key = 'customer_plugins' if plugin_type == PluginTypes.CUSTOMER else 'marker_plugins'

        if key not in profile:
            return

        index = None
        for idx, item in enumerate(profile[key]):
            if 'route' not in item:
                continue
            if item['route'] == route:
                index = idx
                break

        if index is not None:
            del profile[key][index]

        await self.update_user_profile(
            user_id=user_id,
            organization_id=organization_id,
            profile=profile,
        )

    # roles
    @autodoc.section("employee")
    async def set_user_roles(
        self, user_id: str, roles: Optional[List[str]], organization_id: Optional[str] = None
    ) -> None:
        """Set user roles.

        Args:
            user_id: user id.
            roles:
                list of user roles. Available roles are: 'CUSTOMER', 'ORGANIZATION_ADMIN',
                pass empty list to set marker role.
            organization_id: optional organization identifier. Defaults to None.
        """
        employee = await self.get_employee(user_id=user_id, organization_id=organization_id)
        await self.client.set_employee_info(employee.uid, roles=roles, organization_id=organization_id)

    @autodoc.section("employee")
    async def get_user_roles(self, user_id: str, organization_id: str) -> Optional[List[str]]:
        """Get user roles.

        Args:
            user_id: user id.
            organization_id: organization identifier.

        Returns:
            list user roles or None. None or empty list stands for marker role.
        """
        employee = await self.get_employee(user_id=user_id, organization_id=organization_id)
        return employee.roles

    # report
    @autodoc.section("employee")
    async def set_user_report(
        self, user_id: str, report: Dict[str, Any], organization_id: Optional[str] = None
    ) -> None:
        """Set user report.

        Args:
            user_id: user id.
            report: user report.
            organization_id: optional organization identifier. Defaults to None.
        """

        employee = await self.get_employee(user_id=user_id, organization_id=organization_id)
        await self.client.set_employee_info(employee.uid, report=report, organization_id=organization_id)

    @autodoc.section("employee")
    async def get_user_report(self, user_id: str, organization_id: Optional[str] = None) -> Dict[str, Any]:
        """Get user report

        Args:
            user_id: user id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            user report.
        """
        employee = await self.get_employee(user_id=user_id, organization_id=organization_id)
        return employee.report

    @autodoc.section("employee")
    async def update_user_report(
        self, user_id: str, report: Dict[str, Any], organization_id: Optional[str] = None
    ) -> None:
        """Update user report.

        Args:
            user_id: user id.
            report (Dict[str, Any]): user report.
            organization_id: optional organization identifier. Defaults to None.
        """
        employee = await self.get_employee(user_id=user_id, organization_id=organization_id)
        await self.client.update_employee_info(employee.uid, report=report, organization_id=organization_id)

    @autodoc.section("employee")
    async def get_employee_info(
        self,
        employee_id: str,
        with_pools: Optional[bool] = None,
        with_info: Optional[bool] = None,
        organization_id: Optional[str] = None,
    ) -> Employee:
        """Get full information about employee.

        Args:
            employee_id: employee id.
            with_pools: If set to True, load employee's pools. Defaults to None.
            with_info: if set to true, load personal info. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            full information about employee.
        """
        return await self.client.get_employee_info(
            employee_id=employee_id, with_pools=with_pools, with_info=with_info, organization_id=organization_id
        )

    @autodoc.section("employee")
    async def get_user_info(self, user_id: str, organization_id: Optional[str] = None) -> Employee:
        """Get information about employee.

        Args:
            user_id: user id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about employee.
        """
        markers = await self.get_employees(with_info=True, person_ids=[user_id], organization_id=organization_id)
        for marker in markers:
            if marker.person_id == user_id:
                return marker
        raise ValueError(f'user "{user_id}" not found')

    @autodoc.section("employee")
    async def get_employees(
        self,
        query: Optional[str] = None,
        person_ids: Optional[List[str]] = None,
        with_pools: Optional[bool] = None,
        with_info: Optional[bool] = None,
        organization_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        active: Optional[bool] = None,
        roles: Optional[List[str]] = None,
    ) -> List[Employee]:
        """Get information about employees.

        Args:
            query: search query. Defaults to None.
            person_ids: person ids. Defaults to None.
            with_pools: If set to True, load employee's pools. Defaults to None.
            with_info: If set to True, load personal info. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.
            page: page number for pagination. Defaults to None.
            size: page size for pagination. Defaults to None.
            active: If set to True, get only active employees. Defaults to None.
            roles: filter by roles (CUSTOMER or ORGANIZATION_ADMIN). Defaults to None.

        Returns:
            list of employees.
        """
        return await run_with_pagination(
            self.client.get_employees,
            query=query,
            with_pools=with_pools,
            with_info=with_info,
            organization_id=organization_id,
            person_ids=person_ids,
            active=active,
            roles=roles,
            page=page,
            size=size,
        )

    @autodoc.section("organization")
    async def set_organization(self, org_key: Optional[str]) -> None:
        """Set current organization which is used by client.

        Args:
            org_key: organization id or name. If set to None, sets first organization which was found.
        """
        await self.client.set_organization(org_key=org_key)

    @autodoc.section("files")
    async def download_file(self, task_id: str, file_id: str, organization_id: Optional[str] = None) -> bytes:
        """Download file by id.

        Args:
            task_id: task id to download file from.
            file_id: file id to download.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            file content.
        """
        return await self.client.download_file(task_id=task_id, file_id=file_id, organization_id=organization_id)

    @autodoc.section("statistics")
    async def get_task_stats(self, task_id: str, organization_id: Optional[str] = None) -> TaskStats:
        """Get statistics for task.

        Args:
            task_id: task id to get statistics for.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            task statistics.
        """
        return await self.client.get_task_stats(task_id=task_id, organization_id=organization_id)

    @autodoc.section("statistics")
    async def get_task_stats_advanced(self, task_id: str, organization_id: Optional[str] = None) -> TaskStatsAdvanced:
        """Get estimation date and number of assignments in progress for task.

        Args:
            task_id: task id to get statistics for.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            task statistics.
        """
        return await self.client.get_task_stats_advanced(task_id=task_id, organization_id=organization_id)

    @autodoc.section("statistics")
    async def get_list_tasks_statistics(
        self, task_ids: List[str], update_date_from: Optional[str] = None, organization_id: Optional[str] = None
    ) -> List[TaskStatisticsItem]:
        """Get statistics for selected tasks.

        Args:
            task_ids: task ids to get statistics for.
            update_date_from: filter by update date, return tasks whose statistics changed on or after that day
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            task statistics.
        """
        return await self.client.get_list_task_statictics(
            task_ids=task_ids, update_date_from=update_date_from, organization_id=organization_id
        )

    @autodoc.section("project")
    async def archive_projects(self, uids: List[str], organization_id: Optional[str] = None) -> Optional[dict]:
        """Archive projects.

        Args:
            uids: list of project ids to archive.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            empty dict.
        """
        return await self.client.archive_projects(uids=uids, organization_id=organization_id)

    @autodoc.section("project")
    async def restore_projects(self, uids: List[str], organization_id: Optional[str] = None) -> Optional[dict]:
        """Restore projects from archive.

        Args:
            uids: list of project ids to unarchive.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            empty dict.
        """
        return await self.client.restore_projects(uids=uids, organization_id=organization_id)

    @autodoc.section("marker")
    async def get_tasks_for_markup(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
    ) -> List[TaskflowTaskData]:
        """Get all task available for markup.

        Args:
            page: optional page number for pagination. Defaults to None.
            size: optional page size for pagination. Defaults to None.
            query: optional search query. Defaults to None.

        Returns:
            list of tasks for markup.
        """
        return await self.client.get_tasks_for_markup(page=page, size=size, query=query)

    @autodoc.section("marker")
    async def submit_markup_task(self, task_id: str, assignment_id: str, markup_result: Dict[str, Any]) -> None:
        """Submit markup task.

        Args:
            task_id: task id to submit.
            assignment_id: assignment id to submit.
            markup_result: result of markup.
        """
        return await self.client.submit_markup_task(
            task_id=task_id, assignment_id=assignment_id, markup_result=markup_result
        )

    @autodoc.section("marker")
    async def skip_markup_task(self, task_id: str, assignment_id: str) -> None:
        """Skip markup task,

        Args:
            task_id: task id to skip.
            assignment_id: assignment id to skip.
        """
        return await self.client.skip_markup_task(task_id=task_id, assignment_id=assignment_id)

    @autodoc.section("marker")
    async def get_markup_task(self, task_id: str) -> MarkupTask:
        """Get current assignment to markup in task.

        Args:
            task_id: task id.

        Returns:
            markup task.
        """
        return await self.client.get_markup_task(task_id=task_id)

    @autodoc.section("task")
    async def poll_for_task_state(
        self,
        task_id: str,
        state: TaskState,
        retry_amount: int = 15,
        wait_seconds: float = 3,
        organization_id: Optional[str] = None,
    ) -> TaskState:
        """Wait while task has needed state.

        Args:
            task_id: task id.
            state: task state needed.
            retry_amount: amount of retries for polling. Defaults to 15.
            wait_seconds: amount of seconds for polling. Defaults to 3.
            organization_id: optional organization id. Defaults to None.

        Returns:
            task state after finish of polling.
        """
        return await self.client.poll_for_task_state(
            task_id=task_id,
            state=state,
            retry_amount=retry_amount,
            wait_seconds=wait_seconds,
            organization_id=organization_id,
        )

    @autodoc.section("files")
    async def get_task_files_meta(self, task_id: str, organization_id: Optional[str] = None) -> List[FileMetaData]:
        """Get metadata for all files in task.

        Args:
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of task files metadata.
        """
        return await self.client.get_task_files_meta(task_id, organization_id=organization_id)

    @autodoc.section("person")
    async def get_self_person(self, with_organizations: bool = False) -> Person:
        """Get information about your user.

        Args:
            with_organizations: include available organizations. Defaults to False.

        Returns:
            your user information.
        """
        return await self.client.get_self_person(with_organizations=with_organizations)

    @autodoc.section("statistics")
    async def get_marker_stats(
        self,
        date_from: str,
        date_to: str,
        types: Iterable[str] = ('markers',),
        stats_format: str = 'csv',
        organization_id: Optional[str] = None,
    ) -> AsyncGenerator[Tuple[str, io.TextIOWrapper], None]:
        """Get statistics for marker in organization.

        Args:
            date_from: minimal date of statistics collection.
            date_to: maximal date of statistics collection.
            types: type of statistics ('markers', 'tasks').
            stats_format: format of statistics ('csv' or 'xlsx'). Defaults to 'csv'.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            marker statistics.
        """
        data = await self.client.get_marker_stats(
            date_from=date_from,
            date_to=date_to,
            types=types,
            stats_format=stats_format,
            organization_id=organization_id,
        )
        for fname, file in download_extract_zip(data):
            yield fname, io.TextIOWrapper(file)

    @autodoc.section("statistics")
    async def get_marker_project_stats(
        self,
        project_id: str,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: Iterable[str] = ('markers',),  # tasks
        stats_format: str = 'csv',
        organization_id: Optional[str] = None,
    ) -> AsyncGenerator[Tuple[str, io.TextIOWrapper], None]:
        """Get statistics for marker in project.

        Args:
            project_id: project id.
            from_date: minimal date of statistics collection.
            to_date: maximal date of statistics collection.
            types: type of statistics ('markers', 'tasks').
            stats_format: format of statistics ('csv' or 'xlsx'). Defaults to 'csv'.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            marker statistics.
        """
        data = await self.client.get_marker_project_stats(
            project_id=project_id,
            from_date=from_date,
            to_date=to_date,
            types=types,
            stats_format=stats_format,
            organization_id=organization_id,
        )
        for fname, file in download_extract_zip(data):
            yield fname, io.TextIOWrapper(file)

    @autodoc.section("statistics")
    async def get_project_stats(self, project_id: str, organization_id: Optional[str] = None) -> ProjectStatistic:
        """Get project statistics.

        Args:
            project_id: project id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            project statistics.
        """
        return await self.client.get_project_stats(project_id=project_id, organization_id=organization_id)

    @autodoc.section("statistics")
    async def get_organization_stats(self, organization_id: Optional[str] = None) -> OrganizationStatistic:
        """Get organization statistics.

        Args:
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            organization statistics.
        """
        return await self.client.get_organization_stats(organization_id=organization_id)

    @autodoc.section("skill")
    async def create_skill(self, name: str, organization_id: Optional[str] = None, is_public: bool = False) -> Skill:
        """Create new skill with given name.

        Args:
            name: skill name.
            organization_id: optional organization identifier. Defaults to None.
            is_public: is skill public. Defaults to False.

        Returns:
            created skill.
        """
        return await self.client.create_skill(name=name, organization_id=organization_id, is_public=is_public)

    @autodoc.section("skill")
    async def get_skills_list(
        self,
        query: Optional[str] = None,
        with_markers_count: Optional[bool] = None,
        organization_id: Optional[str] = None,
        size: Optional[int] = None,
        page: Optional[int] = None,
    ) -> List[Skill]:
        """Get all available skills.

        Args:
            query: search query for skill name.
            with_markers_count: include markers count which has this skill in response.
            organization_id: optional organization id. Defaults to None.
            size: page size for pagination. Defaults to None.
            page: page number for pagination. Defaults to None.

        Returns:
            list of skills.
        """
        return await run_with_pagination(
            self.client.get_skills_list,
            query=query,
            with_markers_count=with_markers_count,
            organization_id=organization_id,
            page=page,
            size=size,
        )

    @autodoc.section("skill")
    async def get_markers_skills_list(
        self,
        query: Optional[str] = None,
        size: Optional[int] = None,
        page: Optional[int] = None,
        organization_id: Optional[str] = None,
        with_info: Optional[bool] = None,
    ) -> List[MarkerSkill]:
        """Get list of markers' skills and their values.

        Args:
            query: search query for skill name. Defaults to None.
            size: size of page for pagination. Defaults to None.

        Returns:
            markers with their skills and skills' values.
        """
        func = partial(
            self.client.get_markers_skills_list,
            query=query,
            organization_id=organization_id,
            with_info=with_info,
        )
        return await run_with_has_next_pagination(
            func=func,
            page=page,
            size=size,
        )

    @autodoc.section("skill")
    async def get_public_skills_list(
        self,
        query: Optional[str] = None,
        size: Optional[int] = None,
        page: Optional[int] = None,
    ) -> List[PublicSkill]:
        """Get list of markers' skills and their values.

        Args:
            query: search query for skill name. Defaults to None.
            size: size of page for pagination. Defaults to None.
            page: page number for pagination. Defaults to None.

        Returns:
            markers with their skills and skills' values.
        """
        return await self.client.get_public_skills_list(query=query, size=size, page=page)

    @autodoc.section("skill")
    async def set_marker_skill(
        self, marker_id: str, skill_id: str, value: int, organization_id: Optional[str] = None
    ) -> SetMarkerSkillResponse:
        """Add skill and its value to marker.

        Args:
            marker_id: marker id to add skill to.
            skill_id: skill id to add to marker.
            value: skill value from 0 to 100.
            organization_id: organization identifier. Defaults to None.

        Returns:
            object which contains person_id, skill_id and skill value.
        """
        return await self.client.set_marker_skill(
            marker_id=marker_id, skill_id=skill_id, value=value, organization_id=organization_id
        )

    @autodoc.section("skill")
    async def set_markers_skills(
        self, table_path: Union[Path, str], organization_id: Optional[str] = None
    ) -> SetMarkersSkillsResponse:
        """Add skills to markers from table with columns 'person', 'skill', 'value'.

        Args:
            table_path: path to table with markers skill data to import.

        Returns:
            object which contains information about successfull updates and errors.
        """
        return await self.client.set_skills_by_markers(table_path=table_path, organization_id=organization_id)

    @autodoc.section("skill")
    async def set_markers_skills_json(
        self, json_data: List[Dict[str, Any]], organization_id: Optional[str] = None
    ) -> SetMarkersSkillsResponse:
        """Add skills to markers via list with objects inside.

        Args:
            json_data: list of dicts with fields 'person', 'skill', 'value'.

        Returns:
            object which contains information about successfull updates and errors.
        """
        return await self.client.set_skills_by_markers_with_json(json_data=json_data, organization_id=organization_id)

    @autodoc.section("skill")
    async def update_skill(
        self,
        skill_id: str,
        name: str,
        window_size: int = 10,
        is_public: bool = False,
        organization_id: Optional[str] = None,
    ) -> Skill:
        """Update information about skill.

        Args:
            skill_id: skill id to update.
            name: new skill name.
            window_size: new skill window size.
            is_public: is skill public. Defaults to False.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about updated skill.
        """
        return await self.client.update_skill(
            skill_id=skill_id,
            name=name,
            window_size=window_size,
            is_public=is_public,
            organization_id=organization_id,
        )

    @autodoc.section("skill")
    async def get_skill(self, skill_id: str, organization_id: Optional[str] = None) -> Skill:
        """Get information about skill by skill id.

        Args:
            skill_id: skill id to get information about.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about skill.
        """
        return await self.client.get_skill(
            skill_id=skill_id,
            organization_id=organization_id,
        )

    @autodoc.section("skill")
    async def rename_skill(self, skill_name: str, target_name: str, organization_id: Optional[str] = None) -> Skill:
        """Find skill by name and rename it. Only first found skill will be updated.

        Args:
            skill_name: skill name to search by.
            target_name: new skill name.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about updated skill.
        """
        skills = await self.get_skills_list(query=skill_name, organization_id=organization_id)
        target_skills = []
        for skill in skills:
            if skill.name == skill_name:
                target_skills.append(skill)
        if not target_skills:
            raise ValueError(f'No skill "{skill_name}" found')
        if len(target_skills) > 1:
            raise ValueError(f'More than one "{skill_name}" found')
        target_skill = target_skills[0]
        return await self.update_skill(
            skill_id=target_skill.uid,
            name=target_name,
            window_size=target_skill.window_size or 64,
            organization_id=organization_id,
        )

    @autodoc.section("skill")
    async def disable_skill(self, skill_id: str, organization_id: Optional[str] = None) -> None:
        """Disable skill.

        Args:
            skill_id: skill id to disable.
            organization_id: optional organization identifier. Defaults to None.
        """
        await self.client.disable_skill(skill_id=skill_id, organization_id=organization_id)

    @autodoc.section("skill")
    async def enable_skill(self, skill_id: str, organization_id: Optional[str] = None) -> None:
        """Enable skill.

        Args:
            skill_id: skill id to enable.
            organization_id: optional organization identifier. Defaults to None.
        """
        await self.client.enable_skill(skill_id=skill_id, organization_id=organization_id)

    @autodoc.section("task")
    async def set_task_payload(self, task_id: str, payload: dict, organization_id: Optional[str] = None) -> dict:
        """Set task payload.

        Args:
            task_id: task id to set payload for.
            payload: payload to set.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            new task payload.
        """
        return await self.client.set_task_payload(task_id=task_id, payload=payload, organization_id=organization_id)

    @autodoc.section("task")
    async def get_task_payload(self, task_id: str, organization_id: Optional[str] = None) -> dict:
        """Get task payload.

        Args:
            task_id: task id to get payload for.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            task payload.
        """
        return await self.client.get_task_payload(task_id=task_id, organization_id=organization_id)

    @autodoc.section("task")
    async def load_task_payload(self, task: TaskData) -> None:
        """Add payload to task (to 'payload' field).

        Args:
            task: task to load payload for.
        """
        task.payload = await self.client.get_task_payload(task_id=task.uid, organization_id=task.organization_id)

    @autodoc.section("project")
    async def load_project_method(self, project: Project, download_brief: bool = False) -> None:
        """Load project methodic (it contains brief and interface).

        Args:
            project: project to load method for.
            download_brief: download brief if it is a url. Sets is_brief_as_url to False for compatibility.
        """
        project.method = await self.get_method(
            method_id=project.method_id,
            organization_id=project.organization_id,
            download_brief=download_brief,
        )

    @autodoc.section("task")
    async def delete_task_payload(self, task_id: str, organization_id: Optional[str] = None) -> None:
        """Delete payload from task.

        Args:
            task_id: task id to delete payload for.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.delete_task_payload(task_id=task_id, organization_id=organization_id)

    @autodoc.section("organization")
    async def get_current_organization_id(self) -> str:
        """Get organization id which is currently used by client.

        Returns:
            current organization id.
        """
        return await self.client.get_current_organization_id()

    @autodoc.section("invites")
    async def get_active_vendor_change_request(self) -> Optional[VendorChangeRecord]:
        """Get active vendor change request for current user.

        Returns:
            Active vendor change request record or None if not found.
        """
        return await self.client.get_active_vendor_change_request()

    @autodoc.section("invites")
    async def cancel_vendor_change_request(self) -> None:
        """Cancel active vendor change request for current user.

        Returns:
            None.
        """
        return await self.client.cancel_vendor_change_request()

    @autodoc.section("invites")
    async def apply_partner_invite(self, invite_name: str, partner_id: str, utm_referral: Optional[str] = None) -> None:
        """Apply partner invite.

        Args:
            invite_name: invite name.
            partner_id: partner id.
            utm_referral: utm referral. Defaults to None.
        """
        return await self.client.apply_partner_invite(
            invite_name=invite_name, partner_id=partner_id, utm_referral=utm_referral
        )

    @autodoc.section("invites")
    async def get_invite(self, uid: str, organization_id: Optional[str] = None) -> InviteData:
        """Get invite by its id.

        Args:
            uid: invite id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            full information about invite.
        """
        return await self.client.get_invite(uid=uid, organization_id=organization_id)

    @autodoc.section("invites")
    async def put_invite(self, data: InviteData) -> InviteData:
        """Add new invite to organization.

        Args:
            data: invite data to create it.

        Returns:
            full information about created invite.
        """
        return await self.client.put_invite(data=data)

    @autodoc.section("invites")
    async def delete_invite(self, uid: str, organization_id: Optional[str] = None) -> InviteData:
        """Delete invite.

        Args:
            uid: invite id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            full information about deleted invite.
        """
        return await self.client.delete_invite(uid=uid, organization_id=organization_id)

    @autodoc.section("invites")
    async def get_invites_pending(
        self, organization_id: Optional[str] = None, invite_name: Optional[str] = None, state: str = 'NEW'
    ) -> List[InviteApplication]:
        """Get all the requests to join organization.

        Args:
            organization_id: optional organization identifier. Defaults to None.
            invite_name: filter by invite name. Defaults to None.
            state: filter by state. Defaults to 'NEW'.

        Returns:
            all the requests to join organization.
        """
        return await self.client.get_invites_pending(
            organization_id=organization_id, invite_name=invite_name, state=state
        )

    @autodoc.section("invites")
    async def accept_invite(self, invite_id: str, pools: List[str], organization_id: Optional[str] = None) -> None:
        """Approve request to join organization.

        Args:
            invite_id: invite id to approve.
            pools: list of pools to add user to.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.accept_invites(
            invite_request_ids=[invite_id], pool_ids=pools, organization_id=organization_id
        )

    @autodoc.section("invites")
    async def create_invite(self, data: InviteRequest) -> InviteData:
        """Create new invite to organization.

        Args:
            data: invite request data.

        Returns:
            created invite data.
        """
        return await self.client.create_invite(data=data)

    @autodoc.section("invites")
    async def create_invite_request(self, invite_id: str, organization_id: Optional[str] = None) -> InviteApplication:
        """Create request to join organization.

        Args:
            invite_id: invite id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            invite request data.
        """
        return await self.client.create_invite_request(invite_id=invite_id, organization_id=organization_id)

    @autodoc.section("invites")
    async def get_invites(
        self,
        active: bool = True,
        page: Optional[int] = None,
        size: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[InviteData]:
        """Get invites.

        Args:
            active: get only active invites. Defaults to True.
            page: page number for pagination. Defaults to None.
            size: page size for pagination. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of invites.
        """
        return await run_with_pagination(
            self.client.get_invites,
            active=active,
            organization_id=organization_id,
            page=page,
            size=size,
        )

    @autodoc.section("person")
    async def get_persons(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        emails: Optional[List[str]] = None,
        with_organizations: Optional[bool] = None,
        organization_id: Optional[str] = None,
        person_ids: Optional[List[str]] = None,
        only_active: Optional[bool] = None,
    ) -> List[Person]:
        """Get users list.

        Args:
            page: page number for pagination. Defaults to None.
            size: page size for pagination. Defaults to None.
            query: search query. Defaults to None.
            emails: list of emails to search. Defaults to None.
            with_organizations: include info about organizations. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.
            person_ids: list of person ids to search. Defaults to None.
            only_active: whether to include only active users. Defaults to None.

        Returns:
            list of users.
        """
        return await run_with_pagination(
            self.client.get_persons,
            query=query,
            emails=emails,
            with_organizations=with_organizations,
            organization_id=organization_id,
            person_ids=person_ids,
            only_active=only_active,
            page=page,
            size=size,
        )

    @autodoc.section("person")
    async def get_person(
        self,
        person_id: Optional[str] = None,
        organization_id: Optional[str] = None,
        email: Optional[str] = None,
        with_organizations: Optional[bool] = None,
    ) -> Person:
        """Get person by id or email.

        Args:
            person_id: person id. Cannot be passed together with email. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.
            email: person email. Cannot be passed together with person_id. Defaults to None.
            with_organizations: include info about organizations. Defaults to None.

        Returns:
            information about user.
        """
        assert (
            person_id is None and email is not None or person_id is not None and email is None
        ), 'provide only email or only person_id'
        if person_id is not None:
            persons = await self.get_persons(
                person_ids=[person_id], organization_id=organization_id, with_organizations=with_organizations
            )
        else:
            assert email is not None, 'provide person_id or email'
            persons = await self.get_persons(
                emails=[email], organization_id=organization_id, with_organizations=with_organizations
            )
        assert len(persons) == 1, 'person not found'
        return persons[0]

    @autodoc.section("pool")
    async def get_organization_pools(
        self,
        organization_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        with_shared_pools: Optional[bool] = None,
    ) -> List[Pool]:
        """Get pool in selected organization.

        Args:
            organization_id: optional organization identifier. Defaults to None.
            page: page number for pagination. Defaults to None.
            size: page size for pagination. Defaults to None.
            query: query to search by name or uid. Defaults to None.

        Returns:
            list of pools.
        """
        return await run_with_pagination(
            self.client.get_organization_pools,
            organization_id=organization_id,
            query=query,
            with_shared_pools=with_shared_pools,
            page=page,
            size=size,
        )

    @autodoc.section("pool")
    async def attach_user_to_pool(self, pool_id: str, user_id: str, organization_id: Optional[str] = None) -> bool:
        """Add user to pool.

        Args:
            pool_id: pool id to add user to.
            user_id: user id to add to pool.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            True if user was successfully added to pool, False otherwise.
        """
        return await self.client.attach_user_to_pool(pool_id=pool_id, user_id=user_id, organization_id=organization_id)

    @autodoc.section("pool")
    async def detach_user_from_pool(self, pool_id: str, user_id: str, organization_id: Optional[str] = None) -> bool:
        """Remove user from pool.

        Args:
            pool_id: pool id to remove user from.
            user_id: user id to remove from pool.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            True if user was successfully removed from pool, False otherwise.
        """
        return await self.client.detach_user_from_pool(
            pool_id=pool_id, user_id=user_id, organization_id=organization_id
        )

    @autodoc.section("pool")
    async def create_pool(
        self,
        markers: List[str],
        name: str,
        organization_id: Optional[str] = None,
        access: Optional[Literal["public", "organization", "private"]] = None,
        acl: Optional[List[str]] = None,
        group_type: Optional[Literal["MARKERS", "VALIDATORS"]] = None,
    ) -> Pool:
        """Create new pool.

        Access levels:

        - public: pool can be added to project in any organization.

        - organization: pool can be added only to project in the same organization or organization in acl.

        - private (or None): pool can be added only to project in the same organization.

        Args:
            markers: list of users ids to add to new pool.
            name: new pool name.
            organization_id: optional organization identifier. Defaults to None.
            access: pool access level. Defaults to None.
            acl: list of allowed organizations ids for 'organization' access. Defaults to None.
            group_type: type of pool (MARKERS or VALIDATORS). Defaults to None.

        Returns:
            information about newly created pool.
        """
        return await self.client.create_pool(
            markers=markers,
            name=name,
            organization_id=organization_id,
            access=access,
            acl=acl,
            group_type=group_type,
        )

    @autodoc.section("pool")
    async def get_pool(
        self, pool_id: str, with_markers: Optional[bool] = None, organization_id: Optional[str] = None
    ) -> Pool:
        """Get information about pool by id.

        Args:
            pool_id: pool id.
            with_markers: if True, return list of users in pool.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about pool.
        """
        return await self.client.get_pool(pool_id=pool_id, with_markers=with_markers, organization_id=organization_id)

    @autodoc.section("pool")
    async def update_pool(
        self,
        pool_id: str,
        name: str,
        organization_id: Optional[str] = None,
        access: Optional[Literal["public", "organization", "private"]] = None,
        acl: Optional[List[str]] = None,
    ) -> Pool:
        """Update pool name.

        Access levels:

        - public: pool can be added to project in any organization.

        - organization: pool can be added only to project in the same organization or organization in acl.

        - private (or None): pool can be added only to project in the same organization.

        Args:
            pool_id: pool id.
            name: new pool name.
            organization_id: optional organization identifier. Defaults to None.
            access: pool access level. Defaults to None.
            acl: list of allowed organizations ids for 'organization' access. Defaults to None.

        Returns:
            information about updated pool.
        """
        return await self.client.update_pool(
            pool_id=pool_id,
            name=name,
            organization_id=organization_id,
            access=access,
            acl=acl,
        )

    @autodoc.section("pool")
    async def delete_pool(self, pool_id: str, organization_id: Optional[str] = None) -> None:
        """Delete pool.

        Args:
            pool_id: pool id.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.delete_pool(pool_id=pool_id, organization_id=organization_id)

    @autodoc.section("pool")
    async def detach_markers(
        self, pool_id: str, uids: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        """Remove users from pool.

        Args:
            pool_id: pool id to remove users from.
            uids: list of users ids to remove from pool.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object which contains information about errors while removing users from pool.
        """
        return await self.client.detach_markers(pool_id=pool_id, uids=uids, organization_id=organization_id)

    @autodoc.section("pool")
    async def move_markers(
        self, pool_id: str, target_pool: str, uids: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        """Move users from one pool to another.

        Args:
            pool_id: pool id to move users from.
            target_pool: pool id to move users to.
            uids: list of users ids to move from pool to target pool.
            organization_id: optional organization identifier. Defaults to None.

        Returns; object which contains information about errors while moving users from pool to target pool.
        """
        return await self.client.move_markers(
            pool_id=pool_id, target_pool=target_pool, uids=uids, organization_id=organization_id
        )

    @autodoc.section("project")
    async def get_method(
        self,
        method_id: str,
        task_id: Optional[str] = None,
        organization_id: Optional[str] = None,
        download_brief: bool = False,
    ) -> MethodData:
        """Get methodic by id. It contains brief, interface, specification and config.
           If methodic is a url, brief will be downloaded and is_brief_as_url will be set to False.

        Args:
            method_id: method id.
            task_id: task id.
            organization_id: optional organization identifier. Defaults to None.
            download_brief: download brief if it is a url. Defaults to False.

        Returns:
            information about methodic.
        """
        method = await self.client.get_method(method_id=method_id, task_id=task_id, organization_id=organization_id)
        if (
            method.is_brief_as_url
            and method.marker_brief is not None
            and method.marker_brief.startswith("/files/")
            and download_brief
        ):
            brief_bytes = await self.download_dataset_file(
                file_id=method.marker_brief.rsplit("/", 1)[-1],
                organization_id=organization_id,
            )
            method.marker_brief = brief_bytes.decode("utf-8")
            method.is_brief_as_url = False
        return method

    @autodoc.section("project")
    async def update_method(
        self, method: Union[MethodData, MethodDataRequest, dict], organization_id: Optional[str] = None
    ) -> MethodData:
        """Update project methodic.

        Args:
            method: new method data.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about updated methodic.
        """
        if isinstance(method, dict):
            method_dc: MethodData = from_dict(data_class=MethodData, data=method)
        else:
            method_dc = method  # type: ignore

        marker_brief = method_dc.marker_brief
        is_brief_as_url = method_dc.is_brief_as_url

        if marker_brief is not None and is_brief_as_url:
            warnings.warn(
                "Changing 'marker_brief' while 'is_brief_as_url' is set to True is deprecated and will be ignored. "
                "To update the brief, either: use TagmeClientAdvanced.upload_methodics_file, "
                "or set 'is_brief_as_url' to False",
                DeprecationWarning,
            )

        method_dc.marker_brief = None
        method_dc.is_brief_as_url = None
        await self.client.update_method(method=method_dc, organization_id=organization_id)

        if marker_brief is not None and not is_brief_as_url:
            with TempDir() as tmp_dir:
                filename = Path(tmp_dir) / f"{str(uuid4())}.txt"
                with open(filename, "w") as f:
                    f.write(marker_brief)
                upload_result = await self.upload_methodics_file(
                    method_id=method_dc.uid,
                    filepath=filename,
                    file_type=MethodFileType.BRIEF,
                    organization_id=organization_id,
                )
                if not upload_result.created_files or upload_result.errors:
                    error_text = ""
                    if upload_result.errors:
                        error_text = str(upload_result.errors[0])
                    raise RuntimeError(f"Failed to upload methodic brief: {error_text}")
        return await self.get_method(method_dc.uid, organization_id=organization_id)

    @autodoc.section("project")
    async def list_method_brief_versions(
        self,
        method_id: str,
    ) -> List[BriefVersionInfo]:
        """Get all brief versions.

        Args:
            method_id: uid of method, brief belongs to
        Returns:
            information about method's brief versions
        """
        return await self.client.list_method_brief_versions(method_id=method_id)

    @autodoc.section("project")
    async def get_brief_version_info(
        self,
        method_id: str,
        version: Union[str, int] = "latest",
        date_time: Optional[datetime] = None,
        with_person_info: bool = False,
    ) -> Tuple[BriefVersionInfo, dict]:
        """Get certait brief version by its number or date.

        Args:
            method_id: uid of method, brief belongs to
            version: number of brief version or 'latest'
            date_time: datetime when version was used
            with_person_info: return personal information of version's author
        Returns:
            information about brief version with response headers
        """
        return await self.client.get_brief_version_info(
            method_id=method_id, version=version, date_time=date_time, with_person_info=with_person_info
        )

    @autodoc.section("project")
    async def get_method_brief(self, method_id: str) -> Tuple[str, dict]:
        """Get brief with headers by method id.

        Args:
            method_id: uid of method, brief belongs to
        Returns:
            tuple with brief content or url and response headers
        """
        return await self.client.get_method_brief(method_id=method_id)

    @autodoc.section("project")
    async def download_brief_version_file(
        self,
        method_id: str,
        version: Union[str, int] = "latest",
        date_time: Optional[datetime] = None,
    ) -> str:
        """Download certait brief version by its number or date.

        Args:
            method_id: uid of method, brief belongs to
            version: number of brief version or 'latest'
            date_time: datetime when version was used
        Returns:
            file of certain brief version
        """
        return (
            await self.client.download_brief_version_file(method_id=method_id, version=version, date_time=date_time)
        ).decode('utf-8')

    @autodoc.section("project")
    async def list_method_interface_versions(
        self,
        method_id: str,
    ) -> List[InterfaceVersionInfo]:
        """Get all interface versions.

        Args:
            method_id: uid of method, interface belongs to
        Returns:
            information about method's interface versions
        """
        return await self.client.list_method_interface_versions(method_id=method_id)

    @autodoc.section("project")
    async def get_interface_version_info(
        self,
        method_id: str,
        version: Union[str, int] = "latest",
        date_time: Optional[datetime] = None,
        with_person_info: Optional[bool] = None,
    ) -> InterfaceVersionInfo:
        """Get certait interface version by its number or date.

        Args:
            method_id: uid of method, interface belongs to
            version: number of interface version or 'latest'
            date_time: datetime when version was used
            with_person_info: return personal information of version's author
        Returns:
            information about interface version
        """
        return await self.client.get_interface_version_info(
            method_id=method_id, version=version, date_time=date_time, with_person_info=with_person_info
        )

    @autodoc.section("project")
    async def download_interface_version(
        self,
        method_id: str,
        version: Union[str, int] = "latest",
        date_time: Optional[datetime] = None,
        task_id: Optional[str] = None,
    ) -> InterfaceVersionInfo:
        """Download certait interface version by its number or date.

        Args:
            method_id: uid of method, interface belongs to
            version: number of interface version or 'latest'
            date_time: datetime when version was used
            task_id: id of task to get entities from
        Returns:
            data   of certain interface version
        """
        return await self.client.download_interface_version(
            method_id=method_id, version=version, date_time=date_time, task_id=task_id
        )

    @autodoc.section("project")
    async def update_method_brief(
        self,
        method_id: str,
        file_path: str,
        file_name: str,
    ) -> None:
        """Update brief file of method.

        Args:
            method_id: uid of method, brief belongs to
            file_path: path, where file is stored
            file_name: name of file
        Returns:
            None
        """
        return await self.client.update_method_brief(method_id=method_id, file_path=file_path, file_name=file_name)

    @autodoc.section("project")
    async def create_cross_project_validation_pipeline(
        self,
        config: PipelineInitialConfig,
        organization_id: Optional[str] = None,
    ) -> None:
        """Create validation pipeline between two different projects.

        Args:
            config: Configuration for the validation pipeline.
            organization_id: optional organization identifier. Defaults to None.
        """
        data_pipe = config.generate_validation_project_settings()
        quality_pipe = config.generate_source_project_settings()

        await self.update_project(
            config.validation_project_id,
            organization_id=organization_id,
            pipeline=data_pipe,
            is_pipeline_enabled=True,
        )
        await self.update_project(
            config.source_project,
            organization_id=organization_id,
            pipeline=quality_pipe,
            is_pipeline_enabled=True,
        )

    @autodoc.section("project")
    async def create_single_project_validation_pipeline(
        self,
        config: PipelineInitialConfig,
        organization_id: Optional[str] = None,
    ) -> None:
        """Create validation pipeline within a single project.
        The source and destination project IDs in the config must be the same.

        Args:
            config: Configuration for the validation pipeline.
            organization_id: optional organization identifier. Defaults to None.
        """
        if config.source_project != config.validation_project_id:
            raise ValueError(
                "For single project validation, source_project_id and destination_project_id must be the same."
            )

        pipeline_settings = config.generate_single_project_validation_settings()

        await self.update_project(
            config.validation_project_id,
            organization_id=organization_id,
            pipeline=pipeline_settings,
            is_pipeline_enabled=True,
        )

    @autodoc.section("project")
    async def create_validation_pipeline(
        self,
        config: PipelineInitialConfig,
        organization_id: Optional[str] = None,
    ) -> None:
        """Create validation pipeline.
        This method acts as a dispatcher, calling either create_cross_project_validation_pipeline
        or create_single_project_validation_pipeline based on the provided config.

        Args:
            config: Configuration for the validation pipeline.
            organization_id: optional organization identifier. Defaults to None.
        """
        if config.source_project == config.validation_project_id:
            await self.create_single_project_validation_pipeline(config, organization_id)
        else:
            await self.create_cross_project_validation_pipeline(config, organization_id)

    @autodoc.section("project")
    async def get_brief_read_status(
        self,
        method_id: str,
        organization_id: Optional[str] = None,
    ) -> BriefReadStatusData:
        """Get methodic brief read status by id.

        Args:
            method_id: method id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about methodic brief read status.
        """
        method = await self.client.get_brief_read_status(method_id=method_id, organization_id=organization_id)
        return method

    @autodoc.section("project")
    async def set_brief_read_status(
        self,
        method_id: str,
        read_token: str,
        organization_id: Optional[str] = None,
    ) -> None:
        """Set methodic brief read status by id.

        Args:
            method_id: method id.
            read_token: token from headers get_brief method
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            Nothing.
        """
        await self.client.set_brief_read_status(
            method_id=method_id, read_token=read_token, organization_id=organization_id
        )

    @autodoc.section("files")
    async def disable_control_task(self, task_id: str, file_uid: str, organization_id: Optional[str] = None) -> None:
        """Disable control task.

        Args:
            task_id: task id.
            file_uid: control task file uid to disable.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.disable_control_task(
            task_id=task_id, file_uid=file_uid, organization_id=organization_id
        )

    @autodoc.section("files")
    async def get_file(self, task_id: str, file_uid: str, organization_id: Optional[str] = None) -> TaskFile:
        """Get information about task file.

        Args:
            task_id: task id.
            file_uid: file uid to get information about.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about task file.
        """
        return await self.client.get_file(task_id=task_id, file_uid=file_uid, organization_id=organization_id)

    @autodoc.section("organization")
    async def get_full_organizations(
        self,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        org_ids: Optional[List[str]] = None,
        ignore_org: Optional[bool] = None,
    ) -> List[FullOrganization]:
        """Get information about organizations.

        Args:
            query: search query to filter organizations.
            page: page number for pagination. Defaults to None.
            size: page size for pagination. Defaults to None.
            org_ids: list of organization IDs to filter organizations. Defaults to None.
            ignore_org: whether to ignore organizations. Defaults to None.

        Returns:
            list of organizations.
        """
        return await run_with_pagination(
            self.client.get_full_organizations,
            query=query,
            org_ids=org_ids,
            ignore_org=ignore_org,
            page=page,
            size=size,
        )

    @autodoc.section("organization")
    async def get_full_organization(
        self, organization_id: str, with_employees: Optional[bool] = None
    ) -> FullOrganization:
        """Get information about organization by id.

        Args:
            organization_id: organization identifier.
            with_employees: include information about employees.

        Returns:
            information about organization.
        """
        return await self.client.get_full_organization(organization_id=organization_id, with_employees=with_employees)

    @autodoc.section("organization")
    async def update_organization(
        self,
        organization_id: str,
        name: Optional[str] = None,
        config: Optional[OrganizationConfig] = None,
        contacts: Optional[str] = None,
    ) -> FullOrganization:
        """Update organization info.

        Args:
            organization_id: organization identifier.
            name: new organization name.
            config: new organization config.
            contacts: new organization contacts.

        Returns:
            new organization info.
        """
        return await self.client.update_organization(
            organization_id=organization_id, name=name, config=config, contacts=contacts
        )

    @autodoc.section("results")
    async def download_table_results(
        self,
        task_id: str,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        organization_id: Optional[str] = None,
        make_file: bool = True,
    ) -> Optional[List]:
        """Get table with markup results and save to file.

        Args:
            task_id: task id to get results from.
            date_from: minimal date of results to get. Defaults to None.
            date_to: maximal date of results to get. Defaults to None.
            file_format: file format to save results ('csv', 'json', 'xlsx', 'tsv'). Defaults to 'csv'.
        """
        return await self.client.download_table_results(
            task_id=task_id,
            date_from=date_from,
            date_to=date_to,
            file_format=file_format,
            organization_id=organization_id,
            make_file=make_file,
        )

    @autodoc.section("attachments")
    async def download_attachment(
        self, attachment_url: str, dir_path: str, organization_id: Optional[str] = None
    ) -> str:
        """Download attachment by url and save to file.

        Args:
            attachment_url: attachment url to download.
            dir_path: path to directory to save attachment.

        Returns:
            path to saved attachment.
        """
        return await self.client.download_attachment(
            attachment_url=attachment_url, dir_path=dir_path, organization_id=organization_id
        )

    @autodoc.section("attachments")
    async def download_attachments(
        self, task_id: str, dir_path: str, organization_id: Optional[str] = None
    ) -> List[str]:
        """Download all attachments from task.

        Args:
            task_id: task id to download attachments from.
            dir_path: path to directory to save attachments.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of paths to saved attachments.
        """
        return await self.client.download_attachments(
            task_id=task_id, dir_path=dir_path, organization_id=organization_id
        )

    @autodoc.section("client")
    async def close(self) -> None:
        """Close client http connection.
        Always do it before finishing to work with client or use 'async with' construction.
        """
        return await self.client.close()

    # datasets

    @autodoc.section("dataset")
    async def create_dataset(
        self,
        name: str,
        access: str = 'organization',
        data_classification_level: Optional[str] = None,
        data_source: Optional[str] = None,
        organization_id: Optional[str] = None,
        acl: Optional[List[str]] = None,
        dataset_type: Optional[str] = DatasetType.DATASET.value,
    ) -> Dataset:
        """Create new dataset.

        Args:
            name: name of new dataset.
            data_classification_level: data classification level ('K2', 'K3').
            data_source: data source.
            organization_id: optional organization identifier. Defaults to None.
            access: access level.
            acl: access control list.
            dataset_type: dataset type

        Returns:
            Information about created dataset.
        """
        return await self.client.create_dataset(
            name=name,
            data_classification_level=data_classification_level,
            data_source=data_source,
            organization_id=organization_id,
            access=access,
            acl=acl,
            dataset_type=dataset_type,
        )

    @autodoc.section("dataset")
    async def update_dataset(
        self,
        dataset_id: str,
        name: str,
        access: str = 'organization',
        data_classification_level: Optional[str] = None,
        data_source: Optional[str] = None,
        organization_id: Optional[str] = None,
        acl: Optional[List[str]] = None,
    ) -> Dataset:
        """Update dataset information.

        Args:
            dataset_id: dataset id to update.
            name: name of new dataset.
            data_classification_level: data classification level ('K2', 'K3').
            data_source: data source.
            organization_id: optional organization identifier. Defaults to None.
            access: access level.
            acl: access control list.

        Returns:
            information about updated dataset.
        """
        return await self.client.update_dataset(
            dataset_id=dataset_id,
            name=name,
            data_classification_level=data_classification_level,
            data_source=data_source,
            organization_id=organization_id,
            access=access,
            acl=acl,
        )

    @autodoc.section("dataset")
    async def get_dataset(self, dataset_id: str, organization_id: Optional[str] = None) -> Dataset:
        """Get information about dataset.

        Args:
            dataset_id: dataset id to get information about.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about dataset.
        """
        return await self.client.get_dataset(dataset_id=dataset_id, organization_id=organization_id)

    @autodoc.section("dataset")
    async def get_org_lora_dataset(self, organization_id: Optional[str] = None) -> Dataset:
        """Get organization lora dataset.

        Args:
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            information about organization lora dataset.
        """
        return await self.client.get_org_lora_dataset(organization_id=organization_id)

    @autodoc.section("dataset")
    async def get_datasets(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        organization_id: Optional[str] = None,
        with_authors: Optional[bool] = None,
    ) -> List[Dataset]:
        """Get organization's datasets.

        Args:
            page: page number for pagination. Defaults to None.
            size: page size for pagination. Defaults to None.
            query: text query for filtering datasets.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of information about datasets.
        """
        return await self.client.get_datasets(
            page=page, size=size, query=query, organization_id=organization_id, with_authors=with_authors
        )

    # ----------items-----------
    @autodoc.section("dataset")
    async def get_dataset_files(
        self, dataset_id: str, organization_id: Optional[str] = None, with_authors: Optional[bool] = None
    ) -> List[DatasetFile]:
        """Get files from dataset (their id, name, url).

        Args:
            dataset_id: dataset id to get files from.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of files from dataset.
        """
        return await self.client.get_dataset_files(
            dataset_id=dataset_id, organization_id=organization_id, with_authors=with_authors
        )

    @autodoc.section("dataset")
    async def get_dataset_file(
        self,
        file_id: str,
        organization_id: Optional[str] = None,
    ) -> DatasetFile:
        """Get dataset file by file_id (its id, name, url).

        Args:
            file_id: dataset file id to get.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            file from dataset.
        """
        return await self.client.get_dataset_file(file_id=file_id, organization_id=organization_id)

    @autodoc.section("dataset")
    async def upload_folder_to_dataset(
        self,
        dataset_id: str,
        folder: Union[str, Path],
        exclude_ext_filter: Optional[Set[str]] = None,
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        """Upload files from folder to dataset.

        Args:
            dataset_id: id of dataset to upload files to.
            folder: path to folder with files to upload.
            exclude_ext_filter: set of file extensions to exclude.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object which contains information about uploaded files and errors.
        """
        return await self.client.upload_folder_to_dataset(
            dataset_id=dataset_id, folder=folder, exclude_ext_filter=exclude_ext_filter, organization_id=organization_id
        )

    @autodoc.section("dataset")
    async def upload_dataset_files(
        self,
        dataset_id: str,
        filepaths: Sequence[Union[str, Path]],
        batch_size: int = BATCH_SIZE,
        organization_id: Optional[str] = None,
        tqdm_on: Union[str, bool] = False,
    ) -> UploadFilesResult:
        """Upload selected files to dataset.

        Args:
            dataset_id: id of dataset to upload files to.
            filepaths: list of paths to files to upload.
            batch_size: size of batch used during uploading. Defaults to 16.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object which contains information about uploaded files and errors.
        """
        return await self.client.upload_dataset_files(
            dataset_id=dataset_id,
            filepaths=filepaths,
            batch_size=batch_size,
            organization_id=organization_id,
            tqdm_on=tqdm_on,
        )

    @autodoc.section("dataset")
    async def replace_dataset_file(
        self,
        dataset_id: str,
        file_id: str,
        filepath: Union[str, Path],
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        """Replace file under existing uid and link.

        Args:
            dataset_id: id of dataset to upload file to.
            file_id: id of file to replace.
            filepath: path to new file.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            object which contains information about uploaded file and errors.
        """
        return await self.client.replace_dataset_file(
            dataset_id=dataset_id,
            file_id=file_id,
            filepath=filepath,
            organization_id=organization_id,
        )

    @autodoc.section("dataset")
    async def download_dataset_data(
        self, dataset_id: str, destination_dir: Union[str, Path], organization_id: Optional[str] = None
    ) -> int:
        """Download files from dataset.

        Args:
            dataset_id: id of dataset to download files from.
            destination_dir: path to directory where files will be downloaded.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            number of files downloaded successfully.
        """
        destination_dir = Path(destination_dir)
        destination_dir.mkdir(parents=True, exist_ok=True)
        try:
            dataset_files = await self.client.get_dataset_files(dataset_id=dataset_id, organization_id=organization_id)
        except ClientResponseError as error:
            if error.status == HTTPForbidden.status_code:
                logger.error('Only dataset owner can download dataset data')
            return 0

        files_downloaded = 0
        for item in dataset_files:
            try:
                bytes_file = await self.client.download_dataset_file(
                    file_id=item.id,
                    organization_id=organization_id,
                )
            except ClientResponseError:
                continue

            async with aiofiles.open(destination_dir / item.name, mode='wb') as file:
                await file.write(bytes_file)
            files_downloaded += 1

        return files_downloaded

    @autodoc.section("dataset")
    async def download_dataset_file(
        self, file_id: str, organization_id: Optional[str] = None, with_headers: bool = False
    ) -> Union[bytes, Any]:
        """Download dataset file.

        Args:
            file_id: id of file to download.
            organization_id: optional organization identifier. Defaults to None.
            with_headers: if True, return tuple with bytes and headers. Defaults to False.

        Returns:
            bytes of file if with_headers is False, tuple with bytes and headers otherwise.
        """
        return await self.client.download_dataset_file(
            file_id=file_id, organization_id=organization_id, with_headers=with_headers
        )

    @autodoc.section("dataset")
    async def remove_dataset(self, dataset_id: str, organization_id: Optional[str] = None) -> None:
        """Delete dataset.

        Args:
            dataset_id: id of dataset to remove.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.remove_dataset(dataset_id=dataset_id, organization_id=organization_id)

    @autodoc.section("files")
    async def delete_file(self, file_id: str, organization_id: Optional[str] = None) -> None:
        """Delete file.

        Args:
            file_id: id of file to delete.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.delete_file(file_id=file_id, organization_id=organization_id)

    @autodoc.section("results")
    async def review_markup(self, review: MarkupReview, organization_id: str) -> None:
        """Leave review on markup task.

        Args:
            review: status (ACCEPTED, REJECTED), comment and quality to set to assignment.
            organization_id: organization identifier.
        """
        await self.client.review_markup(review, organization_id=organization_id)

    @autodoc.section("results")
    async def review_multiple_markups(
        self, reviews: Union[List[MarkupReview], List[dict]], organization_id: str
    ) -> MarkupReviewResult:
        """Leave reviews on multiple markup tasks.

        Args:
            reviews: status (ACCEPTED, REJECTED), comment and quality to set to assignment.
            organization_id: organization identifier.
        """
        return await self.client.review_multiple_markups(reviews=reviews, organization_id=organization_id)

    @autodoc.section("results")
    async def delete_assignments_quality(self, assignment_ids: List[str], organization_id: str) -> MarkupReviewResult:
        """Delete quality on multiple reviews of markup tasks.

        Args:
            assignment_ids: assignment ids where quality will be deleted
            organization_id: organization identifier.

        Returns:
            object which contains information about markup review errors.
        """
        return await self.client.delete_assignments_quality(
            assignment_ids=assignment_ids, organization_id=organization_id
        )

    @autodoc.section("results")
    async def delete_assignments_comments(self, assignment_ids: List[str], organization_id: str) -> MarkupReviewResult:
        """Delete comments on multiple reviews of markup tasks.

        Args:
            assignment_ids: assignment ids where quality will be deleted
            organization_id: organization identifier.

        Returns:
            object which contains information about markup review errors.
        """
        return await self.client.delete_assignments_comments(
            assignment_ids=assignment_ids, organization_id=organization_id
        )

    @autodoc.section("results")
    async def get_markup_result(self, assignment_id: str, organization_id: str) -> Optional[MarkupResult]:
        """Get result of assignment markup.

        Args:
            assignment_id: id of markup task.
            organization_id: organization identifier.

        Returns:
            object which contains information about markup task result.
        """
        return await self.client.get_markup_result(assignment_id=assignment_id, organization_id=organization_id)

    @autodoc.section("results")
    async def get_markup_result_index(self, assignment_id: str, organization_id: str) -> Optional[AssignmentIndex]:
        """Get indexing of assignment markup.

        Args:
            assignment_id: id of markup task.
            organization_id: organization identifier.

        Returns:
            object which contains information about previous and next markup task results.
        """
        return await self.client.get_markup_result_index(assignment_id=assignment_id, organization_id=organization_id)

    @autodoc.section("results")
    async def get_task_statistics(self, task_id: str, organization_id: str) -> Optional[TaskStatistics]:
        """Get markup stats for task.

        Args:
            task_id: id of task.
            organization_id: organization identifier.

        Returns:
            object which contains information task markup stats.
        """
        return await self.client.get_task_statistics(task_id=task_id, organization_id=organization_id)

    @autodoc.section("results")
    async def get_markup_results(  # pylint: disable=R0913
        self,
        task_id: str,
        organization_id: str,
        marker_ids: Optional[List[str]] = None,
        file_name: Optional[str] = None,
        file_ids: Optional[List[str]] = None,
        statuses: Optional[List[str]] = None,
        file_types: Optional[List[FileType]] = None,
        submitted_ats: Optional[List[date]] = None,
        assignment_ids: Optional[List[str]] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        sort_field: Optional[MarkupResultSortField] = None,
        sort_order: Optional[SortOrder] = None,
    ) -> MarkupResults:
        """Get results of markup.

        Args:
            task_id: id of markup task.
            organization_id: organization identifier.
            marker_ids: optional list of marker ids.
            file_name: filter by file name.
            file_ids: filter by file ids.
            statuses: filter by assignment status.
            file_types: filter by file type.
            submitted_ats: filter by submission date.
            assignment_ids: filter by assignment id.
            page: optional page number for pagination.
            size: optional page size for pagination.
            sort_field: field to sort results by.
            sort_order: sort order ('asc', 'desc').

        Returns:
            markup results.
        """
        return await self.client.get_markup_results(
            task_id=task_id,
            organization_id=organization_id,
            marker_ids=marker_ids,
            file_name=file_name,
            file_ids=file_ids,
            statuses=statuses,
            file_types=file_types,
            submitted_ats=submitted_ats,
            assignment_ids=assignment_ids,
            page=page,
            size=size,
            sort_field=sort_field,
            sort_order=sort_order,
        )

    @autodoc.section("results")
    async def get_assignment_result_by_marker(self, assignment_id: str) -> AssignmentResultByMarker:
        """Get assignment result for marker.

        Args:
            assignment_id: assignment id to retrieve results for

        Returns:
            Object containing information about assignment including markup result
        """
        return await self.client.get_assignment_result_by_marker(assignment_id=assignment_id)

    @autodoc.section("statistics")
    async def get_validate_time_statistics(
        self,
        organization_id: str,
        task_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> ValidateTimeStatistics:
        """Get validator time statistics.

        Args:
            organization_id: organization identifier.
            task_id: id of markup task.
            page: optional page number for pagination.
            size: optional page size for pagination.

        Returns:
            validate time statistics.
        """
        return await self.client.get_validate_time_statistics(
            task_id=task_id,
            organization_id=organization_id,
            page=page,
            size=size,
        )

    @autodoc.section("statistics")
    async def get_validate_time_statistics_by_customer(
        self,
        organization_id: str,
        task_ids: Optional[List[str]] = None,
        validator_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> ValidateTimeStatistics:
        """Get validator time statistics by customer.

        Args:
            organization_id: organization identifier.
            task_ids: ids of markup task.
            validator_id: id of validator.
            page: optional page number for pagination.
            size: optional page size for pagination.

        Returns:
            validate time statistics.
        """
        return await self.client.get_validate_time_statistics_by_customer(
            task_ids=task_ids,
            validator_id=validator_id,
            organization_id=organization_id,
            page=page,
            size=size,
        )

    @autodoc.section("statistics")
    async def get_markup_marker_statistics(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        sort_field: Optional[MarkupMarkerStatisticsSortField] = None,
        sort_order: Optional[SortOrder] = None,
    ) -> MarkupMarkerStatistics:
        """Get marker statistics.

        Args:
            page: optional page number for pagination.
            size: optional page size for pagination.
            query: filter by project name.
            start_date: filter by statistics start date.
            end_date: filter by statistics end date.
            sort_field: field to sort results by.
            sort_order: sort order ('asc', 'desc').

        Returns:
            marker statistics.
        """
        return await self.client.get_markup_marker_statistics(
            page=page,
            size=size,
            query=query,
            start_date=start_date,
            end_date=end_date,
            sort_field=sort_field,
            sort_order=sort_order,
        )

    @autodoc.exclude
    async def collect_org_events(
        self, from_to_date: str, cache: Optional[dict], organization_id: Optional[str] = None
    ) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, str]]:
        if not cache:
            cache = {
                'stats': {},
                'events': {},
            }

        task_statistics, _marker_statistics = await self.export_org_stats(
            from_date=from_to_date,
            to_date=from_to_date,
            types=['tasks'],
            organization_id=organization_id,
        )

        statuses = {}
        exceptions = []
        for task_stat in sorted(task_statistics, key=lambda x: x.task_id):
            try:
                if from_to_date not in cache['stats']:
                    cache['stats'][from_to_date] = {}
                completed_assignments, time_spent = cache['stats'][from_to_date].get(task_stat.task_id, (0, 0))
                completed_calculated = task_stat.completed_assignments
                if completed_calculated == completed_assignments:
                    statuses[task_stat.task_id] = 'NOT_CHANGED'
                    continue

                values = []
                for assignment in await self.get_task_assignments(
                    task_id=task_stat.task_id,
                    date_from=from_to_date,
                    date_to=from_to_date,
                    organization_id=organization_id,
                ):
                    values.append(assignment)
                if from_to_date not in cache['events']:
                    cache['events'][from_to_date] = {}
                cache['events'][from_to_date][task_stat.task_id] = values

                time_spent = (
                    sum(
                        (x.end_date - x.start_date).total_seconds()
                        for x in values
                        if x.end_date and x.start_date and not x.skipped_at
                    )
                    * 0.1
                    / 3600
                )
                if from_to_date not in cache['stats']:
                    cache['stats'][from_to_date] = {}
                cache['stats'][from_to_date][task_stat.task_id] = (len(values), time_spent)
                statuses[task_stat.task_id] = 'OK'

            except Exception as exc:  # pylint: disable=broad-except
                statuses[task_stat.task_id] = 'ERROR'
                exceptions.append((task_stat.task_id, exc, task_stat.task_id))

            for task_id, e, url in exceptions:
                logger.info(f'Failed to collect {task_id} {e}: {url}')

        return cache, statuses

    @autodoc.section("templates")
    async def get_template(self, template_id: str, organization_id: Optional[str] = None) -> Template:
        """
        Get a template by ID.

        Args:
            template_id (str): The ID of the template to get.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            Template: The template with the specified ID.
        """
        return await self.client.get_template(template_id=template_id, organization_id=organization_id)

    @autodoc.section("templates")
    async def create_template(
        self,
        name: str,
        description: Optional[str] = None,
        documentation: Optional[str] = None,
        contacts: Optional[str] = None,
        categories: Optional[List[str]] = None,
        from_method_id: Optional[str] = None,
        organization_id: Optional[str] = None,
        access: Optional[str] = None,
        acl: Optional[List[str]] = None,
    ) -> Template:
        """
        Create a new template.

        Args:
            name (str): The name of the template.
            description (Optional[str]): The description of the template.
            documentation (Optional[str]): The documentation of the template.
            contacts (Optional[str]): The contacts of the template.
            categories (Optional[List[str]]): The categories of the template.
            from_method_id (Optional[str]): The ID of the method to create the template from.
            organization_id: optional organization identifier. Defaults to None.
            access: (Optional[str]): The access level of the template.
            acl: (Optional[List[str]]): The ACL of the template.

        Returns:
            Template: The created template.
        """
        return await self.client.create_template(
            name=name,
            description=description,
            documentation=documentation,
            contacts=contacts,
            categories=categories,
            from_method_id=from_method_id,
            organization_id=organization_id,
            access=access,
            acl=acl,
        )

    @autodoc.section("templates")
    async def publish_template(self, template_id: str, organization_id: Optional[str] = None) -> None:
        """
        Publish a template.

        Args:
            template_id (str): The ID of the template to publish.
            organization_id: optional organization identifier. Defaults to None.

        """
        return await self.client.publish_template(template_id=template_id, organization_id=organization_id)

    @autodoc.section("templates")
    async def unpublish_template(self, template_id: str, organization_id: Optional[str] = None) -> None:
        """
        Unpublish a template.

        Args:
            template_id (str): The ID of the template to unpublish.
            organization_id: optional organization identifier. Defaults to None.

        """
        return await self.client.unpublish_template(template_id=template_id, organization_id=organization_id)

    @autodoc.section("templates")
    async def get_templates_list(
        self,
        query: Optional[str] = None,
        categories: Optional[List[str]] = None,
        archived: Optional[bool] = None,
        size: Optional[int] = None,
        page: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[Template]:
        """
        Get a list of templates.

        Args:
            query (Optional[str]): The query to search for.
            categories (Optional[List[str]]): The categories to filter by.
            archived (Optional[bool]): Flag to return only archived/unarchived.
            size (Optional[int]): Page size for pagination. Defaults to None.
            page (Optional[int]): The page number to return.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            List[Template]: A list of templates.
        """
        return await run_with_pagination(
            self.client.get_templates_list,
            query=query,
            categories=categories,
            archived=archived,
            size=size,
            page=page,
            organization_id=organization_id,
        )

    @autodoc.section("templates")
    async def update_template(
        self,
        template_id: str,
        name: str,
        description: Optional[str] = None,
        documentation: Optional[str] = None,
        contacts: Optional[str] = None,
        categories: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
        access: Optional[str] = None,
        acl: Optional[List[str]] = None,
    ) -> Template:
        """
        Update a template.

        Args:
            template_id (str): The ID of the template to update.
            name (str): The new name of the template.
            description (Optional[str]): The new description of the template.
            documentation (Optional[str]): The new documentation of the template.
            contacts (Optional[str]): The new contacts of the template.
            categories (Optional[List[str]]): The new categories of the template.
            organization_id: optional organization identifier. Defaults to None.
            access: (Optional[str]): The access level of the template.
            acl: (Optional[List[str]]): The ACL of the template.

        Returns:
            Template: The updated template.
        """
        return await self.client.update_template(
            template_id=template_id,
            name=name,
            description=description,
            documentation=documentation,
            contacts=contacts,
            categories=categories,
            organization_id=organization_id,
            access=access,
            acl=acl,
        )

    @autodoc.section("templates")
    async def check_template(self, template_id: str, organization_id: Optional[str] = None) -> CheckTemplateResult:
        """
        Check a template.

        Args:
            template_id (str): The ID of the template to check.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            CheckTemplateResult: The result of the check.
        """
        return await self.client.check_template(template_id=template_id, organization_id=organization_id)

    @autodoc.section("templates")
    async def get_published_templates_list(
        self,
        query: Optional[str] = None,
        categories: Optional[List[str]] = None,
        size: Optional[int] = None,
        page: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[Template]:
        """
        Get a list of published templates.

        Args:
            query (Optional[str]): The query to search for.
            categories (Optional[List[str]]): The categories to filter by.
            size (Optional[int]): Page size for pagination. Defaults to None.
            page (Optional[int]): The page number to return.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            List[Template]: A list of templates.
        """
        return await run_with_pagination(
            self.client.get_published_templates_list,
            query=query,
            categories=categories,
            size=size,
            page=page,
            organization_id=organization_id,
        )

    @autodoc.section("templates")
    async def apply_template_to_project(
        self,
        template_id: str,
        project_id: str,
        organization_id: Optional[str] = None,
        autoupdate_params: Optional[dict] = None,
    ) -> None:
        """
        Apply a template to a project.

        Args:
            template_id (str): The ID of the template to apply.
            project_id (str): The ID of the project to apply the template to.
            organization_id: optional organization identifier. Defaults to None.

        """
        return await self.client.apply_template_to_project(
            template_id=template_id,
            project_id=project_id,
            organization_id=organization_id,
            autoupdate_params=autoupdate_params,
        )

    @autodoc.section("templates")
    async def add_images_to_template(
        self, template_id: str, files_paths: List[str], organization_id: Optional[str] = None
    ) -> UploadFilesResult:
        """
        Add images to a template.

        Args:
            template_id (str): The ID of the template to add images to.
            files_paths (List[str]): The list containing the images to add.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            UploadFilesResult: The result of adding the images to the template.
        """
        return await self.client.add_images_to_template(
            template_id=template_id, files_paths=files_paths, organization_id=organization_id
        )

    @autodoc.section("templates")
    async def get_template_images_list(
        self, template_id: str, organization_id: Optional[str] = None
    ) -> SimpleImagesListResult:
        """
        Get a list of images for a template.

        Args:
            template_id (str): The ID of the template to get images for.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            SimpleImagesListResult: A list of images for the template.
        """
        return await self.client.get_template_images_list(template_id=template_id, organization_id=organization_id)

    @autodoc.section("templates")
    async def upload_template_preview(
        self, template_id: str, files_paths: List[str], organization_id: Optional[str] = None
    ) -> PreviewFileResult:
        """
        Upload a preview for a template.

        Args:
            template_id (str): The ID of the template to upload the preview for.
            files_paths (List[str]): The list containing the preview to upload.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            PreviewFileResult: The result of uploading the preview.
        """
        return await self.client.upload_template_preview(
            template_id=template_id, files_paths=files_paths, organization_id=organization_id
        )

    @autodoc.section("templates")
    async def delete_template_preview(self, template_id: str, organization_id: Optional[str] = None) -> None:
        """
        Delete the preview for a template.

        Args:
            template_id (str): The ID of the template to delete the preview for.
            organization_id: optional organization identifier. Defaults to None.

        """
        return await self.client.delete_template_preview(template_id, organization_id)

    @autodoc.section("templates")
    async def archive_template(self, template_id: str, organization_id: Optional[str] = None) -> None:
        """
        Archive a template.

        Args:
            template_id (str): The ID of the template to archive.
            organization_id: optional organization identifier. Defaults to None.

        """
        return await self.client.archive_template(template_id=template_id, organization_id=organization_id)

    @autodoc.section("templates")
    async def unarchive_template(self, template_id: str, organization_id: Optional[str] = None) -> None:
        """
        Unarchive a template.

        Args:
            template_id (str): The ID of the template to unarchive.
            organization_id: optional organization identifier. Defaults to None.

        """
        return await self.client.unarchive_template(template_id=template_id, organization_id=organization_id)

    # -----------------------------------------------------------------------------
    #                                  LORA - MODELS
    # -----------------------------------------------------------------------------

    @autodoc.section("lora-models")
    async def create_model(
        self,
        model_data: Union[ModelCreateRequest, dict],
        organization_id: Optional[str] = None,
    ) -> Model:
        """
        Create new model entity.

        Args:
            model_data: Dict or ModelCreateRequest dataclass.
            organization_id: optional organization. Defaults to current organization.

        Returns:
            Model: Created Model.
        """

        return await self.client.create_model(model_data=model_data, organization_id=organization_id)

    @autodoc.section("lora-models")
    async def get_model(
        self,
        model_id: str,
        organization_id: Optional[str] = None,
    ) -> Model:
        """Get model entity by uid.

        Args:
            model_id: Model identifier.
            organization_id: optional organization. Defaults to current organization.

        Returns:
            Model: Model.
        """

        return await self.client.get_model(model_id=model_id, organization_id=organization_id)

    @autodoc.section("lora-models")
    async def get_all_lora_models(
        self,
        organization_id: Optional[str] = None,
    ) -> List[Model]:
        """Get all organization models.

        Args:
            organization_id: optional organization. Defaults to current organization.

        Returns:
            List[Model]: list of Models.
        """
        return await self.client.get_all_lora_models(organization_id=organization_id)

    @autodoc.section("lora-models")
    async def delete_model(
        self,
        model_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        """
        Get model entity by uid.

        Args:
            model_id: Model identifier.
            organization_id: optional organization. Defaults to current organization.

        Returns:
            Model: Model.
        """

        return await self.client.delete_model(model_id=model_id, organization_id=organization_id)

    @autodoc.section("lora-models")
    async def verify_lora_configuration(
        self,
        business_task_id: str,
        model_version_id: str,
        organization_id: Optional[str] = None,
    ) -> VerifyLoraConfiguration:
        """Verify Lora configuration access.

        Args:
            business_initiative_id: business initiative id.
            model_id: model id.

        Returns:
            allowed,
            business_initiative_name,
            model_confidentional_category,
        """
        return await self.client.verify_lora_configuration(
            business_task_id=business_task_id,
            model_version_id=model_version_id,
            organization_id=organization_id,
        )

    @autodoc.section("lora-models")
    async def create_organization_configuration(
        self,
        configuration_data: Union[dict, CreateOrganizationConfiguration],
        organization_id: Optional[str] = None,
    ) -> OrganizationConfiguration:
        """Create organization configuration.

        Args:
            configuration_data: configuration data.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            created_configuration_info
        """
        return await self.client.create_organization_configuration(
            configuration_data=configuration_data,
            organization_id=organization_id,
        )

    @autodoc.section("lora-models")
    async def get_lora_configuration(
        self,
        organization_id: Optional[str] = None,
    ) -> OrganizationConfiguration:
        """Get lora configuration.

        Args:
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            lora configuration info.
        """
        return await self.client.get_lora_configuration(organization_id=organization_id)

    @autodoc.section("lora-models")
    async def delete_lora_configuration(
        self,
        organization_id: Optional[str] = None,
    ) -> None:
        """Soft delete lora configuration.

        Args:
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.delete_lora_configuration(organization_id=organization_id)

    @autodoc.section("lora-models")
    async def hard_delete_lora_configuration(
        self,
        organization_id: Optional[str] = None,
    ) -> None:
        """Hard delete lora configuration:
        delets all lora-models for the organization and then ints configuration.

        WARNING: This method will delete all lora-models for the organization.

        Args:
            organization_id: optional organization identifier. Defaults to None.
        """
        try:
            return await self.delete_lora_configuration(organization_id=organization_id)
        except APIResponseError:
            models = await self.get_all_lora_models(organization_id=organization_id)

            for model in models:
                await self.delete_model(
                    model_id=model.uid,
                    organization_id=organization_id,
                )

            return await self.delete_lora_configuration(organization_id=organization_id)

    @autodoc.section("lora-models")
    async def initialize_mls_project(
        self,
        organization_id: Optional[str] = None,
    ) -> None:
        """Initialize mls project.

        Args:
            business_initiative_id: id of business initiative.
            model_id: model id.
        """
        return await self.client.initialize_mls_project(organization_id=organization_id)

    @autodoc.section("lora-models")
    async def create_model_train(  # pylint: disable=too-many-arguments
        self,
        model_id: str,
        model_alias: str,
        model_tuned_alias: str,
        comment: str,
        file_id: Optional[str] = None,
        filename: Optional[str] = None,
        published: Optional[bool] = None,
        model_tuned_file_id: Optional[str] = None,
        model_tuned_id: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> str:
        """Create model train.

        Args:
            model_id: model id.
            model_alias: model alias.
            model_tuned_alias: model tuned alias.
            comment: comment.
            file_id: file id.
            filename: filename.
            published: published.
            model_tuned_file_id: model tuned file id.
            model_tuned_id: model tuned id.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            train id.
        """
        return await self.client.create_model_train(
            model_id=model_id,
            model_alias=model_alias,
            model_tuned_alias=model_tuned_alias,
            comment=comment,
            file_id=file_id,
            filename=filename,
            published=published,
            model_tuned_file_id=model_tuned_file_id,
            model_tuned_id=model_tuned_id,
            organization_id=organization_id,
        )

    @autodoc.section("lora-models")
    async def transit_file_to_ml_storage(
        self,
        model_id: str,
        train_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        """
        Transit file to ML storage.

        Args:
            model_id: model id.
            train_id: train id.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.transit_file_to_ml_storage(
            model_id=model_id, train_id=train_id, organization_id=organization_id
        )

    @autodoc.section("task")
    async def get_project_public_assignments(
        self,
        project_id: str,
        organization_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> GetProjectPublicAssignmentsResponse:
        """Get project public assignments.

        Args:
            project_id: project id
            organization_id: optional organization identifier. Defaults to None.
            page: optional page number. Defaults to None.
            size: optional page size. Defaults to None.

        Returns:
            public assignments for project.
        """
        return await self.client.get_project_public_assignments(
            project_id=project_id,
            organization_id=organization_id,
            page=page,
            size=size,
        )

    @autodoc.section("task")
    async def get_projects_with_public_assignments(
        self,
        organization_id: Optional[str] = None,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> List[ProjectsWithPublicAssignment]:
        """Get projects with public assignments.

        Args:
            organization_id: optional organization identifier. Defaults to None.
            query: optional search query. Defaults to None.
            page: optional page number. Defaults to None.
            size: optional page size. Defaults to None.

        Returns:
            projects with public assignments.
        """
        return await self.client.get_projects_with_public_assignments(
            organization_id=organization_id,
            query=query,
            page=page,
            size=size,
        )

    @autodoc.section("validators")
    async def send_validation_task(
        self,
        file_id: str,
        validators: List[Union[str, ValidationRequestItem]],
        test_file_id: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        """
        Send file validation task.

        Args:
            file_id: id of file to validate.
            validators: paths to needed validators.
            test_file_id: id of file with test data
            options: options to run validators with.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.send_validation_task(
            file_id=file_id,
            validators=validators,
            test_file_id=test_file_id,
            organization_id=organization_id,
        )

    @autodoc.section("validators")
    async def get_validation_status(
        self, file_id: str, organization_id: Optional[str] = None
    ) -> ValidationPipelineResult:
        """
        Get current validation status for file.

        Args:
            file_id: id of file on validation.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            ValidationPipelineResult: status of validation pipeline.
        """
        return await self.client.get_validation_status(file_id, organization_id=organization_id)

    @autodoc.section("validators")
    async def cancel_validation_task(
        self,
        file_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        """
        Cancel validation task.

        Args:
            file_id: id of file to cancel validation for.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.cancel_validation_task(file_id, organization_id=organization_id)

    @autodoc.section("validators")
    async def get_validators(self) -> List[ValidatorDetail]:
        """
        Get information about all available validators.

        Returns:
            List[ValidatorDetail]: information about all available validators.
        """
        return await self.client.get_validators()

    @autodoc.section("validators")
    async def get_validator(self, source: str) -> ValidatorDetail:
        """
        Get information about validator.

        Args:
            source: path to validator.

        Returns:
            ValidatorDetail: information about validator.
        """
        return await self.client.get_validator(source)

    @autodoc.section("validators")
    async def get_base_validators_source_code(self) -> Dict[str, str]:
        """
        Get source codes of all base validators.

        Returns:
            Dict[str, str]: mapping from file path to source code.
        """
        return await self.client.get_base_validators_source_code()

    @autodoc.section("validators")
    async def get_validator_source_code(self, source: str) -> str:
        """
        Get source code of validator.

        Args:
            source: path to validator.

        Returns:
            str: source code of validator.
        """
        return await self.client.get_validator_source_code(source)

    @autodoc.section("validators")
    async def get_validator_projects(
        self,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> List[ValidatorProject]:
        """
        Get list of projects available to validator.

        Args:
            :param size: page size
            :param page: page
            :param query: either uuid of project or name

        Returns:
            List: list of projects available for validator.
        """
        return await self.client.get_validator_projects(query=query, page=page, size=size)

    @autodoc.section("validators")
    async def get_validator_project(self, project_id: str) -> ValidatorProject:
        """
        Get project available to validator.

        Args:
            :param project_id: project uuid

        Returns:
            ValidatorProject: project available for validator.
        """
        return await self.client.get_validator_project(project_id=project_id)

    @autodoc.section("validators")
    async def get_validator_tasks(
        self,
        project_id: str,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> List[ValidatorTask]:
        """
        Get list of projects available to validator.

        Args:
            :param project_id: project uuid
            :param size: page size
            :param page: page
            :param query: either uuid of task or name

        Returns:
            List: list of tasks available in project for validator.
        """
        return await self.client.get_validator_tasks(project_id=project_id, query=query, page=page, size=size)

    @autodoc.section("validators")
    async def get_validator_task(
        self,
        project_id: str,
        task_id: str,
    ) -> ValidatorTask:
        """
        Get task available to validator.

        Args:
            :param task_id: task uuid
            :param project_id: project uuid

        Returns:
            ValidatorTask: task available for validator.
        """
        return await self.client.get_validator_task(project_id=project_id, task_id=task_id)

    @autodoc.section("validators")
    async def get_validator_user_info(
        self,
    ) -> ValidatorInfo:
        """
        Get validator user info.

        Returns:
            ValidatorInfo: info about validator.
        """
        return await self.client.get_validator_user_info()

    @autodoc.section("project")
    async def get_project_with_least_markup_time(
        self,
        projects: List[Project],
        from_date: Union[Tuple[int, int, int], str] = None,  # year, month, day
        to_date: Union[Tuple[int, int, int], str] = None,  # year, month, day
    ) -> Project:
        """
        Get project with the least markup time. If params 'from_date' and 'to_date' are not specified, the last
        30 days are used to count marking speed.

        Args:
            projects: list of projects to compare
            from_date: start date for calculating the marking speed. Defaults to None
            to_date: end date for calculating the marking speed. Defaults to None
        Returns:
            Project: the project with the least remaining markup time
        """

        now = datetime.now()
        if from_date is None:
            from_date = (now - timedelta(days=30)).strftime("%Y-%m-%d")
        elif isinstance(from_date, tuple):
            from_date = f"{from_date[0]}-{from_date[1]:02d}-{from_date[2]:02d}"

        if to_date is None:
            to_date = now.strftime("%Y-%m-%d")
        elif isinstance(to_date, tuple):
            to_date = f"{to_date[0]}-{to_date[1]:02d}-{to_date[2]:02d}"

        project_stats = {}
        for p in projects:
            task_stats, _ = await self.client.export_project_stats(
                project_id=p.uid,
                from_date=from_date,
                to_date=to_date,
                types=[ExportTypes.TASKS],
                organization_id=p.organization_id,
            )
            total_completed = sum(t.completed_assignments for t in task_stats)
            total_remaining = sum(t.count_assignments - t.completed_assignments for t in task_stats)

            if total_completed > 0:
                days_period = (
                    datetime.strptime(to_date, "%Y-%m-%d") - datetime.strptime(from_date, "%Y-%m-%d")
                ).days or 30
                speed_per_day = total_completed / days_period
                estimated_days_remaining = total_remaining / speed_per_day if speed_per_day > 0 else float('inf')
            else:
                estimated_days_remaining = float('inf')  # If there are no completed tasks

            project_stats[p.uid] = estimated_days_remaining

        if not project_stats:
            raise ValueError("Could not retrieve statistics for any project")

        min_project_id = min(project_stats, key=project_stats.__getitem__)
        project_map = {p.uid: p for p in projects}
        return project_map[min_project_id]

    @autodoc.section("validation")
    async def validate_task_results(
        self,
        task_id: str,
        algorithm: Literal["krippendorff", "spearman", "dawid_skene", "ttest", "confidence_interval"],
        criteria: List[str],
        options: Optional[dict] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        """
        Create a task to validate annotation results using the specified algorithm.

        This method triggers asynchronous processing. Results can be retrieved later using
        `get_task_results_validation_info`.

        Args:
            task_id: ID of the task for which validation is performed.
            algorithm: Algorithm used for consistency analysis. Available options:
                - **krippendorff**: Krippendorff's alpha.
                - **spearman**: Spearman’s rank correlation coefficient.
                - **dawid_skene**: Dawid-Skene model.
                - **ttest**: One-sample t-test.
                - **confidence_interval**: Confidence interval for the mean.

            criteria: List of criterion names to analyze (e.g., `["relevance", "grammar"]`).
            options: Optional algorithm-specific parameters:
                - For **spearman**:
                    - `min_periods` (int, default: 3) — minimum number of overlapping ratings
                    needed to compute correlation.
                - For **ttest**:
                    - `thresholds` (dict) — mapping from criterion name to threshold value (e.g., `{"relevance": 3.5}`).
                    The test checks if the mean rating is significantly greater than this threshold (one-sided).
                - For **confidence_interval**:
                    - `thresholds` (dict, optional) — business thresholds per criterion. If provided,
                    the result includes whether the lower bound of the CI exceeds
                    the threshold (indicating robust exceedance).
                - For **krippendorff**:
                    - `difference_function` (str, default: "ordinal") — level of measurement for the data:
                    "nominal", "ordinal", "interval", or "ratio". Affects how differences are computed.
                - For **dawid_skene**:
                    - `thresholds` (dict, optional) — business thresholds per criterion.
                    - `run_ttest` (bool, default: True) — whether to run a one-sample t-test over dawid_skene results.
                    - `run_ci` (bool, default: True) — whether to compute confidence intervals for dawid_skene results.

                Example:
                ```python
                options = {
                    "thresholds": {"criterion_1": 3.0, "criterion_2": 4.0},
                    "min_periods": 2,
                    "difference_function": "ordinal"
                }
                ```

            organization_id: Optional organization identifier. Used for internal routing.

        Examples:
            Example 1: Run Krippendorff's alpha with custom measurement level:
            ```python
            await client.validate_task_results(
                task_id="cb9f9d92-120a-4c99-afc4-c1de6529bfc4",
                algorithm="krippendorff",
                criteria=["relevance", "grammar"],
                options={"level_of_measurement": "ordinal"}
            )
            ```

            Example 2: Compute confidence intervals and check business thresholds:
            ```python
            await client.validate_task_results(
                task_id="cb9f9d92-120a-4c99-afc4-c1de6529bfc4",
                algorithm="confidence_interval",
                criteria=["relevance", "grammar"],
                options={"thresholds": {"relevance": 4.0, "grammar": 0.5}}
            )
            ```

            Example 3: Perform one-sample t-test against quality thresholds:
            ```python
            await client.validate_task_results(
                task_id="cb9f9d92-120a-4c99-afc4-c1de6529bfc4",
                algorithm="ttest",
                criteria=["relevance", "grammar"],
                options={"thresholds": {"relevance": 4.0, "grammar": 0.5}}
            )
            ```

            Example 4: Use Spearman correlation with low minimum overlap:
            ```python
            await client.validate_task_results(
                task_id="cb9f9d92-120a-4c99-afc4-c1de6529bfc4",
                algorithm="spearman",
                criteria=["relevance", "grammar"],
                options={"min_periods": 2}
            )
            ```

            Example 5: Dawid-Skene aggregation (no options needed):
            ```python
            await client.validate_task_results(
                task_id="cb9f9d92-120a-4c99-afc4-c1de6529bfc4",
                algorithm="dawid_skene",
                criteria=["relevance", "grammar"],
                options={
                    "thresholds": {"relevance": 4.0, "grammar": 0.5},
                    "run_ttest": True,
                    "run_ci": False
                }
            )
            ```

        Note:
            Validation results are available asynchronously. Use `get_task_results_validation_info`
            to retrieve the status and output of the validation task.
        """
        return await self.client.validate_task_results(
            task_id=task_id,
            algorithm=algorithm,
            criteria=criteria,
            options=options,
            organization_id=organization_id,
        )

    @autodoc.section("validation")
    async def get_task_results_validation_info(
        self, task_id: str, organization_id: Optional[str] = None
    ) -> TaskResultsValidationInfo:
        """
        Get results and statuses of tasks validation.

        Args:
            task_id: id of task to get validation results info for.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            TaskResultsValidationInfo: validation info
        """
        return await self.client.get_task_results_validation_info(
            task_id=task_id,
            organization_id=organization_id,
        )

    @autodoc.section("validation")
    async def download_all_task_results_validation_info(
        self,
        task_id: str,
        output_path: Union[str, Path],
        organization_id: Optional[str] = None,
    ) -> None:
        """
        Download and aggregate all consistency validation results for a task into a single JSON file.

        This method:
        - Fetches all validation task info for the given task.
        - Downloads result files for each validation run.
        - Aggregates results with metadata (algorithm, criteria, options, status) into one JSON.
        - Saves the aggregated results to the specified output path.

        Args:
            task_id: ID of the task to retrieve consistency results for.
            output_path: Path to save the aggregated JSON results.
            organization_id: Optional organization identifier.

        Example:
            ```python
            await client.download_all_consistency_results(
                task_id="cb9f9d92-120a-4c99-afc4-c1de6529bfc4",
                output_path="consistency_summary.json"
            )
            ```
            Output format:
            ```json
            {
            "krippendorff": {
                "status": "completed",
                "message": null,
                "options": {"difference_function": "ordinal"},
                "mean_result": 0.9,
                "result": {
                "criterion_1": 0.92,
                "criterion_2": 0.87
                }
            },
            "spearman": {
                "status": "completed",
                "message": null,
                "options": {"min_periods": 3},
                "mean_result": 0.85,
                "result": {
                "criterion_1": 0.85,
                "criterion_2": 0.81
                }
            }
            }
            ```
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Получаем информацию о валидациях
        validation_info = await self.get_task_results_validation_info(task_id=task_id, organization_id=organization_id)

        aggregated_results = {}

        for result_info in validation_info.latest_results:
            algorithm = result_info.algorithm
            file_id = result_info.result_file_id
            options = result_info.params.get("options")
            mean_result = result_info.mean_result

            # Получаем статус
            status_entry = next(
                (s for s in validation_info.latest_statuses if s.algorithm == algorithm),
                None,
            )
            status = status_entry.status if status_entry else "unknown"
            message = status_entry.message if status_entry else None

            # Скачиваем файл с результатами
            if file_id and (status in ('success', 'failed')):
                try:
                    result_file_data = await self.download_dataset_file(file_id)
                    result = json.loads(result_file_data.decode("utf-8"))
                except Exception as e:
                    result = {"error": f"Failed to download or parse result file: {str(e)}"}
            else:
                result = {"error": "No result file available"}

            # Сохраняем всё в агрегированный словарь
            aggregated_results[algorithm] = {
                "status": status,
                "message": message,
                "mean_result": mean_result,
                "options": options or {},
                "result": result,
            }

        # Сохраняем в JSON
        with output_path.open("w", encoding="utf-8") as f:
            json.dump(aggregated_results, f, ensure_ascii=False, indent=4)

    @autodoc.section("plugin")
    # pylint: disable=too-many-arguments
    async def create_plugin_template(
        self,
        name: str,
        description: Optional[str] = None,
        documentation: Optional[str] = None,
        contacts: Optional[str] = None,
        access: Literal["public", "organization", "private"] = "private",
        title: Optional[str] = None,
        config: Optional[dict] = None,
        acl: Optional[List[str]] = None,
        scope: Literal["SIDEBAR"] = "SIDEBAR",
        roles: Optional[List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]] = None,
        organization_id: Optional[str] = None,
    ) -> PluginTemplate:
        """Create plugin template.

        Args:
            name: plugin name.
            description: plugin description.
            documentation: plugin documentation.
            contacts: plugin owner's contacts.
            access: access.
            title: title to show in sidebar.
            config: plugin configuration.
            acl: organizations to share template with (if access is organization).
            scope: scope of plugin (now only SIDEBAR).
            roles: available roles.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            created plugin template.
        """
        return await self.client.create_plugin_template(
            name=name,
            description=description,
            documentation=documentation,
            contacts=contacts,
            access=access,
            title=title,
            config=config,
            acl=acl,
            scope=scope,
            roles=roles,
            organization_id=organization_id,
        )

    @autodoc.section("plugin")
    # pylint: disable=too-many-arguments
    async def update_plugin_template(
        self,
        plugin_template_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        documentation: Optional[str] = None,
        contacts: Optional[str] = None,
        access: Optional[Literal["public", "organization", "private"]] = None,
        title: Optional[str] = None,
        config: Optional[dict] = None,
        acl: Optional[List[str]] = None,
        scope: Optional[Literal["SIDEBAR"]] = None,
        roles: Optional[List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]] = None,
        organization_id: Optional[str] = None,
    ) -> PluginTemplate:
        """Update plugin template.

        Args:
            plugin_template_id: plugin template id to update
            name: plugin name
            description: plugin description
            documentation: plugin documentation
            contacts: plugin owner's contacts
            access: access
            title: title to show in sidebar
            config: plugin configuration
            acl: organizations to share template with (if access is organization)
            scope: scope of plugin (now only SIDEBAR)
            roles: available roles
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            updated plugin template.
        """
        return await self.client.update_plugin_template(
            plugin_template_id=plugin_template_id,
            name=name,
            description=description,
            documentation=documentation,
            contacts=contacts,
            access=access,
            title=title,
            config=config,
            acl=acl,
            scope=scope,
            roles=roles,
            organization_id=organization_id,
        )

    @autodoc.section("plugin")
    async def delete_plugin_template(self, plugin_template_id: str, organization_id: Optional[str] = None) -> None:
        """Delete plugin template.

        Args:
            plugin_template_id: plugin template id to delete
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.delete_plugin_template(
            plugin_template_id=plugin_template_id, organization_id=organization_id
        )

    @autodoc.section("plugin")
    async def get_plugin_template(
        self, plugin_template_id: str, organization_id: Optional[str] = None
    ) -> PluginTemplate:
        """Get plugin template.

        Args:
            plugin_template_id: plugin template id to get
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            plugin template info.
        """
        return await self.client.get_plugin_template(
            plugin_template_id=plugin_template_id, organization_id=organization_id
        )

    @autodoc.section("plugin")
    async def get_plugin_templates(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> List[PluginTemplate]:
        """Get plugin templates created by current organization's users.

        Args:
            page: page number for pagination.
            size: number of items per page for pagination.
            query: optional search query for file names.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of plugin templates.
        """
        func = partial(
            self.client.get_plugin_templates,
            query=query,
            organization_id=organization_id,
        )
        return await run_with_has_next_pagination(
            func=func,
            page=page,
            size=size,
        )

    @autodoc.section("plugin")
    async def get_published_plugin_templates(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> List[PluginTemplate]:
        """Get plugin templates available to install for current organization.

        Args:
            page: page number for pagination.
            size: number of items per page for pagination.
            query: optional search query for file names.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            list of plugin templates.
        """
        func = partial(
            self.client.get_published_plugin_templates,
            query=query,
            organization_id=organization_id,
        )
        return await run_with_has_next_pagination(
            func=func,
            page=page,
            size=size,
        )

    @autodoc.section("plugin")
    async def publish_plugin_template(self, plugin_template_id: str, organization_id: Optional[str] = None) -> None:
        """Publish plugin template.

        Args:
            plugin_template_id: plugin template id to publish.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.publish_plugin_template(
            plugin_template_id=plugin_template_id, organization_id=organization_id
        )

    @autodoc.section("plugin")
    async def unpublish_plugin_template(self, plugin_template_id: str, organization_id: Optional[str] = None) -> None:
        """Unpublish plugin template.

        Args:
            plugin_template_id: plugin template id to unpublish.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.unpublish_plugin_template(
            plugin_template_id=plugin_template_id, organization_id=organization_id
        )

    @autodoc.section("plugin")
    async def check_plugin_template(
        self, plugin_template_id: str, organization_id: Optional[str] = None
    ) -> CheckPluginTemplateResult:
        """Check if plugin template is ready for publishing.

        Args:
            plugin_template_id: plugin template id to check.
            organization_id: optional organization identifier. Defaults to None.

        Results:
            object with check status.
        """
        return await self.client.check_plugin_template(
            plugin_template_id=plugin_template_id, organization_id=organization_id
        )

    @autodoc.section("plugin")
    async def create_organization_plugin(
        self,
        plugin_template_id: str,
        roles: List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]],
        route: str,
        enabled: bool = True,
        organization_id: Optional[str] = None,
    ) -> PluginAssignment:
        """Install plugin template for organization.

        Args:
            plugin_template_id: plugin template id to install.
            roles: roles which will see plugin.
            route: route for plugin.
            enabled: enable/disable plugin.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            info about installed plugin.
        """
        return await self.client.create_organization_plugin(
            plugin_template_id=plugin_template_id,
            roles=roles,
            route=route,
            enabled=enabled,
            organization_id=organization_id,
        )

    @autodoc.section("plugin")
    async def update_organization_plugin(
        self,
        plugin_assignment_id: str,
        enabled: Optional[bool] = False,
        roles: Optional[List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]] = None,
        route: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> PluginAssignment:
        """Update installed plugin.

        Args:
            plugin_assignment_id: plugin assignment id to update.
            enabled: enable/disable plugin.
            roles: roles which will see plugin.
            route: route for plugin.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            info about installed plugin.
        """
        return await self.client.update_organization_plugin(
            plugin_assignment_id=plugin_assignment_id,
            enabled=enabled,
            roles=roles,
            route=route,
            organization_id=organization_id,
        )

    @autodoc.section("plugin")
    async def delete_organization_plugin(
        self,
        plugin_assignment_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        """Uninstall plugin from organization.

        Args:
            plugin_assignment_id: plugin assignment id to delete.
            organization_id: optional organization identifier. Defaults to None.
        """
        return await self.client.delete_organization_plugin(
            plugin_assignment_id=plugin_assignment_id, organization_id=organization_id
        )

    @autodoc.section("plugin")
    async def get_organization_plugins(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> List[InstalledPlugin]:
        """Get plugins installed for current organization.

        Args:
            page: page number for pagination.
            size: number of items per page for pagination.
            query: optional search query for plugin names.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            plugins installed for current organization.
        """
        func = partial(
            self.client.get_organization_plugins,
            query=query,
            organization_id=organization_id,
        )
        return await run_with_has_next_pagination(
            func=func,
            page=page,
            size=size,
        )

    @autodoc.section("plugin")
    async def get_plugin_template_installations(
        self,
        plugin_template_id: str,
        organization_id: Optional[str] = None,
    ) -> List[PluginInstallation]:
        """Get organizations where plugin is installed.

        Args:
            plugin_template_id: plugin template id to get installations.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            organizations info where plugin is installed.
        """
        return await self.client.get_plugin_template_installations(
            plugin_template_id=plugin_template_id, organization_id=organization_id
        )

    @autodoc.section("plugin")
    async def get_my_plugins(
        self,
        scope: Literal["MARKER_SIDEBAR", "ORGANIZATION_SIDEBAR"] = "MARKER_SIDEBAR",
        disable_cache: bool = False,
        organization_id: Optional[str] = None,
    ) -> List[UserPlugin]:
        """Get current user plugins.

        Args:
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            short info about plugins available for current user.
        """
        return await self.client.get_my_plugins(
            scope=scope, disable_cache=disable_cache, organization_id=organization_id
        )

    @autodoc.section("plugin")
    async def upload_plugin_template_file(
        self,
        plugin_template_id: str,
        file_type: Literal["icon", "preview", "bundle"],
        file_path: str,
        organization_id: Optional[str] = None,
    ) -> PluginTemplateFileResult:
        """Upload file to plugin template.

        Args:
            plugin_template_id: plugin template id to upload file to.
            file_type: type of file to upload.
            file_path: path to file to upload.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            info about uploaded file.
        """
        return await self.client.upload_plugin_template_file(
            plugin_template_id=plugin_template_id,
            file_type=file_type,
            file_path=file_path,
            organization_id=organization_id,
        )

    # -----------------------------------------------------------------------------
    #                                  BONUSES
    # -----------------------------------------------------------------------------

    @autodoc.section("bonuses")
    async def add_bonuses(
        self,
        task_id: str,
        bonus: float,
        bonus_at: date,
        comment: str,
        marker_ids: List[str],
        average_quality: Optional[float] = None,
        marking_duration_secs: Optional[float] = None,
        marked_count: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> AddBonusesResponse:
        """
        Add bonuses to markers for their work on a task.

        Args:
            task_id: ID of the task for which bonuses are awarded.
            bonus: bonus amount to be paid to each marker.
            bonus_at: calendar date when the bonus was awarded. Interpreted by the server
                as a Moscow-time (MSK) date, so pass the MSK calendar day you want the
                bonus to be attributed to (e.g. statistics and daily aggregation are
                computed in MSK).
            comment: comment explaining the reason for the bonus.
            marker_ids: list of marker IDs who will receive the bonus.
            average_quality: average quality of work (optional).
            marking_duration_secs: total time spent on marking in seconds (optional).
            marked_count: number of items marked (optional).
            organization_id: optional organization identifier. Defaults to None.

        Example:
            ```python
            await client.add_bonuses(
                task_id="cb9f9d92-120a-4c99-afc4-c1de6529bfc4",
                bonus=500.0,
                bonus_at=date(2024, 1, 15),  # MSK calendar date
                comment="Excellent work quality",
                marker_ids=["marker_1", "marker_2"],
                average_quality=4.8,
                marking_duration_secs=3600,
                marked_count=150,
            )
            ```
        """
        bonus_at_str = bonus_at.isoformat()

        return await self.client.add_bonuses(
            task_id=task_id,
            bonus=bonus,
            bonus_at=bonus_at_str,
            comment=comment,
            marker_ids=marker_ids,
            average_quality=average_quality,
            marking_duration_secs=marking_duration_secs,
            marked_count=marked_count,
            organization_id=organization_id,
        )

    @autodoc.section("bonuses")
    async def get_bonuses(
        self,
        task_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
        author_ids: Optional[List[str]] = None,
        bonuses_ids: Optional[List[str]] = None,
        markers_ids: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
    ) -> TaskBonuses:
        """
        Get bonus information for a task with filtering and pagination.

        Args:
            task_id: ID of the task to get bonuses for.
            page: page number for pagination. Defaults to None.
            size: number of items per page. Defaults to None.
            author_ids: filter by author IDs. Defaults to None.
            bonuses_ids: filter by specific bonus IDs. Defaults to None.
            markers_ids: filter by marker IDs. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            TaskBonuses: list of bonuses with pagination info.

        Example:
            ```python
            bonuses = await client.get_bonuses(
                task_id="cb9f9d92-120a-4c99-afc4-c1de6529bfc4",
                page=1,
                size=50,
                markers_ids=["marker_1", "marker_2"]
            )
            ```
        """
        return await self.client.get_bonuses(
            task_id=task_id,
            page=page,
            size=size,
            author_ids=author_ids,
            bonuses_ids=bonuses_ids,
            markers_ids=markers_ids,
            organization_id=organization_id,
        )

    @autodoc.section("bonuses")
    async def edit_bonus(
        self,
        bonus_id: str,
        bonus: float,
        comment: str,
        average_quality: Optional[float] = None,
        marking_duration_secs: Optional[float] = None,
        marked_count: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        """
        Edit an existing bonus.

        Args:
            bonus_id: ID of the bonus to edit.
            bonus: new bonus amount.
            comment: new comment explaining the bonus.
            average_quality: updated average quality of work. Defaults to None.
            marking_duration_secs: updated marking duration in seconds. Defaults to None.
            marked_count: updated count of marked items. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Example:
            ```python
            await client.edit_bonus(
                bonus_id="bonus_123",
                bonus=750.0,
                comment="Updated bonus for exceptional performance",
                average_quality=4.9,
                marking_duration_secs=4200,
                marked_count=180
            )
            ```
        """
        return await self.client.edit_bonus(
            bonus_id=bonus_id,
            bonus=bonus,
            comment=comment,
            average_quality=average_quality,
            marking_duration_secs=marking_duration_secs,
            marked_count=marked_count,
            organization_id=organization_id,
        )

    @autodoc.section("bonuses")
    async def get_marker_stats_in_project(
        self,
        project_id: str,
        stats_at: Union[str, datetime],
        markers_ids: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
    ) -> MarkerStats:
        """
        Get marker statistics for a specific project and date.

        Args:
            project_id: ID of the project to get statistics for.
            date: date for which to get statistics (string in "YYYY-MM-DD" format or datetime object).
            markers_ids: filter by specific marker IDs. If None, returns stats for all markers. Defaults to None.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            MarkerStats: statistics for markers in the project.

        Example:
            ```python
            stats = await client.get_marker_stats_in_project(
                project_id="project_123",
                stats_at="2025-11-25T12:00:00.000Z",
                markers_ids=["marker_1", "marker_2"]
            )
            ```
        """
        return await self.client.get_marker_stats_in_project(
            project_id=project_id,
            stats_at=stats_at,
            markers_ids=markers_ids,
            organization_id=organization_id,
        )

    @autodoc.section("bonuses")
    async def get_task_bonuses_summary(
        self,
        task_id: str,
        organization_id: Optional[str] = None,
    ) -> TaskBonusesSummary:
        """
        Get summary information about bonuses for a task.

        Args:
            task_id: ID of the task to get bonus summary for.
            organization_id: optional organization identifier. Defaults to None.

        Returns:
            TaskBonusesSummary: summary information including total bonuses, counts, etc.

        Example:
            ```python
            summary = await client.get_task_bonuses_summary(
                task_id="cb9f9d92-120a-4c99-afc4-c1de6529bfc4"
            )
            ```
        """
        return await self.client.get_task_bonuses_summary(
            task_id=task_id,
            organization_id=organization_id,
        )

    # -----------------------------------------------------------------------------
    #                                  DATA GALAXY
    # -----------------------------------------------------------------------------

    @autodoc.section("data_galaxy")
    async def get_data_galaxy_datasets(
        self,
        limit: int = 10,
        offset: int = 0,
        q: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> DataGalaxyDatasetsList:
        """Get a paginated list of DataGalaxy datasets.

        Args:
            limit: Maximum number of datasets to return. Defaults to 10.
            offset: Number of datasets to skip. Defaults to 0.
            q: Optional search query to filter datasets.
            organization_id: Optional organization identifier. Defaults to None.

        Returns:
            DataGalaxyDatasetsList containing items, next_offset, and total_count.

        Example:
            ```python
            datasets = await client.get_data_galaxy_datasets(limit=10, offset=0)
            for ds in datasets.items:
                print(ds.title)
            ```
        """
        return await self.client.get_data_galaxy_datasets(
            limit=limit,
            offset=offset,
            q=q,
            organization_id=organization_id,
        )

    @autodoc.section("data_galaxy")
    async def get_data_galaxy_dataset(
        self,
        dataset_id: str,
        organization_id: Optional[str] = None,
    ) -> DataGalaxyDatasetData:
        """Get detailed information about a DataGalaxy dataset including its data records.

        Args:
            dataset_id: The unique identifier of the dataset.
            limit: Maximum number of data records to return. Defaults to 10.
            offset: Number of data records to skip. Defaults to 0.
            organization_id: Optional organization identifier. Defaults to None.

        Returns:
            DataGalaxyDatasetData containing dataset info and data records.

        Example:
            ```python
            dataset = await client.get_data_galaxy_dataset("dataset-123", limit=100)
            print(f"Dataset: {dataset.dataset.title}")
            print(f"Records: {len(dataset.data)}")
            ```
        """
        return await self.client.get_data_galaxy_dataset(
            dataset_id=dataset_id,
            organization_id=organization_id,
        )

    @autodoc.section("data_galaxy")
    async def download_data_galaxy_dataset(
        self,
        dataset_id: str,
        task_id: str,
        organization_id: Optional[str] = None,
    ) -> dict:
        """Download data from a DataGalaxy dataset into a TagMe task.

        This method triggers a server-side import of data from a DataGalaxy dataset
        into the specified TagMe task.

        Args:
            dataset_id: The unique identifier of the source DataGalaxy dataset.
            task_id: The identifier of the target TagMe task to download data into.
            organization_id: Optional organization identifier. Defaults to None.

        Returns:
            Response dict from the download operation.

        Example:
            ```python
            result = await client.download_data_galaxy_dataset(
                dataset_id="dg-dataset-123",
                task_id="task-456",
            )
            ```
        """
        return await self.client.download_data_galaxy_dataset(
            dataset_id=dataset_id,
            task_id=task_id,
            organization_id=organization_id,
        )

    @autodoc.section("data_galaxy")
    async def upload_data_galaxy_dataset(
        self,
        dataset_id: str,
        task_id: str,
        organization_id: Optional[str] = None,
    ) -> dict:
        """Upload data to a DataGalaxy dataset from a storage dataset.

        This method initiates an upload from a storage dataset to a DataGalaxy dataset.

        Args:
            dataset_id: The unique identifier of the target DataGalaxy dataset.
            task_id: The identifier of the source task dataset.
            organization_id: Optional organization identifier. Defaults to None.

        Returns:
            Response from the upload operation.

        Example:
            ```python
            result = await client.upload_data_galaxy_dataset(
                dataset_id="dg-dataset-123",
                task_id="some uid"
            )
            ```
        """
        return await self.client.upload_data_galaxy_dataset(
            dataset_id=dataset_id,
            task_id=task_id,
            organization_id=organization_id,
        )


class TagmeBotClient:
    def __init__(
        self,
        config: Union[str, Path, CrowdConfig, TagmeConfig] = DEFAULT_CONFIG,
        http: Optional[HttpWrapper] = None,
    ):
        self.client = TagmeClient(config=config, http=http)
        self.url = self.client.url

    async def get_tasks(self, page: Optional[int] = None, size: Optional[int] = None) -> List[TaskflowTaskData]:
        return await self.client.get_tasks_for_markup(page=page, size=size)

    async def get_markup_task(self, task_id: str) -> MarkupTask:
        return await self.client.get_markup_task(task_id=task_id)

    async def submit_markup_task(self, task_id: str, assignment_id: str, markup_result: Dict) -> None:
        return await self.client.submit_markup_task(
            task_id=task_id, assignment_id=assignment_id, markup_result=markup_result
        )

    async def get_task_file(self, task: MarkupTask) -> MarkupTaskFile:
        if not task.file_url.startswith('api/v0'):
            task.file_url = 'api/v0/' + task.file_url.strip('/')
        file_resp = await self.client.raw_request(HttpMethod.GET, task.file_url)

        return MarkupTaskFile(
            name=file_resp.content_disposition.filename if file_resp.content_disposition else None,
            content_type=file_resp.content_type,
            content=file_resp.content,
        )

    async def save_attachment(
        self, token: str, data: Union[bytes, str], filename: str, content_type: Optional[str] = None
    ) -> str:
        return await self.client.save_attachment(token=token, data=data, filename=filename, content_type=content_type)

    # FUTURE:
    async def get_train_set(self, task_id: str) -> List[MarkupTask]:
        raise NotImplementedError('get_train_set is not implemented yet')

    async def get_prod_set(self, task_id: str) -> List[MarkupTask]:
        raise NotImplementedError('get_prod_set is not implemented yet')

    async def submit_prod_set(self, task_id: str, prod_results: List[Tuple[str, Dict]]) -> None:
        raise NotImplementedError('submit_prod_set is not implemented yet')
