# pylint: disable=C0302
import asyncio
import json
import mimetypes
import os
import tempfile
import time
import warnings
from contextlib import ExitStack
from datetime import date, datetime
from functools import partial
from json.decoder import JSONDecodeError
from pathlib import Path
from typing import (
    Any,
    Callable,
    Coroutine,
    Dict,
    Generator,
    Iterable,
    List,
    Literal,
    Optional,
    Sequence,
    Set,
    Tuple,
    Union,
)

import aiofiles
import aiohttp
import aiohttp.client_exceptions
import urllib3
from aiohttp import FormData

from crowd_sdk.core.utils.common import cast_params, chunks
from crowd_sdk.core.utils.common import dataclass_from_dict as from_dict
from crowd_sdk.core.utils.common import dataclass_to_dict, logger
from crowd_sdk.core.utils.http_client import APIResponseError, HttpMethod
from crowd_sdk.core.utils.jwt_client import JWTAPI, HttpWrapper, ResponseType, Token
from crowd_sdk.tagme.config import DEFAULT_CLIENT_ID, DEFAULT_CONFIG, CrowdConfig, TagmeConfig
from crowd_sdk.tagme.http_client.common import preprocess_archive
from crowd_sdk.tagme.http_client.datacls import (
    EXPORT_SUFFIX,
    AddBonusesResponse,
    AssignAssignmentRequest,
    AssignAssignmentsResult,
    Assignment,
    AssignmentIndex,
    AssignmentResultByMarker,
    AssignMultipleAssignmentRequest,
    BriefReadStatusData,
    BriefVersionInfo,
    CheckPluginTemplateResult,
    CheckTaskResult,
    CheckTemplateResult,
    Contacts,
    CreateOrganizationConfiguration,
    DataGalaxyDatasetData,
    DataGalaxyDatasetInfo,
    DataGalaxyDatasetsList,
    Dataset,
    DatasetFile,
    DatasetType,
    DeleteAllFilesrResult,
    DeleteSomeFilesResult,
    Employee,
    ErrorMarkersResponse,
    ExportFormat,
    ExportTypes,
    FileMetaData,
    FileType,
    FullOrganization,
    GetProjectPublicAssignmentsResponse,
    InstalledPlugin,
    InterfaceVersionInfo,
    InviteApplication,
    InviteData,
    InviteRequest,
    Item,
    MarkerSkill,
    MarkersStatistic,
    MarkerStatInProject,
    MarkerStats,
    MarkupMarkerStatistics,
    MarkupMarkerStatisticsSortField,
    MarkupResult,
    MarkupResults,
    MarkupResultSortField,
    MarkupReview,
    MarkupReviewResult,
    MarkupTask,
    MetaData,
    MetaType,
    MethodData,
    MethodDataRequest,
    MethodFileType,
    Model,
    ModelCreateRequest,
    Organization,
    OrganizationConfig,
    OrganizationConfiguration,
    OrganizationStatistic,
    Person,
    PluginAssignment,
    PluginInstallation,
    PluginTemplate,
    PluginTemplateFileResult,
    Pool,
    PreviewFileResult,
    Project,
    ProjectStatistic,
    ProjectsWithPublicAssignment,
    ProjectTask,
    ProjectTaskPaginated,
    PublicSkill,
    SetMarkerSkillResponse,
    SetMarkersSkillsResponse,
    SimpleImagesListResult,
    Skill,
    SortOrder,
    SPInfo,
    TaskBonus,
    TaskBonuses,
    TaskBonusesSummary,
    TaskData,
    TaskDataRequest,
    TaskFile,
    TaskFilesCount,
    TaskflowTaskData,
    TaskHierarchy,
    TaskInfo,
    TaskResult,
    TaskResultsValidationInfo,
    TasksStatistic,
    TaskState,
    TaskStatistics,
    TaskStatisticsItem,
    TaskStats,
    TaskStatsAdvanced,
    TaskTabItemStats,
    Template,
    UpdateMetaDataRequest,
    UploadFilesResult,
    UserPlugin,
    ValidateTimeStatistics,
    ValidationPipelineResult,
    ValidationRequestItem,
    ValidatorDetail,
    ValidatorInfo,
    ValidatorProject,
    ValidatorTask,
    VendorChangeRecord,
    VerifyLoraConfiguration,
)
from crowd_sdk.tagme.http_client.sentry import init_sentry
from crowd_sdk.tagme.utils.datacls import SyncSettings
from crowd_sdk.tagme.utils.pagination import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    PaginatedResponse,
    get_paginated_response,
    run_with_pagination,
)

BATCH_SIZE = 16
UPLOAD_ATTEMPTS = 100


def clear_none(d: Dict[str, Any]) -> Dict[str, Any]:
    for k in list(d.keys()):
        if d[k] is None:
            del d[k]
    return d


def parse_date_tuple(dt: Union[Tuple[int, int, int], str]) -> str:
    if isinstance(dt, str):
        return dt
    else:
        return date(*dt).strftime('%Y-%m-%d')


def find_attachments(data: Any) -> Generator[str, None, None]:
    if isinstance(data, dict):
        for _, item in data.items():
            if isinstance(item, str) and 'attachment' in item:
                yield item
            elif isinstance(item, (dict, list)):
                yield from find_attachments(item)

    elif isinstance(data, list):
        for item in data:
            if isinstance(item, str) and 'attachment' in item:
                yield item
            elif isinstance(item, (dict, list)):
                yield from find_attachments(item)


def str_or_data(src: str) -> Any:
    if isinstance(src, int):
        return src
    try:
        return json.loads(src)
    except JSONDecodeError:
        return src


def row_to_task(row: Dict[str, Any]) -> Dict[str, Any]:  # pylint: disable=R0912
    task_data = {}
    control_data = {}
    premarkup_data = {}
    hint = {}
    file_path = None
    file_id = None

    for key, value in row.items():
        if key.startswith('GOLDEN:'):
            key = key[len('GOLDEN:') :]
            if value:
                control_data[key] = str_or_data(value)
        elif key.startswith('HINT:'):
            key = key[len('HINT:') :]
            if value:
                hint[key] = value
        elif key.startswith('PREMARKUP:'):
            key = key[len('PREMARKUP:') :]
            if value:
                premarkup_data[key] = str_or_data(value)
        elif key.startswith('BASELINE:'):
            key = key[len('BASELINE:') :]
            if value:
                premarkup_data[key] = str_or_data(value)
        elif key.startswith('INPUT:'):
            key = key[len('INPUT:') :]
            task_data[key] = str_or_data(value)
        elif key == 'PATH':
            file_path = value
        elif key == 'ID':
            file_id = value

    res = {
        'task': task_data,
        'file_path': file_path,
        'id': file_id,
    }
    if premarkup_data:
        res['premarkup'] = premarkup_data
    if control_data:
        res['control'] = control_data
    if hint:
        res['hint'] = '\n'.join(list(hint.values()))
    return res


class TagmeClient(JWTAPI):  # pylint: disable=too-many-public-methods
    def __init__(
        self,
        config: Union[str, Path, dict, CrowdConfig, TagmeConfig] = DEFAULT_CONFIG,
        http: Optional[HttpWrapper] = None,
    ) -> None:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        self.lock = asyncio.Lock()
        self.config: TagmeConfig = TagmeConfig.from_any(config)
        super().__init__(http=http, config=self.config, rate_limit=self.config.rate_limit)

        init_sentry(self.config)
        self.__org: Optional[Organization] = None
        self.__orgs: List[Organization] = []
        self.token_marker = Token(self.config, self.auth_http)
        self.token = self.token_marker.access_token
        self.token_orgs: Dict[str, Token] = {}

    async def __aenter__(self) -> 'TagmeClient':
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def get_org_token(self, org_id: Optional[str] = None) -> Token:
        filled_org_id = org_id or await self.get_current_organization_id()
        token = self.token_orgs.get(filled_org_id)
        if not token:
            token = self.update_org_token(filled_org_id)
        return token

    def update_org_token(self, org_id: str) -> Token:
        auth_headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Organization-id': org_id}
        token = Token(self.config, self.auth_http, auth_headers)
        self.token_orgs[org_id] = token
        return token

    def marker_header(self) -> Dict[str, str]:
        return {'Authorization': f'{self.auth_type} {self.token_marker.get_access_token()}'}

    async def request(
        self,
        method: HttpMethod,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        return_headers: bool = False,
        **kwargs: Any,
    ) -> Any:
        headers = headers or {}

        saved_params_org_id: Optional[str] = None
        saved_json_org_id: Optional[str] = None
        if 'Authorization' not in headers:
            if self.config.client_id == DEFAULT_CLIENT_ID:
                kw_org_id = kwargs.get('organization_id') or kwargs.get('params', {}).get('organization_id')
                saved_params_org_id = kw_org_id
                if not kw_org_id and isinstance(kwargs.get('json', {}), dict):
                    kw_org_id = kwargs.get('json', {}).get('organization_id')
                    saved_json_org_id = kw_org_id

                token_object = await self.get_org_token(kw_org_id)
                token = token_object.get_access_token()
            else:
                token = self.token_marker.get_access_token()

            headers['Authorization'] = f'{self.auth_type} {token}'
        headers['X-User-Id'] = self.token_marker.user_id

        kwargs.pop('organization_id', None)

        if 'params' in kwargs:
            kwargs['params'].pop('organization_id', None)

        res = await self._request(
            method, url, ssl_context=self.ssl_context, headers=headers, return_headers=return_headers, **kwargs
        )
        if saved_params_org_id is not None:
            kwargs['organization_id'] = saved_params_org_id
        if saved_json_org_id and "json" in kwargs:
            kwargs["json"]["organization_id"] = saved_json_org_id
        return res

    # -----------------------------------------------------------------------------
    #                                  CLIENT
    # -----------------------------------------------------------------------------

    async def get_self_person(self, with_organizations: bool = False) -> Person:
        url = 'api/v0/selfperson'
        resp = await self.get(
            url=url, params=cast_params(withOrganizations=with_organizations), headers=self.marker_header()
        )
        return from_dict(data_class=Person, data=resp)

    async def get_current_organization(self) -> Organization:
        if self.__org is None:
            return await self.set_organization(self.config.org)
        return self.__org

    async def get_current_organization_id(self) -> str:
        return (await self.get_current_organization()).uid

    async def get_current_organization_name(self) -> str:
        return (await self.get_current_organization()).name

    async def set_organization(self, org_key: Optional[str]) -> Organization:
        orgs = await self.get_organizations()
        for org in sorted(orgs, key=lambda x: 0 if 'CUSTOMER' in x.roles else 1):
            if org_key in (org.uid, org.name) or org_key is None:
                self.__org = org
                return org
        raise KeyError(f'Organization "{org_key}" not found in {orgs}')

    async def get_organization(self, org_key: Optional[str] = None) -> Organization:
        if self.__org:
            if org_key is None or org_key in (self.__org.uid, self.__org.name):
                return self.__org
        for org in await self.get_organizations():
            if org_key is None:
                return org
            if org_key in (org.uid, org.name):
                return org
        raise KeyError(f'Organization "{org_key}" not found in {self.__orgs}')

    async def get_organizations(self) -> List[Organization]:
        if not self.__orgs:
            person = await self.get_self_person(with_organizations=True)
            self.__orgs = person.organizations or []
        assert self.__orgs, 'There\'s no organizations for user'
        return self.__orgs

    # -----------------------------------------------------------------------------
    #                                  PROJECT
    # -----------------------------------------------------------------------------

    async def get_taskflow_projects(
        self,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        only_favourite: Optional[bool] = None,
        project_id: Optional[str] = None,
    ) -> ProjectTaskPaginated:
        """
        Get projects available for marking
        """
        url = "api/v0/taskflow/projects"
        params = cast_params(
            query=query,
            page=page,
            size=size,
            is_only_favourite=only_favourite,
            project_id=project_id,
        )

        resp = await self.get(url=url, params=params)
        items = [from_dict(data_class=ProjectTask, data=_) for _ in resp['items']]
        return ProjectTaskPaginated(items=items, has_next=resp['has_next'])

    # pylint: disable=too-many-arguments
    async def get_projects(
        self,
        with_tasks_count: bool = False,
        archived: Optional[bool] = False,
        organization_id: Optional[str] = None,
        with_pipeline: Optional[bool] = False,
        query: Optional[str] = None,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        is_bookmarked: Optional[bool] = None,
        is_pipelined: Optional[bool] = None,
        update_date_from: Optional[str] = None,
    ) -> PaginatedResponse[Project]:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/markup_project'
        params = cast_params(
            organization_id=organization_id,
            withTasksCount=with_tasks_count,
            withPipeline=with_pipeline,
            archived=archived,
            query=query,
            page=page,
            size=size,
            is_bookmarked=is_bookmarked,
            is_pipelined=is_pipelined,
            update_date_from=update_date_from,
        )
        resp = await self.get(url=url, params=params)
        return get_paginated_response(resp, Project)

    async def get_project(
        self, project_id: str, with_tasks_count: bool = False, organization_id: Optional[str] = None
    ) -> Project:
        url = f'api/v0/markup_project/{project_id}'
        resp = await self.get(
            url=url, params=cast_params(withTasksCount=with_tasks_count, organization_id=organization_id)
        )
        return from_dict(data_class=Project, data=resp)

    async def create_project(
        self,
        name: str,
        description: Optional[str] = None,
        organization_id: Optional[str] = None,
        inner_comment: Optional[str] = None,
        template_id: Optional[str] = None,
        is_brief_autoupdate: Optional[bool] = None,
        is_forms_autoupdate: Optional[bool] = None,
        is_config_autoupdate: Optional[bool] = None,
        is_specification_autoupdate: Optional[bool] = None,
        contacts: Optional[str] = None,
    ) -> Project:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/markup_project'
        json_data = cast_params(
            name=name,
            organization_id=organization_id,
            description=description,
            inner_comment=inner_comment,
            template_id=template_id,
            is_brief_autoupdate=is_brief_autoupdate,
            is_forms_autoupdate=is_forms_autoupdate,
            is_config_autoupdate=is_config_autoupdate,
            is_specification_autoupdate=is_specification_autoupdate,
            contacts=contacts,
            cast_bool=False,
        )
        resp = await self.post(url=url, params=cast_params(organization_id=organization_id), json=json_data)
        return from_dict(data_class=Project, data=resp)

    async def update_project(  # pylint: disable=R0913
        self,
        project_id: str,
        name: Optional[str] = None,
        organization_id: Optional[str] = None,
        description: Optional[str] = None,
        inner_comment: Optional[str] = None,
        pipeline: Optional[Union[SyncSettings, dict]] = None,
        is_pipeline_enabled: Optional[bool] = None,
        is_brief_autoupdate: Optional[bool] = None,
        is_forms_autoupdate: Optional[bool] = None,
        is_config_autoupdate: Optional[bool] = None,
        is_specification_autoupdate: Optional[bool] = None,
        markers_count_plan: Optional[int] = None,
        pipeline_errors: Optional[str] = None,
        contacts: Optional[str] = None,
    ) -> Project:
        organization_id = organization_id or await self.get_current_organization_id()
        url = f'api/v0/markup_project/{project_id}'
        if pipeline and isinstance(pipeline, SyncSettings):
            pipeline = dataclass_to_dict(pipeline)
        json_data = cast_params(
            name=name,
            description=description,
            inner_comment=inner_comment,
            pipeline=pipeline,
            is_pipeline_enabled=is_pipeline_enabled,
            is_brief_autoupdate=is_brief_autoupdate,
            is_forms_autoupdate=is_forms_autoupdate,
            is_config_autoupdate=is_config_autoupdate,
            is_specification_autoupdate=is_specification_autoupdate,
            markers_count_plan=markers_count_plan,
            contacts=contacts,
            cast_bool=False,
            pipeline_errors=pipeline_errors,
        )
        resp = await self.put(url=url, params=cast_params(organization_id=organization_id), json=json_data)
        return from_dict(data_class=Project, data=resp)

    async def update_project_errors(
        self,
        project_id: str,
        organization_id: str,
        need_to_stop_pipeline: bool = True,
        pipeline_errors: Optional[str] = None,
    ) -> None:
        url = f"/api/v0/markup_project/{project_id}/pipeline_errors"
        await self.put(
            url=url,
            json={"pipeline_errors": pipeline_errors, "need_to_stop_pipeline": need_to_stop_pipeline},
            params=cast_params(organization_id=organization_id),
        )

    async def archive_projects(self, uids: List[str], organization_id: Optional[str] = None) -> Optional[dict]:
        url = 'api/v0/markup_project/archive'
        if not uids:
            return None

        return await self.put(url=url, json=cast_params(uids=uids), params=cast_params(organization_id=organization_id))

    async def restore_projects(self, uids: List[str], organization_id: Optional[str] = None) -> Optional[dict]:
        url = 'api/v0/markup_project/restore'
        if not uids:
            return None

        return await self.put(url=url, json=cast_params(uids=uids), params=cast_params(organization_id=organization_id))

    async def add_users_to_project(self, project_id: str, pool_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/markup_project/{project_id}/pools/{pool_id}'
        await self.post(url=url, params=cast_params(organization_id=organization_id))

    async def delete_users_from_project(
        self, project_id: str, pool_id: str, organization_id: Optional[str] = None
    ) -> None:
        url = f'api/v0/markup_project/{project_id}/pools/{pool_id}'
        await self.delete(url=url, params=cast_params(organization_id=organization_id))

    async def get_pools(self, project_id: str, organization_id: Optional[str] = None) -> List[str]:
        project = await self.get_project(project_id=project_id, organization_id=organization_id)
        return project.pools

    async def get_project_stats(self, project_id: str, organization_id: Optional[str] = None) -> ProjectStatistic:
        url = f'api/v0/statistics/project/{project_id}'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=ProjectStatistic, data=resp)

    async def get_organization_stats(self, organization_id: Optional[str] = None) -> OrganizationStatistic:
        organization_id = organization_id or await self.get_current_organization_id()
        url = f'api/v0/statistics/organization/{organization_id}'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=OrganizationStatistic, data=resp)

    async def create_project_bookmark(self, project_id: str, organization_id: Optional[str] = None) -> None:
        url = f'/api/v0/markup_project/{project_id}/bookmark'
        await self.post(url=url, params=cast_params(organization_id=organization_id))

    async def delete_project_bookmark(self, project_id: str, organization_id: Optional[str] = None) -> None:
        url = f'/api/v0/markup_project/{project_id}/bookmark'
        await self.delete(url=url, params=cast_params(organization_id=organization_id))

    async def export_project_stats(
        self,
        project_id: str,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        organization_id: Optional[str] = None,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        url = f'api/v0/statistics/project/{project_id}/export'

        if types is None:
            types = [ExportTypes.MARKERS, ExportTypes.TASKS]
        from_date = parse_date_tuple(from_date)
        to_date = parse_date_tuple(to_date)

        # optional parameter for change 'from_date' -> 'from' and 'to_date' -> 'to' and types -> types[]
        params = cast_params(
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
            organization_id=organization_id,
            map_keys=[('from_date', 'from'), ('to_date', 'to'), ('types', 'types[]'), ('file_format', 'format')],
        )
        with tempfile.TemporaryDirectory() as temporary:
            tmp = Path(temporary)
            # add response_type=ResponseType.RAW_RESPONSE for response as raw bytes
            raw_resp = await self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)
            archive = tmp / 'archive.zip'
            target_dir = tmp / 'csv'
            # write data to archive
            with open(archive, 'wb') as f:
                f.write(raw_resp)

            return preprocess_archive(archive, target_dir)

    async def export_org_stats(
        self,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: List[Union[ExportTypes, str]] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        organization_id: Optional[str] = None,
        hourly: Optional[bool] = None,
    ) -> Tuple[List[TasksStatistic], List[MarkersStatistic]]:
        if not organization_id:
            organization_id = await self.get_current_organization_id()
        url = f'api/v0/statistics/organization/{organization_id}/export'

        if types is None:
            types = [ExportTypes.MARKERS, ExportTypes.TASKS]
        from_date = parse_date_tuple(from_date)
        to_date = parse_date_tuple(to_date)

        # optional parameter for change 'from_date' -> 'from' and 'to_date' -> 'to' and types -> types[]
        params = cast_params(
            from_date=from_date,
            to_date=to_date,
            types=types,
            file_format=file_format,
            organization_id=organization_id,
            hourly=hourly,
            map_keys=[('from_date', 'from'), ('to_date', 'to'), ('types', 'types[]'), ('file_format', 'format')],
        )
        with tempfile.TemporaryDirectory() as temporary:
            tmp = Path(temporary)
            # add response_type=ResponseType.RAW_RESPONSE for response as raw bytes
            raw_resp = await self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)
            archive = tmp / 'archive.zip'
            target_dir = tmp / 'csv'
            # write data to archive
            with open(archive, 'wb') as f:
                f.write(raw_resp)

            return preprocess_archive(archive, target_dir)

    async def get_contacts(self, project_id: str, organization_id: Optional[str] = None) -> Contacts:
        url = f'/api/v0/markup_project/{project_id}/contacts'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=Contacts, data=resp)

    # -----------------------------------------------------------------------------
    #                                  METHOD
    # -----------------------------------------------------------------------------

    async def get_method(
        self, method_id: str, task_id: Optional[str] = None, organization_id: Optional[str] = None
    ) -> MethodData:
        url = f'api/v0/method/{method_id}'
        resp = await self.get(url=url, params=cast_params(task_id=task_id, organization_id=organization_id))
        return from_dict(data_class=MethodData, data=resp)

    async def list_method_brief_versions(
        self,
        method_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
        with_person_info: Optional[bool] = None,
    ) -> List[BriefVersionInfo]:
        url = f"api/v0/method/{method_id}/brief/versions"
        params = cast_params(
            page=page,
            size=size,
            withPersonInfo=with_person_info,
        )

        resp = await self.get(url=url, params=params)
        return [from_dict(data_class=BriefVersionInfo, data=_) for _ in resp['items']]

    async def get_brief_version_info(
        self,
        method_id: str,
        version: Union[str, int] = "latest",
        date_time: Optional[datetime] = None,
        with_person_info: bool = False,
    ) -> Tuple[BriefVersionInfo, dict]:
        if isinstance(version, str):
            assert version == "latest"

        url = f"api/v0/method/{method_id}/brief/info"

        resp, headers = await self.get(
            url=url,
            params=cast_params(
                v=version,
                datetime=str(date_time) if date_time else None,
                withPersonInfo=with_person_info,
            ),
            return_headers=True,
        )
        return from_dict(data_class=BriefVersionInfo, data=resp), headers

    async def download_brief_version_file(
        self,
        method_id: str,
        version: Union[str, int] = "latest",
        date_time: Optional[datetime] = None,
    ) -> bytes:
        if isinstance(version, str):
            assert version == "latest"

        url = f"api/v0/method/{method_id}/brief/download"

        return await self.get(
            url=url,
            params=cast_params(
                v=version,
                datetime=str(date_time) if date_time else None,
            ),
            response_type=ResponseType.RAW_RESPONSE,
        )

    async def list_method_interface_versions(
        self,
        method_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
        with_person_info: Optional[bool] = None,
    ) -> List[InterfaceVersionInfo]:
        url = f"api/v0/method/{method_id}/interface/versions"
        params = cast_params(
            page=page,
            size=size,
            withPersonInfo=with_person_info,
        )

        resp = await self.get(url=url, params=params)
        return [from_dict(data_class=InterfaceVersionInfo, data=_) for _ in resp['items']]

    async def get_interface_version_info(
        self,
        method_id: str,
        version: Union[str, int] = "latest",
        date_time: Optional[datetime] = None,
        with_person_info: Optional[bool] = None,
    ) -> InterfaceVersionInfo:
        if isinstance(version, str):
            assert version == "latest"

        url = f"api/v0/method/{method_id}/interface/info"

        resp = await self.get(
            url=url,
            params=cast_params(
                v=version,
                datetime=str(date_time) if date_time else None,
                withPersonInfo=with_person_info,
            ),
        )
        resp["method_id"] = method_id
        return from_dict(data_class=InterfaceVersionInfo, data=resp)

    async def download_interface_version(
        self,
        method_id: str,
        version: Union[str, int] = "latest",
        date_time: Optional[datetime] = None,
        task_id: Optional[str] = None,
    ) -> InterfaceVersionInfo:
        if isinstance(version, str):
            assert version == "latest"

        url = f"api/v0/method/{method_id}/interface/download"

        resp = await self.get(
            url=url,
            params=cast_params(
                v=version,
                datetime=str(date_time) if date_time else None,
                task_id=task_id,
            ),
        )

        resp["method_id"] = method_id
        return from_dict(data_class=InterfaceVersionInfo, data=resp)

    async def update_method_brief(self, method_id: str, file_path: str, file_name: str) -> None:
        url = f"api/v0/storage/method/{method_id}/brief"
        data = FormData()
        with open(file_path, "rb") as f:
            data.add_field("file", f, filename=file_name)
            await self.put(
                url=url,
                data=data,
            )

    async def get_method_brief(self, method_id: str) -> Tuple[str, dict]:
        url = f"api/v0/method/{method_id}/brief"
        return await self.get(url=url, response_type=ResponseType.TEXT_RESPONSE, return_headers=True)

    async def update_method(
        self, method: Union[MethodData, MethodDataRequest, dict], organization_id: Optional[str] = None
    ) -> MethodData:
        if isinstance(method, dict):
            method = from_dict(data_class=MethodData, data=method)

        assert isinstance(method, (MethodData, MethodDataRequest))
        url = f'api/v0/method/{method.uid}'
        resp = await self.put(
            url=url,
            params=cast_params(organization_id=organization_id),
            json=dataclass_to_dict(method, exclude=('uid', 'organization_id', 'person_id', 'modification_date')),
        )
        return from_dict(data_class=MethodData, data=resp)

    async def get_brief_read_status(self, method_id: str, organization_id: Optional[str] = None) -> BriefReadStatusData:
        url = f"/api/v0/method/{method_id}/brief/read_status"
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=BriefReadStatusData, data=resp)

    async def set_brief_read_status(
        self, method_id: str, read_token: str, organization_id: Optional[str] = None
    ) -> None:
        url = f"api/v0/method/{method_id}/brief/set_read_status"
        await self.put(
            url=url, params=cast_params(organization_id=organization_id), headers={"X-READ-INFO-TOKEN": read_token}
        )

    # -----------------------------------------------------------------------------
    #                                  ORGANIZATIONS
    # -----------------------------------------------------------------------------

    async def get_full_organizations(
        self,
        query: Optional[str] = None,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        org_ids: Optional[List[str]] = None,
        ignore_org: Optional[bool] = None,
    ) -> PaginatedResponse[FullOrganization]:
        url = 'api/v0/organizations'
        resp = await self.get(
            url=url,
            params=cast_params(
                query=query,
                page=page,
                size=size,
                org_ids=org_ids,
                ignore_org=ignore_org,
                map_keys=[('org_ids', 'org_ids[]')],
            ),
        )
        return get_paginated_response(resp, FullOrganization)

    async def get_full_organization(
        self, organization_id: str, with_employees: Optional[bool] = None
    ) -> FullOrganization:
        url = f'api/v0/organization/{organization_id}'
        resp = await self.get(url=url, params=cast_params(withEmployees=with_employees))
        return from_dict(data_class=FullOrganization, data=resp)

    async def update_organization(
        self,
        organization_id: str,
        name: Optional[str] = None,
        config: Optional[OrganizationConfig] = None,
        contacts: Optional[str] = None,
    ) -> FullOrganization:
        url = f'api/v0/organization/{organization_id}'
        resp = await self.put(url=url, json=cast_params(name=name, config=dataclass_to_dict(config), contacts=contacts))
        return from_dict(data_class=FullOrganization, data=resp)

    # -----------------------------------------------------------------------------
    #                                  TASK
    # -----------------------------------------------------------------------------

    async def create_task(
        self,
        task: Union[TaskDataRequest, TaskData, dict],
        organization_id: Optional[str] = None,
    ) -> TaskData:
        url = 'api/v0/tasks'
        organization_id = organization_id or await self.get_current_organization_id()
        if isinstance(task, dict):
            task["organization_id"] = organization_id
            task = from_dict(data_class=TaskDataRequest, data=task)

        assert isinstance(task, (TaskDataRequest, TaskData))
        task.data_classification_level = task.data_classification_level or self.config.data_category
        task.data_source = task.data_source or self.config.data_source

        task_data = dataclass_to_dict(task)
        task_data.pop("organization_id", None)
        resp = await self.post(url=url, json=task_data, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    async def duplicate_task(
        self,
        original_task: Union[TaskData, dict],
        task: dict = None,
        organization_id: Optional[str] = None,
    ) -> TaskData:
        uid = original_task["uid"] if isinstance(original_task, dict) else str(original_task.uid)

        url = f"/api/v0/tasks/{uid}/duplicate"
        if not task:
            task = {}
        task.pop("organization_id", None)

        resp = await self.post(
            url=url,
            json=task,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=TaskData, data=resp)

    async def update_task(
        self,
        task: Union[TaskData, dict],
        organization_id: Optional[str] = None,
    ) -> TaskData:
        if isinstance(task, dict):
            task = from_dict(data_class=TaskData, data=task)

        assert isinstance(task, TaskData)
        url = f'api/v0/tasks/{task.uid}'
        task.data_classification_level = task.data_classification_level or self.config.data_category
        task.data_source = task.data_source or self.config.data_source

        await self.put(
            url=url,
            json=dataclass_to_dict(task, serialize_nulls=True),
            params=cast_params(organization_id=organization_id),
        )
        return task

    async def get_tasks(  # pylint: disable=R0913
        self,
        project_id: Optional[str] = None,
        price_min: Optional[float] = None,
        price_max: Optional[float] = None,
        priority_min: Optional[int] = None,
        priority_max: Optional[int] = None,
        query: Optional[str] = None,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        update_date_from: Optional[str] = None,
        organization_id: Optional[str] = None,
        states: Optional[List[TaskState]] = None,
        task_ids: Optional[List[str]] = None,
    ) -> PaginatedResponse[TaskData]:
        url = 'api/v0/tasks'
        resp = await self.get(
            url=url,
            params=cast_params(
                project_id=project_id,
                price_min=price_min,
                price_max=price_max,
                priority_min=priority_min,
                priority_max=priority_max,
                query=query,
                page=page,
                size=size,
                update_date_from=update_date_from,
                organization_id=organization_id,
                states=states,
                task_ids=task_ids,
                map_keys=[('states', 'state[]'), ('task_ids', 'task_id[]')],
            ),
        )
        return get_paginated_response(resp, TaskData, mapper=clear_none)

    async def get_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        url = f'api/v0/tasks/{task_id}'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    async def get_task_hierarchy(self, task_id: str) -> TaskHierarchy:
        url = f'api/v0/tasks/{task_id}/hierarchy_info'
        resp = await self.get(url=url)
        return from_dict(data_class=TaskHierarchy, data=resp)

    async def start_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        url = f'api/v0/tasks/{task_id}/start'
        resp = await self.post(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    async def check_task(self, task_id: str, organization_id: Optional[str] = None) -> CheckTaskResult:
        url = f'api/v0/tasks/{task_id}/check'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=CheckTaskResult, data=resp)

    async def unarchive_task(self, task_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/taskflow/task/{task_id}/unarchive'
        await self.post(url=url, organization_id=organization_id)

    async def archive_task(self, task_id: str, organization_id: Optional[str]) -> None:
        url = f'api/v0/taskflow/task/{task_id}/archive'
        await self.post(url=url, organization_id=organization_id)

    async def stop_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        url = f'api/v0/tasks/{task_id}/stop'
        resp = await self.post(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    async def get_task_information(self, task_id: str, organization_id: Optional[str] = None) -> TaskInfo:
        url = f'api/v0/taskflow/task/{task_id}'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskInfo, data=resp)

    async def get_task_info(self, task_id: str, organization_id: Optional[str] = None) -> Dict:
        url = f'api/v0/storage/{task_id}/info'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return resp

    async def complete_task(self, task_id: str, organization_id: Optional[str] = None) -> TaskData:
        url = f'api/v0/tasks/{task_id}/complete'
        resp = await self.post(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskData, data=resp)

    async def remove_task(self, task_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/tasks/{task_id}/remove'
        await self.put(url=url, params=cast_params(organization_id=organization_id))

    async def get_task_stats(self, task_id: str, organization_id: Optional[str] = None) -> TaskStats:
        url = f'api/v0/statistics/task/{task_id}'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskStats, data=resp)

    async def get_task_stats_advanced(self, task_id: str, organization_id: Optional[str] = None) -> TaskStatsAdvanced:
        url = f'api/v0/statistics/task/{task_id}/advanced'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskStatsAdvanced, data=resp)

    async def get_list_task_statictics(
        self, task_ids: List[str], update_date_from: Optional[str] = None, organization_id: Optional[str] = None
    ) -> List[TaskStatisticsItem]:
        url = '/api/v0/statistics/tasks'
        resp = await self.get(
            url=url,
            params=cast_params(
                task_ids=task_ids,
                update_date_from=update_date_from,
                organization_id=organization_id,
                map_keys=[('task_ids', 'taskId[]')],
            ),
        )
        return [from_dict(data_class=TaskStatisticsItem, data=clear_none(task_stat_data)) for task_stat_data in resp]

    async def get_task_results(
        self,
        task_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[TaskResult]:
        warnings.warn('get_task_results is deprecated, use get_task_assignments instead', DeprecationWarning)
        if page or size:
            raise ValueError('Pagination is not supported yet for get_task_results')

        assignment_index: Dict[str, List[Assignment]] = {}

        for assignment in await self.get_task_assignments(task_id, organization_id=organization_id):
            key = assignment.item_id
            if key not in assignment_index:
                assignment_index[key] = []
            assignment_index[key].append(assignment)

        results = []
        for item_id, assignments in assignment_index.items():
            result_item = TaskResult.from_assignments(item_id, assignments)
            results.append(result_item)

        return results

    async def get_task_assignments(
        self,
        task_id: str,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        organization_id: Optional[str] = None,
        updated_date_from: Optional[str] = None,
        updated_date_to: Optional[str] = None,
        marker_ids: Optional[str] = None,
        item_types: Optional[List[Literal["data", "control", "study"]]] = None,
        statuses: Optional[List[Literal["ACCEPTED", "REJECTED", "EXPIRED", "SKIPPED", "SUBMITTED"]]] = None,
        consistency: Optional[float] = None,
        consistency_filter: Optional[Literal["lte", "gte", "gt", "lt", "eq"]] = None,
    ) -> List[Assignment]:
        url = 'api/v0/assignments'
        resp = await self.get(
            url=url,
            params=cast_params(
                task_id=task_id,
                date_from=date_from,
                date_to=date_to or datetime.now().strftime('%Y-%m-%d'),
                updated_date_from=updated_date_from,
                updated_date_to=updated_date_to,
                file_format=ExportFormat.JSON,
                organization_id=organization_id,
                map_keys=[
                    ('file_format', 'format'),
                    ("item_types", "item_types[]"),
                    ("statuses", "statuses[]"),
                    ("marker_ids", "marker_ids[]"),
                ],
                marker_ids=marker_ids,
                item_types=item_types,
                statuses=statuses,
                consistency=consistency,
                consistency_filter=consistency_filter,
            ),
        )

        result = [from_dict(data_class=Assignment, data=item) for item in resp]

        if not result:
            try:
                await self.get_task(task_id=task_id, organization_id=organization_id)
            except APIResponseError as ex:
                if ex.status == 403:
                    raise RuntimeError(f'Forbidden to get task {task_id}') from ex
                if ex.status == 404:
                    raise RuntimeError(f'Task not found: {task_id}') from ex
                raise

        return result

    async def gen_assignment_url(
        self,
        assignment_id: str,
        organization_id: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> str:
        organization_id = organization_id or await self.get_current_organization_id()
        base_url = base_url or self.get_base_url()
        return f'{base_url}/company/{organization_id}/assignment/{assignment_id}/reel'

    async def gen_task_url(
        self, project_id: str, task_id: str, organization_id: Optional[str] = None, base_url: Optional[str] = None
    ) -> str:
        organization_id = organization_id or await self.get_current_organization_id()
        base_url = base_url or self.get_base_url()
        return f'{base_url}/company/{organization_id}/project/{project_id}/task/{task_id}/overview'

    async def gen_project_url(
        self, project_id: str, organization_id: Optional[str] = None, base_url: Optional[str] = None
    ) -> str:
        organization_id = organization_id or await self.get_current_organization_id()
        base_url = base_url or self.get_base_url()
        return f'{base_url}/company/{organization_id}/project/{project_id}'

    def gen_file_url(self, file_id: str, base_url: Optional[str] = None) -> str:
        base_url = base_url or self.get_base_url()
        return f'{base_url}/files/{file_id}'

    async def delete_items_from_task(
        self, task_id: str, organization_id: Optional[str] = None
    ) -> DeleteAllFilesrResult:
        url = f'api/v0/delete/{task_id}/all'
        resp = await self.delete(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=DeleteAllFilesrResult, data=resp)

    async def delete_some_items_from_task(
        self, task_id: str, files: List[str], organization_id: Optional[str] = None
    ) -> DeleteSomeFilesResult:
        url = f'api/v0/delete/{task_id}'
        resp = await self.post(
            url=url, json=cast_params(uids=files), params=cast_params(organization_id=organization_id)
        )
        return from_dict(data_class=DeleteSomeFilesResult, data=resp)

    async def poll_for_task_state(
        self,
        task_id: str,
        state: TaskState,
        retry_amount: int = 15,
        wait_seconds: float = 3,
        organization_id: Optional[str] = None,
    ) -> TaskState:
        task = None
        for _ in range(retry_amount):
            await asyncio.sleep(wait_seconds)
            task = await self.get_task(task_id=task_id, organization_id=organization_id)
            if task.state is state:
                return state

        if isinstance(task, TaskData):
            raise ValueError(f'Incorrect task state {task.state}, expected {state}')

        raise ValueError('No task were selected')

    async def set_task_payload(self, task_id: str, payload: dict, organization_id: Optional[str] = None) -> dict:
        url = f'api/v0/tasks/{task_id}/payload'
        if 'payload' not in payload:
            payload = {"payload": payload}
        resp = await self.put(url=url, json=payload, params=cast_params(organization_id=organization_id))
        return resp.get('payload', {})

    async def get_task_payload(self, task_id: str, organization_id: Optional[str] = None) -> dict:
        url = f'api/v0/tasks/{task_id}/payload'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return resp.get('payload', {})

    async def delete_task_payload(self, task_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/tasks/{task_id}/payload'
        return await self.delete(url=url, params=cast_params(organization_id=organization_id))

    # -----------------------------------------------------------------------------
    #                                  Invites
    # -----------------------------------------------------------------------------
    async def get_invites(
        self,
        active: bool = True,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        organization_id: Optional[str] = None,
    ) -> PaginatedResponse[InviteData]:
        url = 'api/v0/invites'
        resp = await self.get(
            url=url,
            params=cast_params(
                organization_id=organization_id,
                active=active,
                page=page,
                size=size,
            ),
        )
        return get_paginated_response(resp, InviteData)

    async def get_invite(self, uid: str, organization_id: Optional[str] = None) -> InviteData:
        url = f'api/v0/invite/{uid}'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=InviteData, data=resp)

    async def delete_invite(self, uid: str, organization_id: Optional[str] = None) -> InviteData:
        url = f'api/v0/invite/{uid}'
        return await self.delete(url=url, params=cast_params(organization_id=organization_id))

    async def put_invite(self, data: InviteData) -> InviteData:
        url = f'api/v0/invite/{data.uid}'
        resp = await self.put(
            url=url, json=dataclass_to_dict(data), params=cast_params(organization_id=data.organization_id)
        )
        return from_dict(data_class=InviteData, data=resp)

    async def create_invite(self, data: InviteRequest) -> InviteData:
        url = 'api/v0/invite'
        resp = await self.post(
            url=url, json=dataclass_to_dict(data), params=cast_params(organization_id=data.organization_id)
        )
        return from_dict(data_class=InviteData, data=resp)

    async def create_invite_request(self, invite_id: str, organization_id: Optional[str] = None) -> InviteApplication:
        url = 'api/v0/inviterequest'
        resp = await self.post(
            url=url,
            json=cast_params(invite_id=invite_id),
            headers=self.marker_header(),
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=InviteApplication, data=resp)

    async def get_invites_pending(
        self, organization_id: Optional[str] = None, invite_name: Optional[str] = None, state: str = 'NEW'
    ) -> List[InviteApplication]:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/inviterequests'
        resp = await self.get(url=url, params=cast_params(state=state, organization_id=organization_id))
        decoded_resp = [from_dict(data_class=InviteApplication, data=item) for item in resp['items']]
        if invite_name:
            return [item for item in decoded_resp if item.invite_name == invite_name]
        else:
            return decoded_resp

    async def accept_invites(
        self, invite_request_ids: List[str], pool_ids: Optional[List[str]] = None, organization_id: Optional[str] = None
    ) -> None:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/inviterequests/approve'
        await self.put(
            url=url,
            json=cast_params(pool_ids=pool_ids, invite_request_ids=invite_request_ids, organization_id=organization_id),
        )

    async def decline_invites(self, invite_request_ids: List[str], organization_id: Optional[str] = None) -> None:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/inviterequests/reject'
        await self.put(
            url=url, json=cast_params(invite_request_ids=invite_request_ids, organization_id=organization_id)
        )

    # -----------------------------------------------------------------------------
    #                                  POOL
    # -----------------------------------------------------------------------------

    async def update_marker_in_pool(
        self, marker_id: str, pool_id: str, data: dict, organization_id: Optional[str] = None
    ) -> None:
        organization_id = organization_id or await self.get_current_organization_id()
        url = f"/api/v0/pool/{pool_id}/marker/{marker_id}"
        body = {**data, **cast_params(organization_id=organization_id)}
        await self.put(
            url=url,
            json=body,
        )

    async def get_organization_pools(
        self,
        organization_id: Optional[str] = None,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        query: Optional[str] = None,
        with_shared_pools: Optional[bool] = None,
    ) -> PaginatedResponse[Pool]:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/pools'
        resp = await self.get(
            url=url,
            params=cast_params(
                withMembersCount=True,
                organization_id=organization_id,
                page=page,
                size=size,
                query=query,
                withSharedPools=with_shared_pools,
            ),
        )
        return get_paginated_response(resp, Pool)

    async def attach_user_to_pool(self, pool_id: str, user_id: str, organization_id: Optional[str] = None) -> bool:
        url = f'api/v0/pool/{pool_id}/attach/{user_id}'
        resp = await self.post(
            url=url,
            response_type=ResponseType.TEXT_RESPONSE,
            ignore_statuses=404,
            params=cast_params(organization_id=organization_id),
        )
        return resp is not None

    async def detach_user_from_pool(self, pool_id: str, user_id: str, organization_id: Optional[str] = None) -> bool:
        url = f'api/v0/pool/{pool_id}/detach/{user_id}'
        resp = await self.post(
            url=url,
            response_type=ResponseType.TEXT_RESPONSE,
            ignore_statuses=404,
            params=cast_params(organization_id=organization_id),
        )
        return resp is not None

    async def create_pool(
        self,
        markers: List[str],
        name: str,
        organization_id: Optional[str] = None,
        access: Optional[Literal["public", "organization", "private"]] = None,
        acl: Optional[List[str]] = None,
        group_type: Optional[Literal["MARKERS", "VALIDATORS"]] = None,
    ) -> Pool:
        url = 'api/v0/pool'
        organization_id = organization_id or await self.get_current_organization_id()
        json_data = cast_params(
            members=markers,
            name=name,
            organization_id=organization_id,
            access=access,
            acl=acl,
            group_type=group_type,
        )
        resp = await self.post(url=url, json=json_data, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=Pool, data=resp)

    async def get_pool(
        self, pool_id: str, with_markers: Optional[bool] = None, organization_id: Optional[str] = None
    ) -> Pool:
        url = f'api/v0/pool/{pool_id}'
        resp = await self.get(url=url, params=cast_params(withMarkers=with_markers, organization_id=organization_id))
        if isinstance(resp, dict):
            cleared_members = [item for item in resp.get('members', []) if item.get('person') is not None]
            resp['members'] = cleared_members
        return from_dict(data_class=Pool, data=resp)

    async def update_pool(
        self,
        pool_id: str,
        name: str,
        organization_id: Optional[str] = None,
        access: Optional[Literal["public", "organization", "private"]] = None,
        acl: Optional[List[str]] = None,
    ) -> Pool:
        url = f'api/v0/pool/{pool_id}'
        json_data = cast_params(name=name, access=access, acl=acl)
        resp = await self.put(url=url, json=json_data, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=Pool, data=resp)

    async def delete_pool(self, pool_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/pool/{pool_id}'
        await self.delete(url=url, params=cast_params(organization_id=organization_id))

    async def detach_markers(
        self, pool_id: str, uids: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        url = f'api/v0/pool/{pool_id}/detach'
        resp = await self.post(
            url=url, json=cast_params(uids=uids), params=cast_params(organization_id=organization_id)
        )
        return from_dict(ErrorMarkersResponse, resp)

    async def move_markers(
        self, pool_id: str, target_pool: str, uids: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        url = f'api/v0/pool/{pool_id}/move'
        resp = await self.post(
            url=url,
            json=cast_params(target_pool=target_pool, uids=uids),
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(ErrorMarkersResponse, resp)

    # -----------------------------------------------------------------------------
    #                                  MARKUP
    # -----------------------------------------------------------------------------

    async def get_tasks_for_markup(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
    ) -> List[TaskflowTaskData]:
        url = 'api/v0/taskflow/projects'
        resp = await self.get(
            url=url,
            params=cast_params(page=page, size=size, query=query),
            headers=self.marker_header(),
        )

        return [from_dict(data_class=TaskflowTaskData, data=item) for item in resp['items']]

    async def download_attachment(
        self, attachment_url: str, dir_path: str, organization_id: Optional[str] = None
    ) -> str:
        if 'http' in attachment_url:
            url = attachment_url.split('/', 3)[-1]
        else:
            url = attachment_url

        attachment_id = attachment_url.rsplit('/', 1)[-1]

        params = cast_params(organization_id=organization_id)
        content_type, raw_resp = await self.get(url=url, params=params, response_type=ResponseType.FILE_RESPONSE)
        fpath = (Path(dir_path) / attachment_id).with_suffix(mimetypes.guess_extension(content_type) or '')
        with open(fpath, 'wb') as f:
            f.write(raw_resp)
        return str(fpath)

    async def download_attachments(
        self, task_id: str, dir_path: str, organization_id: Optional[str] = None
    ) -> List[str]:
        url = 'api/v0/assignments'
        params = cast_params(
            task_id=task_id,
            file_format='json',
            organization_id=organization_id,
            map_keys=[('file_format', 'format')],
        )
        raw_resp = await self.get(url=url, params=params)

        result: List[str] = []
        for item in raw_resp:
            for attachment_url in find_attachments(item['result']):
                fname = await self.download_attachment(
                    attachment_url=attachment_url, dir_path=dir_path, organization_id=organization_id
                )
                result.append(fname)
        return result

    async def get_attachment(
        self,
        attachment_id: str,
    ) -> None:
        url = f"api/v0/attachment/{attachment_id}"
        await self.get(url=url, headers=self.marker_header())

    async def save_attachment(
        self, token: str, data: Union[bytes, str], filename: str, content_type: Optional[str] = None
    ) -> str:
        url = f'api/v0/attachment/{token}'

        content_type = content_type or mimetypes.guess_type(filename)[0] or 'application/octet-stream'

        form = [{'name': 'file', 'value': data, 'filename': filename, 'content_type': content_type}]
        resp = await self.post(url=url, form=form, headers=self.marker_header())

        return resp['attachment_id']

    async def get_markup_task(self, task_id: str) -> MarkupTask:
        url = f'api/v0/taskflow/task/{task_id}/assignment'
        try:
            resp = await self.get(url=url, headers=self.marker_header())
            if resp is None:
                return MarkupTask.build_empty_task()
            return from_dict(data_class=MarkupTask, data=resp)
        except aiohttp.ClientResponseError as error:
            if error.status == 404:
                return MarkupTask.build_empty_task()
            raise

    async def submit_markup_task(self, task_id: str, assignment_id: str, markup_result: Dict[str, Any]) -> None:
        url = f'api/v0/taskflow/task/{task_id}/assignment/{assignment_id}'
        await self.post(url=url, json=markup_result, headers=self.marker_header())

    async def skip_markup_task(self, task_id: str, assignment_id: str) -> None:
        url = f'/api/v0/taskflow/task/{task_id}/assignment/{assignment_id}/skip'
        await self.post(url=url, headers=self.marker_header())

    async def review_markup(self, review: MarkupReview, organization_id: str) -> None:
        url = f'/api/v0/taskflow/assignments/{review.assignment_id}'
        req_body = dataclass_to_dict(
            review,
            exclude=('assignment_id',),
            map_keys=[('comment', 'reviewer_comment')],
        )
        await self.put(url=url, json=req_body, organization_id=organization_id)

    async def review_multiple_markups(
        self, reviews: Union[List[MarkupReview], List[Dict[str, Any]]], organization_id: str
    ) -> MarkupReviewResult:
        url = '/api/v0/taskflow/assignments'
        assert len(reviews)
        if isinstance(reviews[0], MarkupReview):
            req_body: List[Dict[str, Any]] = [
                dataclass_to_dict(review, map_keys=[('comment', 'reviewer_comment')]) for review in reviews
            ]
        else:
            req_body: List[Dict[str, Any]] = reviews  # type: ignore
        response = await self.put(url=url, json=req_body, organization_id=organization_id)
        return from_dict(data_class=MarkupReviewResult, data=response)

    async def delete_assignments_quality(self, assignment_ids: List[str], organization_id: str) -> MarkupReviewResult:
        url = '/api/v0/taskflow/assignments/quality/delete'
        req_body = {"assignment_ids": assignment_ids}
        response = await self.put(url=url, json=req_body, organization_id=organization_id)
        return from_dict(data_class=MarkupReviewResult, data=response)

    async def delete_assignments_comments(self, assignment_ids: List[str], organization_id: str) -> MarkupReviewResult:
        url = '/api/v0/taskflow/assignments/commentaries/delete'
        req_body = {"assignment_ids": assignment_ids}
        response = await self.put(url=url, json=req_body, organization_id=organization_id)
        return from_dict(data_class=MarkupReviewResult, data=response)

    async def get_markup_result(self, assignment_id: str, organization_id: str) -> Optional[MarkupResult]:
        url = f'/api/v0/taskflow/assignments/{assignment_id}'
        try:
            response = await self.get(url=url, organization_id=organization_id)
        except aiohttp.ClientResponseError as error:
            if (error.status == 400 and "Assignment not found" in error.message) or error.status == 404:
                return None
            raise

        return from_dict(data_class=MarkupResult, data=response)

    async def get_markup_result_index(self, assignment_id: str, organization_id: str) -> AssignmentIndex:
        url = f'/api/v0/taskflow/assignments/{assignment_id}/index'
        response = await self.get(url=url, organization_id=organization_id)
        return from_dict(data_class=AssignmentIndex, data=response)

    async def get_task_statistics(self, task_id: str, organization_id: str) -> TaskStatistics:
        url = f'/api/v0/taskflow/statistics/tasks/{task_id}'
        response = await self.get(url=url, organization_id=organization_id)
        return from_dict(data_class=TaskStatistics, data=response)

    async def get_validate_time_statistics(
        self,
        organization_id: str,
        task_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> ValidateTimeStatistics:
        url = '/api/v0/taskflow/validator_statistics'
        params = cast_params(organization_id=organization_id)

        if page is not None:
            params["page"] = page
        if size is not None:
            params["size"] = size
        if task_id is not None:
            params["task_id"] = task_id

        response = await self.get(url=url, params=params, organization_id=organization_id)
        return from_dict(data_class=ValidateTimeStatistics, data=response)

    async def get_validate_time_statistics_by_customer(
        self,
        organization_id: str,
        task_ids: Optional[List[str]] = None,
        validator_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> ValidateTimeStatistics:
        url = '/api/v0/taskflow/validator_statistics_by_customer'
        params = cast_params(organization_id=organization_id)

        if page is not None:
            params["page"] = page
        if size is not None:
            params["size"] = size
        if task_ids is not None:
            params["task_ids"] = task_ids
        if validator_id is not None:
            params["validator_id"] = validator_id

        response = await self.get(url=url, params=params, organization_id=organization_id)
        return from_dict(data_class=ValidateTimeStatistics, data=response)

    async def get_task_items_statistics(
        self,
        task_id: str,
        organization_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
        item_ids: Optional[List[str]] = None,
    ) -> List[TaskTabItemStats]:
        """
        Returns task items statistics by taskID
        """
        url = f"/api/v0/taskflow/task/{task_id}/items_statistics"

        params = cast_params(organization_id=organization_id)
        if page is not None:
            params["page"] = page
        if size is not None:
            params["size"] = size
        if item_ids is not None:
            params["item_id[]"] = item_ids

        response = await self.get(url=url, params=params, organization_id=organization_id)
        return [from_dict(data_class=TaskTabItemStats, data=item) for item in response]

    async def get_task_item_statistics(
        self,
        organization_id: str,
        task_id: str,
        item_id: str,
    ) -> TaskTabItemStats:
        """
        Returns task item statistics by taskID
        """
        url = f"/api/v0/taskflow/task/{task_id}/item/{item_id}/item_statistics"

        response = await self.get(
            url=url, params=cast_params(organization_id=organization_id), organization_id=organization_id
        )
        return from_dict(data_class=TaskTabItemStats, data=response)

    async def get_markup_results(  # pylint: disable=R0913
        self,
        task_id: str,
        organization_id: str,
        marker_ids: Optional[List[str]] = None,
        file_name: Optional[str] = None,
        file_ids: Optional[List[str]] = None,
        statuses: Optional[List[str]] = None,
        file_types: Optional[List[FileType]] = None,
        submitted_ats: Optional[List[date]] = None,
        assignment_ids: Optional[List[str]] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
        sort_field: Optional[MarkupResultSortField] = None,
        sort_order: Optional[SortOrder] = None,
    ) -> MarkupResults:
        file_types_assoc = {
            FileType.STUDY: 'study',
            FileType.CONTROL: 'control',
            FileType.DATA: 'data',
        }
        url = '/api/v0/taskflow/assignments'
        params = cast_params(
            task_id=task_id,
            marker_ids=marker_ids,
            file_name=file_name,
            item_ids=file_ids,
            statuses=statuses,
            item_types=[file_types_assoc[t] for t in file_types if t in file_types_assoc] if file_types else None,
            submitted_ats=submitted_ats,
            assignment_ids=assignment_ids,
            page=page,
            size=size,
            sort_field=sort_field,
            sort_order=sort_order,
            map_keys=[
                ('marker_ids', 'marker_id[]'),
                ('item_ids', 'item_id[]'),
                ('statuses', 'status[]'),
                ('item_types', 'item_type[]'),
                ('submitted_ats', 'submitted[]'),
                ('assignment_ids', 'assignment_id[]'),
            ],
        )

        response = await self.get(url=url, organization_id=organization_id, params=params)
        return from_dict(data_class=MarkupResults, data=response)

    async def get_markup_marker_statistics(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        sort_field: Optional[MarkupMarkerStatisticsSortField] = None,
        sort_order: Optional[SortOrder] = None,
    ) -> MarkupMarkerStatistics:
        url = '/api/v0/taskflow/marker_statistics'
        params = cast_params(
            page=page,
            size=size,
            query=query,
            start_date=start_date,
            end_date=end_date,
            sort_field=sort_field,
            sort_order=sort_order,
        )

        response = await self.get(url=url, params=params)
        return from_dict(data_class=MarkupMarkerStatistics, data=response)

    async def get_assignment_result_by_marker(self, assignment_id: str) -> AssignmentResultByMarker:
        url = f'/api/v0/taskflow/assignments/{assignment_id}/result'
        response = await self.get(url=url)
        return from_dict(data_class=AssignmentResultByMarker, data=response)

    # -----------------------------------------------------------------------------
    #                                  ITEMS
    # -----------------------------------------------------------------------------

    async def put_item_overlap(
        self,
        task_id: str,
        item_id: str,
        overlap: int,
        organization_id: Optional[str] = None,
    ) -> Item:
        url = f'/api/v0/taskflow/task/{task_id}/item/{item_id}/overlap'

        response = await self.put(url=url, json={"overlap": overlap}, organization_id=organization_id)
        return from_dict(data_class=Item, data=response)

    async def increase_item_overlap(
        self,
        task_id: str,
        item_id: str,
        organization_id: Optional[str] = None,
    ) -> Item:
        url = f'/api/v0/taskflow/task/{task_id}/item/{item_id}/increase_overlap'

        response = await self.put(url=url, organization_id=organization_id)
        return from_dict(data_class=Item, data=response)

    async def assign_assignment(
        self,
        task_id: str,
        item_id: str,
        marker_id: str,
        expired_after: datetime,
        original_assignment_id: Optional[str] = None,
        price: Optional[float] = None,
        is_increase_overlap: Optional[bool] = None,
        is_release_to_pool_on_expire: Optional[bool] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        url = f'/api/v0/taskflow/task/{task_id}/item/{item_id}/assign'
        body: Dict[str, Any] = {
            'marker_id': marker_id,
            'expired_after': expired_after.strftime("%Y-%m-%dT%H:%M:%SZ"),
        }

        if original_assignment_id is not None:
            body['original_assignment_id'] = original_assignment_id

        if price is not None:
            body['price'] = price

        if is_increase_overlap is not None:
            body['is_increase_overlap'] = is_increase_overlap

        if is_release_to_pool_on_expire is not None:
            body['is_release_to_pool_on_expire'] = is_release_to_pool_on_expire

        await self.put(url=url, organization_id=organization_id, json=body)

    async def assign_assignments(
        self,
        assignments: List[AssignAssignmentRequest],
        organization_id: Optional[str] = None,
    ) -> None:
        warnings.warn('assign_assignments is deprecated, use assign_multiple_assignments instead', DeprecationWarning)
        url = '/api/v0/taskflow/items/assign'
        req_body = [dataclass_to_dict(assignment) for assignment in assignments]
        await self.put(url=url, json=req_body, organization_id=organization_id)

    async def assign_multiple_assignments(
        self,
        items: List[AssignMultipleAssignmentRequest],
        organization_id: Optional[str] = None,
    ) -> AssignAssignmentsResult:
        url = '/api/v0/taskflow/assign'
        req_body = [dataclass_to_dict(assignment) for assignment in items]
        response = await self.put(url=url, json=req_body, organization_id=organization_id)
        return from_dict(data_class=AssignAssignmentsResult, data=response)

    async def unassign_assignment(
        self,
        task_id: str,
        assignment_id: str,
        is_keep_price: Optional[bool] = None,
        is_decrease_overlap: Optional[bool] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        if is_keep_price:
            warnings.warn('is_keep_price is deprecated, and will be deleted in following releases', DeprecationWarning)
        url = f'/api/v0/taskflow/task/{task_id}/assignment/{assignment_id}/unassign'
        params = cast_params(
            is_keep_price=is_keep_price,
            is_decrease_overlap=is_decrease_overlap,
        )

        await self.put(url=url, organization_id=organization_id, params=params)

    # -----------------------------------------------------------------------------
    #                                  STORAGE
    # -----------------------------------------------------------------------------

    async def wait_until_sdct_done(
        self, task_id: str, retry_time: int = 10, organization_id: Optional[str] = None
    ) -> None:
        while True:
            sp_res = await self.get_storage_proxy_info(task_id=task_id, organization_id=organization_id)
            if sp_res is not None and sp_res.checking_files_count > 0:
                await asyncio.sleep(retry_time)
            else:
                break

    async def get_storage_proxy_info(self, task_id: str, organization_id: Optional[str] = None) -> Optional[SPInfo]:
        url = f'api/v0/storage/{task_id}/stat'
        resp = await self.get(url=url, ignore_statuses=404, params=cast_params(organization_id=organization_id))
        if resp is None:
            return None
        return from_dict(data_class=SPInfo, data=resp)

    async def _get_storage_proxy_files(self, task_id: str, organization_id: Optional[str] = None) -> List[TaskFile]:
        url = f'api/v0/storageproxy/{task_id}'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return [from_dict(data_class=TaskFile, data=item) for item in resp['items']]

    async def upload_folder_to_task(
        self,
        task_id: str,
        folder: Union[str, Path],
        batch_size: int = BATCH_SIZE,
        exclude_ext_filter: Optional[Set[str]] = None,
        organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
    ) -> UploadFilesResult:
        folder = Path(folder)

        files: List[Path] = []
        for f in folder.iterdir():
            if not f.is_file():
                continue
            if exclude_ext_filter is not None and f.suffix in exclude_ext_filter:
                continue
            files.append(f)

        return await self.upload_files(
            task_id=task_id, filepaths=files, batch_size=batch_size, organization_id=organization_id, tqdm_on=tqdm_on
        )

    async def upload_files(
        self,
        task_id: str,
        filepaths: Sequence[Union[str, Path]],
        batch_size: int = BATCH_SIZE,
        organization_id: Optional[str] = None,
        tqdm_on: Union[bool, str] = False,
        preserve_order: bool = False,
    ) -> UploadFilesResult:
        url = f'api/v0/stream_upload/{task_id}'

        async def check_task_upload(
            batch_files: List[Union[str, Path]], organization_id: Optional[str]
        ) -> List[Union[str, Path]]:
            return await self._check_task_uploaded(
                task_id=task_id, batch_files=batch_files, organization_id=organization_id
            )

        return await self.upload_files_base(
            url=url,
            filepaths=filepaths,
            batch_size=batch_size,
            organization_id=organization_id,
            check_upload=check_task_upload,
            tqdm_on=tqdm_on,
            preserve_order=preserve_order,
        )

    async def upload_methodics_file(
        self,
        method_id: str,
        filepath: Union[str, Path],
        file_type: MethodFileType,
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        url = f"api/v0/storage/method/{method_id}/{file_type.value}"

        check_upload = partial(self._check_dataset_uploaded, dataset_id=method_id, organization_id=organization_id)

        return await self.upload_files_base(
            url=url,
            filepaths=[filepath],
            organization_id=organization_id,
            check_upload=check_upload,
            method=HttpMethod.PUT,
        )

    async def replace_file(
        self,
        task_id: str,
        file_id: str,
        filepath: Union[str, Path],
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        url = f'api/v0/stream_upload/{task_id}/file/{file_id}'

        async def check_task_upload(
            batch_files: List[Union[str, Path]], organization_id: Optional[str] = None
        ) -> List[Union[str, Path]]:
            return await self._check_task_uploaded(
                task_id=task_id,
                batch_files=batch_files,
                organization_id=organization_id,
            )

        return await self.upload_files_base(
            url=url,
            filepaths=[filepath],
            organization_id=organization_id,
            check_upload=check_task_upload,
            method=HttpMethod.PUT,
        )

    async def upload_files_batch(
        self,
        url: str,
        batch_files: Sequence[Union[str, Path]],
        check_upload: Callable,
        organization_id: Optional[str] = None,
        method: HttpMethod = HttpMethod.POST,
    ) -> UploadFilesResult:
        result = UploadFilesResult(created_files=[], errors=[])
        for i in range(UPLOAD_ATTEMPTS):
            try:
                form = []
                for path in map(Path, batch_files):
                    try:
                        form.append(
                            {
                                'name': 'file',
                                'value': await aiofiles.open(path, 'rb'),
                                'filename': path.name,
                                'content_type': mimetypes.guess_type(str(path))[0] or 'application/json',
                            }
                        )
                    except FileNotFoundError:
                        logger.error(f'File not found error: {path}')

                if form:
                    resp = await self.custom_request(
                        method=method,
                        url=url,
                        form=form,
                        raise_for_status=False,
                        params=cast_params(organization_id=organization_id),
                    )
                    if 'error' in resp:
                        result.errors.append(resp['error'])
                        logger.error('error uploading files: %s', resp['error'])
                        break
                    resp = from_dict(data_class=UploadFilesResult, data=resp)
                    result.created_files.extend(resp.created_files)
                    result.errors.extend(resp.errors)
                    break

            except (
                aiohttp.client_exceptions.ClientConnectionError,
                aiohttp.client_exceptions.ClientResponseError,
                RuntimeError,
                JSONDecodeError,
            ):
                await asyncio.sleep(0.5)
                unaploaded = await check_upload(batch_files=batch_files, organization_id=organization_id)
                logger.info('error uploading files %s\nattempt no. %s', unaploaded, i)
                batch_files = unaploaded
                if i == UPLOAD_ATTEMPTS - 1:
                    raise

            finally:
                await asyncio.gather(*(x['value'].close() for x in form))

        return result

    async def safe_upload_files_batch(
        self,
        semaphore: asyncio.Semaphore,
        url: str,
        batch_files: Sequence[Union[str, Path]],
        check_upload: Callable,
        organization_id: Optional[str] = None,
        method: HttpMethod = HttpMethod.POST,
    ) -> UploadFilesResult:
        async with semaphore:
            return await self.upload_files_batch(
                url=url,
                batch_files=batch_files,
                check_upload=check_upload,
                organization_id=organization_id,
                method=method,
            )

    async def upload_files_base(
        self,
        url: str,
        filepaths: Sequence[Union[str, Path]],
        check_upload: Callable,
        batch_size: int = BATCH_SIZE,
        organization_id: Optional[str] = None,
        tqdm_on: Union[str, bool] = False,
        method: HttpMethod = HttpMethod.POST,
        preserve_order: bool = False,
    ) -> UploadFilesResult:
        files_num = len(filepaths)
        logger.debug('Uploading %s files to tagme storage %s', files_num, url)
        result = UploadFilesResult(created_files=[], errors=[])

        if preserve_order:
            for batch_files in chunks(
                filepaths, n=batch_size, tqdm_on=tqdm_on
            ):  # TODO: order in storage + batch_size > 1
                batch_res = await self.upload_files_batch(
                    url=url,
                    batch_files=batch_files,
                    check_upload=check_upload,
                    organization_id=organization_id,
                    method=method,
                )
                result.created_files += batch_res.created_files
                result.errors += batch_res.errors
            return result

        batch_futures: List[Coroutine] = []
        semaphore = asyncio.Semaphore(5)
        for batch_files in chunks(filepaths, n=batch_size, tqdm_on=tqdm_on):
            batch_futures.append(
                self.safe_upload_files_batch(
                    semaphore=semaphore,
                    url=url,
                    batch_files=batch_files,
                    check_upload=check_upload,
                    organization_id=organization_id,
                    method=method,
                )
            )
        batch_results: List[UploadFilesResult] = await asyncio.gather(*batch_futures)
        for item in batch_results:
            result.created_files += item.created_files
            result.errors += item.errors

        return result

    async def _check_task_uploaded(
        self, task_id: str, batch_files: List[Union[str, Path]], organization_id: Optional[str] = None
    ) -> List[Union[str, Path]]:
        if await self.get_storage_proxy_info(task_id, organization_id=organization_id) is not None:
            uploaded = await self._get_storage_proxy_files(task_id=task_id, organization_id=organization_id)

        else:
            uploaded = await run_with_pagination(
                self.get_task_files,
                task_id=task_id,
                organization_id=organization_id,
            )

        pool = {Path(x).name: x for x in batch_files}
        missing = set(pool.keys()).difference(x.name for x in uploaded)
        return [pool[x] for x in missing]

    async def update_meta_data(
        self, task_id: str, data: Union[List[Dict], List[UpdateMetaDataRequest]], organization_id: Optional[str] = None
    ) -> dict:
        if data and isinstance(data[0], UpdateMetaDataRequest):
            data = list(map(dataclass_to_dict, data))

        url = f'api/v0/meta/{task_id}'
        return await self.patch(url=url, json=data, params=cast_params(organization_id=organization_id))

    async def get_meta_data(
        self, task_id: str, file_uid: str, types: Optional[List[MetaType]] = None, organization_id: Optional[str] = None
    ) -> MetaData:
        url = f'api/v0/storage/{task_id}/meta'
        resp = await self.get(
            url=url,
            params=cast_params(
                types=types or (MetaType.PREMARKUP, MetaType.CONTROL, MetaType.EXPLANATION),
                file_uid=file_uid,
                map_keys=[('types', 'types[]')],
                organization_id=organization_id,
            ),
        )
        if resp is None:
            return MetaData()

        return from_dict(data_class=MetaData, data=resp)

    async def upload_single_file(self, url: str, file: Path, **kwargs: Any) -> Optional[Dict]:
        attempts = UPLOAD_ATTEMPTS
        file = Path(file)
        while attempts > 0:
            try:
                async with aiofiles.open(file.absolute(), mode='rb') as file_object:
                    form = [
                        {
                            'name': 'file',
                            'value': file_object,
                            'filename': file.name,
                            'content_type': mimetypes.guess_type(str(file))[0] or 'application/json',
                        }
                    ]
                    return await self.post(url=url, form=form, **kwargs)
            except aiohttp.client_exceptions.ClientResponseError as exc:
                if attempts <= 1 or exc.status >= 400:
                    raise exc
                time.sleep(0.1)
                attempts -= 1
            except (
                aiohttp.client_exceptions.ClientConnectionError,
                RuntimeError,
            ) as exc:
                if attempts <= 1:
                    raise exc
                time.sleep(0.1)
                attempts -= 1

        return None

    async def upload_table(
        self,
        task_id: str,
        file: Path,
        delimeter: Optional[str] = None,
        quotechar: Optional[str] = None,
        escapechar: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        url = f'api/v0/storage/{task_id}/upload_table_data'
        await self.upload_single_file(
            url=url,
            file=file,
            params=cast_params(
                delimeter=delimeter, quotechar=quotechar, escapechar=escapechar, organization_id=organization_id
            ),
            response_type=ResponseType.RAW_RESPONSE,
        )

    async def download_table_results(
        self,
        task_id: str,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        file_format: ExportFormat = ExportFormat.CSV,
        organization_id: Optional[str] = None,
        make_file: bool = True,
    ) -> Optional[List]:
        url = 'api/v0/assignments'
        params = cast_params(
            task_id=task_id,
            date_from=date_from,
            date_to=date_to,
            file_format=file_format,
            map_keys=[('file_format', 'format')],
            organization_id=organization_id,
        )
        if file_format == ExportFormat.JSON:
            resp = await self.get(url=url, params=params)
            if make_file:
                results = (Path(__file__).parent / 'results').with_suffix(EXPORT_SUFFIX[file_format])
                with open(results, 'w') as f:
                    json.dump(resp, f)
            return resp
        else:
            raw_resp = await self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)
            results = (Path(__file__).parent / 'results').with_suffix(EXPORT_SUFFIX[file_format])
            with open(results, 'wb') as fbin:
                fbin.write(raw_resp)
            return None

    async def get_task_files(
        self,
        task_id: str,
        query: Optional[str] = None,
        types: Optional[List[Union[FileType, str]]] = None,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        organization_id: Optional[str] = None,
    ) -> PaginatedResponse[TaskFile]:
        url = f'api/v0/storage/{task_id}'

        resp = await self.get(
            url=url,
            params=cast_params(
                page=page,
                size=size,
                query=query,
                types=types,
                map_keys=[('types', 'types[]')],
                organization_id=organization_id,
            ),
        )
        return get_paginated_response(resp, TaskFile)

    async def get_task_files_count(
        self,
        task_id: str,
        types: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
    ) -> TaskFilesCount:
        url = f'/api/v0/storage/{task_id}/files_count'

        if types is None:
            types = ["all", "control", "study", "data"]

        resp = await self.get(
            url=url,
            params=cast_params(
                types=types,
                organization_id=organization_id,
                map_keys=[('types', 'type[]')],
            ),
        )
        return from_dict(data_class=TaskFilesCount, data=resp)

    async def get_task_files_meta(self, task_id: str, organization_id: Optional[str] = None) -> List[FileMetaData]:
        url = f'api/v0/storage/{task_id}/meta/all'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return [from_dict(data_class=FileMetaData, data=_) for _ in resp]

    async def download_file(self, task_id: str, file_id: str, organization_id: Optional[str] = None) -> bytes:
        url = f'api/v0/storage/{task_id}/{file_id}'
        return await self.get(
            url=url, response_type=ResponseType.RAW_RESPONSE, params=cast_params(organization_id=organization_id)
        )

    async def disable_control_task(self, task_id: str, file_uid: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/storage/{task_id}/{file_uid}/disable'
        return await self.put(url=url, params=cast_params(organization_id=organization_id))

    async def get_file(self, task_id: str, file_uid: str, organization_id: Optional[str] = None) -> TaskFile:
        url = f'api/v0/storage/{task_id}/{file_uid}/info'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskFile, data=resp)

    async def get_all_files(
        self,
        task_id: str,
        query: Optional[str] = None,
        types: Optional[List[Union[FileType, str]]] = None,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        organization_id: Optional[str] = None,
    ) -> PaginatedResponse[TaskFile]:
        url = f'api/v0/storage/{task_id}/all_files'
        adhoc_types = [t.value.lower() if isinstance(t, FileType) else t for t in types or []]
        # TODO(cerikoff): remove this adhock when input type will be == output type
        resp = await self.get(
            url=url,
            params=cast_params(
                page=page,
                size=size,
                query=query,
                types=adhoc_types,
                map_keys=[('types', 'types[]')],
                organization_id=organization_id,
            ),
        )
        return get_paginated_response(resp, TaskFile)

    # -----------------------------------------------------------------------------
    #                                  EMPLOYEES
    # -----------------------------------------------------------------------------

    async def add_employee_to_organization(
        self, person_id: str, roles: List[str] = None, organization_id: str = None
    ) -> Employee:
        url = "api/v0/employee"
        if not roles:
            roles = []
        resp = await self.post(
            url=url,
            json=cast_params(person_id=person_id, roles=roles, organization_id=organization_id),
        )
        return from_dict(data_class=Employee, data=resp)

    async def set_employee_info(
        self,
        employee_id: str,
        profile: Optional[Dict[str, Any]] = None,
        report: Optional[Dict[str, Any]] = None,
        config: Optional[Dict[str, Any]] = None,
        roles: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
    ) -> Employee:
        url = f'api/v0/employee/{employee_id}'
        resp = await self.put(
            url=url,
            json=cast_params(profile=profile, report=report, config=config, roles=roles),
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=Employee, data=resp)

    async def update_employee_info(
        self,
        employee_id: str,
        profile: Optional[Dict[str, Any]] = None,
        report: Optional[Dict[str, Any]] = None,
        config: Optional[Dict[str, Any]] = None,
        roles: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
    ) -> Employee:
        employee = await self.get_employee_info(employee_id, organization_id=organization_id)
        employee.profile.update(profile or {})
        employee.report.update(report or {})
        employee.config.update(config or {})
        profile = employee.profile
        report = employee.report
        config = employee.config
        url = f'api/v0/employee/{employee_id}'
        resp = await self.put(
            url=url,
            json=cast_params(profile=profile, report=report, config=config, roles=roles),
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=Employee, data=resp)

    async def get_employee_info(
        self,
        employee_id: str,
        with_pools: Optional[bool] = None,
        with_info: Optional[bool] = None,
        organization_id: Optional[str] = None,
    ) -> Employee:
        url = f'api/v0/employee/{employee_id}'
        resp = await self.get(
            url=url, params=cast_params(withPools=with_pools, withPersonInfo=with_info, organization_id=organization_id)
        )
        return from_dict(data_class=Employee, data=resp)

    async def get_employees(
        self,
        query: Optional[str] = None,
        person_ids: Optional[List[str]] = None,
        with_pools: Optional[bool] = None,
        with_info: Optional[bool] = None,
        organization_id: Optional[str] = None,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        active: Optional[bool] = None,
        roles: Optional[List[str]] = None,
    ) -> PaginatedResponse[Employee]:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/employees'
        resp = await self.get(
            url=url,
            params=cast_params(
                withPools=with_pools,
                withPersonInfo=with_info,
                query=query,
                organization_id=organization_id,
                page=page,
                size=size,
                active=active,
                person_id=person_ids,
                role=roles,
                map_keys=[('person_id', 'person_id[]'), ('role', 'role[]')],
            ),
        )
        return get_paginated_response(resp, Employee)

    # -----------------------------------------------------------------------------
    #                                  MARKERS
    # -----------------------------------------------------------------------------

    async def get_marker_info(
        self, marker_id: str, with_pools: bool, with_info: bool, organization_id: Optional[str] = None
    ) -> Employee:
        employees = await run_with_pagination(
            self.get_employees,
            with_pools=with_pools,
            with_info=with_info,
            person_ids=[marker_id],
            organization_id=organization_id,
        )

        if not employees:
            raise ValueError(f'not found marker with id={marker_id}')

        return employees[0]

    async def get_persons(
        self,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        query: Optional[str] = None,
        emails: Optional[List[str]] = None,
        with_organizations: Optional[bool] = None,
        organization_id: Optional[str] = None,
        person_ids: Optional[List[str]] = None,
        only_active: Optional[bool] = None,
    ) -> PaginatedResponse[Person]:
        url = 'api/v0/persons'
        resp = await self.get(
            url=url,
            params=cast_params(
                page=page,
                size=size,
                query=query,
                emails=emails,
                withOrganizations=with_organizations,
                organization_id=organization_id,
                person_ids=person_ids,
                only_active=only_active,
                map_keys=[('person_ids', 'person_id[]'), ('emails', 'emails[]')],
            ),
        )
        return get_paginated_response(resp, Person)

    async def add_marker(
        self, marker_email: str, pools: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        return await self.add_markers(emails=[marker_email], pools=pools, organization_id=organization_id)

    async def add_markers(
        self, emails: List[str], pools: List[str], organization_id: Optional[str] = None
    ) -> ErrorMarkersResponse:
        url = 'api/v0/markers'
        resp = await self.post(
            url=url, json=cast_params(emails=emails, pools=pools), params=cast_params(organization_id=organization_id)
        )
        return from_dict(ErrorMarkersResponse, resp)

    async def get_marker_project_stats(
        self,
        project_id: str,
        from_date: Union[Tuple[int, int, int], str],  # year, month, day
        to_date: Union[Tuple[int, int, int], str],  # year, month, day
        types: Iterable[str] = ('markers',),  # tasks
        stats_format: str = 'csv',
        organization_id: Optional[str] = None,
    ) -> bytes:
        url = f'api/v0/statistics/project/{project_id}/export'
        from_date = parse_date_tuple(from_date)
        to_date = parse_date_tuple(to_date)
        params = cast_params(
            from_date=from_date,
            to_date=to_date,
            format=stats_format,
            types=types,
            organization_id=organization_id,
            map_keys=[('from_date', 'from'), ('to_date', 'to'), ('types', 'types[]')],
        )
        return await self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)

    async def get_marker_stats(
        self,
        date_from: str,
        date_to: str,
        types: Iterable[str] = ('markers',),
        stats_format: str = 'csv',
        organization_id: Optional[str] = None,
    ) -> bytes:
        organization_id = organization_id or await self.get_current_organization_id()
        url = f'api/v0/statistics/organization/{organization_id}/export'
        params = cast_params(
            organization_id=organization_id,
            date_from=date_from,
            date_to=date_to,
            types=types,
            format=stats_format,
            map_keys=[('date_from', 'from'), ('date_to', 'to'), ('types', 'types[]')],
        )
        return await self.get(url=url, params=params, response_type=ResponseType.RAW_RESPONSE)

    async def get_project_public_assignments(
        self,
        project_id: str,
        organization_id: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> GetProjectPublicAssignmentsResponse:
        url = f"/api/v0/taskflow/project/{project_id}/public_assignments"

        params = cast_params(organization_id=organization_id)
        if page is not None:
            params["page"] = page
        if size is not None:
            params["size"] = size

        resp = await self.get(url=url, params=params)
        return from_dict(data_class=GetProjectPublicAssignmentsResponse, data=resp)

    async def get_projects_with_public_assignments(
        self,
        organization_id: Optional[str] = None,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> List[ProjectsWithPublicAssignment]:
        url = "/api/v0/taskflow/get_public_projects"

        params = cast_params(organization_id=organization_id)
        if page is not None:
            params["page"] = page
        if size is not None:
            params["size"] = size
        if query is not None:
            params["query"] = query

        resp = await self.get(url=url, params=params)
        return [from_dict(data_class=ProjectsWithPublicAssignment, data=item) for item in resp]

    # -----------------------------------------------------------------------------
    #                                  SKILLS
    # -----------------------------------------------------------------------------

    async def create_skill(
        self, name: str, organization_id: Optional[str] = None, is_public: bool = False, window_size: int = 64
    ) -> Skill:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/skill'
        resp = await self.post(
            url=url,
            json=cast_params(
                organization_id=organization_id,
                name=name,
                is_public=is_public,
                window_size=window_size,
                cast_bool=False,
            ),
        )
        return from_dict(data_class=Skill, data=resp)

    async def get_skill(self, skill_id: str, organization_id: Optional[str] = None) -> Skill:
        organization_id = organization_id or await self.get_current_organization_id()
        url = f'api/v0/skill/{skill_id}'
        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=Skill, data=resp)

    async def disable_skill(self, skill_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/skill/{skill_id}/disable'
        await self.post(url=url, params=cast_params(organization_id=organization_id))

    async def enable_skill(self, skill_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/skill/{skill_id}/enable'
        await self.post(url=url, params=cast_params(organization_id=organization_id))

    async def get_skills_list(
        self,
        query: Optional[str] = None,
        with_markers_count: Optional[bool] = None,
        organization_id: Optional[str] = None,
        size: int = DEFAULT_PAGE_SIZE,
        page: int = DEFAULT_PAGE_NUMBER,
    ) -> PaginatedResponse[Skill]:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/skills'
        params = cast_params(
            orgId=organization_id,
            organization_id=organization_id,
            withMarkersCount=with_markers_count,
            query=query,
            page=page,
            size=size,
        )
        resp = await self.get(url=url, params=params)
        return get_paginated_response(resp, Skill)

    async def get_public_skills_list(
        self,
        query: Optional[str] = None,
        size: Optional[int] = None,
        page: Optional[int] = None,
    ) -> List[PublicSkill]:
        url = 'api/v0/taskflow/skills'
        params = cast_params(
            page=page,
            size=size,
            query=query,
        )
        resp = await self.get(url=url, params=params)
        return [from_dict(data_class=PublicSkill, data=item) for item in resp['items']]

    async def get_markers_skills_list(
        self,
        query: Optional[str] = None,
        size: int = DEFAULT_PAGE_SIZE,
        page: int = DEFAULT_PAGE_NUMBER,
        organization_id: Optional[str] = None,
        with_info: Optional[bool] = None,
    ) -> Tuple[List[MarkerSkill], int, bool]:
        organization_id = organization_id or await self.get_current_organization_id()
        url = 'api/v0/skills/by_marker'

        params = cast_params(
            orgId=organization_id,
            organization_id=organization_id,
            page=page,
            size=size,
            query=query,
            withPersonInfo=with_info,
        )
        resp = await self.get(url=url, params=params)
        items = [from_dict(data_class=MarkerSkill, data=item) for item in resp['items']]
        has_next = resp['has_next']
        return items, page, has_next

    async def set_marker_skill(
        self,
        marker_id: str,
        skill_id: str,
        value: int,
        organization_id: Optional[str] = None,
    ) -> SetMarkerSkillResponse:
        url = f'api/v0/skill/{skill_id}/{marker_id}'
        resp = await self.put(
            url=url, json=cast_params(value=value), params=cast_params(organization_id=organization_id)
        )
        return from_dict(data_class=SetMarkerSkillResponse, data=resp)

    async def set_skills_by_markers(
        self, table_path: Union[Path, str], organization_id: Optional[str] = None
    ) -> SetMarkersSkillsResponse:
        url = "api/v0/skills/by_marker/upload"
        data = aiohttp.FormData()

        path = Path(table_path) if isinstance(table_path, str) else table_path

        with path.open("rb") as f:
            data.add_field("file", f, filename=f"file.{path.suffix}")

            resp = await self.put(url=url, data=data, params=cast_params(organization_id=organization_id))

        return from_dict(data_class=SetMarkersSkillsResponse, data=resp)

    async def set_skills_by_markers_with_json(
        self, json_data: List[Dict[str, Any]], organization_id: Optional[str] = None
    ) -> SetMarkersSkillsResponse:
        url = "api/v0/skills/by_marker/upload"

        resp = await self.put(url=url, json=json_data, params=cast_params(organization_id=organization_id))

        return from_dict(data_class=SetMarkersSkillsResponse, data=resp)

    async def update_skill(
        self,
        skill_id: str,
        name: str,
        window_size: int = 10,
        is_public: bool = False,
        organization_id: Optional[str] = None,
    ) -> Skill:
        url = f'api/v0/skill/{skill_id}'
        resp = await self.put(
            url=url,
            json=cast_params(name=name, window_size=window_size, is_public=is_public, cast_bool=False),
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=Skill, data=resp)

    # -----------------------------------------------------------------------------
    #                                  DATASETS
    # -----------------------------------------------------------------------------

    async def create_dataset(
        self,
        name: str,
        data_classification_level: Optional[str] = None,
        access: str = 'organization',
        data_source: Optional[str] = None,
        organization_id: Optional[str] = None,
        acl: Optional[List[str]] = None,
        dataset_type: Optional[str] = DatasetType.DATASET.value,
    ) -> Dataset:
        url = 'api/v0/datasets'

        resp = await self.post(
            url=url,
            json={
                'name': name,
                'access': access,
                'data_classification_level': data_classification_level or self.config.data_category,
                'data_source': data_source or self.config.data_source,
                'acl': acl,
                'dataset_type': dataset_type,
            },
            params={'organization_id': organization_id},
        )
        return from_dict(data_class=Dataset, data=resp)

    async def update_dataset(
        self,
        dataset_id: str,
        name: str,
        data_classification_level: Optional[str] = None,
        data_source: Optional[str] = None,
        organization_id: Optional[str] = None,
        access: Optional[str] = None,
        acl: Optional[List[str]] = None,
    ) -> Dataset:
        url = f'api/v0/datasets/{dataset_id}'

        resp = await self.put(
            url=url,
            json=cast_params(
                name=name,
                data_classification_level=data_classification_level or self.config.data_category,
                data_source=data_source or self.config.data_source,
                access=access,
                acl=acl,
            ),
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=Dataset, data=resp)

    async def get_dataset(self, dataset_id: str, organization_id: Optional[str] = None) -> Dataset:
        url = f'api/v0/datasets/{dataset_id}'

        resp = await self.get(
            url=url,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=Dataset, data=resp)

    async def get_datasets(
        self,
        page: Optional[int] = None,
        size: Optional[int] = None,
        query: Optional[str] = None,
        organization_id: Optional[str] = None,
        with_authors: Optional[bool] = None,
    ) -> List[Dataset]:
        if size is None:
            size = 100
        url = 'api/v0/datasets'
        with_authors_str = "true" if with_authors else None

        resp = {'has_next': True, 'items': []}
        results: List[Dataset] = []

        if page is None:
            page = 1
            while resp['has_next']:
                resp = await self.get(
                    url=url,
                    params=cast_params(
                        page=page,
                        size=size,
                        query=query,
                        organization_id=organization_id,
                        with_authors=with_authors_str,
                    ),
                )
                page += 1
                results.extend([from_dict(data_class=Dataset, data=item) for item in resp['items']])  # type: ignore
        else:
            resp = await self.get(
                url=url,
                params=cast_params(
                    page=page,
                    size=size,
                    query=query,
                    organization_id=organization_id,
                    with_authors=with_authors_str,
                ),
            )
            results.extend([from_dict(data_class=Dataset, data=item) for item in resp['items']])  # type: ignore
        return results

    # ----------items-----------
    async def get_dataset_files(
        self,
        dataset_id: str,
        organization_id: Optional[str] = None,
        with_authors: Optional[bool] = None,
    ) -> List[DatasetFile]:
        url = f'api/v0/datasets/{dataset_id}/files/info'

        with_authors_str = "true" if with_authors else None
        resp = {'has_next': True, 'items': []}
        results: List[DatasetFile] = []
        page = 1
        while resp['has_next']:
            resp = await self.get(
                url=url,
                params=cast_params(
                    page=page,
                    size=100,
                    map_keys=[('types', 'types[]')],
                    organization_id=organization_id,
                    with_authors=with_authors_str,
                ),
            )
            page += 1
            results.extend([from_dict(data_class=DatasetFile, data=item) for item in resp['items']])  # type: ignore

        return results

    async def get_dataset_file(
        self,
        file_id: str,
        organization_id: Optional[str] = None,
    ) -> DatasetFile:
        url = f"/api/v0/files/{file_id}/info"

        resp = await self.get(
            url=url,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=DatasetFile, data=resp)

    async def upload_folder_to_dataset(
        self,
        dataset_id: str,
        folder: Union[str, Path],
        batch_size: int = BATCH_SIZE,
        exclude_ext_filter: Optional[Set[str]] = None,
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        folder = Path(folder)

        files: List[Path] = []
        for f in folder.iterdir():
            if not f.is_file():
                continue
            if exclude_ext_filter is not None and f.suffix in exclude_ext_filter:
                continue
            files.append(f)

        return await self.upload_dataset_files(dataset_id, files, batch_size, organization_id=organization_id)

    async def upload_dataset_files(
        self,
        dataset_id: str,
        filepaths: Sequence[Union[str, Path]],
        batch_size: int = BATCH_SIZE,
        organization_id: Optional[str] = None,
        tqdm_on: Union[str, bool] = False,
    ) -> UploadFilesResult:
        url = f'api/v0/datasets/{dataset_id}/files'

        async def check_dataset_upload(
            batch_files: List[Union[str, Path]],
            organization_id: Optional[str] = None,
        ) -> List[Union[str, Path]]:
            return await self._check_dataset_uploaded(dataset_id, batch_files, organization_id=organization_id)

        return await self.upload_files_base(
            url=url,
            filepaths=filepaths,
            batch_size=batch_size,
            organization_id=organization_id,
            check_upload=check_dataset_upload,
            tqdm_on=tqdm_on,
        )

    async def replace_dataset_file(
        self,
        dataset_id: str,
        file_id: str,
        filepath: Union[str, Path],
        organization_id: Optional[str] = None,
    ) -> UploadFilesResult:
        url = f'api/v0/datasets/{dataset_id}/files/{file_id}'

        async def check_dataset_upload(
            batch_files: List[Union[str, Path]],
            organization_id: Optional[str] = None,
        ) -> List[Union[str, Path]]:
            return await self._check_dataset_uploaded(dataset_id, batch_files, organization_id=organization_id)

        return await self.upload_files_base(
            url=url,
            filepaths=[filepath],
            organization_id=organization_id,
            check_upload=check_dataset_upload,
            method=HttpMethod.PUT,
        )

    async def _check_dataset_uploaded(
        self, dataset_id: str, batch_files: List[Union[str, Path]], organization_id: Optional[str] = None
    ) -> List[Union[str, Path]]:
        uploaded = await self.get_dataset_files(dataset_id, organization_id=organization_id)

        pool = {Path(x).name: x for x in batch_files}
        missing = set(pool.keys()).difference(x.name for x in uploaded)
        return [pool[x] for x in missing]

    async def download_dataset_file(
        self, file_id: str, organization_id: Optional[str] = None, with_headers: bool = False
    ) -> Union[bytes, Any]:
        url = f'api/v0/files/{file_id}'
        return await self.get(
            url=url,
            response_type=ResponseType.RAW_RESPONSE,
            params=cast_params(organization_id=organization_id),
            return_headers=with_headers,
        )

    async def remove_dataset(self, dataset_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/datasets/{dataset_id}'
        await self.delete(url=url, params=cast_params(organization_id=organization_id))

    async def delete_file(self, file_id: str, organization_id: Optional[str] = None) -> None:
        url = f'/api/v0/files/{file_id}'
        await self.delete(url=url, params=cast_params(organization_id=organization_id))

    async def get_org_lora_dataset(self, organization_id: Optional[str] = None) -> Dataset:
        url = '/api/v0/datasets/lora'

        resp = await self.get(
            url=url,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=Dataset, data=resp)

    # -------------- partner invite -----------
    async def apply_partner_invite(self, invite_name: str, partner_id: str, utm_referral: Optional[str] = None) -> None:
        url = f'api/v0/partner_invite/{invite_name}'
        await self.put(url=url, json=cast_params(partner_id=partner_id, utm_referral=utm_referral))

    async def get_active_vendor_change_request(self) -> Optional[VendorChangeRecord]:
        url = 'api/v0/partner_invite'

        resp = await self.get(url=url)
        return from_dict(data_class=VendorChangeRecord, data=resp)

    async def cancel_vendor_change_request(self) -> None:
        url = 'api/v0/partner_invite/cancel_request'
        await self.put(url=url)

    # -----------------------------------------------------------------------------
    #                                  TEMPLATES
    # -----------------------------------------------------------------------------

    async def get_template(self, template_id: str, organization_id: Optional[str] = None) -> Template:
        url = f'api/v0/templates/{template_id}'
        resp = await self.get(
            url=url,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=Template, data=resp)

    async def create_template(
        self,
        name: str,
        description: Optional[str] = None,
        documentation: Optional[str] = None,
        contacts: Optional[str] = None,
        categories: Optional[List[str]] = None,
        from_method_id: Optional[str] = None,
        organization_id: Optional[str] = None,
        access: Optional[str] = None,
        acl: Optional[List[str]] = None,
    ) -> Template:
        url = 'api/v0/templates'
        resp = await self.post(
            url=url,
            json=cast_params(
                name=name,
                description=description,
                documentation=documentation,
                contacts=contacts,
                categories=categories,
                from_method_id=from_method_id,
                organization_id=organization_id,
                access=access,
                acl=acl,
            ),
        )
        return from_dict(data_class=Template, data=resp)

    async def publish_template(self, template_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/templates/{template_id}/publish'
        await self.put(
            url=url,
            params=cast_params(organization_id=organization_id),
        )

    async def unpublish_template(self, template_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/templates/{template_id}/unpublish'
        await self.put(
            url=url,
            params=cast_params(organization_id=organization_id),
        )

    async def get_templates_list(
        self,
        query: Optional[str] = None,
        categories: Optional[List[str]] = None,
        archived: Optional[bool] = None,
        size: int = DEFAULT_PAGE_SIZE,
        page: int = DEFAULT_PAGE_NUMBER,
        organization_id: Optional[str] = None,
    ) -> PaginatedResponse[Template]:
        url = 'api/v0/templates'
        params = cast_params(
            query=query,
            categories=categories,
            archived=archived,
            page=page,
            size=size,
            organization_id=organization_id,
            map_keys=[('categories', 'categories[]')],
        )
        resp = await self.get(url=url, params=params)
        return get_paginated_response(resp, Template)

    async def update_template(
        self,
        template_id: str,
        name: str,
        description: Optional[str] = None,
        documentation: Optional[str] = None,
        contacts: Optional[str] = None,
        categories: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
        access: Optional[str] = None,
        acl: Optional[List[str]] = None,
    ) -> Template:
        url = f'api/v0/templates/{template_id}'
        resp = await self.put(
            url=url,
            json=cast_params(
                name=name,
                description=description,
                documentation=documentation,
                contacts=contacts,
                categories=categories,
                organization_id=organization_id,
                access=access,
                acl=acl,
            ),
        )
        return from_dict(data_class=Template, data=resp)

    async def check_template(self, template_id: str, organization_id: Optional[str] = None) -> CheckTemplateResult:
        url = f'api/v0/templates/{template_id}/check'
        resp = await self.get(
            url=url,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=CheckTemplateResult, data=resp)

    async def get_published_templates_list(
        self,
        query: Optional[str] = None,
        categories: Optional[List[str]] = None,
        size: int = DEFAULT_PAGE_SIZE,
        page: int = DEFAULT_PAGE_NUMBER,
        organization_id: Optional[str] = None,
    ) -> PaginatedResponse[Template]:
        url = '/api/v0/templates/published'
        params = cast_params(
            query=query,
            categories=categories,
            page=page,
            size=size,
            organization_id=organization_id,
        )
        resp = await self.get(url=url, params=params)
        return get_paginated_response(resp, Template)

    async def apply_template_to_project(
        self,
        template_id: str,
        project_id: str,
        organization_id: Optional[str] = None,
        autoupdate_params: Optional[dict] = None,
    ) -> None:
        url = f'api/v0/templates/{template_id}/apply_to_project/{project_id}'
        await self.put(
            url=url,
            params=cast_params(organization_id=organization_id),
            json=(
                cast_params(
                    **autoupdate_params,
                )
                if autoupdate_params
                else None
            ),
        )

    async def add_images_to_template(
        self, template_id: str, files_paths: List[str], organization_id: Optional[str] = None
    ) -> UploadFilesResult:
        data = FormData()
        with ExitStack() as stack:
            for file_path in files_paths:
                data.add_field(
                    "file",
                    stack.enter_context(open(file_path, "rb")),
                    filename=os.path.basename(file_path),
                )
            url = f'api/v0/templates/{template_id}/add_images'
            resp = await self.post(
                url=url,
                data=data,
                params=cast_params(organization_id=organization_id),
            )
        return from_dict(data_class=UploadFilesResult, data=resp)

    async def get_template_images_list(
        self, template_id: str, organization_id: Optional[str] = None
    ) -> SimpleImagesListResult:
        url = f'api/v0/templates/{template_id}/images_list'
        resp = await self.get(
            url=url,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=SimpleImagesListResult, data=resp)

    async def upload_template_preview(
        self, template_id: str, files_paths: List[str], organization_id: Optional[str] = None
    ) -> PreviewFileResult:
        data = FormData()
        with ExitStack() as stack:
            for file_path in files_paths:
                data.add_field(
                    "file",
                    stack.enter_context(open(file_path, "rb")),
                    filename=os.path.basename(file_path),
                )
            url = f'api/v0/templates/{template_id}/upload_preview'
            resp = await self.put(
                url=url,
                data=data,
                params=cast_params(organization_id=organization_id),
            )
        return from_dict(data_class=PreviewFileResult, data=resp)

    async def delete_template_preview(self, template_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/templates/{template_id}/delete_preview'
        await self.put(
            url=url,
            params=cast_params(organization_id=organization_id),
        )

    async def archive_template(self, template_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/templates/{template_id}/archive'
        await self.put(
            url=url,
            params=cast_params(organization_id=organization_id),
        )

    async def unarchive_template(self, template_id: str, organization_id: Optional[str] = None) -> None:
        url = f'api/v0/templates/{template_id}/unarchive'
        await self.put(
            url=url,
            params=cast_params(organization_id=organization_id),
        )

    # -----------------------------------------------------------------------------
    #                                  VALIDATORS
    # -----------------------------------------------------------------------------
    async def send_validation_task(
        self,
        file_id: str,
        validators: List[Union[str, ValidationRequestItem]],
        test_file_id: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        req_validators: List[dict] = []
        for item in validators:
            if isinstance(item, str):
                req_validators.append({"source": item, "options": {}})
            else:
                req_validators.append({"source": item.source, "options": item.options})
        url = "/api/v0/validation"
        params = cast_params(
            organization_id=organization_id,
        )
        body = cast_params(file_id=file_id, validators=req_validators, test_file_id=test_file_id)
        await self.post(
            url=url,
            params=params,
            json=body,
        )

    async def get_validation_status(
        self,
        file_id: str,
        organization_id: Optional[str] = None,
    ) -> ValidationPipelineResult:
        url = f"/api/v0/validation/{file_id}"
        params = cast_params(organization_id=organization_id)
        response = await self.get(url, params=params)
        return from_dict(data_class=ValidationPipelineResult, data=response)

    async def cancel_validation_task(
        self,
        file_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        url = f"/api/v0/validation/{file_id}/cancel"
        params = cast_params(organization_id=organization_id)
        await self.post(url, params=params)

    async def get_validators(self) -> List[ValidatorDetail]:
        url = "/api/v0/validators"
        response = await self.get(url)
        return [from_dict(data_class=ValidatorDetail, data=item) for item in response]

    async def get_validator(self, source: str) -> ValidatorDetail:
        url = f"/api/v0/validators/info/{source}"
        response = await self.get(url)
        return from_dict(data_class=ValidatorDetail, data=response)

    async def get_base_validators_source_code(self) -> Dict[str, str]:
        url = "/api/v0/validators/base"
        response = await self.get(url)
        return response

    async def get_validator_source_code(self, source: str) -> str:
        url = f"/api/v0/validators/source/{source}"
        response = await self.get(url, response_type=ResponseType.TEXT_RESPONSE)
        return response

    async def get_validator_projects(
        self,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> List[ValidatorProject]:
        url = "/api/v0/taskflow/validator/projects"
        params = cast_params(
            query=query,
            page=page,
            size=size,
        )
        response = await self.get(url=url, params=params)
        return [from_dict(data_class=ValidatorProject, data=item) for item in response["items"]]

    async def get_validator_project(self, project_id: str) -> ValidatorProject:
        url = f'/api/v0/taskflow/validator/project/{project_id}'
        response = await self.get(url)
        return from_dict(data_class=ValidatorProject, data=response)

    async def get_validator_tasks(
        self,
        project_id: str,
        query: Optional[str] = None,
        page: Optional[int] = None,
        size: Optional[int] = None,
    ) -> List[ValidatorTask]:
        url = f'/api/v0/taskflow/validator/project/{project_id}/tasks'
        params = cast_params(
            query=query,
            page=page,
            size=size,
        )
        response = await self.get(url=url, params=params)
        return [from_dict(data_class=ValidatorTask, data=item) for item in response["items"]]

    async def get_validator_task(self, project_id: str, task_id: str) -> ValidatorTask:
        url = f'/api/v0/taskflow/validator/project/{project_id}/task/{task_id}'
        response = await self.get(url)
        return from_dict(data_class=ValidatorTask, data=response)

    async def get_validator_user_info(self) -> ValidatorInfo:
        url = "/api/v0/taskflow/user/info"
        response = await self.get(url=url)
        return from_dict(data_class=ValidatorInfo, data=response)

    # -----------------------------------------------------------------------------
    #                                  LORA-MODELS
    # -----------------------------------------------------------------------------
    async def create_model(
        self,
        model_data: Union[ModelCreateRequest, dict],
        organization_id: Optional[str] = None,
    ) -> Model:
        url = 'api/v0/models'
        organization_id = organization_id or await self.get_current_organization_id()

        if isinstance(model_data, ModelCreateRequest):
            model_data = dataclass_to_dict(model_data)

        resp = await self.post(url=url, json=model_data, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=Model, data=resp)

    async def get_model(
        self,
        model_id: str,
        organization_id: Optional[str] = None,
    ) -> Model:
        url = f'api/v0/models/{model_id}'
        organization_id = organization_id or await self.get_current_organization_id()

        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=Model, data=resp)

    async def get_all_lora_models(
        self,
        organization_id: Optional[str] = None,
    ) -> List[Model]:
        url = "api/v0/models"
        organization_id = organization_id or await self.get_current_organization_id()

        resp = await self.get(url=url, params=cast_params(organization_id=organization_id))
        return [from_dict(data_class=Model, data=model) for model in resp]

    async def delete_model(
        self,
        model_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        url = f'api/v0/models/{model_id}'
        organization_id = organization_id or await self.get_current_organization_id()

        await self.delete(url=url, params=cast_params(organization_id=organization_id))

    async def verify_lora_configuration(
        self,
        business_task_id: str,
        model_version_id: str,
        organization_id: Optional[str] = None,
    ) -> VerifyLoraConfiguration:
        url = "api/v0/lora/configuration/verify"
        resp = await self.put(
            url=url,
            params=cast_params(
                organization_id=organization_id,
            ),
            json={
                "mms_business_task_id": business_task_id,
                "mms_model_version_id": model_version_id,
            },
        )
        return from_dict(data_class=VerifyLoraConfiguration, data=resp)

    async def create_organization_configuration(
        self,
        configuration_data: Union[dict, CreateOrganizationConfiguration],
        organization_id: Optional[str] = None,
    ) -> OrganizationConfiguration:
        url = "api/v0/lora/configuration"
        if isinstance(configuration_data, CreateOrganizationConfiguration):
            configuration_data = dataclass_to_dict(configuration_data)

        resp = await self.post(
            url=url,
            params=cast_params(organization_id=organization_id),
            json=configuration_data,
        )
        return from_dict(data_class=OrganizationConfiguration, data=resp)

    async def get_lora_configuration(
        self,
        organization_id: Optional[str] = None,
    ) -> OrganizationConfiguration:
        url = "api/v0/lora/configuration"
        resp = await self.get(
            url=url,
            params=cast_params(organization_id=organization_id),
        )
        return from_dict(data_class=OrganizationConfiguration, data=resp)

    async def delete_lora_configuration(
        self,
        organization_id: Optional[str] = None,
    ) -> None:
        url = "api/v0/lora/configuration"
        return await self.delete(
            url=url,
            params=cast_params(organization_id=organization_id),
        )

    async def initialize_mls_project(
        self,
        organization_id: Optional[str] = None,
    ) -> None:
        url = "api/v0/lora/mls/init"
        return await self.post(
            url=url,
            params=cast_params(organization_id=organization_id),
        )

    async def create_model_train(
        self,
        model_id: str,
        model_alias: str,
        model_tuned_alias: str,
        comment: str,
        file_id: Optional[str] = None,
        filename: Optional[str] = None,
        published: Optional[bool] = None,
        model_tuned_file_id: Optional[str] = None,
        model_tuned_id: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> str:
        url = f"/api/v0/models/{model_id}/train"
        body = cast_params(
            model_alias=model_alias,
            model_tuned_alias=model_tuned_alias,
            comment=comment,
            file_id=file_id,
            filename=filename,
            published=published,
            model_tuned_file_id=model_tuned_file_id,
            model_tuned_id=model_tuned_id,
        )
        params = cast_params(organization_id=organization_id)
        resp = await self.post(url, params=params, json=body)
        return resp["uid"]

    async def transit_file_to_ml_storage(
        self,
        model_id: str,
        train_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        url = f"/api/v0/models/{model_id}/train/{train_id}/ml_storage/upload"
        return await self.post(url, params=cast_params(organization_id=organization_id))

    # -----------------------------------------------------------------------------
    #                                  CONSISTENCY CALCULATION
    # -----------------------------------------------------------------------------
    async def validate_task_results(
        self,
        task_id: str,
        algorithm: Literal["krippendorff", "spearman", "dawid_skene", "ttest", "confidence_interval"],
        criteria: List[str],
        options: Optional[dict] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        url = f"api/v0/validation/results/{task_id}"
        body = cast_params(
            algorithm=algorithm,
            criteria=criteria,
            options=options,
        )
        params = cast_params(organization_id=organization_id)
        await self.post(url, params=params, json=body)

    async def get_task_results_validation_info(
        self, task_id: str, organization_id: Optional[str] = None
    ) -> TaskResultsValidationInfo:
        url = f"api/v0/validation/results/{task_id}"
        resp = await self.get(url, params=cast_params(organization_id=organization_id))
        return from_dict(data_class=TaskResultsValidationInfo, data=resp)

    # -----------------------------------------------------------------------------
    #                                  PLUGINS MARKETPLACE
    # -----------------------------------------------------------------------------
    async def create_plugin_template(
        self,
        name: str,
        description: Optional[str] = None,
        documentation: Optional[str] = None,
        contacts: Optional[str] = None,
        access: Literal["public", "organization", "private"] = "private",
        title: Optional[str] = None,
        config: Optional[dict] = None,
        acl: Optional[List[str]] = None,
        scope: Literal["SIDEBAR"] = "SIDEBAR",
        roles: Optional[List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]] = None,
        organization_id: Optional[str] = None,
    ) -> PluginTemplate:
        roles = roles or ["MARKER"]
        documentation = documentation or ""
        body = cast_params(
            name=name,
            description=description,
            documentation=documentation,
            contacts=contacts,
            access=access,
            title=title,
            config=config,
            acl=acl,
            scope=scope,
            roles=roles,
        )
        params = cast_params(organization_id=organization_id)
        url = "/api/v0/plugins/templates"
        resp = await self.post(url, params=params, json=body)
        return from_dict(data_class=PluginTemplate, data=resp)

    async def update_plugin_template(
        self,
        plugin_template_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        documentation: Optional[str] = None,
        contacts: Optional[str] = None,
        access: Optional[Literal["public", "organization", "private"]] = None,
        title: Optional[str] = None,
        config: Optional[dict] = None,
        acl: Optional[List[str]] = None,
        scope: Optional[Literal["SIDEBAR"]] = None,
        roles: Optional[List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]] = None,
        organization_id: Optional[str] = None,
    ) -> PluginTemplate:
        body = cast_params(
            name=name,
            description=description,
            documentation=documentation,
            contacts=contacts,
            access=access,
            title=title,
            config=config,
            acl=acl,
            scope=scope,
            roles=roles,
        )
        url = f"/api/v0/plugins/templates/{plugin_template_id}"
        params = cast_params(organization_id=organization_id)
        resp = await self.put(url, params=params, json=body)
        return from_dict(data_class=PluginTemplate, data=resp)

    async def delete_plugin_template(self, plugin_template_id: str, organization_id: Optional[str] = None) -> None:
        url = f"/api/v0/plugins/templates/{plugin_template_id}"
        params = cast_params(organization_id=organization_id)
        await self.delete(url, params=params)

    async def get_plugin_template(
        self, plugin_template_id: str, organization_id: Optional[str] = None
    ) -> PluginTemplate:
        url = f"/api/v0/plugins/templates/{plugin_template_id}"
        params = cast_params(organization_id=organization_id)
        resp = await self.get(url, params=params)
        return from_dict(data_class=PluginTemplate, data=resp)

    async def get_plugin_templates(
        self,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        query: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> Tuple[List[PluginTemplate], int, bool]:
        url = "/api/v0/plugins/templates"
        params = cast_params(page=page, size=size, query=query, organization_id=organization_id)
        resp = await self.get(url, params=params)
        items = [from_dict(data_class=PluginTemplate, data=item) for item in resp["items"]]
        has_next = resp["has_next"]
        return items, page, has_next

    async def get_published_plugin_templates(
        self,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        query: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> Tuple[List[PluginTemplate], int, bool]:
        url = "/api/v0/plugins/templates/published"
        params = cast_params(page=page, size=size, query=query, organization_id=organization_id)
        resp = await self.get(url, params=params)
        items = [from_dict(data_class=PluginTemplate, data=item) for item in resp["items"]]
        has_next = resp["has_next"]
        return items, page, has_next

    async def publish_plugin_template(self, plugin_template_id: str, organization_id: Optional[str] = None) -> None:
        url = f"/api/v0/plugins/templates/{plugin_template_id}/publish"
        params = cast_params(organization_id=organization_id)
        await self.put(url, params=params)

    async def unpublish_plugin_template(self, plugin_template_id: str, organization_id: Optional[str] = None) -> None:
        url = f"/api/v0/plugins/templates/{plugin_template_id}/unpublish"
        params = cast_params(organization_id=organization_id)
        await self.put(url, params=params)

    async def check_plugin_template(
        self, plugin_template_id: str, organization_id: Optional[str] = None
    ) -> CheckPluginTemplateResult:
        url = f"/api/v0/plugins/templates/{plugin_template_id}/check"
        params = cast_params(organization_id=organization_id)
        resp = await self.get(url, params=params)
        return from_dict(data_class=CheckPluginTemplateResult, data=resp)

    async def create_organization_plugin(
        self,
        plugin_template_id: str,
        roles: List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]],
        route: str,
        enabled: bool = True,
        organization_id: Optional[str] = None,
    ) -> PluginAssignment:
        url = "/api/v0/plugins"
        params = cast_params(organization_id=organization_id)
        body = cast_params(
            plugin_template_id=plugin_template_id,
            roles=roles,
            route=route,
            enabled=enabled,
        )
        resp = await self.post(url, params=params, json=body)
        return from_dict(data_class=PluginAssignment, data=resp)

    async def update_organization_plugin(
        self,
        plugin_assignment_id: str,
        enabled: Optional[bool] = False,
        roles: Optional[List[Literal["MARKER", "CUSTOMER", "ORGANIZATION_ADMIN"]]] = None,
        route: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> PluginAssignment:
        url = f"/api/v0/plugins/{plugin_assignment_id}"
        params = cast_params(organization_id=organization_id)
        body = cast_params(enabled=enabled, roles=roles, route=route)
        resp = await self.put(url, params=params, json=body)
        return from_dict(data_class=PluginAssignment, data=resp)

    async def delete_organization_plugin(
        self,
        plugin_assignment_id: str,
        organization_id: Optional[str] = None,
    ) -> None:
        url = f"/api/v0/plugins/{plugin_assignment_id}"
        params = cast_params(organization_id=organization_id)
        await self.delete(url, params=params)

    async def get_organization_plugins(
        self,
        page: int = DEFAULT_PAGE_NUMBER,
        size: int = DEFAULT_PAGE_SIZE,
        query: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> Tuple[List[InstalledPlugin], int, bool]:
        url = "/api/v0/plugins"
        params = cast_params(page=page, size=size, query=query, organization_id=organization_id)
        resp = await self.get(url, params=params)
        items = [from_dict(data_class=InstalledPlugin, data=item) for item in resp["items"]]
        has_next = resp["has_next"]
        return items, page, has_next

    async def get_plugin_template_installations(
        self,
        plugin_template_id: str,
        organization_id: Optional[str] = None,
    ) -> List[PluginInstallation]:
        url = f"/api/v0/plugins/{plugin_template_id}/installations"
        params = cast_params(organization_id=organization_id)
        resp = await self.get(url, params=params)
        return [from_dict(data_class=PluginInstallation, data=item) for item in resp["items"]]

    async def get_my_plugins(
        self,
        scope: Literal["MARKER_SIDEBAR", "ORGANIZATION_SIDEBAR"] = "MARKER_SIDEBAR",
        disable_cache: bool = False,
        organization_id: Optional[str] = None,
    ) -> List[UserPlugin]:
        url = "/api/v0/plugins/my"
        params = cast_params(scope=scope, disable_cache=disable_cache, organization_id=organization_id)
        resp = await self.get(url, params=params)
        return [from_dict(data_class=UserPlugin, data=item) for item in resp]

    async def upload_plugin_template_file(
        self,
        plugin_template_id: str,
        file_type: Literal["icon", "preview", "bundle"],
        file_path: str,
        organization_id: Optional[str] = None,
    ) -> PluginTemplateFileResult:
        data = FormData()
        with ExitStack() as stack:
            data.add_field(
                "file",
                stack.enter_context(open(file_path, "rb")),
                filename=os.path.basename(file_path),
            )
            url = f'api/v0/templates/{plugin_template_id}/upload_file'
            resp = await self.put(
                url=url,
                data=data,
                params=cast_params(file_type=file_type, organization_id=organization_id),
            )
        return from_dict(data_class=PluginTemplateFileResult, data=resp)

    # -----------------------------------------------------------------------------
    #                                  BONUSES
    # -----------------------------------------------------------------------------
    async def add_bonuses(
        self,
        task_id: str,
        bonus: float,
        bonus_at: str,
        comment: str,
        marker_ids: List[str],
        average_quality: Optional[float] = None,
        marking_duration_secs: Optional[float] = None,
        marked_count: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> AddBonusesResponse:
        url = "api/v0/taskflow/bonus"
        json_data = cast_params(
            task_id=task_id,
            bonus=bonus,
            bonus_at=bonus_at,
            comment=comment,
            marker_ids=marker_ids,
            average_quality=average_quality,
            marking_duration_secs=marking_duration_secs,
            marked_count=marked_count,
        )

        resp = await self.post(url=url, params=cast_params(organization_id=organization_id), json=json_data)
        return from_dict(data_class=AddBonusesResponse, data=resp)

    async def get_bonuses(
        self,
        task_id: str,
        page: Optional[int] = None,
        size: Optional[int] = None,
        author_ids: Optional[List[str]] = None,
        bonuses_ids: Optional[List[str]] = None,
        markers_ids: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
    ) -> TaskBonuses:
        url = f"api/v0/taskflow/task/{task_id}/bonus"
        params = cast_params(
            page=page,
            size=size,
            author_ids=author_ids,
            bonuses_ids=bonuses_ids,
            markers_ids=markers_ids,
            organization_id=organization_id,
            map_keys=[
                ('author_ids', 'author_id[]'),
                ('bonuses_ids', 'bonus_id[]'),
                ('markers_ids', 'marker_id[]'),
            ],
        )

        resp = await self.get(url=url, params=params)
        items = [from_dict(data_class=TaskBonus, data=_) for _ in resp['items']]
        return TaskBonuses(items=items, has_next=resp['has_next'])

    async def edit_bonus(
        self,
        bonus_id: str,
        bonus: float,
        comment: str,
        average_quality: Optional[float] = None,
        marking_duration_secs: Optional[float] = None,
        marked_count: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> None:
        url = f"api/v0/taskflow/bonus/{bonus_id}"
        json_data = cast_params(
            bonus=bonus,
            comment=comment,
            average_quality=average_quality,
            marking_duration_secs=marking_duration_secs,
            marked_count=marked_count,
        )
        await self.put(url=url, params=cast_params(organization_id=organization_id), json=json_data)

    async def get_marker_stats_in_project(
        self,
        project_id: str,
        stats_at: Union[str, datetime],
        markers_ids: Optional[List[str]] = None,
        organization_id: Optional[str] = None,
    ) -> MarkerStats:
        url = "api/v0/taskflow/bonus/markers/stats"
        if isinstance(stats_at, datetime):
            stats_at = stats_at.isoformat()
        params = cast_params(
            project_id=project_id,
            date=stats_at,
            markers_ids=markers_ids,
            organization_id=organization_id,
            map_keys=[
                ('markers_ids', 'marker_id[]'),
            ],
        )

        resp = await self.get(url=url, params=params)
        items = [from_dict(data_class=MarkerStatInProject, data=_) for _ in resp]
        return MarkerStats(items=items)

    async def get_task_bonuses_summary(
        self,
        task_id: str,
        organization_id: Optional[str] = None,
    ) -> TaskBonusesSummary:
        url = f"api/v0/taskflow/task/{task_id}/bonus_summary"
        params = cast_params(
            task_id=task_id,
            organization_id=organization_id,
        )

        resp = await self.get(url=url, params=params)
        return from_dict(data_class=TaskBonusesSummary, data=resp)

    # -----------------------------------------------------------------------------
    #                                  DATA GALAXY
    # -----------------------------------------------------------------------------

    async def get_data_galaxy_datasets(
        self,
        limit: int = 10,
        offset: int = 0,
        q: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> DataGalaxyDatasetsList:
        url = 'api/v0/data_galaxy/datasets'
        params = cast_params(
            limit=limit,
            offset=offset,
            q=q,
            organization_id=organization_id,
        )

        resp = await self.get(
            url=url,
            params=params,
        )

        items = [from_dict(data_class=DataGalaxyDatasetInfo, data=item) for item in resp.get('items', [])]
        return DataGalaxyDatasetsList(
            items=items,
            next_offset=resp.get('next_offset', 0),
            total_count=resp.get('total_count', 0),
        )

    async def get_data_galaxy_dataset(
        self,
        dataset_id: str,
        organization_id: Optional[str] = None,
    ) -> DataGalaxyDatasetData:
        url = f'api/v0/data_galaxy/datasets/{dataset_id}'
        params = cast_params(
            organization_id=organization_id,
        )

        resp = await self.get(
            url=url,
            params=params,
        )
        dataset_info = from_dict(data_class=DataGalaxyDatasetInfo, data=resp)
        return DataGalaxyDatasetData(
            dataset=dataset_info,
            data=resp.get('data', []),
        )

    async def download_data_galaxy_dataset(
        self,
        dataset_id: str,
        task_id: str,
        organization_id: Optional[str] = None,
    ) -> dict:
        url = f'api/v0/data_galaxy/datasets/{dataset_id}/download'
        params = cast_params(
            task_id=task_id,
            organization_id=organization_id,
        )

        resp = await self.get(
            url=url,
            params=params,
        )
        return resp or {}

    async def upload_data_galaxy_dataset(
        self,
        dataset_id: str,
        task_id: str,
        organization_id: Optional[str] = None,
    ) -> dict:
        url = f'api/v0/data_galaxy/datasets/{dataset_id}/upload'
        params = cast_params(
            task_id=task_id,
            organization_id=organization_id,
        )

        resp = await self.post(
            url=url,
            params=params,
        )
        return resp or {}
