import logging
from enum import Enum
from typing import Any, Dict, Iterable, List, Optional, Union

from tqdm import tqdm

from crowd_sdk.core.utils.common import chunks
from crowd_sdk.core.utils.http_client import APIResponseError
from crowd_sdk.tagme import TagmeStatsClient
from crowd_sdk.tagme.types import FullOrganization, Person, Project, TaskData


class EntityType(Enum):
    TASK = "TASK"
    PROJECT = "PROJECT"
    PERSON = "PERSON"
    ORGANIZATION = "ORGANIZATION"


class TagmeStatsCache:
    def __init__(self) -> None:
        self._client = TagmeStatsClient()
        self._entities: Dict[EntityType, Dict[str, Any]] = {}

    # Getters

    async def get_person(self, person_id: str) -> Optional[Person]:
        return await self.__get_entity(EntityType.PERSON, person_id)

    async def get_project(self, project_id: str) -> Optional[Project]:
        return await self.__get_entity(EntityType.PROJECT, project_id)

    async def get_task(self, task_id: str) -> Optional[TaskData]:
        return await self.__get_entity(EntityType.TASK, task_id)

    async def get_organization(self, organization_id: str) -> Optional[FullOrganization]:
        return await self.__get_entity(EntityType.ORGANIZATION, organization_id)

    def get_persons(self) -> List[Person]:
        return self.__get_entities(EntityType.PERSON)

    def get_projects(self) -> List[Project]:
        return self.__get_entities(EntityType.PROJECT)

    def get_tasks(self) -> List[TaskData]:
        return self.__get_entities(EntityType.TASK)

    def get_organizations(self) -> List[FullOrganization]:
        return self.__get_entities(EntityType.ORGANIZATION)

    @staticmethod
    def __tqdm_args(tqdm_on: Union[bool, str] = False) -> Dict:
        return {
            "desc": tqdm_on if isinstance(tqdm_on, str) else None,
            "disable": (not tqdm_on),
        }

    # Common methods

    async def __fetch_entity(self, entity_type: EntityType, entity_id: str) -> Any:
        if entity_type == EntityType.PERSON:
            return await self.__fetch_person(entity_id)
        if entity_type == EntityType.PROJECT:
            return await self.__fetch_project(entity_id)
        if entity_type == EntityType.TASK:
            return await self.__fetch_task(entity_id)
        if entity_type == EntityType.ORGANIZATION:
            return await self.__fetch_organization(entity_id)
        raise RuntimeError(f"Invalid entity type: {entity_type.value}")

    async def __get_entity(self, entity_type: EntityType, entity_id: str) -> Any:
        if entity_type not in self._entities:
            logging.warning(f"Cache for entity type '{entity_type}' not filled")
            self._entities[entity_type] = {}
        if entity_id in self._entities[entity_type]:
            return self._entities[entity_type][entity_id]
        entity = await self.__fetch_entity(entity_type, entity_id)
        self._entities[entity_type][entity_id] = entity
        return entity

    def __get_entities(self, entity_type: EntityType) -> List[Any]:
        if entity_type in self._entities:
            return list(self._entities[entity_type].values())
        logging.warning(f"Cache for entity type '{entity_type}' not filled")
        return []

    def __update_entities(self, entity_type: EntityType, entities: Iterable[Any]) -> None:
        if entity_type not in self._entities:
            self._entities[entity_type] = {}
        for entity in entities:
            self._entities[entity_type][entity.uid] = entity

    # Organizations

    async def update_organizations(self) -> None:
        organizations = await self._client.get_organizations()
        self.__update_entities(EntityType.ORGANIZATION, organizations)

    async def __fetch_organization(self, organization_id: str) -> Optional[FullOrganization]:
        await self.update_organizations()
        return self._entities.get(EntityType.ORGANIZATION, {}).get(organization_id)

    # Persons

    async def update_persons(
        self,
        emails: Optional[List[str]] = None,
        person_ids: Optional[List[str]] = None,
        tqdm_on: Union[bool, str] = False,
    ) -> None:
        assert emails is None or person_ids is None, "emails and person_ids cannot be passed at once"
        persons: List[Person] = []
        if person_ids is not None:
            for person_ids_ in chunks(person_ids, 100, tqdm_on=tqdm_on):
                persons.extend(await self._client.get_persons(person_ids=person_ids_, with_organizations=True))
        if emails is not None:
            for emails_ in chunks(emails, 100, tqdm_on=tqdm_on):
                persons.extend(await self._client.get_persons(emails=emails_, with_organizations=True))
        self.__update_entities(EntityType.PERSON, persons)

    async def __fetch_person(self, entity_id: str) -> Optional[Person]:
        persons = await self._client.get_persons(person_ids=[entity_id])
        if not persons:
            logging.debug(f"Person {entity_id} not found")
            return None
        return persons[0]

    # Projects

    async def update_projects(
        self,
        organization_ids: List[str],
        tqdm_on: Union[bool, str] = False,
    ) -> None:
        projects: List[Project] = []
        for organization_id in tqdm(organization_ids, **(self.__tqdm_args(tqdm_on))):
            projects.extend(await self._client.get_projects(organization_id))
        self.__update_entities(EntityType.PROJECT, projects)

    async def __fetch_project(self, entity_id: str) -> Optional[Project]:
        try:
            return await self._client.get_project(entity_id)
        except APIResponseError as ex:
            logging.error(f"Failed to fetch project {entity_id}: {str(ex)}")
        return None

    # Tasks

    async def update_tasks_by_organizations(
        self,
        organization_ids: List[str],
        tqdm_on: Union[bool, str] = False,
    ) -> None:
        tasks: List[TaskData] = []
        for organization_id in tqdm(organization_ids, **(self.__tqdm_args(tqdm_on))):
            tasks.extend(await self._client.get_tasks(organization_id=organization_id))
        self.__update_entities(EntityType.TASK, tasks)

    async def update_tasks_by_projects(
        self,
        project_ids: str,
        organization_id: str,
        tqdm_on: Union[bool, str] = False,
    ) -> None:
        tasks: List[TaskData] = []
        for project_id in tqdm(project_ids, **(self.__tqdm_args(tqdm_on))):
            try:
                tasks.extend(await self._client.get_tasks(organization_id, project_id))
            except APIResponseError as ex:
                logging.error(f"Failed to get tasks for project {project_id}: {str(ex)}")
        self.__update_entities(EntityType.TASK, tasks)

    async def __fetch_task(self, entity_id: str) -> Optional[TaskData]:
        try:
            return await self._client.get_task(entity_id)
        except APIResponseError as ex:
            logging.error(f"Failed to fetch task {entity_id}: {str(ex)}")
        return None
