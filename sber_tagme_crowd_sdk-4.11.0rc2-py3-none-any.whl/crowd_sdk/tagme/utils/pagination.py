from functools import partial
from typing import Any, Awaitable, Callable, List, Mapping, Optional, Tuple, Type, TypeVar

from crowd_sdk.core.utils.common import dataclass_from_dict as from_dict

_T = TypeVar("_T")
PaginatedResponse = Tuple[List[_T], int, int]


DEFAULT_PAGE_NUMBER = 1
DEFAULT_PAGE_SIZE = 100


def _infer_pagination_params(page: Optional[int], size: Optional[int]) -> Tuple[int, int, Optional[int]]:
    if (page is None) != (size is None):
        raise ValueError("page and size parameters must be only passed together")

    page_number = page or DEFAULT_PAGE_NUMBER
    page_size = size or DEFAULT_PAGE_SIZE
    total = None

    return page_number, page_size, total


async def __run_with_pagination(
    func: Callable[..., Awaitable[Tuple[List[_T], Any, Any]]],
    page: Optional[int],
    size: Optional[int],
) -> List[_T]:
    page_number, page_size, total = _infer_pagination_params(page, size)
    result: List[_T] = []

    while total is None or (page_number - 1) * page_size < total:
        items, page_number, total = await func(page=page_number, size=page_size)
        result.extend(items)
        if page is not None and size is not None:
            break
        page_number += 1
    return result


async def run_with_pagination(
    func: Callable[..., Awaitable[PaginatedResponse[_T]]],
    **kwargs: Any,
) -> List[_T]:
    page = kwargs.pop("page", None)
    size = kwargs.pop("size", None)
    _func = partial(
        func,
        **kwargs,
    )
    return await __run_with_pagination(
        func=_func,
        page=page,
        size=size,
    )


async def run_with_has_next_pagination(
    func: Callable[..., Awaitable[Tuple[List[_T], Any, Any]]],
    page: Optional[int],
    size: Optional[int],
) -> List[_T]:
    page_number, page_size, _ = _infer_pagination_params(page, size)
    result: List[_T] = []
    has_next = True
    while has_next:
        items, page_number, has_next = await func(page=page_number, size=page_size)
        result.extend(items)
        if page is not None and size is not None:
            break
        page_number += 1
    return result


def get_paginated_response(
    resp: Mapping[str, Any],
    data_class: Type[_T],
    mapper: Optional[Callable[[dict], dict]] = None,
) -> PaginatedResponse[_T]:
    mapper = mapper or (lambda x: x)
    return (
        [from_dict(data_class=data_class, data=mapper(item)) for item in resp['items']],
        resp["page"],
        resp["total"],
    )
