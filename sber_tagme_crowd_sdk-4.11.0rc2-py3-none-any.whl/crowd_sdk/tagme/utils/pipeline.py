import asyncio
import json
import logging
import re
import sys
import time
from collections import defaultdict
from enum import Enum
from hashlib import md5
from itertools import chain
from pathlib import Path
from statistics import median
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple, Union
from uuid import uuid4

import pandas as pd
from aioprometheus import Gauge, Histogram
from dacite import Config, DaciteError, from_dict

from crowd_sdk.core.utils.common import cast_params, dataclass_to_dict, merge
from crowd_sdk.core.utils.http_client import APIResponseError, HttpWrapper
from crowd_sdk.core.utils.jwt_client import ResponseType
from crowd_sdk.core.utils.os import TempDir
from crowd_sdk.tagme import TagmeClientAdvanced
from crowd_sdk.tagme.config import DEFAULT_CONFIG, CrowdConfig, TagmeConfig
from crowd_sdk.tagme.http_client.datacls import (
    AdvancedTaskDataWithErrors,
    Assignment,
    AssignmentStatusType,
    MarkupReview,
    MarkupReviewResult,
    MetaData,
    Organization,
    UpdateMetaDataRequest,
)
from crowd_sdk.tagme.types import Dataset, MetaType, Project, TaskData, TaskDataRequest, TaskFile, TaskResult, TaskState
from crowd_sdk.tagme.utils.datacls import (
    AggregatedResults,
    ConsistencyFilter,
    ResultAggregation,
    SyncSettings,
    ValidationFieldType,
    validation_project_keys,
)
from crowd_sdk.tagme.utils.quality import filter_dict, get_dict_hash

logger = logging.getLogger(__name__)


UUID_PATTERN = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
RESULT_SENT_FIELD = "result_sent"


def get_merged_validation_sync_settings(project: Project, task: TaskData) -> SyncSettings:
    if not task.payload or not task.payload.get("pipeline"):
        task_sync_settings_dict = {}
    else:
        task_pipeline_payload = task.payload.get("pipeline", {})
        task_sync_settings = from_dict(
            data_class=SyncSettings, data=task_pipeline_payload, config=Config(cast=[Enum, Tuple])
        )
        task_sync_settings_dict = task_sync_settings.asdict(
            filter_attrs=tuple(validation_project_keys & set(task_pipeline_payload.keys()))
        )

    logger.debug("task_sync_settings_dict: %s", task_sync_settings_dict)
    logger.debug("project.pipeline: %s", project.pipeline)
    sync_settings: SyncSettings = from_dict(
        data_class=SyncSettings,
        data=merge(task_sync_settings_dict, project.pipeline or {}),
        config=Config(cast=[Enum, Tuple]),
    )
    return sync_settings


def get_value(src: List[str], task_data: dict, result: Union[dict, AggregatedResults]) -> Any:
    if src[0] == 'file.url':
        value = task_data['file.url']
    elif src[0] == 'file':
        value = json.loads(task_data['file_data'])  # FIXME: refactor get_value & result_to_data
    elif src[0] == 'result':
        value = result
    elif src[0] == 'premarkup':
        value = task_data['premarkup']
    else:
        raise NotImplementedError(f'src={src[0]}')

    for key in src[1:]:
        if not isinstance(value, dict):
            raise ValueError(f"Cannot access key '{key}' in non-dict value of type {type(value)}")
        value = value.get(key)
        if value is None:
            break

    return value


def filter_assignments_by_status(
    df: pd.DataFrame, not_sent_mask: pd.Series, overlap: int, assignment_statuses_to_send: List[AssignmentStatusType]
) -> pd.DataFrame:
    if df.empty:
        return df

    overlap_statuses: List[AssignmentStatusType] = ["ACCEPTED", "REJECTED"]
    if "SUBMITTED" in assignment_statuses_to_send:
        overlap_statuses.append("SUBMITTED")

    overlap_statuses_passed_mask = df.groupby("item_id")["status"].transform(
        lambda x: x.isin(overlap_statuses).sum() >= overlap
    )

    result: pd.DataFrame = df[
        not_sent_mask & overlap_statuses_passed_mask & df["status"].isin(assignment_statuses_to_send)
    ]  # type: ignore

    return result.reset_index(drop=True)


async def filter_by_marker_settings(
    not_sent_assignments_df: pd.DataFrame,
    total_already_sent_by_marker_map: Dict[str, int],
    total_assignments_by_marker_map: Dict[str, int],
    sync_settings: SyncSettings,
) -> pd.DataFrame:
    """Фильтрация заданий по настройкам marker_* (по пользователям)"""
    if not_sent_assignments_df.empty:
        return not_sent_assignments_df

    filtered_assignments = []

    for marker_id_raw, marker_not_sent_assignments in not_sent_assignments_df.groupby('marker_id'):
        marker_id = str(marker_id_raw)
        total_marker_not_sent = marker_not_sent_assignments.shape[0]

        total_marker_assignments = total_assignments_by_marker_map.get(marker_id, 0)
        total_marker_already_sent = total_already_sent_by_marker_map.get(marker_id, 0)

        to_send_count = max(
            sync_settings.marker_assignments_min - total_marker_already_sent,
            (total_marker_assignments - total_marker_already_sent) * sync_settings.marker_assignments_percent // 100,
            0,
        )

        logger.debug(
            "FILTERING: Marker %s: total=%d, not_sent=%d, already_sent=%d, to_send=%d",
            marker_id,
            total_marker_assignments,
            total_marker_not_sent,
            total_marker_already_sent,
            to_send_count,
        )

        if to_send_count == 0:
            continue

        if to_send_count >= total_marker_not_sent:
            filtered_assignments.append(marker_not_sent_assignments)
        else:
            sampled_assignments = marker_not_sent_assignments.sample(n=to_send_count, random_state=42)
            filtered_assignments.append(sampled_assignments)

    return pd.concat(filtered_assignments, ignore_index=True) if filtered_assignments else pd.DataFrame()


async def filter_by_task_settings(
    not_sent_assignments_df: pd.DataFrame,
    total_already_sent: int,
    total_task_assignments: int,
    sync_settings: SyncSettings,
) -> pd.DataFrame:
    """Фильтрация заданий по настройкам task_* (по всей задаче)"""
    if not_sent_assignments_df.empty:
        return not_sent_assignments_df

    total_not_sent = len(not_sent_assignments_df)

    to_send_count = max(
        sync_settings.task_assignments_min - total_already_sent,
        (total_task_assignments - total_already_sent) * sync_settings.task_assignments_percent // 100,
        0,
    )

    logger.debug(
        "FILTERING: Task %s: total=%d, not_sent=%d, already_sent=%d, to_send=%d",
        sync_settings.source_task,
        total_task_assignments,
        total_not_sent,
        total_already_sent,
        to_send_count,
    )

    if to_send_count == 0:
        return pd.DataFrame()

    if to_send_count >= total_not_sent:
        return not_sent_assignments_df

    return not_sent_assignments_df.sample(n=to_send_count, random_state=42)


def aggregate_result(consistency_table: Dict[str, int], hash_result: Dict[str, dict], total: int) -> AggregatedResults:
    results = AggregatedResults()
    for k, v in consistency_table.items():
        results.add(weight=v / total, result=hash_result[k])

    return results


def is_successful(x: Dict) -> bool:
    return x.get('success', True)


def do_nothing(_x: Dict) -> bool:
    return True


class PremarkupRWHandler:
    """Utility to read/write data located under `premarkup`."""

    def __init__(self, sync_settings: SyncSettings):
        self._sync_settings = sync_settings
        self._result_field_chain: List[str] = self._resolve_result_field_chain()

    @staticmethod
    def __remove_premarkup_prefix(path: str) -> str:
        if path.startswith("premarkup"):
            return path[len("premarkup") :].strip(".")
        return path

    def _resolve_result_field_chain(self) -> List[str]:
        result_destination = "premarkup"
        for source, destination in self._sync_settings.fields or []:
            if source == "result":
                result_destination = destination
                break

        if not result_destination.startswith("premarkup"):
            raise ValueError("destination for 'result' field must start with 'premarkup'")

        trimmed_destination = self.__remove_premarkup_prefix(result_destination)
        return [part for part in trimmed_destination.split(".") if part]

    def _traverse(self, premarkup: Dict[str, Any], *, create_missing: bool = False) -> Dict[str, Any]:
        node: Dict[str, Any] = premarkup
        if not self._result_field_chain:
            return node

        for key in self._result_field_chain:
            next_node_raw = node.get(key)
            if next_node_raw is None:
                if not create_missing:
                    logger.debug("key %s is missing in premarkup", key)
                    return {}
                next_node: Dict[str, Any] = {}
                node[key] = next_node
            elif not isinstance(next_node_raw, dict):
                if not create_missing:
                    logger.debug("Expected dict at key %s, got %s", key, type(next_node_raw))
                    return {}
                next_node = {}
                node[key] = next_node
            else:
                next_node = next_node_raw
            node = next_node
        return node

    def read_assignment_payload(self, premarkup: Dict[str, Any]) -> Dict[str, Any]:
        payload = self._traverse(premarkup)
        if payload is None:
            return {}
        if not isinstance(payload, dict):
            logger.debug("Expected dict at 'result', got %s", type(payload))
            return {}
        return payload

    def read_assignment_id(self, premarkup: Dict[str, Any]) -> Optional[str]:
        payload = self.read_assignment_payload(premarkup)
        assignment_id = payload.get("assignment_id")
        if assignment_id is not None and not isinstance(assignment_id, str):
            logger.debug("Expected assignment_id to be str, got %s", type(assignment_id))
            return None
        return assignment_id

    def read_aggregated_results(self, premarkup: Dict[str, Any]) -> List[Dict[str, Any]]:
        node = self._traverse(premarkup)
        aggregated = node.get("aggregated", [])
        if aggregated is None:
            return []
        if not isinstance(aggregated, list):
            raise ValueError(f"Expected <result_path>.aggregated in premarkup to be list, got {type(aggregated)}")
        return aggregated

    def ensure_result_node(self, premarkup: Dict[str, Any]) -> Dict[str, Any]:
        return self._traverse(premarkup, create_missing=True)

    @staticmethod
    def is_result_sent(premarkup: Dict[str, Any]) -> bool:
        return bool(premarkup.get(RESULT_SENT_FIELD))

    @staticmethod
    def mark_result_sent(premarkup: Dict[str, Any]) -> None:
        premarkup[RESULT_SENT_FIELD] = True


class FilenameEncoder:
    @classmethod
    def encode(
        cls,
        source_file: Union[str, TaskFile],
        assignment_id: Optional[str] = None,
        result_aggregation: ResultAggregation = ResultAggregation.SEPARATE,
    ) -> str:
        if isinstance(source_file, TaskFile):
            source_file = source_file.name
        if result_aggregation == ResultAggregation.SEPARATE:
            if not assignment_id:
                raise ValueError("assignment_id is required when using ResultAggregation.SEPARATE")

            return f"{assignment_id}_{source_file}"
        elif result_aggregation == ResultAggregation.AGGREGATE:
            uid = str(uuid4())
            return f"agregated_{uid}_{source_file}"
        raise NotImplementedError(f"Unknown result_aggregation value: {result_aggregation}")

    @classmethod
    def validate_assignment_id(cls, assignment_id: str) -> None:
        if not re.match(UUID_PATTERN, assignment_id):
            raise ValueError(f"Bad assignment id: {assignment_id}")

    @classmethod
    def decode(
        cls, target_file: Union[str, TaskFile], result_aggregation: ResultAggregation = ResultAggregation.SEPARATE
    ) -> Tuple[str, Union[None, str]]:
        """Decode task file name into assignment_id and filename

        Raises:
            NotImplementedError: raised whed unknown result_aggregation passed
            ValueError: raised when filename can't be splitted by "_"
            ValueError: raised when retrieved assignment_id doesn't match `UUID_PATTERN`

        Returns:
            Tuple[str, Union[None, str]]: tuple of filename and assignment_id (assignment_id None if AGGREGATE)
        """
        if isinstance(target_file, TaskFile):
            target_file = target_file.name
        if result_aggregation == ResultAggregation.SEPARATE:
            assignment_id, filename = target_file.split("_", maxsplit=1)
            cls.validate_assignment_id(assignment_id)
            return (filename, assignment_id)
        elif result_aggregation == ResultAggregation.AGGREGATE:
            raise NotImplementedError("No need to decode aggrgated yet: it uses premarkup data to get assignments uids")
        raise NotImplementedError(f"Unknown result_aggregation value: {result_aggregation}")


class TagmePipeline:
    _result_filters: Dict[str, Callable[[Dict], bool]] = {
        'is_successful': is_successful,
        'all': do_nothing,
    }

    def __init__(
        self,
        executor: str,
        config: Union[str, Path, CrowdConfig, TagmeConfig] = DEFAULT_CONFIG,
        http: Optional[HttpWrapper] = None,
        client: Optional[TagmeClientAdvanced] = None,
        scan_delay: int = 600,
        pipeline_metrics_collector: Optional[dict] = None,
    ) -> None:
        self.executor = executor
        self.client = client or TagmeClientAdvanced(config=config, http=http)
        self._task_scheduled: List[TaskData] = []
        self.scan_delay = scan_delay
        self._pipeline_metrics_collector = pipeline_metrics_collector
        self.project_hard_errors: Dict[str, List] = defaultdict(list)
        self.project_light_errors: Dict[str, List] = defaultdict(list)
        self.project_api_errors: Dict[str, List] = defaultdict(list)
        self.project_processed: Set[str] = set()
        self.task_api_errors: Dict[str, str] = {}
        self.projects_organizations_mapping: Dict[str, set] = defaultdict(set)
        self._item_metada_map: Dict[str, MetaData] = {}
        self._assignment_validation_item_map: Dict[str, List[str]] = {}

    @classmethod
    def register_result_filter(cls, name: str, handler: Callable[[Dict], bool]) -> None:
        cls._result_filters[name] = handler

    @staticmethod
    def strip_filename(fname: str, is_target: bool = False) -> str:
        if fname.endswith('.json'):
            fname = fname[: -len('.json')]
        if is_target:
            return fname.split('_', 1)[-1]
        return fname

    async def get_item_metadata(self, task: TaskData, item_id: str, force_refetch: bool = False) -> MetaData:
        metadata: Optional[MetaData] = None

        if not force_refetch:
            metadata = self._item_metada_map.get(item_id)

        if not metadata:
            metadata = await self.client.get_meta_data(task.uid, item_id, organization_id=task.organization_id)

        # mypy сходит с ума из-за этих строчек
        self._item_metada_map[item_id] = metadata  # type: ignore
        return metadata  # type: ignore

    def _clear_cached_metadata(self) -> None:
        self._item_metada_map = {}

    def update_assignment_validation_items_map(self, assignment_id: str, item_id: str) -> None:
        if assignment_id in self._assignment_validation_item_map:
            self._assignment_validation_item_map[assignment_id].append(item_id)
        else:
            self._assignment_validation_item_map[assignment_id] = [item_id]

    def get_assignment_validation_items(self, assignment_id: str) -> List[str]:
        return self._assignment_validation_item_map.get(assignment_id, [])

    def _clear_assignment_validation_item_map(self) -> None:
        self._assignment_validation_item_map = {}

    def clear_cache(self) -> None:
        self._clear_cached_metadata()
        self._clear_assignment_validation_item_map()

    async def get_aggregated_file_assignments(
        self,
        validation_task: TaskData,
        item_id: str,
        organization_id: Optional[str],
        sync_settings: SyncSettings,
    ) -> Set[str]:  # TODO: merge with get_validation_source_assignment_id to handle validation of aggregated
        metadata: MetaData = await self.client.get_meta_data(
            task_id=validation_task.uid, file_uid=item_id, organization_id=organization_id
        )
        if not metadata.premarkup:
            logger.warning(
                "Item %s of task %s has no premarkup to retrieve source assignments", item_id, validation_task.uid
            )
            return set()

        premarkup_handler = PremarkupRWHandler(sync_settings)
        results_list = premarkup_handler.read_aggregated_results(metadata.premarkup)

        assignments: Set[Optional[str]] = {
            single_res.get("result", {}).get("assignment_id") for single_res in results_list
        }
        assignments.discard(None)
        if not assignments:
            return set()

        return assignments  # type: ignore

    async def get_already_sent_source_assignments_mask(
        self,
        assignments_df: pd.DataFrame,
        source_task: TaskData,
        organization_id: Optional[str],
        sync_settings: SyncSettings,
    ) -> 'pd.Series[bool]':
        target_task_files: List[TaskFile] = await self.client.get_task_files(
            task_id=source_task.uid, organization_id=organization_id
        )
        logger.debug("target task files count: %d", len(target_task_files))

        all_sent_assignments: Set[str] = set()
        premarkup_handler = PremarkupRWHandler(sync_settings)

        if sync_settings.result_aggregation == ResultAggregation.SEPARATE:
            for task_file in target_task_files:
                try:
                    _, assignment_id = FilenameEncoder.decode(task_file, sync_settings.result_aggregation)
                    if assignment_id is None:
                        raise ValueError("couldn't get assignment_id from task file name")
                    all_sent_assignments.add(assignment_id)
                except ValueError as exc:
                    logger.info("couldn't get assignment_id from task file name: %s", exc)
                    metadata: MetaData = await self.client.get_meta_data(
                        task_id=source_task.uid, file_uid=task_file.uid, organization_id=organization_id
                    )
                    if not metadata.premarkup:
                        logger.debug("task_file %s has no premarkup to get assignment_id", task_file.uid)
                        raise ValueError(f"task_file {task_file.uid} has no premarkup to get assignment_id") from exc

                    assignment_id = premarkup_handler.read_assignment_id(metadata.premarkup)
                    if not assignment_id:
                        logger.debug(
                            "task_file %s has no assignment_id in premarkup: %s", task_file.uid, metadata.premarkup
                        )
                        raise ValueError(
                            f"task_file {task_file.uid} has no assignment_id in filename or in premarkup"
                        ) from exc

                    all_sent_assignments.add(assignment_id)

        elif sync_settings.result_aggregation == ResultAggregation.AGGREGATE:
            for target_file in target_task_files:
                file_assignments = await self.get_aggregated_file_assignments(
                    source_task, target_file.uid, organization_id, sync_settings
                )
                all_sent_assignments.update(file_assignments)
        else:
            raise NotImplementedError(f"Unknown result_aggregation value: {sync_settings.result_aggregation}")

        mask: 'pd.Series[bool]' = assignments_df["assignment_id"].isin(all_sent_assignments)
        return mask

    async def get_already_sent_validation_assignments_mask(
        self,
        assignments_df: pd.DataFrame,
        validation_task: TaskData,
        organization_id: Optional[str],
        sync_settings: SyncSettings,
    ) -> 'pd.Series[bool]':
        validation_task_files: List[TaskFile] = await self.client.get_task_files(
            task_id=validation_task.uid, organization_id=organization_id
        )
        logger.debug("Validation task files count: %d", len(validation_task_files))

        sent_task_files: Set[str] = set()
        premarkup_handler = PremarkupRWHandler(sync_settings)
        for task_file in validation_task_files:
            metadata: MetaData = await self.get_item_metadata(task=validation_task, item_id=task_file.uid)
            if not metadata.premarkup:
                logger.warning("no premarkup in validation task %s file %s", validation_task.uid, task_file.uid)
                continue

            if premarkup_handler.is_result_sent(metadata.premarkup):
                sent_task_files.add(task_file.uid)

        logger.debug("sent_task_files: %s", sent_task_files)
        mask: 'pd.Series[bool]' = assignments_df["item_id"].isin(sent_task_files)
        return mask

    async def prepare_data(
        self,
        target_task: TaskData,
        source_task: TaskData,
        sync_settings: SyncSettings,
        tmp_dir: str,
        limit: Optional[int] = None,
        organization_id: Optional[str] = None,
    ) -> List[dict]:
        task_assignments_df: pd.DataFrame = pd.DataFrame(  # TODO: optimize, maybe load only necessary attributes
            await self.client.get_task_assignments(
                source_task.uid, organization_id=organization_id
            )  # maybe collect only new assignments since last update
        )
        logger.debug("Total collected assignments: %d", len(task_assignments_df))
        if task_assignments_df.empty:
            return []

        already_sent_assignments_mask: 'pd.Series[bool]' = await self.get_already_sent_source_assignments_mask(
            task_assignments_df, target_task, organization_id, sync_settings
        )
        logger.debug("Total assignments already sent: %d", int(already_sent_assignments_mask.sum()))
        not_sent_mask: 'pd.Series[bool]' = ~already_sent_assignments_mask

        logger.debug("Total assignments not sent yet: %d", int(not_sent_mask.sum()))

        if int(not_sent_mask.sum()) == 0:
            return []

        min_overlap = (
            source_task.overlap if sync_settings.result_aggregation == ResultAggregation.AGGREGATE else 1
        )  # TODO: extract overlap from item, instead of task
        assignments_filtered_by_status: pd.DataFrame = filter_assignments_by_status(
            task_assignments_df,
            not_sent_mask=not_sent_mask,
            overlap=min_overlap,
            assignment_statuses_to_send=sync_settings.assignment_statuses_source,
        )

        logger.debug("Total collected assignments after filter by status: %d", len(assignments_filtered_by_status))

        logger.debug("result_aggregation: %s", sync_settings.result_aggregation)
        if sync_settings.result_aggregation == ResultAggregation.SEPARATE:
            if sync_settings.marker_assignments_percent != 100:
                logger.debug(
                    "marker_assignments_percent = %d - filtering by markers", sync_settings.marker_assignments_percent
                )
                total_already_sent_by_marker_map: Dict[str, int] = {}
                total_assignments_by_marker_map: Dict[str, int] = {}

                for marker_id_raw, marker_assignments in task_assignments_df.groupby('marker_id'):
                    marker_id = str(marker_id_raw)
                    total_assignments_by_marker_map[marker_id] = len(marker_assignments)
                    total_already_sent_by_marker_map[marker_id] = int(
                        already_sent_assignments_mask[marker_assignments.index].sum()  # type: ignore
                    )
                assignments = await filter_by_marker_settings(
                    assignments_filtered_by_status,
                    total_already_sent_by_marker_map,
                    total_assignments_by_marker_map,
                    sync_settings,
                )
            elif sync_settings.task_assignments_percent != 100:
                logger.debug(
                    "task_assignments_percent = %d - filtering by task", sync_settings.task_assignments_percent
                )
                total_task_assignments: int = len(task_assignments_df)
                total_already_sent = int(already_sent_assignments_mask.sum())  # type: ignore
                assignments = await filter_by_task_settings(
                    assignments_filtered_by_status, total_already_sent, total_task_assignments, sync_settings
                )
            else:
                logger.debug("using all 100% of task assignments")
                assignments = assignments_filtered_by_status
        else:
            if sync_settings.marker_assignments_percent != 100 or sync_settings.task_assignments_percent != 100:
                raise NotImplementedError(
                    "Setting percentage along with ResultAggregation.AGGREGATE is not implemented yet"
                )
            assignments = assignments_filtered_by_status

        logger.debug("Total collected assignments after all filters: %d", len(assignments))
        if assignments.empty:
            return []

        if limit is not None and len(assignments) > limit:
            assignments = assignments.head(limit)

        json_data: List[dict] = []
        for _, group in assignments.groupby("item_id"):
            item_assignments: List[Assignment] = []
            for __, row in group.iterrows():
                assignment = from_dict(Assignment, row.to_dict())

                item_assignments.append(assignment)

            if not item_assignments:
                continue

            json_data.extend(
                await self.process_item(
                    item_assignments,
                    sync_settings,
                    tmp_dir,
                    organization_id=organization_id or source_task.organization_id,  # type: ignore
                )
            )

        if not json_data:
            logger.info(f'nothing to upload for task "{target_task.name}" ({target_task.uid})')

        return json_data

    async def load_task_data(
        self, item: Union[TaskResult, TaskFile], organization_id: str, with_premarkup: bool = False
    ) -> dict:
        if isinstance(item, TaskResult):
            task_id, entity_id, file_name = item.task_id, item.entity_id, item.file_name
        else:
            task_id, entity_id, file_name = item.bucket, item.uid, item.name

        file_data = await self.client.download_file(task_id, entity_id, organization_id=organization_id)
        result: dict = {'file_name': file_name, 'file_data': file_data, 'task_id': task_id}
        if with_premarkup:
            meta = await self.client.get_meta_data(
                task_id, entity_id, types=[MetaType.PREMARKUP], organization_id=organization_id
            )
            if not meta or not meta.premarkup:
                raise ValueError(f'not found required premarkup in item {entity_id} of task {task_id}')

            result['premarkup'] = meta.premarkup

        return result

    async def get_dataset(self, task_id: str, organization_id: str) -> Dataset:
        ds: Optional[Dataset] = None
        for dataset in await self.client.get_datasets(query=f'pipeline_{task_id}', organization_id=organization_id):
            if dataset.name == f'pipeline_{task_id}':
                ds = dataset
                break
        else:
            ds = await self.client.create_dataset(name=f'pipeline_{task_id}', organization_id=organization_id)

        return ds  # type: ignore

    async def upload_file_data(self, file_path: Union[str, Path], task_id: str, organization_id: str) -> str:
        file_path = str(file_path)
        ds = await self.get_dataset(task_id, organization_id=organization_id)
        files = await self.client.upload_dataset_files(ds.id, filepaths=[file_path], organization_id=organization_id)
        assert len(files.created_files) == 1

        if files.errors:
            raise ValueError(f'Can\'t upload {file_path} to {ds.id}: {files.errors}')

        return self.client.gen_file_url(files.created_files[0].uid)

    async def upload_attachment(
        self, url: str, prefix: str, base_path: str, task_id: str, organization_id: Optional[str] = None
    ) -> str:
        organization_id = organization_id or await self.client.get_current_organization_id()
        unique_filename = md5(url.encode()).hexdigest() + '.wav'
        with open(Path(base_path) / unique_filename, 'wb') as f:
            file_data = await self.client.client.get(
                url=url[len(prefix) :],
                response_type=ResponseType.RAW_RESPONSE,
                params=cast_params(organization_id=organization_id),
            )

            f.write(file_data)

        return await self.upload_file_data(Path(base_path) / unique_filename, task_id, organization_id=organization_id)

    async def result_to_data(  # FIXME: очень непрозрачный метод, needs refactoring
        self,
        result: Union[dict, AggregatedResults],
        task_data: dict,  # FIXME: dict[unknown, unknown]
        fields: List[Tuple[str, str]],
        base_filepath: str,
        organization_id: str,
        extra_fields: Optional[dict] = None,
    ) -> dict:  # FIXME: dict[unknown, unknown]
        file_name = task_data['file_name']
        file_data = task_data['file_data']
        task_id = task_data['task_id']

        if isinstance(result, AggregatedResults):
            encoded_filename = FilenameEncoder.encode(file_name, result_aggregation=ResultAggregation.AGGREGATE)
            result = {"aggregated": result}
        else:
            encoded_filename = FilenameEncoder.encode(
                file_name, assignment_id=result.get("assignment_id"), result_aggregation=ResultAggregation.SEPARATE
            )
        data: Dict[str, Any] = {'id': encoded_filename}

        for src_, dst_ in fields:
            src, dst = src_.split('.'), dst_.split('.')

            if src == ['file']:  # binary
                unique_filename = md5(file_data).hexdigest()
                with open(Path(base_filepath) / unique_filename, 'wb') as f:
                    f.write(file_data)
                if dst == ['file']:
                    data['upload_file'] = unique_filename
                    continue

                task_data['file.url'] = await self.upload_file_data(  # FIXME: why dot-separated?
                    Path(base_filepath) / unique_filename, task_id, organization_id=organization_id
                )
                src = ['file.url']

            if dst[0] == 'file':
                dst[0] = 'task'

            target = data  # FIXME ???
            for key in dst[:-1]:
                target = target.setdefault(key, {})
            target_value = get_value(src, task_data, result)
            if (
                isinstance(target_value, str)
                and target_value.startswith('https://tagme.sberdevices.ru/')
                and '/attachment/' in target_value
            ):
                target_value = await self.upload_attachment(
                    target_value,
                    'https://tagme.sberdevices.ru/',
                    base_filepath,
                    task_id,
                    organization_id=organization_id,
                )
                base_url = self.client.client.get_base_url().rstrip('/') + '/'
                if base_url != 'https://tagme.sberdevices.ru/':
                    target_value = target_value.replace(base_url, 'https://tagme.sberdevices.ru/')
            target[dst[-1]] = target_value

        if extra_fields:
            data.setdefault('premarkup', {}).update(extra_fields)

        if 'task' in data and 'upload_file' in data:
            raise ValueError('incorrect fields in pipeline config')

        return data

    async def process_item(
        self, assignments: List[Assignment], sync_settings: SyncSettings, tmp_dir: str, organization_id: str
    ) -> List[dict]:
        """Only for assignments with same item_id

        Args:
            assignments (List[Assignment]): list of assignments
            sync_settings (SyncSettings): pipeline settings
            tmp_dir (str): path to temp dir
            organization_id (str): organization uid

        Raises:
            NotImplementedError: raised if sync_settings.consistency_filter is not ALL_UNIQUE or UNSURE
            NotImplementedError: raised if sync_settings.result_aggregation is not AGGREGATE or SEPARATE

        Returns:
            List[dict]: target task items data
        """
        hash_result: Dict[str, dict] = {}
        # FIXME не работает. При повторном запуске пайплайна не будет информации
        # FIXME о консистентности предыдущих ответов -> отправятся все, что не отправились в прошлый раз
        consistency_table: Dict[str, int] = defaultdict(int)

        # Filter Assignments if needed
        assert sync_settings.result_filter in self._result_filters, (
            f'No assignments filter "{sync_settings.result_filter}" registered in '
            f'TagmePipeline._result_filters: {list(TagmePipeline._result_filters.keys())}'
        )
        result_filter = self._result_filters[sync_settings.result_filter]
        results = {}

        for assignment in assignments:
            result = assignment.result
            if result and result_filter(result):
                results[assignment.assignment_id] = result

        # Filter Item if needed
        total = len(results)
        if not results:
            return []

        for assignment_id, result in results.items():
            if sync_settings.ignore_fields:
                filter_dict(result, sync_settings.ignore_fields, 1)

            hash_ = get_dict_hash(result)
            consistency_table[hash_] += 1
            if hash_ not in hash_result:
                result["assignment_id"] = assignment_id
                hash_result[hash_] = result

        extra_fields = {
            'source_entity_id': assignments[0].item_id,
            'source_task_id': assignments[0].task_id,
            'source_file_name': assignments[0].file_name,
            'source_item_id': assignments[0].item_id,
        }

        # FIXME пересмотреть логику, сейчас вообще не очевидно, как это работает и для чего
        # можно использовать просто согласованность из assignment
        if sync_settings.consistency_filter == ConsistencyFilter.UNSURE:
            # TODO should validate all results or most consistent for unsure?
            # TODO более глубокий анализ результатов на консистентность
            assert sync_settings.consistency_share_threshold is not None
            max_share = max(consistency_table.values()) / total
            if max_share >= sync_settings.consistency_share_threshold:
                return []

        elif sync_settings.consistency_filter != ConsistencyFilter.ALL_UNIQUE:
            raise NotImplementedError

        # Aggregate, transform
        if sync_settings.result_aggregation == ResultAggregation.SEPARATE:
            values: Iterable[Union[dict, AggregatedResults]] = hash_result.values()
        elif sync_settings.result_aggregation == ResultAggregation.AGGREGATE:
            values = (aggregate_result(consistency_table, hash_result, total),)
        else:
            raise NotImplementedError

        item_without_result = TaskResult(
            uid=assignments[0].item_id,
            entity_id=assignments[0].item_id,
            task_id=assignments[0].task_id,
            organization_id=assignments[0].organization_id,
            person_id=assignments[0].person_id,
            storage_id=assignments[0].task_id,
            file_name=assignments[0].file_name,
            entity_type=assignments[0].item_type,
            price=assignments[0].price,
        )

        fields = sync_settings.fields
        task_data = await self.load_task_data(
            item_without_result,
            with_premarkup=any(x[0].startswith('premarkup.') for x in fields),
            organization_id=organization_id,
        )

        return [
            await self.result_to_data(
                v, task_data, fields, tmp_dir, organization_id=organization_id, extra_fields=extra_fields
            )
            for v in values
        ]

    def check_executor(self, config: dict) -> bool:
        if isinstance(config, dict):
            conf_executor: str = config.get("executor", "tagme")

            return conf_executor == self.executor
        return False

    async def __remove_from_payload_pipeline_field(
        self, task: TaskData, key: str, reload_paylod: bool = True, update_payload_in_task: bool = True
    ) -> None:
        if reload_paylod:
            initial_payload = await self.client.get_task_payload(task_id=task.uid, organization_id=task.organization_id)
        else:
            initial_payload = task.payload or {}

        if not initial_payload:
            logger.warning("Trying to remove key `%s` from emty task payload. Task: %s", key, task.uid)
            return

        if not isinstance(initial_payload.get("pipeline"), dict):
            logger.warning(
                "Expected payload.pipeline to be dict, but got `%s`. Task: %s",
                type(initial_payload.get("pipeline")),
                task.uid,
            )
            return

        new_pipeline_settings: Dict[str, Any] = initial_payload["pipeline"]
        new_pipeline_settings.pop(key, -1)
        await self.client.set_task_payload(
            task_id=task.uid,
            payload=initial_payload | {"pipeline": new_pipeline_settings},
            organization_id=task.organization_id,
        )
        if update_payload_in_task:
            await self.client.load_task_payload(task=task)

    async def __ensure_payload_pipeline_field(
        self, task: TaskData, key: str, value: Any, reload_paylod: bool = True
    ) -> None:
        if reload_paylod:
            initial_payload = await self.client.get_task_payload(task_id=task.uid, organization_id=task.organization_id)
        else:
            initial_payload = task.payload or {}

        initial_payload.setdefault("pipeline", {})

        if initial_payload["pipeline"].get(key) != value:
            initial_payload["pipeline"][key] = value
            await self.client.set_task_payload(
                task_id=task.uid, payload=initial_payload, organization_id=task.organization_id
            )

    async def _ensure_validation_task_id_in_payload(
        self, source_task: TaskData, validation_task_id: str, reload_payload: bool = True
    ) -> None:
        await self.__ensure_payload_pipeline_field(
            source_task, "validation_task_id", validation_task_id, reload_paylod=reload_payload
        )

    async def _ensure_source_task_id_in_payload(
        self, validation_task: TaskData, source_task_id: str, reload_payload: bool = True
    ) -> None:
        await self.__ensure_payload_pipeline_field(
            validation_task, "source_task", source_task_id, reload_paylod=reload_payload
        )

    async def _create_task_from_source(
        self, task: TaskData, project_id: str, organization_id: str, base_task: Optional[TaskData] = None
    ) -> TaskData:
        new_task_request = TaskDataRequest(
            organization_id=organization_id,
            project_id=project_id,
            name=task.name,
            description=f'validation for {task.description}',
            data_source=task.data_source,
            data_classification_level=task.data_classification_level,
            depersonalize=task.depersonalize,
        )

        initial_payload = await self.client.get_task_payload(task.uid, organization_id=organization_id)
        new_task_payload: Dict[str, Any] = initial_payload or {}

        if base_task:
            logger.info("Using base task %s to create new validation task for %s", base_task.uid, task.uid)
            new_task_request.control_count = base_task.control_count
            new_task_request.control_fraction = base_task.control_fraction
            new_task_request.out_skill_id = base_task.out_skill_id
            new_task_request.expected_consistency = base_task.expected_consistency
            new_task_request.expected_quality = base_task.expected_quality
            new_task_request.filter = base_task.filter
            new_task_request.overlap = base_task.overlap
            new_task_request.price = base_task.price
            new_task_request.skip_strategy = base_task.skip_strategy
            new_task_request.item_timeout_seconds = base_task.item_timeout_seconds
            new_task_request.priority = base_task.priority
            new_task_request.max_items_per_day = base_task.max_items_per_day
            new_task_request.is_straight_order = base_task.is_straight_order
            new_task_request.is_auto_accept = base_task.is_auto_accept
            new_task_request.auto_accept_period_day = base_task.auto_accept_period_day
            new_task_request.auto_accept_threshold = base_task.auto_accept_threshold

            if not base_task.payload:
                await self.client.load_task_payload(base_task)
                if base_task.payload and isinstance(base_task.payload, dict):
                    new_task_payload = merge(new_task_payload, base_task.payload)

        new_task = await self.client.create_task(new_task_request, organization_id=organization_id)

        new_task_payload.setdefault("pipeline", {})
        new_task_payload["pipeline"]["source_task"] = task.uid
        new_task_payload["pipeline"].pop("validation_task_id", None)
        new_task_payload["pipeline"].pop("validation_project_id", None)
        new_task.payload = await self.client.set_task_payload(
            new_task.uid,
            new_task_payload,
            organization_id=organization_id,
        )
        if not new_task.payload:
            await self.client.load_task_payload(new_task)

        return new_task

    async def _ensure_source_task_has_validation_pair(
        self,
        project_id: str,
        organization_id: str,
        source_proj_tasks: List[TaskData],
        target_links: Set[str],
        config: Dict[str, dict],
        project_task_map: Dict[str, List[TaskData]],
        tasks: List[TaskData],
        base_task: Optional[TaskData] = None,
    ) -> None:
        """Process source tasks and create validation tasks

        Parameters
        ----------
        project_id : str
        organization_id : str
        source_proj_tasks : List[TaskData]
        target_links : Set[str] - set of source tasks UIDs and names of validation tasks,
            considering that names must match if task was created automatically
        config : Dict[str, dict]
        project_task_map : Dict[str, List[TaskData]] - map of source project ID to list of its tasks
        tasks : List[TaskData] - list of validation tasks
        base_task : Optional[TaskData] = None - base task to copy settings from
        """
        for task in source_proj_tasks:
            if task.organization_id != organization_id:
                self.project_api_errors[task.project_id].append(
                    f"Task {task.uid} not in organization {organization_id}"
                )
                logger.warning(f"Task {task.uid} not in organization {organization_id}")
                continue

            if task.uid in target_links or task.name in target_links:
                continue

            logger.info("Creating new validation task for %s", task.uid)
            try:
                new_task = await self._create_task_from_source(
                    task=task,
                    project_id=project_id,
                    organization_id=organization_id,
                    base_task=base_task,
                )
            except APIResponseError as err:
                self.project_api_errors[project_id].append(str(err))
                logger.warning(f"Failed to bind with source task {task.uid}")
                continue

            await self._ensure_validation_task_id_in_payload(source_task=task, validation_task_id=new_task.uid)

            logger.info('created new task %s', new_task)

            if new_task.payload is not None:
                merge(new_task.payload, config, override=False)

            tasks.append(new_task)
            project_task_map[project_id].append(new_task)
            # for safety
            target_links.add(task.uid)
            target_links.add(task.name)

    async def _get_project_organization_id(
        self,
        project_id: str,
        projects: Dict[str, Project],
        organization_id: Optional[str] = None,
    ) -> str:
        if project_id in projects:
            return projects[project_id].organization_id

        project = await self.client.get_project(project_id=project_id, organization_id=organization_id)
        return project.organization_id

    async def _check_projects_organizations(
        self,
        target_project_id: str,
        source_project_id: str,
        projects: Dict[str, Project],
        organization_id: Optional[str] = None,
    ) -> None:
        target_organization_id = await self._get_project_organization_id(
            target_project_id, projects, organization_id=organization_id
        )
        source_organization_id = await self._get_project_organization_id(
            source_project_id, projects, organization_id=organization_id
        )

        if target_organization_id != source_organization_id:
            raise RuntimeError(
                f"Target project {target_project_id} and source project {source_project_id} "
                f"are not in the same organization"
            )

    async def scan_project_tasks(
        self, project_ids: Optional[Sequence[str]] = None, organization_id: Optional[str] = None
    ) -> List[TaskData]:
        if organization_id is None:
            organization_id = await self.client.get_current_organization_id()

        projects_list, project_errors = await self.client.get_projects_advanced_with_errors(
            project_ids=project_ids,
            organization_id=organization_id,
            with_pipeline=True,
            archived=False,
            is_pipelined=True,
        )
        # NOTE: теперь проекты фильтруются сразу по executor
        # не получится в одном проекте запускать несколько экзекьюторов, прописывая их в payload задач.
        # #Но оно и не надо - вызывает много ошибок
        projects: Dict[str, Project] = {
            p.uid: p for p in projects_list if p.pipeline and p.is_pipeline_enabled and self.check_executor(p.pipeline)
        }
        project_pipelines: Dict[str, Dict[str, Any]] = {p.uid: {"pipeline": p.pipeline} for p in projects.values()}

        tasks_with_errors: AdvancedTaskDataWithErrors = await self.client.get_tasks_advanced_with_errors(
            project_ids=list(projects.keys()),
            with_payload=True,
            with_empty=True,
            with_project_pipeline=project_pipelines,
            organization_id=organization_id,
            project_errors=project_errors,
        )

        self.project_api_errors.update(
            {k: self.project_api_errors.get(k, []) + v for k, v in tasks_with_errors.project_errors.items()}
        )
        self.task_api_errors.update(tasks_with_errors.task_errors)

        project_task_map: Dict[str, List[TaskData]] = defaultdict(list)

        for task in tasks_with_errors.tasks:
            project_task_map[task.project_id].append(task)

        for project_id, config_ in list(project_pipelines.items()):
            if 'pipeline' not in config_:
                continue

            try:
                config: SyncSettings = from_dict(
                    data_class=SyncSettings, data=config_['pipeline'], config=Config(cast=[Enum, Tuple])
                )
                if not config.source_project or not config.auto_create_task:
                    continue

            except (AssertionError, DaciteError, ValueError) as ex:
                self.project_hard_errors[project_id].append(str(ex))
                continue

            try:
                await self._check_projects_organizations(
                    project_id, config.source_project, projects, organization_id=organization_id
                )
            except (APIResponseError, RuntimeError) as ex:
                self.project_api_errors[project_id].append(str(ex))
                logger.warning(ex)
                continue

            if config.source_project not in project_task_map:
                try:
                    project_task_map[config.source_project] = await self.client.get_tasks(
                        project_id=config.source_project, organization_id=organization_id
                    )
                except APIResponseError as ex:
                    self.project_api_errors[project_id].append(str(ex))
                    logger.warning(f"Project {project_id}: {ex}")
                    continue

            source_proj_tasks = project_task_map[config.source_project]

            all_tasks_is_archived = True
            for task in source_proj_tasks:
                if task.state != TaskState.ARCHIVE:
                    all_tasks_is_archived = False
                    break

            if all_tasks_is_archived and len(source_proj_tasks):
                self.project_hard_errors[project_id].append("В исходном проекте нет не архивных задач")
                continue

            target_proj_tasks = project_task_map[project_id]
            target_links = set(
                chain(
                    *[
                        (t.payload.get('pipeline', {}).get('source_task'), t.name)
                        for t in target_proj_tasks
                        if t.payload and self.check_executor(t.payload.get("pipeline", {}))
                    ]
                )
            )
            logger.debug("Project %s. Tarket links: %s", project_id, target_links)
            base_task = None
            if config.base_task:
                try:
                    base_task = await self.client.get_task(task_id=config.base_task, organization_id=organization_id)
                except APIResponseError as ex:
                    self.project_api_errors[project_id].append(str(ex))
                    logger.warning(f"Project {project_id}: {config.base_task}")
                    continue

            await self._ensure_source_task_has_validation_pair(
                project_id=project_id,
                organization_id=projects[project_id].organization_id,
                source_proj_tasks=source_proj_tasks,
                target_links=target_links,
                config=config_,
                project_task_map=project_task_map,
                tasks=tasks_with_errors.tasks,
                base_task=base_task,
            )

        return tasks_with_errors.tasks

    async def scan_tasks(
        self,
        task_ids: Optional[Sequence[str]] = None,
        project_ids: Optional[Sequence[str]] = None,
        organization_id: Optional[str] = None,
    ) -> List[TaskData]:
        tasks: List[TaskData] = []

        if task_ids:
            tasks_with_errors: AdvancedTaskDataWithErrors = await self.client.get_tasks_advanced_with_errors(
                task_ids=task_ids,
                with_payload=True,
                with_empty=True,
                with_project_pipeline=True,
                organization_id=organization_id,
            )

            self.project_api_errors.update(
                {k: self.project_api_errors.get(k, []) + v for k, v in tasks_with_errors.project_errors.items()}
            )
            self.task_api_errors.update(tasks_with_errors.task_errors)
            tasks = [
                task
                for task in tasks_with_errors.tasks
                if task.payload and self.check_executor(task.payload.get("pipeline", {}))
            ]

        if not task_ids or project_ids:
            tasks.extend(await self.scan_project_tasks(project_ids=project_ids, organization_id=organization_id))

        for task in tasks:
            if task.organization_id is not None:
                self.projects_organizations_mapping[task.organization_id].add(task.project_id)

        self._task_scheduled = tasks
        return tasks

    async def process_pipeline(  # pylint: disable=R0912
        self,
        task: TaskData,
        dry_run: bool = False,
        limit: Optional[int] = None,
        organization_id: Optional[str] = None,
        sync_settings: Optional[SyncSettings] = None,
    ) -> Tuple[bool, int]:
        """Часть пайплайна source -> validation.
        Для для валидационной задачи получает исходную и отправляет на валидацию ответы разметчиков

        Args:
            task (TaskData): валидационное задание
            dry_run (bool, optional): дамп заданий в stdout вместо отправки в задачу (DEBUG). Defaults to False.
            limit (Optional[int], optional): сколько ассайнментов отправить за раз. Defaults to None.
            organization_id (Optional[str], optional): uid организации. Defaults to None.
            sync_settings (Optional[SyncSettings], optional): настройки пайплайна (задача + проект). Defaults to None.

        Returns:
            Tuple[bool, int]: кортеж (<задача обработана корректно>, <количество заданий для валидационной задачи>)
        """
        # TODO: limit - бесполезная какая-то штука, за несколько запусков отправятся все ассайнменты все равно
        if not sync_settings:
            assert task.payload
            assert isinstance(task.payload.get('pipeline'), dict)
            sync_settings = from_dict(
                data_class=SyncSettings, data=task.payload['pipeline'], config=Config(cast=[Enum, Tuple])
            )
            logger.info(
                "(%s | %s) Sync settings loaded from payload: %s",
                task.uid,
                task.name,
                sync_settings.asdict(ignore_none=True),  # type: ignore
            )
        if not sync_settings:
            return True, 0

        if sync_settings.source_project and not sync_settings.source_task:
            source_task_query = await self.client.get_tasks(
                project_id=sync_settings.source_project, query=f'{task.name}', organization_id=organization_id
            )

            source_task_query = [x for x in source_task_query if x.name == task.name]
            if not source_task_query:
                return False, 0

            source_task = source_task_query[0]
            sync_settings.source_task = source_task.uid
            await self._ensure_source_task_id_in_payload(validation_task=task, source_task_id=source_task.uid)

        elif sync_settings.source_task:
            source_task = await self.client.get_task(sync_settings.source_task, organization_id=organization_id)
            await self._ensure_validation_task_id_in_payload(source_task=source_task, validation_task_id=task.uid)
        else:
            return True, 0

        if source_task.organization_id != task.organization_id:
            self.project_hard_errors[task.project_id].append(
                f"Task {source_task.uid} not in organization {task.organization_id}"
            )
            logger.warning(f"Task {source_task.uid} not in organization {task.organization_id}")
            return False, 0

        with TempDir() as tmp_dir:
            json_data = []
            try:
                json_data = await self.prepare_data(
                    task, source_task, sync_settings, tmp_dir, limit, organization_id=organization_id
                )
                if not json_data:
                    return True, 0
            except APIResponseError as exc:
                self.project_api_errors[task.project_id].append(exc.json_error)
                return False, 0

            if dry_run:
                json.dump(json_data, sys.stdout, ensure_ascii=False, indent=2)
                return True, 0

            started = task.state == TaskState.RUNNING
            if started:
                try:
                    await self.client.stop_task(task_id=task.uid, organization_id=organization_id)
                except APIResponseError as exc:
                    self.project_api_errors[task.project_id].append(f'failed to stop task {task.uid}: {exc.json_error}')
                    logger.error(f'failed to stop task {task.uid}: {exc.json_error}')

            if sync_settings.auto_start_task and task.state in (TaskState.DONE, TaskState.INITIAL):
                started = True

            try:
                await self.client.upload_json_data(
                    task_id=task.uid, json_data=json_data, base_path=tmp_dir, organization_id=organization_id
                )
            except APIResponseError as exc:
                self.project_api_errors[task.project_id].append(
                    f'failed to upload data to task {task.uid}: {exc.json_error}'
                )
                logger.error(f'failed to upload data to task {task.uid}: {exc.json_error}')
                return False, 0

            if started:
                try:
                    await self.client.start_task(task_id=task.uid, organization_id=organization_id)
                except APIResponseError as exc:
                    if not (
                        exc.json_error
                        and (error := exc.json_error.get("error", {}))
                        and isinstance(error, dict)
                        and error.get("message", "") == "Назначьте разметчиков на проект"
                    ):
                        self.project_api_errors[task.project_id].append(
                            f'failed to start task {task.uid}: {exc.json_error}'
                        )
                        logger.error(f'failed to start task {task.uid}: {exc.json_error}')
            return True, len(json_data)

    async def __get_validation_task_by_id(
        self, task: TaskData, validation_task_id: str, organization_id: Optional[str] = None, with_payload: bool = False
    ) -> Optional[TaskData]:
        try:
            validation_task = await self.client.get_task(task_id=validation_task_id, organization_id=organization_id)
            if with_payload:
                await self.client.load_task_payload(validation_task)
            return validation_task
        except APIResponseError as exc:
            if exc.status == 404:
                logger.warning(
                    "Source task %s refers to a non-existent validation task %s. Removing it from the payload...",
                    task.uid,
                    validation_task_id,
                )
                return await self.__remove_from_payload_pipeline_field(
                    task, "validation_task_id", reload_paylod=False, update_payload_in_task=False
                )
            else:
                raise exc

    async def set_items_as_sent(
        self,
        validation_task: TaskData,
        reviews: List[MarkupReview],
        review_result: MarkupReviewResult,
        sync_settings: SyncSettings,
    ) -> None:
        failed_items = set()
        item_new_metadata_request_map: Dict[str, UpdateMetaDataRequest] = {}
        premarkup_handler = PremarkupRWHandler(sync_settings)
        for review in reviews:
            assignment_id = review.assignment_id

            items = self.get_assignment_validation_items(assignment_id)
            for item_id in items:
                item_metadata = await self.get_item_metadata(validation_task, item_id)

                premarkup = item_metadata.premarkup or {}

                if review_result.failed_assignment_ids and assignment_id in review_result.failed_assignment_ids:
                    failed_items.add(item_id)
                    item_new_metadata_request_map.pop(item_id, None)
                elif item_id not in failed_items:
                    premarkup_handler.mark_result_sent(premarkup)
                    item_new_metadata_request_map[item_id] = UpdateMetaDataRequest(
                        MetaData(premarkup=premarkup), item_id
                    )

        logger.debug("Total items to set as sent: %d", len(item_new_metadata_request_map))

        task_updated = await self.client.get_task(validation_task.uid, organization_id=validation_task.organization_id)
        was_running = task_updated.state == TaskState.RUNNING
        if was_running:
            await self.client.stop_task(validation_task.uid, organization_id=validation_task.organization_id)

        logger.debug(reviews)
        logger.debug(self._item_metada_map)
        logger.debug(self._assignment_validation_item_map)
        logger.debug("item_new_metadata_request_map: %s", item_new_metadata_request_map)
        await self.client.update_meta_data(
            validation_task.uid,
            list(item_new_metadata_request_map.values()),
            organization_id=validation_task.organization_id,
        )

        if was_running:
            await self.client.start_task(validation_task.uid, organization_id=validation_task.organization_id)

    async def process_validation(
        self,
        task: TaskData,
        sync_settings: SyncSettings,
        organization_id: Optional[str] = None,
    ) -> Tuple[Optional[dict], int]:
        organization_id = organization_id or task.organization_id
        assert organization_id
        validation_task: Optional[TaskData] = None

        if sync_settings.validation_task_id:
            validation_task = await self.__get_validation_task_by_id(
                task, sync_settings.validation_task_id, organization_id, with_payload=True
            )
            if not validation_task:
                sync_settings.validation_task_id = None

        if not validation_task and sync_settings.validation_project_id:
            validation_task_query: List[TaskData] = await self.client.get_tasks(
                project_id=sync_settings.validation_project_id, query=f'{task.name}', organization_id=organization_id
            )
            validation_task_query = [x for x in validation_task_query if x.name == task.name]
            if not validation_task_query:
                return None, 0

            validation_task = validation_task_query[0]
            sync_settings.validation_task_id = validation_task.uid
            await self._ensure_validation_task_id_in_payload(source_task=task, validation_task_id=validation_task.uid)

        if not validation_task:
            return None, 0

        if validation_task.organization_id != task.organization_id:
            self.project_hard_errors[task.project_id].append(
                f"Task {validation_task.uid} not in organization {task.organization_id}"
            )
            logger.warning(f"Task {validation_task.uid} not in organization {task.organization_id}")
            return None, 0

        validation_project = await self.client.get_project(validation_task.project_id, organization_id=organization_id)
        validation_sync_settings = get_merged_validation_sync_settings(validation_project, validation_task)

        reviews, error = await self.prepare_validation_data(
            validation_task=validation_task,
            sync_settings=sync_settings,
            organization_id=organization_id,
            validation_sync_settings=validation_sync_settings,
        )

        if not reviews:
            return error, 0

        review_result = await self.client.review_multiple_markups(reviews, organization_id=organization_id)
        await self.set_items_as_sent(validation_task, reviews, review_result, validation_sync_settings)

        return error, len(reviews)

    async def prepare_validation_data(
        self,
        validation_task: TaskData,
        sync_settings: SyncSettings,
        organization_id: str,
        validation_sync_settings: Optional[SyncSettings] = None,
    ) -> Tuple[List[MarkupReview], Optional[dict]]:
        error: Optional[Dict[str, List[str]]] = None

        logger.debug(
            "(%s | %s) USING STATUSES 'assignment_statuses_validation': %s",
            validation_task.uid,
            validation_task.name,
            sync_settings.assignment_statuses_validation,
        )

        task_assignments_df = pd.DataFrame(
            await self.client.get_task_assignments(validation_task.uid, organization_id=organization_id)
        )
        logger.debug("Total collected assignments: %d", len(task_assignments_df))
        if task_assignments_df.empty:
            return [], None

        if validation_sync_settings is None:
            validation_project = await self.client.get_project(
                validation_task.project_id, organization_id=organization_id
            )
            validation_sync_settings = get_merged_validation_sync_settings(validation_project, validation_task)

        already_sent_assignments_mask: 'pd.Series[bool]' = await self.get_already_sent_validation_assignments_mask(
            task_assignments_df,
            validation_task=validation_task,
            organization_id=organization_id,
            sync_settings=validation_sync_settings,
        )
        logger.debug("Total validation assignments already sent: %d", int(already_sent_assignments_mask.sum()))

        not_sent_mask: 'pd.Series[bool]' = ~already_sent_assignments_mask
        logger.debug("Total assignments not sent yet: %d", int(not_sent_mask.sum()))

        assignments: pd.DataFrame = filter_assignments_by_status(
            task_assignments_df,
            not_sent_mask=not_sent_mask,
            overlap=validation_task.overlap,
            assignment_statuses_to_send=sync_settings.assignment_statuses_validation,
        )

        logger.debug("Total collected assignments after filter by status: %d", len(assignments))

        if assignments.empty:
            return [], error

        markup_reviews: List[MarkupReview] = []
        aggregated_results: Dict[str, dict] = defaultdict(dict)

        logger.debug(
            "validation_project_sync_settings for task %s: %s",
            sync_settings.source_task,
            validation_sync_settings,
        )
        for _, row in assignments.iterrows():
            assignment_id = None
            review = row.to_dict()
            assignment = from_dict(Assignment, review)

            result: Optional[Dict[str, Any]] = assignment.result

            if not result:
                continue

            if not result.get("assignment_id"):
                logger.warning(
                    "Task's %s assignment %s has no 'assignment_id' in its result",
                    validation_task.uid,
                    review.get('assignment_id'),
                )
                if not assignment_id:
                    logger.info("Using premarkup to get source task assignment_id")

                    assignment_id = await self.get_validation_source_assignment_id(
                        validation_task=validation_task,
                        item_id=assignment.item_id,
                        organization_id=organization_id,
                        validation_sync_settings=validation_sync_settings,
                    )

                    if not assignment_id:
                        continue
                result["assignment_id"] = assignment_id

            self.update_assignment_validation_items_map(result["assignment_id"], assignment.item_id)

            if result["assignment_id"] not in aggregated_results:
                aggregated_results[result["assignment_id"]] = {}
            #  aggregated_results = {"source_assignment_id": {"validating_assignment_id1"..., "validating_assignment_id2":...}}  pylint: disable=line-too-long
            aggregated_results[result["assignment_id"]][review["assignment_id"]] = review

        for assignment_id, reviews in aggregated_results.items():
            markup_review, error = process_validation_assignment(
                assignment_id=assignment_id,
                reviews=reviews,
                validation_task=validation_task,
                sync_settings=sync_settings,
            )
            if error or not markup_review:
                return [], error

            markup_reviews.append(markup_review)

        return markup_reviews, error

    async def get_validation_source_assignment_id(  # FIXME: не работает для агрегации
        self,
        validation_task: TaskData,
        item_id: str,
        organization_id: str,
        validation_sync_settings: SyncSettings,
    ) -> Union[str, None]:
        metadata: MetaData = await self.client.get_meta_data(
            task_id=validation_task.uid, file_uid=item_id, organization_id=organization_id
        )
        if metadata.premarkup:
            handler = PremarkupRWHandler(validation_sync_settings)
            assignment_id = handler.read_assignment_id(metadata.premarkup) or metadata.premarkup.get("assignment_id")
            if not assignment_id:
                logger.warning("item %s has no assignment_id in premarkup", item_id)
                logger.debug(metadata.premarkup)
            return assignment_id
        return None

    def _collect_metrics(
        self,
        tasks: List[TaskData],
        task_processing_duration: List[float],
        pipeline_processed_tasks: int,
        pipeline_processed_items: int,
    ) -> None:
        if self._pipeline_metrics_collector is None or "metrics_data" not in self._pipeline_metrics_collector:
            return

        task_processing_hist: Optional[Histogram] = self._pipeline_metrics_collector.get(
            "pipeline_task_processing_duration"
        )
        if task_processing_hist is not None:
            task_processing_hist.observe(
                self._pipeline_metrics_collector["metrics_data"],
                median(task_processing_duration) if task_processing_duration else 0,
            )

        queue_tasks_count_gauge: Optional[Gauge] = self._pipeline_metrics_collector.get("pipeline_tasks_in_queue")
        if queue_tasks_count_gauge is not None:
            queue_tasks_count_gauge.add(self._pipeline_metrics_collector["metrics_data"], len(tasks))

        processed_tasks_count_gauge: Optional[Gauge] = self._pipeline_metrics_collector.get("pipeline_processed_tasks")
        if processed_tasks_count_gauge is not None:
            processed_tasks_count_gauge.add(
                self._pipeline_metrics_collector["metrics_data"],
                pipeline_processed_tasks,
            )

        processed_items_count_gauge: Optional[Gauge] = self._pipeline_metrics_collector.get("pipeline_processed_items")
        if processed_items_count_gauge is not None:
            processed_items_count_gauge.add(
                self._pipeline_metrics_collector["metrics_data"],
                pipeline_processed_items,
            )

    async def process_tasks(
        self,
        tasks: List[TaskData],
        dry_run: bool = False,
        limit: Optional[int] = None,
        organization_id: Optional[str] = None,
        batch_size: int = 4,  # pylint: disable=unused-argument
    ) -> None:
        # TODO(volerog): use aiopool for parallel run
        # with AIOPool(workers=batch_size) as pool:
        #     async for _result in pool.map_async(self.process_pipeline, map(lambda x: (x, dry_run, limit), tasks)):
        #         pass
        task_processing_duration = []
        pipeline_processed_tasks = 0
        pipeline_processed_items = 0
        task_validation_duration = []
        validation_processed_tasks = 0
        validation_processed_items = 0

        for task in tasks:  # pylint: disable=too-many-nested-blocks
            try:
                start_time = time.time()
                is_task_processed = False
                processed_task_items = 0
                validated_task_items = 0
                if task.payload is None or task.payload.get('pipeline') is None:
                    is_task_processed, processed_task_items = False, 0
                else:
                    sync_settings = from_dict(
                        data_class=SyncSettings, data=task.payload['pipeline'], config=Config(cast=[Enum, Tuple])
                    )

                    logger.info((task.uid, task.name, sync_settings.asdict(ignore_none=True)))
                    is_task_processed, processed_task_items = await self.process_pipeline(
                        task, dry_run, limit, organization_id=organization_id, sync_settings=sync_settings
                    )

                    if is_task_processed:
                        pipeline_processed_tasks += 1
                        pipeline_processed_items += processed_task_items
                        task_processing_duration.append(time.time() - start_time)
                    start_time = time.time()

                    error, validated_task_items = await self.process_validation(
                        task=task, organization_id=organization_id, sync_settings=sync_settings
                    )

                    if not error:
                        validation_processed_tasks += 1
                        validation_processed_items += validated_task_items
                        task_validation_duration.append(time.time() - start_time)
                    else:
                        hard_error = error.pop("hard_error", None)
                        if hard_error:
                            self.project_hard_errors[task.project_id] += hard_error
                        if error:
                            self.project_light_errors[task.project_id].append(str(error))

                if is_task_processed and validated_task_items:
                    self.project_processed.add(task.project_id)
            except APIResponseError as exc:
                self.project_api_errors[task.project_id].append(str(exc))
            except Exception as exc:  # pylint: disable=broad-except
                self.project_hard_errors[task.project_id].append(str(exc))
                if logger.level <= logging.DEBUG:
                    logger.exception(f"Failed to process task {task.uid}: {str(exc)}")
                else:
                    logger.error(f"Failed to process task {task.uid}: {str(exc)}")
            finally:
                self.clear_cache()

        self._collect_metrics(tasks, task_processing_duration, pipeline_processed_tasks, pipeline_processed_items)

    async def link(
        self,
        source_task: Union[str, TaskData],
        target_task: Union[str, TaskData],
        config: Union[dict, SyncSettings],
    ) -> None:
        if isinstance(target_task, str):
            target_task = await self.client.get_task(task_id=target_task)

        if isinstance(source_task, str):
            source_task = await self.client.get_task(task_id=source_task)

        if source_task.organization_id != target_task.organization_id:  # type: ignore
            raise RuntimeError("Source and target tasks must be in the same organization")

        if isinstance(config, SyncSettings):
            config = dataclass_to_dict(config)

        config['source_task'] = source_task.uid  # type: ignore
        config['executor'] = config['executor'] or self.executor

        await self.client.set_task_payload(target_task.uid, {'pipeline': config})  # type: ignore
        # Markup results transfer
        await self.client.load_task_payload(target_task)
        self._task_scheduled.append(target_task)  # type: ignore

    async def run_once(self, organization_id: Optional[str] = None) -> None:
        await self.process_tasks(self._task_scheduled, organization_id=organization_id)

    async def run(
        self,
        task_ids: Optional[Sequence[str]] = None,
        project_ids: Optional[Sequence[str]] = None,
        organizaions: Optional[List[Organization]] = None,
    ) -> None:
        while True:
            organizations = organizaions or await self.client.get_organizations()
            for organization in organizations:
                if "CUSTOMER" in organization.roles:
                    logger.info(
                        "Pipeline will process org=(%s, %s)",
                        organization.uid,
                        organization.name,
                    )
                    try:
                        await self.scan_tasks(task_ids, project_ids, organization_id=organization.uid)
                        await self.run_once(organization_id=organization.uid)
                    except Exception as ex:  # pylint: disable=E0012, W0703
                        logger.exception(ex)

            logger.info("Sending project errors")
            await self.send_projects_errors(organizations=organizations)

            if logger.level <= logging.DEBUG:
                logger.debug("Errors (if exist):")
                if self.project_api_errors:
                    logger.debug("project_api_errors: \n%s", self.project_api_errors)
                if self.project_hard_errors:
                    logger.debug("project_hard_errors: \n%s", self.project_hard_errors)
                if self.project_light_errors:
                    logger.debug("project_light_errors: \n%s", self.project_light_errors)
                if self.task_api_errors:
                    logger.debug("task_api_errors: \n%s", self.task_api_errors)

            logger.info("Sleeping for %d", self.scan_delay)
            await asyncio.sleep(self.scan_delay)

    async def send_projects_errors(self, organizations: Optional[List[Organization]] = None) -> None:
        project_errors: Dict[str, List] = defaultdict(list)
        need_to_stop_pipelines = {}

        for project_id, val in self.project_api_errors.items():
            if project_id not in self.project_processed:
                if val:
                    project_errors[project_id] += val
                    need_to_stop_pipelines[project_id] = True

        for project_id, val in self.project_hard_errors.items():
            if val:
                project_errors[project_id] += val
                need_to_stop_pipelines[project_id] = True

        for project_id, val in self.project_light_errors.items():
            if val:
                project_errors[project_id] += val
                need_to_stop_pipelines[project_id] = need_to_stop_pipelines.get(project_id, False)

        for task_id, err in self.task_api_errors.items():
            logger.error(f"{task_id}\t {err}")

        if project_errors:  # pylint: disable=R1702
            project_errors_string = {
                project_id: '\n'.join(str(err) for err in errors)[:300] for project_id, errors in project_errors.items()
            }
            organizations = organizations or await self.client.get_organizations()

            for organization in organizations:
                project_errors_sent = set()
                if "CUSTOMER" in organization.roles:
                    for project_id, error in project_errors_string.items():
                        if project_id in self.projects_organizations_mapping[organization.uid]:
                            try:
                                await self.client.update_project_errors(
                                    project_id=project_id,
                                    pipeline_errors=error,
                                    need_to_stop_pipeline=need_to_stop_pipelines.get(project_id, True),
                                    organization_id=organization.uid,
                                )
                                project_errors_sent.add(project_id)
                            except Exception:  # pylint: disable=E0012, W0703
                                pass
                    for key in project_errors_sent:
                        del project_errors[key]
                if not project_errors:
                    break

        if project_errors.keys():
            ids = ';\n\t'.join(project_errors.keys())
            logger.info(f"Could not send errors for projects: \n\t{ids}")

    async def __aenter__(self) -> "TagmePipeline":
        return self

    async def __aexit__(self, exc_type: Optional[type], exc_val: Optional[Exception], exc_tb: Optional[object]) -> None:
        if self.client:
            await self.client.close()


def process_validation_assignment(  # FIXME  нет обработки аггрегированных результатов
    assignment_id: str,
    reviews: Dict[str, Dict[str, Any]],
    validation_task: TaskData,
    sync_settings: SyncSettings,
) -> Tuple[Optional[MarkupReview], Optional[dict]]:
    reviewer_comments = {}
    validation_fields: List[Tuple[str, ValidationFieldType]] = sync_settings.validation_fields or [
        ("quality", "quality"),
        ("reviewer_comment", "reviewer_comment"),
        ("accept", "accept"),
    ]
    quality = 0.0
    errs: Dict[str, List[str]] = defaultdict(list)
    accept = False

    try:
        for review_id, review in reviews.items():
            logger.debug("review: %s", review)
            for src, dst in validation_fields:
                if dst == "quality":
                    if src in review["result"] and review["result"][src] is not None and review["result"][src] != "":
                        quality = (
                            float(review["result"][src])
                            if validation_task.overlap == 1
                            else quality + float(review["consistency"])
                        )
                    else:
                        errs[review_id].append(f"No {src} field in result or invalid type")
                elif dst == "accept":
                    if src in review["result"] and review["result"][src] is not None and review["result"][src] != "":
                        src_val = review["result"][src] if validation_task.overlap == 1 else False
                        accept = src_val == "true" if isinstance(src_val, str) else src_val
                    else:
                        errs[review_id].append(f"No {src} field in result")

                elif dst == "reviewer_comment":
                    reviewer_comments[review_id] = review["result"].get(src)

        if validation_task.overlap > 1:
            quality /= len(reviews)
            if validation_task.auto_accept_threshold is not None:
                accept = quality >= validation_task.auto_accept_threshold

        reviewer_comment = (
            str(reviewer_comments) if len(reviewer_comments) > 1 else next(iter(reviewer_comments.values()))
        )
    except Exception as err:  # pylint: disable=broad-except
        errs["hard_error"].append(str(err))
        return (None, errs)
    return (
        MarkupReview(
            assignment_id=assignment_id,
            status="ACCEPTED" if accept else "REJECTED",
            quality=quality,
            comment=reviewer_comment,
        ),
        errs or None,
    )
