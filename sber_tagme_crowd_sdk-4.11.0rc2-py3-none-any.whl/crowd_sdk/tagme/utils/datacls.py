from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Iterable, List, Literal, Optional, Set, Tuple, Union, overload

from crowd_sdk.core.utils.common import dataclass_to_dict
from crowd_sdk.core.utils.datacls import AsDictMixin, FromDictMixin
from crowd_sdk.tagme.http_client.datacls import AssignmentStatusType


@dataclass
class TaskQuality:
    uid: str
    name: str
    items_count: int
    quality: Optional[float]
    consistency: Optional[float]
    reward: float
    complete_data: bool = True


@dataclass
class ItemQuality:
    uid: str
    task_id: str
    quality: Optional[float]
    consistency: float
    reward: Optional[float]
    complete_data: bool = True


class StatsOutputType(Enum):
    TASK = "task"
    ITEM = "item"


class ConsistencyFilter(Enum):
    ALL_UNIQUE = "all_unique"
    UNSURE = "unsure"


class ResultAggregation(Enum):
    AGGREGATE = "aggregate"
    SEPARATE = "separate"


class AggregatedResults(list):
    def add(self, weight: float, result: Any) -> None:
        self.append({"weight": weight, "result": result})

    def __getitem__(self, item: Any) -> "AggregatedResults":
        if not isinstance(item, str):
            return super().__getitem__(item)

        new = AggregatedResults()
        for i in self:
            new.add(weight=i["weight"], result=i["result"][item])

        return new


ValidationFieldType = Literal["quality", "reviewer_comment", "accept"]


@dataclass
class SyncSettings(FromDictMixin, AsDictMixin):
    fields: List[Tuple[str, str]] = field(default_factory=lambda: [('file', 'file'), ('result', 'premarkup')])
    source_task: Optional[str] = None
    source_project: Optional[str] = None
    result_aggregation: ResultAggregation = ResultAggregation.SEPARATE
    consistency_filter: ConsistencyFilter = ConsistencyFilter.ALL_UNIQUE
    consistency_share_threshold: Optional[float] = None
    ignore_fields: Optional[List[str]] = None
    result_filter: str = "all"
    executor: Optional[str] = None
    auto_create_task: bool = True
    auto_start_task: bool = False
    base_task: Optional[str] = None
    validation_project_id: Optional[str] = None
    validation_task_id: Optional[str] = None
    validation_fields: Optional[List[Tuple[str, ValidationFieldType]]] = None
    assignment_statuses_source: List[AssignmentStatusType] = field(default_factory=lambda: ["ACCEPTED", "SUBMITTED"])
    assignment_statuses_validation: List[AssignmentStatusType] = field(
        default_factory=lambda: ["ACCEPTED", "SUBMITTED"]
    )
    marker_assignments_percent: int = 100
    marker_assignments_min: int = 1
    task_assignments_percent: int = 100
    task_assignments_min: int = 1

    def __post_init__(self) -> None:
        if not (self.source_task or self.source_project or self.validation_project_id or self.validation_task_id):
            raise ValueError(
                "Pipelines config should contain one of (source_task; source_project; "
                "validation_project_id; validation_task_id) value"
            )

        if self.consistency_filter == ConsistencyFilter.UNSURE and self.consistency_share_threshold is None:
            raise ValueError("missing `consistency_share_threshold` value for `unsure` consistency filter")

        if any(not x.startswith("result.") for x in self.ignore_fields or []):
            raise ValueError("every field in `ignore_fields` should start with 'result.'")

        if any(
            len(statuses) == 0 for statuses in (self.assignment_statuses_validation, self.assignment_statuses_source)
        ):
            raise ValueError("'assignment_statuses_source' and 'assignment_statuses_validation' must not be empty")

        for source, destination in self.fields or []:
            if source == "result" and not isinstance(destination, str):
                raise ValueError("destination for 'result' field must be a string")
            if source == "result" and not destination.startswith("premarkup"):
                raise ValueError("destination for 'result' field must start with 'premarkup'")

        def validate_percent(value: int, name: str) -> None:
            if not isinstance(value, int) or not 0 <= value <= 100:
                raise ValueError(f"'{name}' must be an integer from 0 to 100, got {value}")

        def validate_min(value: int, name: str) -> None:
            if not isinstance(value, int) or not value >= 0:
                raise ValueError(f"'{name}' must be an integer greater than or equal to 0, got {value}")

        marker_percentage_changed = self.marker_assignments_percent != 100
        task_percentage_changed = self.task_assignments_percent != 100

        if marker_percentage_changed and task_percentage_changed:
            raise ValueError("Cannot use both marker_* and task_* fields simultaneously")

        if marker_percentage_changed:
            validate_percent(self.marker_assignments_percent, "marker_assignments_percent")
            if self.marker_assignments_min is None:
                raise ValueError("marker_assignments_min is required when using marker fields")
            validate_min(self.marker_assignments_min, "marker_assignments_min")

        elif task_percentage_changed:
            validate_percent(self.task_assignments_percent, "task_assignments_percent")
            if self.task_assignments_min is None:
                raise ValueError("task_assignments_min is required when using marker fields")
            validate_min(self.task_assignments_min, "task_assignments_min")


common_fields: Set[str] = {"executor"}
validation_project_keys: Set[str] = {  # type: ignore
    "source_project",
    "source_task",
    "auto_start_task",
    "auto_create_task",
    "result_aggregation",
    "fields",
    "consistency_filter",
    "consistency_share_threshold",
    "ignore_fields",
    "result_filter",
    "base_task",
    "assignment_statuses_source",
    "marker_assignments_percent",
    "marker_assignments_min",
    "task_assignments_percent",
    "task_assignments_min",
} | common_fields
source_project_keys: Set[str] = {  # type: ignore
    "validation_project_id",
    "validation_task_id",
    "validation_fields",
    "assignment_statuses_validation",
} | common_fields


@dataclass
class PipelineInitialConfig(FromDictMixin):
    """Настройки для первоначальной конфигурации пайплайна.
    Реализует методы для генерации настроек отдельных проектов (исходный/валидационный).

    Parameters
    ----------

    **Common**

    executor: Исполнитель пайплайна. Пайплайн будет выполняться только 'TagmePipeline'
                        с таким же 'executor'. "tagme" - по умолчанию продовый исполнитель.

    **Validation project (pipeline source -> validation)**

    source_project : UID исходного проекта. Откуда брать задачи с ассайнментами на валидацию.
    source_task(only for task payload) : UID исходной задачи. Откуда брать ассайнменты на валидацию.
    auto_create_task: Автоматически создавать валидационное задание.
                        Если False - создавать вручную + прописывать payload.pipeline.source_task.
    auto_start_task : Автоматически запускать валидационное задание.
    result_aggregation : Аггрегировать несколько ассайнментов в один файл валидационного задания.
                        Если AGGREGATE - в premarku.result будет список ответов,
                        если SEPARATE - без списка один объект.
    fields(not recommended) : Поля для передачи результатов разметки.
                        Формат: [(результат разметки: куда класть в файл валидационного задания)].
                        NOTE: лучше не трогать -
    consistency_filter : Фильтр консистентности.
                        ALL_UNIQUE - все с уникальным consistency,
                        UNSURE - по порогу (см. consistency_share_threshold).
    consistency_share_threshold : Порог для фильтра консистентности.
                        Если для item `max(consistency) / count(assignments)` > порог,
                        то item не отправляется на валидацию.
    ignore_fields : Какие поля результатов не передавать в валидационную задачу.
    result_filter : Фильтр результатов. "all" - все, "is_successful" - только если
                        assignment.result["success"] == True. Можно создавать кастомные фильтры.
    base_task : task_id задачи, из которой копировать настройки для новых создаваемых
                        в валидационном проекте задач.
    assignment_statuses_source : Список статусов ассайнмент.
                        из исходного проекта на валидацию.
    marker_assignments_percent : Процент ответов отправленных на валидацию ответов по каждому разметчику.
                        По умолчанию - 100. Должно быть равно строго 100, если используется task_assignments_percent.
    marker_assignments_min : Минимальное количество ответов, отправляемых на валидацию. По умолчанию - 1.
    task_assignments_percent : Процент ответов отправленных на валидацию ответов по задаче.
                        По умолчанию - 100. Должно быть равно строго 100, если используется marker_assignments_percent
    task_assignments_min : Минимальное количество ответов, отправляемых на валидацию. По умолчанию - 1.

    **Source project (pipeline validation -> source)**

    validation_project_id : UID валидационного проекта. Откуда брать коммментарии,
                        качество и статус (принять/отклонить).
    validation_task_id(only for task payload) : UID валидационной задачи. Откуда брать коммментарии,
                        качество и статус (принять/отклонить).
    validation_fields : Поля в валидационном проекте.
    assignment_statuses_validation : Список статусов ассайнментов валидационного
                                            проекта, из которых получать качество,
                                            комментарий и статус.

    Notes
    -----

    - Поля marker_assignments_percent и task_assignments_percent не могут использоваться одновременно:
    если один из процентов изменен, другой должен оставаться равен 100.
    - source_task и validation_task_id используются на уровне задачи. Не прописывайте их в конфиг проекта
    """

    # --- common settings ---
    executor: str = "tagme"

    # --- validation project settings (source -> validation pipeline) ---
    source_project: Optional[str] = None
    source_task: Optional[str] = None
    auto_create_task: bool = True
    auto_start_task: bool = False
    result_aggregation: ResultAggregation = ResultAggregation.SEPARATE
    fields: List[Tuple[str, str]] = field(default_factory=lambda: [("file", "file"), ("result", "premarkup.result")])
    consistency_filter: ConsistencyFilter = ConsistencyFilter.ALL_UNIQUE
    consistency_share_threshold: Optional[float] = None
    ignore_fields: Optional[List[str]] = None
    result_filter: str = "all"
    base_task: Optional[str] = None
    assignment_statuses_source: List[AssignmentStatusType] = field(default_factory=lambda: ["ACCEPTED", "SUBMITTED"])
    marker_assignments_percent: int = 100
    marker_assignments_min: int = 1
    task_assignments_percent: int = 100
    task_assignments_min: int = 1

    # --- source project settings (validation -> source pipeline) ---
    validation_project_id: Optional[str] = None
    validation_task_id: Optional[str] = None
    validation_fields: Optional[List[Tuple[str, ValidationFieldType]]] = None
    assignment_statuses_validation: List[AssignmentStatusType] = field(
        default_factory=lambda: ["ACCEPTED", "SUBMITTED"]
    )

    @overload
    def __generate_settings(self, attributes: Iterable[str], as_dict: Literal[True]) -> Dict[str, Any]:
        ...

    @overload
    def __generate_settings(self, attributes: Iterable[str], as_dict: Literal[False]) -> SyncSettings:
        ...

    @overload
    def __generate_settings(self, attributes: Iterable[str], as_dict: bool) -> Union[SyncSettings, Dict[str, Any]]:
        ...

    def __generate_settings(
        self, attributes: Iterable[str], as_dict: bool = True
    ) -> Union[SyncSettings, Dict[str, Any]]:
        settings_dict: Dict[str, Any] = {}

        target_attributes_flat: Set[str] = set()

        for attr_or_map in attributes:
            if isinstance(attr_or_map, tuple):
                key, value = attr_or_map[1], getattr(self, attr_or_map[0])
                target_attributes_flat.add(attr_or_map[1])
            else:
                key, value = attr_or_map, getattr(self, attr_or_map)
                target_attributes_flat.add(attr_or_map)

            if value is not None:
                settings_dict[key] = value

        settings = SyncSettings.from_dict(settings_dict)  # for attrs validation
        if not as_dict:
            return settings
        return {k: v for k, v in dataclass_to_dict(settings).items() if k in target_attributes_flat}

    @overload
    def generate_validation_project_settings(self, as_dict: Literal[True]) -> Dict[str, Any]:
        ...

    @overload
    def generate_validation_project_settings(self, as_dict: Literal[False]) -> SyncSettings:
        ...

    @overload
    def generate_validation_project_settings(
        self,
    ) -> Dict[str, Any]:
        ...

    def generate_validation_project_settings(self, as_dict: bool = True) -> Union[SyncSettings, Dict[str, Any]]:
        return self.__generate_settings(validation_project_keys, as_dict)

    @overload
    def generate_source_project_settings(self, as_dict: Literal[True]) -> Dict[str, Any]:
        ...

    @overload
    def generate_source_project_settings(self, as_dict: Literal[False]) -> SyncSettings:
        ...

    @overload
    def generate_source_project_settings(
        self,
    ) -> Dict[str, Any]:
        ...

    def generate_source_project_settings(self, as_dict: bool = True) -> Union[SyncSettings, Dict[str, Any]]:
        return self.__generate_settings(source_project_keys, as_dict)

    def generate_single_project_validation_settings(
        self, as_dict: bool = True
    ) -> Union[SyncSettings, Dict[str, Any]]:  # NOTE: write tests, may be redundant
        if self.source_project != self.validation_project_id:
            raise ValueError(
                "Error creating 'ValidationPipelineConfig' for single project: "
                "source_project_id and destination_project_id must be same"
            )
        return self.__generate_settings(validation_project_keys | source_project_keys, as_dict)
