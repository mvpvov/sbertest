#!/usr/bin/env python3
"""Console util for toloka managing"""

import logging
from typing import Any, List

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.cv.upload_pdf import upload_pdf_cli
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced, TagmeConfig, types
from crowd_sdk.tagme.cli.bad_control import bad_control_delete_cli, bad_control_search_cli
from crowd_sdk.tagme.cli.clone_from_toloka import clone_from_toloka_cli
from crowd_sdk.tagme.cli.clone_pool import clone_pool_cli
from crowd_sdk.tagme.cli.clone_project import clone_project_cli
from crowd_sdk.tagme.cli.create_tests import qa_cli
from crowd_sdk.tagme.cli.download_task_data import download_dataset_data_cli, download_task_data_cli
from crowd_sdk.tagme.cli.download_task_datatable import download_task_datatable_cli
from crowd_sdk.tagme.cli.download_task_results import download_task_attachments_cli, download_task_results_cli
from crowd_sdk.tagme.cli.extend_task_results import extend_task_results_cli
from crowd_sdk.tagme.cli.find_projects import find_projects_by_predicate_cli
from crowd_sdk.tagme.cli.get_quality_stats import get_quality_stats_cli
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.cli.import_skills import export_skills_cli, import_skills_cli
from crowd_sdk.tagme.cli.pipeline import pipeline_serve_cli, pipeline_sync_cli
from crowd_sdk.tagme.cli.survey_summarizer import survey_summarizer_cli
from crowd_sdk.tagme.cli.upload_task_data import upload_dataset_data_cli, upload_task_data_cli

logger = logging.getLogger(__name__)


def _mcp_transport_options(fn: click.decorators.FC) -> click.decorators.FC:
    """Общие транспортные опции для всех MCP субкоманд."""
    fn = click.option(
        '--transport',
        type=click.Choice(['stdio', 'sse', 'streamable-http']),
        default='stdio',
        show_default=True,
        help='MCP transport to serve.',
    )(fn)
    fn = click.option('--host', default='127.0.0.1', show_default=True, help='HTTP host for network transports.')(fn)
    fn = click.option('--port', default=8000, show_default=True, type=int, help='HTTP port for network transports.')(fn)
    fn = click.option(
        '--path', 'streamable_http_path', default='/mcp', show_default=True, help='Streamable HTTP endpoint path.'
    )(fn)
    fn = click.option(
        '--stateless-http/--stateful-http', default=False, show_default=True, help='Disable HTTP session state.'
    )(fn)
    fn = click.option(
        '--require-auth/--no-require-auth',
        default=None,
        help='Require Bearer token auth. Defaults to enabled for network transports and disabled for stdio.',
    )(fn)
    fn = click.option(
        '--auth-issuer-url',
        default=None,
        help='Issuer/resource URL advertised by MCP auth metadata. Defaults to http://localhost:<port>.',
    )(fn)
    fn = click.option(
        '--extra-module',
        multiple=True,
        help=(
            'Trusted Python module from PYTHONPATH that defines register_mcp_tools(mcp). '
            'Can be repeated. CROWD_SDK_MCP_EXTRA_MODULES is also supported.'
        ),
    )(fn)
    fn = click.option(
        '--enable-human-mcp', is_flag=True, default=False, help='Enable Human MCP tools (project/task lifecycle).'
    )(fn)
    fn = click.option(
        '--base-toolset',
        type=click.Choice(['full', 'minimal']),
        default=None,
        help=(
            'Non-human base tools: full (default) or minimal (health/platform only). '
            'Overrides CROWD_SDK_MCP_BASE_TOOLSET.'
        ),  # noqa: E501
    )(fn)
    return fn


def _run_mcp(  # pylint: disable=too-many-arguments
    transport: Any,
    host: Any,
    port: Any,
    streamable_http_path: Any,
    stateless_http: Any,
    require_auth: Any,
    auth_issuer_url: Any,
    extra_module: Any,
    enable_human_mcp: Any,
    base_toolset: Any,
    enable_dataset_builder: bool = False,
) -> None:
    try:
        from crowd_sdk.mcp.server import run as run_mcp_server  # pylint: disable=import-outside-toplevel
    except ModuleNotFoundError as exp:
        if exp.name == 'mcp':
            raise click.ClickException('MCP dependencies are not installed. Install crowd_sdk[mcp].') from exp
        raise
    try:
        run_mcp_server(
            transport=transport,
            host=host,
            port=port,
            streamable_http_path=streamable_http_path,
            stateless_http=stateless_http,
            require_auth=require_auth,
            auth_issuer_url=auth_issuer_url,
            extra_modules=list(extra_module),
            enable_human_mcp=enable_human_mcp,
            base_toolset=base_toolset,
            enable_dataset_builder=enable_dataset_builder,
        )
    except ValueError as exp:
        raise click.ClickException(str(exp)) from exp


@tagme_commands.group(name='mcp', invoke_without_command=True)
@_mcp_transport_options
@click.pass_context
def mcp_cli(ctx: click.Context, **kwargs: Any) -> None:
    """Run MCP server (statistic + optional human MCP tools)."""
    if ctx.invoked_subcommand is None:
        _run_mcp(**kwargs)


@mcp_cli.command(name='dataset')
@_mcp_transport_options
def mcp_dataset_cli(**kwargs: Any) -> None:
    """Run MCP server for dataset builder (+ optional human MCP tools)."""
    # dataset сервер не включает statistic по умолчанию
    if kwargs.get('base_toolset') is None:
        kwargs['base_toolset'] = 'minimal'
    _run_mcp(enable_dataset_builder=True, **kwargs)


@tagme_commands.command(name='projects_list')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-a', '--archived/--visible', type=bool, help='Show list archived/visible projects', default=False)
def projects_list_cli(config_path: str, archived: bool) -> None:
    """
    Download dataset from task to specified directory
    """
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()
    projects: List[types.Project] = get_event_loop().run_until_complete(
        TagmeClientAdvanced(config=config_path).get_projects()
    )
    empty = True
    for project in projects:
        if project.is_archived ^ archived:
            continue
        empty = False
        logger.info(f'[archived={project.is_archived}] [uid={project.uid}] [name={project.name}]  {project.pools}')
    if empty:
        logger.info('Project list is empty')


tagme_commangs_collection = click.CommandCollection(
    sources=[
        clone_from_toloka_cli,
        clone_pool_cli,
        clone_project_cli,
        download_task_data_cli,
        download_task_results_cli,
        upload_task_data_cli,
        upload_dataset_data_cli,
        extend_task_results_cli,
        projects_list_cli,
        get_quality_stats_cli,
        pipeline_sync_cli,
        pipeline_serve_cli,
        import_skills_cli,
        upload_pdf_cli,
        bad_control_search_cli,
        bad_control_delete_cli,
        download_task_datatable_cli,
        download_dataset_data_cli,
        export_skills_cli,
        download_task_attachments_cli,
        survey_summarizer_cli,
        qa_cli,
        find_projects_by_predicate_cli,
    ]
)


def main() -> None:
    logging.basicConfig(
        format='%(message)s',
        level=logging.INFO,
    )
    tagme_commands()


if __name__ == '__main__':
    main()
