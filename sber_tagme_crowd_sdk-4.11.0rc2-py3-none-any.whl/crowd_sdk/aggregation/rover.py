import os
import re
from dataclasses import dataclass
from enum import Enum
from typing import Callable, List, Optional

import pandas as pd
from crowdkit.aggregation import ROVER as CrowdKitROVER  # pylint: disable=import-error
from nltk.stem.snowball import SnowballStemmer  # pylint: disable=import-error
from sacremoses import MosesDetokenizer, MosesTokenizer  # pylint: disable=import-error

from crowd_sdk.aggregation.tuned_rover import TunedROVER


class RoverType(Enum):
    DEFAULT = "DEFAULT"
    TUNED = "TUNED"


class NormalizerType(Enum):
    SnowBall = "SnowBall"


@dataclass
class RoverEntryDataclass:
    task: str
    worker: str
    text: str
    cer: Optional[float] = None


@dataclass
class RoverAggDataclass:
    task: str
    rover_text: str
    is_correct: bool = True


def moses_tokenizer(x: str, lang: str = 'ru') -> List[str]:
    # process UZ markup
    if lang in ['uz', 'uznew']:
        replace_pairs = [("'", "APOSTOKEN")]
        for pair in replace_pairs:
            x = x.replace(pair[0], pair[1])
        lang = 'en'

    # process KZ markup
    if lang in ['kz', 'kznew']:
        lang = 'en'

    tokens = MosesTokenizer(lang=lang).tokenize(x)
    return tokens


def moses_detokenizer(x: str, lang: str = 'ru') -> List[str]:
    moses_lang = lang
    if lang in ['uz', 'uznew']:
        moses_lang = 'en'
    if lang in ['kz', 'kznew']:
        moses_lang = 'en'

    phrase = MosesDetokenizer(lang=moses_lang).detokenize(x)

    if lang in ['uz', 'uznew']:
        replace_pairs = [("'", "APOSTOKEN")]
        for pair in replace_pairs:
            phrase = phrase.replace(pair[1], pair[0])

    return phrase


def create_snowball_normalizer(
    language: str = "russian", remove_negative_prefix: bool = True, normalizer_type: str = NormalizerType.SnowBall.value
) -> Callable[[str], str]:
    if normalizer_type == NormalizerType.SnowBall.value:
        normalizer = SnowballStemmer(language=language)

        def normalize(text: str) -> str:
            res = normalizer.stem(text)
            if remove_negative_prefix:
                prefix_mapping = {'ни': 'не'}
                _re_prefix = re.compile(r"^(не|ни)")

                # search from word beginning
                pos = 0
                match = _re_prefix.search(res, pos)

                if match and res != match.group(0):
                    res = res[match.end() :]
                elif match and res == match.group(0) and res in prefix_mapping:
                    res = prefix_mapping[res]

            return res

        return normalize
    else:
        raise ValueError(f"Strange normalizer_type = '{normalizer_type}'")


class ROVER:
    def __init__(
        self,
        tokenizer_func: Optional[Callable] = None,
        detokenizer_func: Optional[Callable] = None,
        rover_type: str = RoverType.DEFAULT.value,
        language: str = "ru",
    ) -> None:
        self.tokenizer_func = tokenizer_func or moses_tokenizer
        self.detokenizer_func = detokenizer_func or moses_detokenizer
        self.rover_type = rover_type
        if rover_type == RoverType.DEFAULT.value:
            rover = CrowdKitROVER
            self.rover_model = rover(tokenizer=self.tokenizer_func, detokenizer=self.detokenizer_func)
        elif rover_type == RoverType.TUNED.value:
            rover = TunedROVER
            self.rover_model = rover(
                tokenizer=self.tokenizer_func, detokenizer=self.detokenizer_func, language=language
            )
        else:
            raise ValueError(f"Strange rover_type: {rover_type}")

        self.columns = ['task', 'worker', 'text', 'cer']

    def predict_transcription(
        self,
        data: List[RoverEntryDataclass],
        cl_ref_path: Optional[os.PathLike] = None,
        normalizer: Optional[Callable] = None,
    ) -> List[RoverAggDataclass]:
        df = pd.DataFrame(data, columns=self.columns).fillna('')

        if self.rover_type == RoverType.DEFAULT.value:
            rover_agg_result = self.rover_model.fit_predict(data=df)
            rover_badagg_result = None
        elif self.rover_type == RoverType.TUNED.value:
            (
                rover_agg_result,
                rover_badagg_result,
            ) = self.rover_model.fit_predict(  # pylint: disable=unexpected-keyword-arg
                data=df, cluster_reference_path=cl_ref_path, normalizer=normalizer
            )
        else:
            raise ValueError(f"Strange rover_type: {self.rover_type}")

        aggreration_res = []
        for task, rover_text in zip(rover_agg_result.index, rover_agg_result):
            rad = RoverAggDataclass(task=task, rover_text=rover_text)
            aggreration_res.append(rad)
        if self.rover_type == RoverType.TUNED.value and (not rover_badagg_result is None):
            for task, rover_text in zip(rover_badagg_result.index, rover_badagg_result):
                rad = RoverAggDataclass(task=task, rover_text=rover_text, is_correct=False)
                aggreration_res.append(rad)

        return aggreration_res
