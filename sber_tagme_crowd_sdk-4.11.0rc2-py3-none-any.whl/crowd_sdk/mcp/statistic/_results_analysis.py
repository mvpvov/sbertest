import json
import math
from collections import Counter, defaultdict
from dataclasses import asdict, is_dataclass
from typing import Any, DefaultDict, Dict, FrozenSet, Iterable, List, Optional, Sequence, Set, Tuple

DEFAULT_ANALYSES = (
    'inspect',
    'class_distribution',
    'agreement_summary',
    'marker_answer_summary',
)

# Синонимы для `analyses` (удобные для LLM/людей) → канонические имена блоков из DEFAULT_ANALYSES.
ANALYSIS_NAME_ALIASES: Dict[str, Tuple[str, ...]] = {
    'agreement': ('agreement_summary',),
    'consistency': ('agreement_summary',),
    'iaa': ('agreement_summary',),
    'inter_annotator_agreement': ('agreement_summary',),
    'quality': ('marker_answer_summary',),
    'time': ('marker_answer_summary',),
    'timing': ('marker_answer_summary',),
    'workload': ('marker_answer_summary',),
    'volume': ('marker_answer_summary',),
    'throughput': ('marker_answer_summary',),
    'accuracy': ('compare_with_control',),
    'control': ('compare_with_control',),
    'golden': ('compare_with_control',),
    'vs_control': ('compare_with_control',),
    'control_check': ('compare_with_control',),
    'distribution': ('class_distribution',),
    'labels': ('class_distribution',),
    'classes': ('class_distribution',),
    'examples': ('sample_results',),
    'samples': ('sample_results',),
    'preview': ('sample_results',),
    'structure': ('inspect',),
    'fields_overview': ('inspect',),
    'generation': ('generation_summary',),
    'lengths': ('generation_summary',),
}

_ALLOWED_ANALYSIS_NAMES: FrozenSet[str] = frozenset(DEFAULT_ANALYSES)


def canonicalize_analyses(analyses: Optional[Sequence[str]]) -> Tuple[str, ...]:
    """Преобразует имена блоков (и распространённые синонимы) в канонические из ``DEFAULT_ANALYSES``.

    ``None`` и пустая последовательность означают полный набор по умолчанию.
    """
    if not analyses:
        return DEFAULT_ANALYSES
    out: List[str] = []
    seen: Set[str] = set()
    unknown: List[str] = []
    for raw in analyses:
        key = str(raw).strip().lower().replace('-', '_')
        if key in _ALLOWED_ANALYSIS_NAMES:
            if key not in seen:
                seen.add(key)
                out.append(key)
            continue
        if key in ANALYSIS_NAME_ALIASES:
            for canon in ANALYSIS_NAME_ALIASES[key]:
                if canon not in seen:
                    seen.add(canon)
                    out.append(canon)
            continue
        unknown.append(str(raw))
    if unknown:
        raise ValueError(
            f'Unsupported analyses: {sorted(set(unknown))}. Use one of: {sorted(_ALLOWED_ANALYSIS_NAMES)}. '
            'Частые синонимы: consistency→agreement_summary; quality/time/workload→marker_answer_summary; '
            'control/golden→compare_with_control; examples→sample_results; labels→class_distribution.'
        )
    return tuple(out)


MISSING_VALUE = '__missing__'
EMPTY_VALUE = '__empty__'
LIST_VALUE_SUFFIX = '[]'


def _mean(values: Iterable[Optional[float]]) -> Optional[float]:
    clean_values = [value for value in values if value is not None]
    if not clean_values:
        return None
    return round(sum(clean_values) / len(clean_values), 4)


def _linear_percentile(values: List[float], p: float) -> Optional[float]:
    """Linear interpolation, p in [0, 100]."""
    if not values or p < 0 or p > 100:
        return None
    xs = sorted(values)
    n = len(xs)
    if n == 1:
        return xs[0]
    rank = (n - 1) * (p / 100.0)
    lo = int(math.floor(rank))
    hi = int(math.ceil(rank))
    if lo == hi:
        return xs[lo]
    return xs[lo] + (xs[hi] - xs[lo]) * (rank - lo)


def _time_spent_percentiles(raw_values: List[Any]) -> Tuple[Optional[float], Optional[float]]:
    nums: List[float] = []
    for value in raw_values:
        if value is None:
            continue
        try:
            nums.append(float(value))
        except (TypeError, ValueError):
            continue
    if not nums:
        return None, None
    p50 = _linear_percentile(nums, 50)
    p90 = _linear_percentile(nums, 90)
    return (
        round(p50, 4) if p50 is not None else None,
        round(p90, 4) if p90 is not None else None,
    )


def _percent(numerator: int, denominator: int) -> Optional[float]:
    if denominator <= 0:
        return None
    return round(numerator / denominator * 100, 2)


def _to_plain_dict(value: Any) -> Dict[str, Any]:
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, dict):
        return value
    return dict(value)


def _normalize_value(value: Any) -> str:
    if value is None:
        return EMPTY_VALUE
    if isinstance(value, str):
        return value if value else EMPTY_VALUE
    if isinstance(value, (int, float, bool)):
        return str(value)
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _is_scalar(value: Any) -> bool:
    return value is None or isinstance(value, (str, int, float, bool))


def _walk_result_leaves(value: Any, prefix: str = '') -> Iterable[Tuple[str, Any]]:
    if isinstance(value, dict):
        for key, item in value.items():
            next_prefix = f'{prefix}.{key}' if prefix else str(key)
            yield from _walk_result_leaves(item, next_prefix)
        return

    if isinstance(value, list):
        list_prefix = f'{prefix}{LIST_VALUE_SUFFIX}' if prefix else LIST_VALUE_SUFFIX
        if not value:
            yield list_prefix, EMPTY_VALUE
            return
        for item in value:
            if _is_scalar(item):
                yield list_prefix, item
            else:
                yield from _walk_result_leaves(item, list_prefix)
        return

    if prefix:
        yield prefix, value


def _extract_result_fields(result: Any) -> Dict[str, List[str]]:
    if not isinstance(result, dict):
        return {}

    fields: DefaultDict[str, List[str]] = defaultdict(list)
    for field, value in _walk_result_leaves(result):
        fields[field].append(_normalize_value(value))
    return dict(fields)


def _limited_counter(counter: Counter, total: int, top_n: int) -> Dict[str, Any]:
    top_values = [
        {'value': value, 'count': count, 'percent': _percent(count, total)}
        for value, count in counter.most_common(top_n)
    ]
    return {
        'total': total,
        'unique_values': len(counter),
        'top_values': top_values,
    }


SUMMARY_ONLY_TOP_CAP = 8


def _effective_top_n(top_n: int, summary_only: bool) -> int:
    return min(top_n, SUMMARY_ONLY_TOP_CAP) if summary_only else top_n


def _effective_sample_limit(sample_limit: int, summary_only: bool) -> int:
    return 0 if summary_only else sample_limit


def _truncate_result_payload(value: Any, max_chars: Optional[int]) -> Any:
    if max_chars is None or max_chars <= 0 or value is None:
        return value
    try:
        serialized = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    except (TypeError, ValueError):
        serialized = str(value)
    if len(serialized) <= max_chars:
        return value
    return {
        '_truncated_preview': True,
        'text': serialized[:max_chars] + '…',
        'original_chars': len(serialized),
        'limit': max_chars,
    }


def _assignment_sample(row: Dict[str, Any], max_result_preview_chars: Optional[int] = None) -> Dict[str, Any]:
    sample = {
        key: row.get(key)
        for key in (
            'assignment_id',
            'item_id',
            'marker_id',
            'status',
            'item_type',
            'quality',
            'consistency',
            'time_spent',
            'result',
            'control',
        )
        if row.get(key) is not None
    }
    if max_result_preview_chars and max_result_preview_chars > 0:
        if 'result' in sample:
            sample['result'] = _truncate_result_payload(sample['result'], max_result_preview_chars)
        if 'control' in sample:
            sample['control'] = _truncate_result_payload(sample['control'], max_result_preview_chars)
    return sample


def _build_inspection(
    assignments: List[Dict[str, Any]],
    result_fields_by_row: List[Dict[str, List[str]]],
    sample_limit: int,
    max_result_preview_chars: Optional[int] = None,
) -> Dict[str, Any]:
    output_fields = sorted({field for row_fields in result_fields_by_row for field in row_fields})
    result_samples: List[Dict[str, Any]] = []
    if sample_limit > 0:
        for row in assignments:
            if row.get('result') is not None:
                result_samples.append(_assignment_sample(row, max_result_preview_chars))
            if len(result_samples) >= sample_limit:
                break

    return {
        'assignments_count': len(assignments),
        'items_count': len({row.get('item_id') for row in assignments if row.get('item_id') is not None}),
        'markers_count': len({row.get('marker_id') for row in assignments if row.get('marker_id') is not None}),
        'output_fields': output_fields,
        'result_rows_count': sum(1 for row in assignments if isinstance(row.get('result'), dict)),
        'sample': result_samples,
    }


def _build_class_distribution(
    assignments: List[Dict[str, Any]],
    result_fields_by_row: List[Dict[str, List[str]]],
    output_fields: Optional[Sequence[str]],
    top_n: int,
) -> Dict[str, Any]:
    selected_fields = sorted(output_fields or {field for row_fields in result_fields_by_row for field in row_fields})
    counters: Dict[str, Counter] = {field: Counter() for field in selected_fields}
    present_rows: Counter = Counter()
    rows_with_result = sum(1 for row in assignments if isinstance(row.get('result'), dict))

    for row_fields in result_fields_by_row:
        for field in selected_fields:
            values = row_fields.get(field)
            if not values:
                continue
            present_rows[field] += 1
            counters[field].update(values)

    fields = {}
    for field in selected_fields:
        total = sum(counters[field].values())
        fields[field] = {
            **_limited_counter(counters[field], total, top_n),
            'assignments_with_field': present_rows[field],
            'missing_assignments': max(rows_with_result - present_rows[field], 0),
        }

    return {
        'rows_with_result': rows_with_result,
        'fields': fields,
    }


def _build_agreement_summary(
    assignments: List[Dict[str, Any]],
    result_fields_by_row: List[Dict[str, List[str]]],
    output_fields: Optional[Sequence[str]],
    min_overlap: int,
    sample_limit: int,
) -> Dict[str, Any]:
    selected_fields = sorted(output_fields or {field for row_fields in result_fields_by_row for field in row_fields})
    grouped: DefaultDict[Tuple[str, str], Counter] = defaultdict(Counter)

    for row, row_fields in zip(assignments, result_fields_by_row):
        item_id = row.get('item_id')
        if item_id is None:
            continue
        for field in selected_fields:
            values = row_fields.get(field)
            if values:
                grouped[(str(item_id), field)].update(values)

    fields: Dict[str, Dict[str, Any]] = {}
    disagreement_samples: List[Dict[str, Any]] = []
    for field in selected_fields:
        eligible_count = 0
        full_agreement = 0
        ties = 0
        majority_rates = []

        for (item_id, item_field), counter in grouped.items():
            if item_field != field:
                continue
            total = sum(counter.values())
            if total < min_overlap:
                continue
            eligible_count += 1
            most_common = counter.most_common()
            majority_count = most_common[0][1]
            majority_rates.append(majority_count / total)
            if majority_count == total:
                full_agreement += 1
            if len(most_common) > 1 and most_common[0][1] == most_common[1][1]:
                ties += 1
            if majority_count < total and len(disagreement_samples) < sample_limit:
                disagreement_samples.append(
                    {
                        'item_id': item_id,
                        'field': field,
                        'total_answers': total,
                        'values': dict(counter.most_common()),
                    }
                )

        fields[field] = {
            'items_with_overlap': eligible_count,
            'full_agreement_items': full_agreement,
            'disagreement_items': eligible_count - full_agreement,
            'tie_items': ties,
            'average_majority_rate': round(sum(majority_rates) / len(majority_rates), 4) if majority_rates else None,
        }

    return {
        'min_overlap': min_overlap,
        'fields': fields,
        'disagreement_sample': disagreement_samples,
    }


def _build_generation_summary(assignments: List[Dict[str, Any]], top_n: int, sample_limit: int) -> Dict[str, Any]:
    field_lengths: DefaultDict[str, List[int]] = defaultdict(list)
    empty_counts: Counter = Counter()
    value_counts: DefaultDict[str, Counter] = defaultdict(Counter)
    invalid_json_like_samples: List[Dict[str, Any]] = []

    for row in assignments:
        result = row.get('result')
        if not isinstance(result, dict):
            continue
        for field, values in _extract_result_fields(result).items():
            for value in values:
                if value == EMPTY_VALUE:
                    empty_counts[field] += 1
                field_lengths[field].append(len(value))
                value_counts[field][value] += 1
                if value and value[0] in '[{' and len(invalid_json_like_samples) < sample_limit:
                    try:
                        json.loads(value)
                    except (TypeError, ValueError):
                        invalid_json_like_samples.append(
                            {
                                'assignment_id': row.get('assignment_id'),
                                'item_id': row.get('item_id'),
                                'field': field,
                                'value_preview': value[:200],
                            }
                        )

    fields = {}
    for field, lengths in field_lengths.items():
        repeated_values = [
            {'value': value, 'count': count} for value, count in value_counts[field].most_common(top_n) if count > 1
        ]
        fields[field] = {
            'values_count': len(lengths),
            'empty_count': empty_counts[field],
            'avg_length': round(sum(lengths) / len(lengths), 2) if lengths else None,
            'min_length': min(lengths) if lengths else None,
            'max_length': max(lengths) if lengths else None,
            'top_repeated_values': repeated_values[:top_n],
        }

    return {
        'fields': fields,
        'invalid_json_like_sample': invalid_json_like_samples,
    }


def _build_marker_answer_summary(  # pylint: disable=R0913
    assignments: List[Dict[str, Any]],
    result_fields_by_row: List[Dict[str, List[str]]],
    output_fields: Optional[Sequence[str]],
    top_n: int,
    marker_profiles: Optional[Dict[str, Dict[str, Any]]] = None,
    summary_only: bool = False,
) -> Dict[str, Any]:
    selected_fields = sorted(output_fields or {field for row_fields in result_fields_by_row for field in row_fields})
    markers: Dict[str, Dict[str, Any]] = {}

    for row, row_fields in zip(assignments, result_fields_by_row):
        marker_id = str(row.get('marker_id') or MISSING_VALUE)
        marker = markers.setdefault(
            marker_id,
            {
                'marker_id': marker_id,
                'person_id': None,
                'email': None,
                'assignments_count': 0,
                'status_counts': Counter(),
                'quality_values': [],
                'consistency_values': [],
                'time_spent_values': [],
                'class_counts': {field: Counter() for field in selected_fields},
            },
        )
        person_id = row.get('person_id')
        if person_id is not None:
            marker['person_id'] = str(person_id)
        row_email = row.get('email')
        if row_email:
            marker['email'] = str(row_email)
        marker['assignments_count'] += 1
        marker['status_counts'][row.get('status') or MISSING_VALUE] += 1
        marker['quality_values'].append(row.get('quality'))
        marker['consistency_values'].append(row.get('consistency'))
        marker['time_spent_values'].append(row.get('time_spent'))
        for field in selected_fields:
            values = row_fields.get(field)
            if values:
                marker['class_counts'][field].update(values)

    profiles = marker_profiles or {}
    items = []
    for marker in markers.values():
        class_counts: Dict[str, Any] = {}
        if not summary_only:
            class_counts = {
                field: _limited_counter(counter, sum(counter.values()), top_n)
                for field, counter in marker['class_counts'].items()
                if counter
            }
        p50, p90 = _time_spent_percentiles(marker['time_spent_values'])
        mid = marker['marker_id']
        prof = profiles.get(mid, {})
        display_name = prof.get('display_name')
        if not display_name:
            display_name = prof.get('fio') or prof.get('email') or marker.get('email') or marker.get('person_id') or mid
        item_out: Dict[str, Any] = {
            'marker_id': mid,
            'display_name': display_name,
            'assignments_count': marker['assignments_count'],
            'status_counts': dict(marker['status_counts']),
            'average_quality': _mean(marker['quality_values']),
            'average_consistency': _mean(marker['consistency_values']),
            'average_time_spent': _mean(marker['time_spent_values']),
            'time_spent_p50': p50,
            'time_spent_p90': p90,
            'class_counts': class_counts,
        }
        person_id = marker.get('person_id')
        if person_id is not None:
            item_out['person_id'] = person_id
        email = prof.get('email') or marker.get('email')
        if email:
            item_out['email'] = email
        fio = prof.get('fio')
        if fio:
            item_out['fio'] = fio
        items.append(item_out)

    items.sort(key=lambda item: item['assignments_count'], reverse=True)
    return {
        'markers_count': len(items),
        'items': items[:top_n],
    }


def _build_sample_results(
    assignments: List[Dict[str, Any]],
    sample_limit: int,
    max_result_preview_chars: Optional[int] = None,
) -> Dict[str, Any]:
    if sample_limit <= 0:
        return {'returned': 0, 'items': []}
    return {
        'returned': min(len(assignments), sample_limit),
        'items': [_assignment_sample(row, max_result_preview_chars) for row in assignments[:sample_limit]],
    }


def _build_compare_with_control(
    assignments: List[Dict[str, Any]],
    result_fields_by_row: List[Dict[str, List[str]]],
    output_fields: Optional[Sequence[str]],
    top_n: int,
) -> Dict[str, Any]:
    selected_fields = sorted(output_fields or {field for row_fields in result_fields_by_row for field in row_fields})
    field_stats: Dict[str, Dict[str, Any]] = {}

    for field in selected_fields:
        total = 0
        matched = 0
        missing_control = 0
        confusion: Counter = Counter()
        for row, row_fields in zip(assignments, result_fields_by_row):
            control = row.get('control')
            if not isinstance(control, dict):
                missing_control += 1
                continue
            result_values = row_fields.get(field)
            control_values = _extract_result_fields(control).get(field)
            if not result_values:
                continue
            if not control_values:
                missing_control += 1
                continue
            result_value = result_values[0]
            control_value = control_values[0]
            total += 1
            matched += int(result_value == control_value)
            confusion[(control_value, result_value)] += 1

        field_stats[field] = {
            'compared_count': total,
            'matched_count': matched,
            'accuracy_percent': _percent(matched, total),
            'missing_control_count': missing_control,
            'top_confusions': [
                {'control': control, 'result': result, 'count': count}
                for (control, result), count in confusion.most_common(top_n)
            ],
        }

    return {
        'fields': field_stats,
    }


def build_task_results_analysis(  # pylint: disable=R0913
    assignments: Sequence[Any],
    analyses: Optional[Sequence[str]] = None,
    output_fields: Optional[Sequence[str]] = None,
    top_n: int = 10,
    sample_limit: int = 3,
    min_overlap: int = 2,
    marker_profiles: Optional[Dict[str, Dict[str, Any]]] = None,
    summary_only: bool = False,
    max_result_preview_chars: Optional[int] = None,
) -> Dict[str, Any]:
    selected_analyses = canonicalize_analyses(analyses)
    if top_n <= 0:
        raise ValueError('top_n must be greater than 0')
    if sample_limit < 0:
        raise ValueError('sample_limit must be non-negative')
    if min_overlap <= 0:
        raise ValueError('min_overlap must be greater than 0')

    eff_top_n = _effective_top_n(top_n, summary_only)
    eff_sample_limit = _effective_sample_limit(sample_limit, summary_only)

    rows = [_to_plain_dict(assignment) for assignment in assignments]
    result_fields_by_row = [_extract_result_fields(row.get('result')) for row in rows]
    status_distribution = Counter(row.get('status') or MISSING_VALUE for row in rows)
    item_type_distribution = Counter(row.get('item_type') or MISSING_VALUE for row in rows)

    result: Dict[str, Any] = {
        'backend': 'sdk_assignments',
        'assignments_count': len(rows),
        'items_count': len({row.get('item_id') for row in rows if row.get('item_id') is not None}),
        'markers_count': len({row.get('marker_id') for row in rows if row.get('marker_id') is not None}),
        'status_distribution': dict(status_distribution),
        'item_type_distribution': dict(item_type_distribution),
        'analyses': list(selected_analyses),
        'analysis_options': {
            'summary_only': summary_only,
            'max_result_preview_chars': max_result_preview_chars,
            'effective_top_n': eff_top_n,
            'effective_sample_limit': eff_sample_limit,
        },
    }

    if 'inspect' in selected_analyses:
        result['inspection'] = _build_inspection(
            rows,
            result_fields_by_row,
            eff_sample_limit,
            max_result_preview_chars,
        )
    if 'class_distribution' in selected_analyses:
        result['class_distribution'] = _build_class_distribution(rows, result_fields_by_row, output_fields, eff_top_n)
    if 'agreement_summary' in selected_analyses:
        result['agreement_summary'] = _build_agreement_summary(
            rows,
            result_fields_by_row,
            output_fields,
            min_overlap,
            eff_sample_limit,
        )
    if 'generation_summary' in selected_analyses:
        result['generation_summary'] = _build_generation_summary(
            rows,
            eff_top_n,
            eff_sample_limit,
        )
    if 'marker_answer_summary' in selected_analyses:
        result['marker_answer_summary'] = _build_marker_answer_summary(
            rows,
            result_fields_by_row,
            output_fields,
            eff_top_n,
            marker_profiles=marker_profiles,
            summary_only=summary_only,
        )
    if 'sample_results' in selected_analyses:
        result['sample_results'] = _build_sample_results(
            rows,
            eff_sample_limit,
            max_result_preview_chars,
        )
    if 'compare_with_control' in selected_analyses:
        result['compare_with_control'] = _build_compare_with_control(
            rows,
            result_fields_by_row,
            output_fields,
            eff_top_n,
        )

    return result
