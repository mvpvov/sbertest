"""Small helpers for interpreting project TASKS export rows (no MCP runtime deps)."""

from typing import Dict, Sequence, Tuple

from crowd_sdk.tagme.http_client.datacls import TasksStatistic


def assignment_estimate_by_tasks_from_export(
    task_rows: Sequence[TasksStatistic],
    task_uids: Sequence[str],
) -> Tuple[int, Dict[str, int]]:
    """Sum count_assignments per task over export rows (coarse; used for project analysis guard)."""
    wanted = set(task_uids)
    per_task: Dict[str, int] = {uid: 0 for uid in task_uids}
    for row in task_rows:
        tid = row.task_id
        if tid in wanted:
            per_task[tid] = per_task.get(tid, 0) + int(row.count_assignments or 0)
    return sum(per_task.values()), per_task
