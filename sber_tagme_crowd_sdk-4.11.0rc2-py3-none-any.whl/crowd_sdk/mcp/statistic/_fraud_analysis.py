# pylint: disable=line-too-long
"""
Heuristic fraud-risk signals over Tagme task assignments (not legal proof).

Uses per-assignment fields where available. ``quality``, ``consistency``, and **mean positive**
duration per marker use the same pattern: with enough markers, outliers are far from the peer
distribution of marker-level means (median − k·pstdev); with 2–3 markers a ratio/median fallback applies.
Duration is **positive** ``time_spent`` when present, otherwise ``end_date - start_date`` when both are
available. For time, **low** mean seconds = suspiciously fast vs peers.
"""

import json
import math
import statistics
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, fields
from datetime import datetime
from typing import Any, DefaultDict, Dict, List, Literal, Optional, Sequence, Set

from crowd_sdk.core.utils.common import DATE_TIME_UTC_FORMATS, parse_date
from crowd_sdk.mcp.statistic._results_analysis import MISSING_VALUE, _linear_percentile, _to_plain_dict


def _coerce_datetime_for_duration(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            return parse_date(value, datetime_formats=DATE_TIME_UTC_FORMATS)
        except ValueError:
            try:
                return datetime.fromisoformat(value.replace('Z', '+00:00'))
            except ValueError:
                return None
    return None


def _assignment_duration_seconds_positive(row: Dict[str, Any]) -> Optional[float]:
    """Для эвристик по времени: явный положительный ``time_spent`` или разница конец−начало по датам.

    Даты: ``start_date``/``end_date`` (как в ``Assignment``), иначе ``pick_date``/``submit_date`` (как в экспорте API).
    """
    raw = row.get('time_spent')
    if raw is not None:
        try:
            v = float(raw)
            if v > 0:
                return v
        except (TypeError, ValueError):
            pass

    def _pair() -> tuple:  # pylint: disable=E1136
        s, e = row.get('start_date'), row.get('end_date')
        if s is not None or e is not None:
            return s, e
        return row.get('pick_date'), row.get('submit_date')

    start_raw, end_raw = _pair()
    start = _coerce_datetime_for_duration(start_raw)
    end = _coerce_datetime_for_duration(end_raw)
    if start is None or end is None:
        return None
    try:
        sec = (end - start).total_seconds()
    except (TypeError, ValueError, OverflowError):
        return None
    if sec <= 0:
        return None
    return float(sec)


RISK_FACTOR_IDS = (
    'low_quality',
    'low_consistency',
    'fast_completion',
    'duplicate_result_fingerprint',
    'marker_high_rejection_ratio',
    'marker_high_expired_ratio',
    'marker_high_skip_ratio',
)

RISK_FACTOR_META: Dict[str, Dict[str, str]] = {
    'low_quality': {
        'title': 'Низкое качество (поле quality), маркер против пира',
        'hint': 'По среднему quality маркера: при ≥4 маркерах с метрикой — сильное отставание от пира '
        '(ниже медианы средних по σ·pstdev этих средних; σ задаётся quality_peer_outlier_sigmas). '
        'При 2–3 маркерах — мягкий fallback (медиана×quality_below_median_factor). '
        'Порог quality_below — абсолютное сравнение среднего маркера.',
    },
    'low_consistency': {
        'title': 'Низкая согласованность (поле consistency), маркер против пира',
        'hint': 'По среднему consistency маркера: при ≥4 маркерах с метрикой — сильное отставание '
        '(ниже медианы средних по σ·pstdev; σ = consistency_peer_outlier_sigmas). '
        'При 2–3 маркерах — fallback (медиана×consistency_below_median_factor). '
        'Порог consistency_below — абсолютно для среднего маркера.',
    },
    'fast_completion': {
        'title': 'Подозрительно быстрое выполнение (time_spent)',
        'hint': 'По **средней** длительности на назначение у маркера (сек): из поля time_spent или, если его нет, '
        'из ``end_date - start_date``. При ≥4 маркерах — сильно быстрее пира '
        '(среднее < медиана средних − σ·pstdev; σ = fast_time_peer_outlier_sigmas). '
        'Если из‑за «тяжёлого» правого хвоста средних по маркерам отсечка становится нефизичной, '
        'σ правило отключается и используется медиана×fast_time_vs_peer_median_ratio. '
        'При 2–3 маркерах — только этот ratio (или абсолютный порог). '
        'Заданный fast_time_absolute_seconds (>0) — порог для **среднего** маркера в секундах.',
    },
    'duplicate_result_fingerprint': {
        'title': 'Массово одинаковый результат',
        'hint': 'Много назначений с идентичным JSON результата: размер группы выше доли от объёма выборки.',
    },
    'marker_high_rejection_ratio': {
        'title': 'Высокая доля отклонённых у разметчика',
        'hint': 'REJECTED / все назначения маркера выше порога при достаточном объёме.',
    },
    'marker_high_expired_ratio': {
        'title': 'Высокая доля просрочек у разметчика',
        'hint': 'EXPIRED / все назначения маркера выше порога.',
    },
    'marker_high_skip_ratio': {
        'title': 'Высокая доля пропусков у разметчика',
        'hint': 'SKIPPED / все назначения маркера выше порога.',
    },
}


# Минимум маркеров со средней метрикой (quality / consistency / mean time) для правила median − k·pstdev.
MIN_MARKERS_FOR_METRIC_SIGMA = 4

# Минимум маркеров для fallback median×factor (2–3 маркера или нулевой pstdev).
MIN_MARKERS_FOR_PEER_MEDIAN_FALLBACK = 2

# Минимум значений на уровне назначений для диагностической медианы по пулу (consistency_assignments).
MIN_SAMPLES_FOR_POOL_MEDIAN = 3

# Минимум положительных time_spent для оценки перцентиля пула (как и раньше).
MIN_SAMPLES_FOR_TIME_POOL = 5


def _fast_time_sigma_cutoff_usable(cutoff: float, peer_median: float) -> bool:
    """Проверка σ-отсечки для «быстрее пира» (секунды).

    Несколько очень **медленных** маркеров раздувают pstdev по **средним** длительностям, медиана при этом
    остаётся около «типичных» — ``median − σ·pstdev`` становится ≤0 или не остаётся слева от медианы,
    и правило становится бессмысленным. Тогда отключаем σ и используем fallback по ``fast_time_vs_peer_median_ratio``.
    """
    if cutoff <= 0:
        return False
    return cutoff < peer_median


@dataclass
class FraudThresholds:
    """Пороги по умолчанию — относительные к объёму/распределению текущей выборки.

    Абсолютные пороги (`quality_below`, `consistency_below`, `fast_time_absolute_seconds`,
    `duplicate_result_min_group`, `marker_min_assignments_for_ratios`) можно задать вручную;
    если они ``None`` (дефолт), используются только относительные правила ниже.
    """

    # quality: среднее quality маркера по его назначениям.
    # По умолчанию (quality_below=None): при ≥ MIN_MARKERS_FOR_METRIC_SIGMA маркерах — outlier:
    #   mean_marker < median(peer means) - quality_peer_outlier_sigmas * pstdev(peer means).
    # При 2–3 маркерах — fallback: mean < median(peer)×quality_below_median_factor.
    # quality_below — абсолютный порог для среднего маркера.
    quality_below: Optional[float] = None
    quality_peer_outlier_sigmas: float = 1.0
    quality_below_median_factor: float = 0.60
    # Аналогично для consistency (среднее по назначениям маркера).
    consistency_below: Optional[float] = None
    consistency_peer_outlier_sigmas: float = 1.0
    consistency_below_median_factor: float = 0.60

    # time_spent (сек): только положительные значения; среднее по назначениям маркера.
    # «Быстро» = среднее время **ниже** порога относительно пира (аналогично quality, но метрика «меньше — хуже»).
    # fast_time_absolute_seconds — если задан, только сравнение среднего маркера с этим числом (сек).
    fast_time_peer_outlier_sigmas: float = 1.5
    fast_time_vs_peer_median_ratio: float = 0.45
    fast_time_absolute_seconds: Optional[float] = None

    # Дубликаты: если duplicate_result_min_group задан — фиксированный минимум размера группы;
    # иначе max(floor, ceil(fraction * len(назначений))).
    duplicate_result_min_group: Optional[int] = None
    duplicate_result_min_fraction: float = 0.02
    duplicate_result_min_group_floor: int = 4

    # Доли отклонений/просрочек/пропусков: только доли, без абсолютных чисел.
    # Минимальное число назначений маркера для учёта долей: если marker_min_assignments_for_ratios задан — он;
    # иначе max(floor, ceil(pool_fraction * среднее_назначений_на_маркера_в_отчёте)).
    marker_min_assignments_for_ratios: Optional[int] = None
    marker_min_assignments_floor: int = 6
    marker_min_assignments_pool_fraction: float = 0.12
    marker_rejected_ratio_above: float = 0.38
    marker_expired_ratio_above: float = 0.30
    marker_skipped_ratio_above: float = 0.45


def _fast_time_absolute_cap_enabled(thr: FraudThresholds) -> bool:
    """Только положительный порог включает ветку «среднее < N сек»; 0/отсутствие — относительные правила (σ/ratio)."""
    cap = thr.fast_time_absolute_seconds
    return cap is not None and cap > 0


def _peer_median_marker_means(marker_mean_by_id: Dict[str, float]) -> Optional[float]:
    vals = list(marker_mean_by_id.values())
    if len(vals) < MIN_MARKERS_FOR_PEER_MEDIAN_FALLBACK:
        return None
    return float(statistics.median(vals))


def _pool_median(values: List[float]) -> Optional[float]:
    if len(values) < MIN_SAMPLES_FOR_POOL_MEDIAN:
        return None
    return float(statistics.median(values))


def _effective_duplicate_min_group(thr: FraudThresholds, assignments_total: int) -> int:
    if thr.duplicate_result_min_group is not None:
        return int(thr.duplicate_result_min_group)
    frac_part = int(math.ceil(thr.duplicate_result_min_fraction * max(1, assignments_total)))
    return max(thr.duplicate_result_min_group_floor, frac_part)


def _effective_marker_min_assignments(thr: FraudThresholds, rows: List[Dict[str, Any]]) -> int:
    if thr.marker_min_assignments_for_ratios is not None:
        return int(thr.marker_min_assignments_for_ratios)
    marker_ids = {str(r.get('marker_id') or MISSING_VALUE) for r in rows}
    avg = len(rows) / max(1, len(marker_ids))
    from_pool = int(math.ceil(thr.marker_min_assignments_pool_fraction * avg))
    return max(thr.marker_min_assignments_floor, from_pool)


def update_fraud_thresholds_from_mapping(thr: FraudThresholds, data: Optional[Dict[str, Any]]) -> None:
    """Apply keys from a mapping (e.g. MCP JSON). Unknown keys are ignored."""
    if not data:
        return
    data = dict(data)
    if data.get('fast_time_vs_peer_median_ratio') is None and data.get('fast_time_vs_pool_p10_ratio') is not None:
        data['fast_time_vs_peer_median_ratio'] = data['fast_time_vs_pool_p10_ratio']

    valid = {f.name for f in fields(FraudThresholds)}
    for key, value in data.items():
        if key not in valid or value is None:
            continue
        setattr(thr, key, value)


def _result_fingerprint(result: Any) -> Optional[str]:
    if not isinstance(result, dict):
        return None
    try:
        return json.dumps(result, sort_keys=True, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        return None


def _pool_time_percentile(values: List[float], p: float) -> Optional[float]:
    if not values:
        return None
    return _linear_percentile(values, p)


def _marker_factor_summary_detail(  # pylint: disable=R0913,too-many-arguments
    mid: str,
    fid: str,
    assignments_flagged_for_factor: int,
    *,
    marker_mean_quality: Dict[str, float],
    quality_flag_meta: Dict[str, Dict[str, Any]],
    pool_med_quality: Optional[float],
    marker_mean_consistency: Dict[str, float],
    consistency_flag_meta: Dict[str, Dict[str, Any]],
    pool_med_consistency: Optional[float],
    marker_mean_time: Dict[str, float],
    fast_flag_meta: Dict[str, Dict[str, Any]],
    pool_med_time: Optional[float],
    marker_status: Dict[str, Counter],
    thr: FraudThresholds,
    pool_time_p10_assignment_level: Optional[float] = None,
) -> Dict[str, Any]:
    """Один фактор в сводке по маркеру: среднее маркера vs медиана по пулу маркеров (и порог), без акцента на числе назначений."""
    out: Dict[str, Any] = {
        'assignments_flagged': int(assignments_flagged_for_factor),
    }
    if fid == 'low_quality':
        if mid in marker_mean_quality:
            out['marker_mean'] = round(marker_mean_quality[mid], 6)
        out['pool_median_marker_averages'] = quality_flag_meta.get(mid, {}).get(
            'pool_median_marker_avg_quality', pool_med_quality
        )
        if mid in quality_flag_meta:
            meta = quality_flag_meta[mid]
            out['rule'] = meta.get('rule')
            if 'cutoff' in meta:
                out['cutoff'] = meta['cutoff']
            for k in ('peer_marker_means_pstdev', 'sigmas', 'median_factor'):
                if k in meta:
                    out[k] = meta[k]
        return out

    if fid == 'low_consistency':
        if mid in marker_mean_consistency:
            out['marker_mean'] = round(marker_mean_consistency[mid], 6)
        out['pool_median_marker_averages'] = consistency_flag_meta.get(mid, {}).get(
            'pool_median_marker_avg_consistency', pool_med_consistency
        )
        if mid in consistency_flag_meta:
            meta = consistency_flag_meta[mid]
            out['rule'] = meta.get('rule')
            if 'cutoff' in meta:
                out['cutoff'] = meta['cutoff']
            for k in ('peer_marker_means_consistency_pstdev', 'sigmas', 'median_factor'):
                if k in meta:
                    out[k] = meta[k]
        return out

    if fid == 'fast_completion':
        out['metric'] = 'mean_time_spent_seconds'
        if mid in marker_mean_time:
            out['marker_mean'] = round(marker_mean_time[mid], 6)
        out['pool_median_marker_averages'] = fast_flag_meta.get(mid, {}).get(
            'pool_median_marker_avg_time_spent', pool_med_time
        )
        if mid in fast_flag_meta:
            meta = fast_flag_meta[mid]
            out['rule'] = meta.get('rule')
            if 'cutoff' in meta:
                out['cutoff'] = meta['cutoff']
            for k in ('peer_marker_means_time_pstdev', 'sigmas', 'median_ratio'):
                if k in meta:
                    out[k] = meta[k]
        if pool_time_p10_assignment_level is not None:
            out['pool_time_p10_assignment_level'] = pool_time_p10_assignment_level
        return out

    if fid == 'duplicate_result_fingerprint':
        out['description'] = 'same_result_json_as_peer_assignments'
        return out

    if fid == 'marker_high_rejection_ratio':
        ctr = marker_status.get(mid, Counter())
        total = int(sum(ctr.values()))
        rej = int(ctr.get('REJECTED', 0))
        out['marker_mean'] = round(rej / total, 6) if total > 0 else None
        out['pool_median_marker_averages'] = None
        out['rule'] = 'rejected_ratio_vs_threshold'
        out['rejected_count'] = rej
        out['assignments_in_status_counts'] = total
        out['threshold_ratio_above'] = thr.marker_rejected_ratio_above
        return out

    if fid == 'marker_high_expired_ratio':
        ctr = marker_status.get(mid, Counter())
        total = int(sum(ctr.values()))
        exp = int(ctr.get('EXPIRED', 0))
        out['marker_mean'] = round(exp / total, 6) if total > 0 else None
        out['pool_median_marker_averages'] = None
        out['rule'] = 'expired_ratio_vs_threshold'
        out['expired_count'] = exp
        out['assignments_in_status_counts'] = total
        out['threshold_ratio_above'] = thr.marker_expired_ratio_above
        return out

    if fid == 'marker_high_skip_ratio':
        ctr = marker_status.get(mid, Counter())
        total = int(sum(ctr.values()))
        skp = int(ctr.get('SKIPPED', 0))
        out['marker_mean'] = round(skp / total, 6) if total > 0 else None
        out['pool_median_marker_averages'] = None
        out['rule'] = 'skipped_ratio_vs_threshold'
        out['skipped_count'] = skp
        out['assignments_in_status_counts'] = total
        out['threshold_ratio_above'] = thr.marker_skipped_ratio_above
        return out

    out['rule'] = fid
    return out


def build_fraud_risk_report(  # pylint: disable=R0913
    assignments: Sequence[Any],
    *,
    marker_profiles: Optional[Dict[str, Dict[str, Any]]] = None,
    sample_limit_per_factor: int = 25,
    thresholds: Optional[FraudThresholds] = None,
    detail_level: Literal['summary', 'full'] = 'summary',
    markers_summary_limit: int = 80,
    include_unflagged_markers: bool = False,
) -> Dict[str, Any]:
    thr = thresholds or FraudThresholds()
    collect_samples = detail_level == 'full'

    rows = [_to_plain_dict(a) for a in assignments]

    pool_times: List[float] = []
    qualities: List[float] = []
    consistencies: List[float] = []
    for row in rows:
        dur = _assignment_duration_seconds_positive(row)
        if dur is not None:
            pool_times.append(dur)
        q = row.get('quality')
        if q is not None:
            try:
                qualities.append(float(q))
            except (TypeError, ValueError):
                pass
        c = row.get('consistency')
        if c is not None:
            try:
                consistencies.append(float(c))
            except (TypeError, ValueError):
                pass

    pool_p10 = _pool_time_percentile(pool_times, 10) if len(pool_times) >= MIN_SAMPLES_FOR_TIME_POOL else None
    q_median_assignment_level = _pool_median(qualities)
    c_med = _pool_median(consistencies)

    by_marker_quality: DefaultDict[str, List[float]] = defaultdict(list)
    for row in rows:
        q = row.get('quality')
        if q is None:
            continue
        try:
            by_marker_quality[str(row.get('marker_id') or MISSING_VALUE)].append(float(q))
        except (TypeError, ValueError):
            pass
    marker_mean_quality = {mid: sum(vs) / len(vs) for mid, vs in by_marker_quality.items() if vs}
    peer_vals = list(marker_mean_quality.values())
    n_quality_markers = len(marker_mean_quality)
    med_peers = float(statistics.median(peer_vals)) if n_quality_markers else None
    pstdev_peers = float(statistics.pstdev(peer_vals)) if n_quality_markers >= 2 else 0.0

    sigma_cutoff: Optional[float] = None
    if (
        thr.quality_below is None
        and n_quality_markers >= MIN_MARKERS_FOR_METRIC_SIGMA
        and pstdev_peers > 1e-12
        and med_peers is not None
    ):
        sigma_cutoff = med_peers - thr.quality_peer_outlier_sigmas * pstdev_peers

    q_med_peers = _peer_median_marker_means(marker_mean_quality)
    if thr.quality_below is not None:
        quality_rule_applied = 'marker_mean_absolute'
    elif sigma_cutoff is not None:
        quality_rule_applied = 'marker_mean_sigma_below_median'
    elif n_quality_markers >= MIN_MARKERS_FOR_PEER_MEDIAN_FALLBACK:
        quality_rule_applied = 'marker_mean_median_factor_fallback'
    else:
        quality_rule_applied = 'none'

    flagged_quality_markers: Set[str] = set()
    quality_flag_meta: Dict[str, Dict[str, Any]] = {}
    for mid, mean_q in marker_mean_quality.items():
        if thr.quality_below is not None:
            if mean_q < thr.quality_below:
                flagged_quality_markers.add(mid)
                quality_flag_meta[mid] = {'rule': 'marker_mean_absolute', 'cutoff': thr.quality_below}
            continue

        if sigma_cutoff is not None:
            if mean_q < sigma_cutoff:
                flagged_quality_markers.add(mid)
                quality_flag_meta[mid] = {
                    'rule': 'marker_mean_sigma_below_median',
                    'cutoff': round(sigma_cutoff, 6),
                    'pool_median_marker_avg_quality': med_peers,
                    'peer_marker_means_pstdev': pstdev_peers,
                    'sigmas': thr.quality_peer_outlier_sigmas,
                }
            continue

        if q_med_peers is not None and mean_q < q_med_peers * thr.quality_below_median_factor:
            flagged_quality_markers.add(mid)
            quality_flag_meta[mid] = {
                'rule': 'marker_mean_median_factor_fallback',
                'cutoff': round(q_med_peers * thr.quality_below_median_factor, 6),
                'pool_median_marker_avg_quality': q_med_peers,
                'median_factor': thr.quality_below_median_factor,
            }

    by_marker_consistency: DefaultDict[str, List[float]] = defaultdict(list)
    for row in rows:
        c = row.get('consistency')
        if c is None:
            continue
        try:
            by_marker_consistency[str(row.get('marker_id') or MISSING_VALUE)].append(float(c))
        except (TypeError, ValueError):
            pass
    marker_mean_consistency = {mid: sum(vs) / len(vs) for mid, vs in by_marker_consistency.items() if vs}
    peer_vals_c = list(marker_mean_consistency.values())
    n_consistency_markers = len(marker_mean_consistency)
    med_peers_c = float(statistics.median(peer_vals_c)) if n_consistency_markers else None
    pstdev_peers_c = float(statistics.pstdev(peer_vals_c)) if n_consistency_markers >= 2 else 0.0

    sigma_cutoff_c: Optional[float] = None
    if (
        thr.consistency_below is None
        and n_consistency_markers >= MIN_MARKERS_FOR_METRIC_SIGMA
        and pstdev_peers_c > 1e-12
        and med_peers_c is not None
    ):
        sigma_cutoff_c = med_peers_c - thr.consistency_peer_outlier_sigmas * pstdev_peers_c

    c_med_peers = _peer_median_marker_means(marker_mean_consistency)
    if thr.consistency_below is not None:
        consistency_rule_applied = 'marker_mean_absolute'
    elif sigma_cutoff_c is not None:
        consistency_rule_applied = 'marker_mean_sigma_below_median'
    elif n_consistency_markers >= MIN_MARKERS_FOR_PEER_MEDIAN_FALLBACK:
        consistency_rule_applied = 'marker_mean_median_factor_fallback'
    else:
        consistency_rule_applied = 'none'

    flagged_consistency_markers: Set[str] = set()
    consistency_flag_meta: Dict[str, Dict[str, Any]] = {}
    for mid, mean_c in marker_mean_consistency.items():
        if thr.consistency_below is not None:
            if mean_c < thr.consistency_below:
                flagged_consistency_markers.add(mid)
                consistency_flag_meta[mid] = {'rule': 'marker_mean_absolute', 'cutoff': thr.consistency_below}
            continue

        if sigma_cutoff_c is not None:
            if mean_c < sigma_cutoff_c:
                flagged_consistency_markers.add(mid)
                consistency_flag_meta[mid] = {
                    'rule': 'marker_mean_sigma_below_median',
                    'cutoff': round(sigma_cutoff_c, 6),
                    'pool_median_marker_avg_consistency': med_peers_c,
                    'peer_marker_means_consistency_pstdev': pstdev_peers_c,
                    'sigmas': thr.consistency_peer_outlier_sigmas,
                }
            continue

        if c_med_peers is not None and mean_c < c_med_peers * thr.consistency_below_median_factor:
            flagged_consistency_markers.add(mid)
            consistency_flag_meta[mid] = {
                'rule': 'marker_mean_median_factor_fallback',
                'cutoff': round(c_med_peers * thr.consistency_below_median_factor, 6),
                'pool_median_marker_avg_consistency': c_med_peers,
                'median_factor': thr.consistency_below_median_factor,
            }

    by_marker_time: DefaultDict[str, List[float]] = defaultdict(list)
    for row in rows:
        dur = _assignment_duration_seconds_positive(row)
        if dur is None:
            continue
        by_marker_time[str(row.get('marker_id') or MISSING_VALUE)].append(dur)
    marker_mean_time = {mid: sum(vs) / len(vs) for mid, vs in by_marker_time.items() if vs}
    peer_vals_t = list(marker_mean_time.values())
    n_time_markers = len(marker_mean_time)
    med_peers_t = float(statistics.median(peer_vals_t)) if n_time_markers else None
    pstdev_peers_t = float(statistics.pstdev(peer_vals_t)) if n_time_markers >= 2 else 0.0

    sigma_cutoff_t: Optional[float] = None
    if (
        not _fast_time_absolute_cap_enabled(thr)
        and n_time_markers >= MIN_MARKERS_FOR_METRIC_SIGMA
        and pstdev_peers_t > 1e-12
        and med_peers_t is not None
    ):
        sigma_cutoff_t = med_peers_t - thr.fast_time_peer_outlier_sigmas * pstdev_peers_t

    time_sigma_fast_rule_note: Optional[str] = None
    if (
        sigma_cutoff_t is not None
        and med_peers_t is not None
        and not _fast_time_sigma_cutoff_usable(sigma_cutoff_t, med_peers_t)
    ):
        time_sigma_fast_rule_note = (
            'sigma_fast_degenerate_distribution: median_peer_means − σ·pstdev не даёт положительного '
            'порога строго ниже медианы (сильный правый хвост средних длительностей по маркерам). '
            'Используется median×ratio fallback при достаточном числе маркеров.'
        )
        sigma_cutoff_t = None

    t_med_peers = _peer_median_marker_means(marker_mean_time)
    if _fast_time_absolute_cap_enabled(thr):
        fast_time_rule_applied = 'marker_mean_absolute_seconds'
    elif sigma_cutoff_t is not None:
        fast_time_rule_applied = 'marker_mean_sigma_fast'
    elif n_time_markers >= MIN_MARKERS_FOR_PEER_MEDIAN_FALLBACK:
        fast_time_rule_applied = 'marker_mean_median_ratio_fallback'
    else:
        fast_time_rule_applied = 'none'

    flagged_fast_markers: Set[str] = set()
    fast_flag_meta: Dict[str, Dict[str, Any]] = {}
    for mid, mean_t in marker_mean_time.items():
        if _fast_time_absolute_cap_enabled(thr):
            if thr.fast_time_absolute_seconds is not None and mean_t < thr.fast_time_absolute_seconds:
                flagged_fast_markers.add(mid)
                fast_flag_meta[mid] = {
                    'rule': 'marker_mean_absolute_seconds',
                    'cutoff': thr.fast_time_absolute_seconds,
                }
            continue

        if sigma_cutoff_t is not None:
            if mean_t < sigma_cutoff_t:
                flagged_fast_markers.add(mid)
                fast_flag_meta[mid] = {
                    'rule': 'marker_mean_sigma_fast',
                    'cutoff': round(sigma_cutoff_t, 6),
                    'pool_median_marker_avg_time_spent': med_peers_t,
                    'peer_marker_means_time_pstdev': pstdev_peers_t,
                    'sigmas': thr.fast_time_peer_outlier_sigmas,
                }
            continue

        if t_med_peers is not None and mean_t < t_med_peers * thr.fast_time_vs_peer_median_ratio:
            flagged_fast_markers.add(mid)
            fast_flag_meta[mid] = {
                'rule': 'marker_mean_median_ratio_fallback',
                'cutoff': round(t_med_peers * thr.fast_time_vs_peer_median_ratio, 6),
                'pool_median_marker_avg_time_spent': t_med_peers,
                'median_ratio': thr.fast_time_vs_peer_median_ratio,
            }

    eff_dup_min = _effective_duplicate_min_group(thr, len(rows))
    eff_marker_min = _effective_marker_min_assignments(thr, rows)

    assignment_flags: DefaultDict[str, Set[str]] = defaultdict(set)

    def _touch(aid: str, fid: str) -> None:
        if not aid:
            aid = MISSING_VALUE
        assignment_flags[aid].add(fid)

    factors_order = list(RISK_FACTOR_IDS)
    factor_samples: Dict[str, List[Dict[str, Any]]] = {fid: [] for fid in factors_order}
    factor_counts: Dict[str, int] = {fid: 0 for fid in factors_order}

    def _add_sample(fid: str, sample: Dict[str, Any]) -> None:
        factor_counts[fid] += 1
        if collect_samples and len(factor_samples[fid]) < sample_limit_per_factor:
            factor_samples[fid].append(sample)

    for row in rows:
        mid = str(row.get('marker_id') or MISSING_VALUE)
        if mid not in flagged_quality_markers:
            continue
        aid = str(row.get('assignment_id') or '')
        iid = row.get('item_id')
        base_sample = {
            'assignment_id': aid or None,
            'marker_id': mid,
            'item_id': str(iid) if iid is not None else None,
            'status': row.get('status'),
            'item_type': row.get('item_type'),
        }
        mean_q = marker_mean_quality[mid]
        q_meta = quality_flag_meta[mid]
        q_detail: Dict[str, Any] = {
            'marker_avg_quality': round(mean_q, 6),
            'rule': q_meta['rule'],
        }
        if 'cutoff' in q_meta:
            q_detail['cutoff'] = q_meta['cutoff']
        for copy_key in (
            'pool_median_marker_avg_quality',
            'peer_marker_means_pstdev',
            'sigmas',
            'median_factor',
        ):
            if copy_key in q_meta:
                q_detail[copy_key] = q_meta[copy_key]
        q_one = row.get('quality')
        if q_one is not None:
            try:
                q_detail['quality_this_assignment'] = float(q_one)
            except (TypeError, ValueError):
                q_detail['quality_this_assignment'] = q_one
        _touch(aid, 'low_quality')
        _add_sample('low_quality', {**base_sample, 'detail': q_detail})

    for row in rows:
        mid = str(row.get('marker_id') or MISSING_VALUE)
        if mid not in flagged_consistency_markers:
            continue
        aid = str(row.get('assignment_id') or '')
        iid = row.get('item_id')
        base_sample = {
            'assignment_id': aid or None,
            'marker_id': mid,
            'item_id': str(iid) if iid is not None else None,
            'status': row.get('status'),
            'item_type': row.get('item_type'),
        }
        mean_c = marker_mean_consistency[mid]
        c_meta = consistency_flag_meta[mid]
        c_detail_m: Dict[str, Any] = {
            'marker_avg_consistency': round(mean_c, 6),
            'rule': c_meta['rule'],
        }
        if 'cutoff' in c_meta:
            c_detail_m['cutoff'] = c_meta['cutoff']
        for ck in (
            'pool_median_marker_avg_consistency',
            'peer_marker_means_consistency_pstdev',
            'sigmas',
            'median_factor',
        ):
            if ck in c_meta:
                c_detail_m[ck] = c_meta[ck]
        c_one = row.get('consistency')
        if c_one is not None:
            try:
                c_detail_m['consistency_this_assignment'] = float(c_one)
            except (TypeError, ValueError):
                c_detail_m['consistency_this_assignment'] = c_one
        _touch(aid, 'low_consistency')
        _add_sample('low_consistency', {**base_sample, 'detail': c_detail_m})

    for row in rows:
        mid = str(row.get('marker_id') or MISSING_VALUE)
        if mid not in flagged_fast_markers:
            continue
        aid = str(row.get('assignment_id') or '')
        iid = row.get('item_id')
        base_sample = {
            'assignment_id': aid or None,
            'marker_id': mid,
            'item_id': str(iid) if iid is not None else None,
            'status': row.get('status'),
            'item_type': row.get('item_type'),
        }
        mean_t = marker_mean_time[mid]
        t_meta = fast_flag_meta[mid]
        t_detail: Dict[str, Any] = {
            'marker_avg_time_spent_seconds': round(mean_t, 6),
            'rule': t_meta['rule'],
        }
        if 'cutoff' in t_meta:
            t_detail['cutoff'] = t_meta['cutoff']
        for tk in (
            'pool_median_marker_avg_time_spent',
            'peer_marker_means_time_pstdev',
            'sigmas',
            'median_ratio',
        ):
            if tk in t_meta:
                t_detail[tk] = t_meta[tk]
        t_one = _assignment_duration_seconds_positive(row)
        if t_one is not None:
            t_detail['time_spent_this_assignment'] = round(t_one, 6)
        t_detail['pool_time_p10_assignment_level'] = pool_p10
        _touch(aid, 'fast_completion')
        _add_sample('fast_completion', {**base_sample, 'detail': t_detail})

    fp_to_aids: DefaultDict[str, List[str]] = defaultdict(list)
    for row in rows:
        aid = str(row.get('assignment_id') or '')
        fp = _result_fingerprint(row.get('result'))
        if fp:
            fp_to_aids[fp].append(aid)

    large_groups = {fp: aids for fp, aids in fp_to_aids.items() if len(aids) >= eff_dup_min}
    row_by_aid: Dict[str, Dict[str, Any]] = {str(r.get('assignment_id') or ''): r for r in rows}
    dup_n = 0
    for fp, aids in large_groups.items():
        dup_n += len(aids)
        for aid in aids:
            _touch(aid, 'duplicate_result_fingerprint')
        if collect_samples:
            for aid in aids:
                if len(factor_samples['duplicate_result_fingerprint']) >= sample_limit_per_factor:
                    break
                rec = row_by_aid.get(aid, {})
                factor_samples['duplicate_result_fingerprint'].append(
                    {
                        'assignment_id': aid or None,
                        'marker_id': str(rec.get('marker_id') or '') or None,
                        'item_id': str(rec.get('item_id')) if rec.get('item_id') is not None else None,
                        'detail': {
                            'duplicate_group_size': len(aids),
                            'duplicate_min_group_effective': eff_dup_min,
                            'fingerprint_prefix': fp[:80],
                        },
                    }
                )
    factor_counts['duplicate_result_fingerprint'] = dup_n

    marker_status: Dict[str, Counter] = defaultdict(Counter)
    for row in rows:
        mid = str(row.get('marker_id') or MISSING_VALUE)
        st = row.get('status') or MISSING_VALUE
        marker_status[mid][str(st)] += 1

    markers_with_high_rejection: Set[str] = set()
    markers_with_high_expired: Set[str] = set()
    markers_with_high_skip: Set[str] = set()

    for mid, counter in marker_status.items():
        total = sum(counter.values())
        if total < eff_marker_min:
            continue
        rej = counter.get('REJECTED', 0)
        exp = counter.get('EXPIRED', 0)
        skp = counter.get('SKIPPED', 0)
        if rej / total >= thr.marker_rejected_ratio_above:
            factor_counts['marker_high_rejection_ratio'] += 1
            markers_with_high_rejection.add(mid)
            if collect_samples and len(factor_samples['marker_high_rejection_ratio']) < sample_limit_per_factor:
                factor_samples['marker_high_rejection_ratio'].append(
                    {
                        'assignment_id': None,
                        'marker_id': mid,
                        'item_id': None,
                        'detail': {
                            'rejected': rej,
                            'total': total,
                            'ratio': round(rej / total, 4),
                            'min_assignments_effective': eff_marker_min,
                        },
                    }
                )
        if exp / total >= thr.marker_expired_ratio_above:
            factor_counts['marker_high_expired_ratio'] += 1
            markers_with_high_expired.add(mid)
            if collect_samples and len(factor_samples['marker_high_expired_ratio']) < sample_limit_per_factor:
                factor_samples['marker_high_expired_ratio'].append(
                    {
                        'assignment_id': None,
                        'marker_id': mid,
                        'item_id': None,
                        'detail': {
                            'expired': exp,
                            'total': total,
                            'ratio': round(exp / total, 4),
                            'min_assignments_effective': eff_marker_min,
                        },
                    }
                )
        if skp / total >= thr.marker_skipped_ratio_above:
            factor_counts['marker_high_skip_ratio'] += 1
            markers_with_high_skip.add(mid)
            if collect_samples and len(factor_samples['marker_high_skip_ratio']) < sample_limit_per_factor:
                factor_samples['marker_high_skip_ratio'].append(
                    {
                        'assignment_id': None,
                        'marker_id': mid,
                        'item_id': None,
                        'detail': {
                            'skipped': skp,
                            'total': total,
                            'ratio': round(skp / total, 4),
                            'min_assignments_effective': eff_marker_min,
                        },
                    }
                )

    profiles = marker_profiles or {}
    marker_factor_hits: DefaultDict[str, Counter] = defaultdict(Counter)
    marker_assignment_flagged: DefaultDict[str, int] = defaultdict(int)

    for aid, fids in assignment_flags.items():
        row = row_by_aid.get(aid)  # type: ignore[assignment]
        if not row:
            continue
        mid = str(row.get('marker_id') or MISSING_VALUE)
        marker_factor_hits[mid].update(fids)
        marker_assignment_flagged[mid] += 1

    def _bump_marker_factor(mid: str, fid: str) -> None:
        marker_factor_hits[mid][fid] += 1

    for mid in markers_with_high_rejection:
        _bump_marker_factor(mid, 'marker_high_rejection_ratio')
    for mid in markers_with_high_expired:
        _bump_marker_factor(mid, 'marker_high_expired_ratio')
    for mid in markers_with_high_skip:
        _bump_marker_factor(mid, 'marker_high_skip_ratio')

    markers_ranked = []
    for mid, mcounter in marker_factor_hits.items():
        prof = profiles.get(mid, {})
        fnz = {k: int(v) for k, v in mcounter.items() if v}
        factors_detail_r = {
            fid: _marker_factor_summary_detail(
                mid,
                fid,
                fnz[fid],
                marker_mean_quality=marker_mean_quality,
                quality_flag_meta=quality_flag_meta,
                pool_med_quality=med_peers,
                marker_mean_consistency=marker_mean_consistency,
                consistency_flag_meta=consistency_flag_meta,
                pool_med_consistency=med_peers_c,
                marker_mean_time=marker_mean_time,
                fast_flag_meta=fast_flag_meta,
                pool_med_time=med_peers_t,
                marker_status=marker_status,
                thr=thr,
                pool_time_p10_assignment_level=pool_p10,
            )
            for fid in fnz
        }
        markers_ranked.append(
            {
                'marker_id': mid,
                'display_name': prof.get('display_name') or prof.get('fio') or prof.get('email') or mid,
                'assignments_with_any_flag': marker_assignment_flagged.get(mid, 0),
                'factors': factors_detail_r,
                'risk_score': len(fnz),
            }
        )
    markers_ranked.sort(
        key=lambda x: (
            -x['risk_score'],  # type: ignore[operator]
            -int(x['assignments_with_any_flag']),  # type: ignore[arg-type]
        )
    )

    marker_totals: Counter = Counter(str(r.get('marker_id') or MISSING_VALUE) for r in rows)
    markers_with_signal = {mid for mid in marker_totals if sum(marker_factor_hits.get(mid, Counter()).values()) > 0}

    markers_summary: List[Dict[str, Any]] = []
    for mid, assignments_total in marker_totals.items():
        mc = marker_factor_hits.get(mid, Counter())
        factors_nonzero = {k: int(v) for k, v in mc.items() if v}
        risk_score = len(factors_nonzero)
        if not include_unflagged_markers and risk_score == 0:
            continue
        prof = profiles.get(mid, {})
        factors_detail = {
            fid: _marker_factor_summary_detail(
                mid,
                fid,
                factors_nonzero[fid],
                marker_mean_quality=marker_mean_quality,
                quality_flag_meta=quality_flag_meta,
                pool_med_quality=med_peers,
                marker_mean_consistency=marker_mean_consistency,
                consistency_flag_meta=consistency_flag_meta,
                pool_med_consistency=med_peers_c,
                marker_mean_time=marker_mean_time,
                fast_flag_meta=fast_flag_meta,
                pool_med_time=med_peers_t,
                marker_status=marker_status,
                thr=thr,
                pool_time_p10_assignment_level=pool_p10,
            )
            for fid in factors_nonzero
        }
        markers_summary.append(
            {
                'marker_id': mid,
                'display_name': prof.get('display_name') or prof.get('fio') or prof.get('email') or mid,
                'assignments_total': int(assignments_total),
                'assignments_flagged': int(marker_assignment_flagged.get(mid, 0)),
                'distinct_risk_factors': len(factors_nonzero),
                'risk_score': int(risk_score),
                'factors': factors_detail,
            }
        )
    markers_summary.sort(
        key=lambda x: (-x['risk_score'], -x['assignments_flagged'], -x['assignments_total']),
    )
    markers_summary = markers_summary[: max(0, markers_summary_limit)]

    totals_by_factor = {fid: int(factor_counts[fid]) for fid in factors_order if factor_counts.get(fid, 0) > 0}
    executive_summary = {
        'detail_level': detail_level,
        'assignments_analyzed': len(rows),
        'assignments_with_any_risk_flag': len(assignment_flags),
        'markers_total_in_data': len(marker_totals),
        'markers_with_any_risk_signal': len(markers_with_signal),
        'markers_listed_in_summary': len(markers_summary),
        'risk_factors_triggered': [fid for fid in factors_order if factor_counts.get(fid, 0) > 0],
        'totals_by_factor': totals_by_factor,
    }
    if detail_level == 'summary':
        executive_summary[
            'full_detail_hint'
        ] = 'Для примеров assignment_id и подсказок по факторам вызовите с detail_level="full".'  # type: ignore[assignment]

    risk_factors_out: List[Dict[str, Any]] = []
    for fid in factors_order:
        meta = RISK_FACTOR_META.get(fid, {})
        cnt = factor_counts.get(fid, 0)
        factor_out: Dict[str, Any] = {
            'id': fid,
            'title': meta.get('title', fid),
            'checked': True,
            'triggered': cnt > 0,
            'count': cnt,
        }
        if detail_level == 'full':
            factor_out['hint'] = meta.get('hint', '')
            factor_out['samples'] = factor_samples[fid]
        risk_factors_out.append(factor_out)

    out: Dict[str, Any] = {
        'backend': 'sdk_fraud_heuristics',
        'executive_summary': executive_summary,
        'markers_summary': markers_summary,
        'risk_factors': risk_factors_out,
        'assignments_count': len(rows),
        'items_count': len({row.get('item_id') for row in rows if row.get('item_id') is not None}),
        'markers_count': len({row.get('marker_id') for row in rows if row.get('marker_id') is not None}),
        'assignments_with_any_flag': len(assignment_flags),
        'thresholds': asdict(thr),
        'pool_baselines': {
            'quality_median_marker_averages': med_peers,
            'quality_peer_marker_means_pstdev': pstdev_peers if n_quality_markers >= 2 else None,
            'quality_outlier_cutoff_sigma_rule': sigma_cutoff,
            'quality_median_assignment_level': q_median_assignment_level,
            'consistency_median_marker_averages': med_peers_c,
            'consistency_peer_marker_means_pstdev': pstdev_peers_c if n_consistency_markers >= 2 else None,
            'consistency_outlier_cutoff_sigma_rule': sigma_cutoff_c,
            'consistency_median_assignment_level': c_med,
            'time_median_marker_averages': med_peers_t,
            'time_peer_marker_means_pstdev': pstdev_peers_t if n_time_markers >= 2 else None,
            'time_outlier_cutoff_sigma_fast': sigma_cutoff_t,
            'time_sigma_fast_rule_note': time_sigma_fast_rule_note,
            'markers_with_time_mean': len(marker_mean_time),
            'time_p10_positive_times': pool_p10,
            'markers_with_quality_mean': len(marker_mean_quality),
            'markers_with_consistency_mean': len(marker_mean_consistency),
            'quality_assignments_count': len(qualities),
            'consistency_assignments_count': len(consistencies),
            'values_for_consistency_median': len(consistencies),
            'values_for_time_percentile': len(pool_times),
            'min_markers_metric_sigma_rule': MIN_MARKERS_FOR_METRIC_SIGMA,
            'min_markers_peer_median_fallback': MIN_MARKERS_FOR_PEER_MEDIAN_FALLBACK,
            'min_markers_quality_sigma_rule': MIN_MARKERS_FOR_METRIC_SIGMA,
            'min_markers_consistency_sigma_rule': MIN_MARKERS_FOR_METRIC_SIGMA,
            'min_markers_time_sigma_rule': MIN_MARKERS_FOR_METRIC_SIGMA,
            'min_markers_quality_peer_median': MIN_MARKERS_FOR_PEER_MEDIAN_FALLBACK,
            'min_samples_consistency_median': MIN_SAMPLES_FOR_POOL_MEDIAN,
            'min_samples_time_percentile': MIN_SAMPLES_FOR_TIME_POOL,
        },
        'effective_thresholds': {
            'duplicate_min_group_size': eff_dup_min,
            'marker_min_assignments_for_ratios': eff_marker_min,
            'quality_rule': quality_rule_applied,
            'consistency_rule': consistency_rule_applied,
            'fast_time_rule': fast_time_rule_applied,
        },
        'pool_time_p10': pool_p10,
        'disclaimer': (
            'Эвристики по данным назначений, не доказательство фрода. Решения принимает человек/политики платформы.'
        ),
    }
    if detail_level == 'full':
        out['markers_ranked_by_signals'] = markers_ranked[:50]
    return out
