# pylint: disable=line-too-long

import logging
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Sequence

import aiohttp

from crowd_sdk.mcp.statistic._export_estimates import assignment_estimate_by_tasks_from_export
from crowd_sdk.mcp.statistic._fraud_analysis import (
    RISK_FACTOR_IDS,
    FraudThresholds,
    build_fraud_risk_report,
    update_fraud_thresholds_from_mapping,
)
from crowd_sdk.mcp.statistic._results_analysis import (
    MISSING_VALUE,
    _to_plain_dict,
    build_task_results_analysis,
    canonicalize_analyses,
)
from crowd_sdk.mcp.statistic._tagme_stats import (
    date_to_iso_day,
    marker_directory_from_stat_rows,
    normalize_for_mcp,
    open_tagme_client,
)
from crowd_sdk.mcp.tools._helpers import (
    PROJECT_ANALYSIS_GUARD_DEFAULT_MAX_ASSIGNMENTS_ESTIMATE,
    PROJECT_ANALYSIS_GUARD_DEFAULT_MAX_TASKS,
    _get_project_tasks_with_organization,
    _get_project_with_organization,
    _infer_project_marker_stats_range,
    _project_metadata,
    _task_metadata,
)
from crowd_sdk.tagme.http_client.client import TagmeClientAdvanced
from crowd_sdk.tagme.http_client.datacls import Project, TaskData
from crowd_sdk.tagme.types import ExportTypes

logger = logging.getLogger(__name__)


async def _compose_marker_profiles_for_task(  # pylint: disable=R0912
    client: TagmeClientAdvanced,
    task: TaskData,
    assignments: Sequence[Any],
    organization_id: Optional[str],
    enrich_from_export: bool,
) -> Dict[str, Dict[str, Any]]:
    """person_id/email from assignments; optional fio/email from project stats export."""

    profiles: Dict[str, Dict[str, Any]] = {}
    for assignment in assignments:
        mid = str(getattr(assignment, 'marker_id', None) or MISSING_VALUE)
        entry = profiles.setdefault(mid, {'person_id': None, 'email': None, 'fio': None})
        pid = getattr(assignment, 'person_id', None)
        if pid:
            entry['person_id'] = str(pid)
        em = getattr(assignment, 'email', None)
        if em:
            entry['email'] = str(em)

    org_id = organization_id or getattr(task, 'organization_id', None)
    if enrich_from_export and org_id and task.project_id:
        from_date = date_to_iso_day(task.start_date or task.created_date or task.update_date)
        to_date = date_to_iso_day(task.finished_date or task.update_date or datetime.utcnow())
        if from_date and to_date:
            try:
                _, marker_rows = await client.export_project_stats(
                    project_id=task.project_id,
                    from_date=from_date,
                    to_date=to_date,
                    organization_id=org_id,
                )
                marker_rows = [r for r in marker_rows if r.task_id == task.uid]
                directory = marker_directory_from_stat_rows(marker_rows)
                for mid, entry in profiles.items():
                    info = directory.get(mid)
                    if not info:
                        continue
                    if info.get('fio'):
                        entry['fio'] = info['fio']
                    if info.get('email') and not entry.get('email'):
                        entry['email'] = info['email']
            except (aiohttp.ClientError, ValueError, KeyError):
                logger.warning(
                    'marker profile enrichment from export failed task_id=%s',
                    task.uid,
                    exc_info=True,
                )

    for mid, entry in profiles.items():
        entry['display_name'] = entry.get('fio') or entry.get('email') or entry.get('person_id') or mid
    return profiles


async def _compose_marker_profiles_for_project(  # pylint: disable=R0913
    client: TagmeClientAdvanced,
    project: Project,
    tasks: List[TaskData],
    assignments: List[Dict[str, Any]],
    organization_id: Optional[str],
    enrich_from_export: bool,
) -> Dict[str, Dict[str, Any]]:
    """Same as per-task profiles, but export covers all tasks in the project date span."""

    profiles: Dict[str, Dict[str, Any]] = {}
    for row in assignments:
        mid = str(row.get('marker_id') or MISSING_VALUE)
        entry = profiles.setdefault(mid, {'person_id': None, 'email': None, 'fio': None})
        pid = row.get('person_id')
        if pid:
            entry['person_id'] = str(pid)
        em = row.get('email')
        if em:
            entry['email'] = str(em)

    org_id = organization_id or project.organization_id
    if enrich_from_export and org_id and project.uid:
        from_date, to_date = _infer_project_marker_stats_range(project, tasks)
        if from_date and to_date:
            try:
                _, marker_rows = await client.export_project_stats(
                    project_id=project.uid,
                    from_date=from_date,
                    to_date=to_date,
                    organization_id=org_id,
                )
                directory = marker_directory_from_stat_rows(marker_rows)
                for mid, entry in profiles.items():
                    info = directory.get(mid)
                    if not info:
                        continue
                    if info.get('fio'):
                        entry['fio'] = info['fio']
                    if info.get('email') and not entry.get('email'):
                        entry['email'] = info['email']
            except (aiohttp.ClientError, ValueError, KeyError):
                logger.warning(
                    'marker profile enrichment from export failed project_id=%s',
                    project.uid,
                    exc_info=True,
                )

    for mid, entry in profiles.items():
        entry['display_name'] = entry.get('fio') or entry.get('email') or entry.get('person_id') or mid
    return profiles


async def analyze_task_results(  # pylint: disable=R0913
    task_id: str,
    organization_id: Optional[str] = None,
    mode: str = 'auto',
    analyses: Optional[Sequence[str]] = None,
    output_fields: Optional[Sequence[str]] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    updated_date_from: Optional[str] = None,
    updated_date_to: Optional[str] = None,
    marker_ids: Optional[str] = None,
    item_types: Optional[Sequence[Literal['data', 'control', 'study']]] = None,
    statuses: Optional[Sequence[Literal['ACCEPTED', 'REJECTED', 'EXPIRED', 'SKIPPED', 'SUBMITTED']]] = None,
    consistency: Optional[float] = None,
    consistency_filter: Optional[Literal['lte', 'gte', 'gt', 'lt', 'eq']] = None,
    top_n: int = 10,
    sample_limit: int = 3,
    min_overlap: int = 2,
    enrich_markers_from_export: bool = True,
    summary_only: bool = False,
    max_result_preview_chars: Optional[int] = 2000,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Анализ **сырых назначений** одной задачи (`get_task_assignments`): ответы, маркеры, сводки.

    Когда вызывать: нужно понять *что именно* отметили (поля result), кто как отличился, примеры строк,
    согласованность по объекту, распределение классов, сверка с control, сводка по маркерам из назначений.
    Параметр `analyses` задаёт блоки (по умолчанию все): inspect, class_distribution, agreement_summary,
    generation_summary, marker_answer_summary, sample_results, compare_with_control.
    Синонимы принимаются и приводятся к этим именам, например: consistency→agreement_summary;
    quality, time, workload→marker_answer_summary; control, golden→compare_with_control;
    labels, classes→class_distribution; examples, samples→sample_results.

    Не вызывать для: быстрого прогресса без назначений → **get_task_stats**; таблицы маркеров из экспорта
    → **get_marker_performance_stats**; риск-сводки → **analyze_fraud_risk**; сразу весь проект →
    **analyze_project_results**.

    **Советы для агента (экономия контекста):** (1) Сначала **get_task_stats** или короткий **analyze_task_results**
    с ``summary_only=True`` и 1–2 блоками в ``analyses``, чтобы оценить объём. (2) Полный разбор — только при
    явной необходимости; расширяй ``analyses`` по шагам. (3) Всегда сужай ``output_fields`` под конкретные поля
    ``result``, если вопрос не про всю схему. (4) Избегай ``sample_results`` и широкого ``inspect``, пока не
    нужны примеры; держи ``top_n``/``sample_limit`` малыми. (5) Тексты в ``result`` обрезаются до
    ``max_result_preview_chars=500`` символов по умолчанию — увеличь при необходимости видеть полный текст.
    (6) API всё равно загружает все назначения по фильтру — сузь период/``marker_ids``/``statuses``,
    если не нужна вся выборка.

    Возвращает: entity_type, task, filters, assignments_count, items_count, markers_count, analyses,
    analysis_options, плюс запрошенные блоки анализа (те же имена, что в `analyses`).
    """
    if mode != 'auto':
        raise ValueError('Only mode="auto" is currently supported')

    async with open_tagme_client(config_path) as client:
        task = await client.get_task(task_id=task_id, organization_id=organization_id)
        assignments = await client.get_task_assignments(
            task_id=task_id,
            date_from=date_from,
            date_to=date_to,
            updated_date_from=updated_date_from,
            updated_date_to=updated_date_to,
            marker_ids=marker_ids,
            item_types=list(item_types) if item_types else None,
            statuses=list(statuses) if statuses else None,
            consistency=consistency,
            consistency_filter=consistency_filter,
            organization_id=organization_id,
        )

        selected_analyses = canonicalize_analyses(analyses)
        marker_profiles = None
        if 'marker_answer_summary' in selected_analyses:
            marker_profiles = await _compose_marker_profiles_for_task(
                client,
                task,
                assignments,
                organization_id,
                enrich_markers_from_export,
            )

    return {
        'entity_type': 'task_results_analysis',
        'task': _task_metadata(task),
        'mode': mode,
        'filters': {
            'date_from': date_from,
            'date_to': date_to,
            'updated_date_from': updated_date_from,
            'updated_date_to': updated_date_to,
            'marker_ids': marker_ids,
            'item_types': list(item_types or []),
            'statuses': list(statuses or []),
            'consistency': consistency,
            'consistency_filter': consistency_filter,
            'enrich_markers_from_export': enrich_markers_from_export,
            'summary_only': summary_only,
            'max_result_preview_chars': max_result_preview_chars,
        },
        **build_task_results_analysis(
            assignments,
            analyses=list(selected_analyses),
            output_fields=output_fields,
            top_n=top_n,
            sample_limit=sample_limit,
            min_overlap=min_overlap,
            marker_profiles=marker_profiles,
            summary_only=summary_only,
            max_result_preview_chars=max_result_preview_chars,
        ),
    }


async def analyze_fraud_risk(  # pylint: disable=R0913,R0914
    task_id: str,
    organization_id: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    updated_date_from: Optional[str] = None,
    updated_date_to: Optional[str] = None,
    marker_ids: Optional[str] = None,
    item_types: Optional[Sequence[Literal['data', 'control', 'study']]] = None,
    statuses: Optional[Sequence[Literal['ACCEPTED', 'REJECTED', 'EXPIRED', 'SKIPPED', 'SUBMITTED']]] = None,
    consistency: Optional[float] = None,
    consistency_filter: Optional[Literal['lte', 'gte', 'gt', 'lt', 'eq']] = None,
    sample_limit_per_factor: int = 25,
    enrich_markers_from_export: bool = True,
    fraud_thresholds: Optional[Dict[str, Any]] = None,
    quality_below: Optional[float] = None,
    consistency_below: Optional[float] = None,
    fast_time_vs_peer_median_ratio: Optional[float] = None,
    fast_time_peer_outlier_sigmas: Optional[float] = None,
    fast_time_vs_pool_p10_ratio: Optional[float] = None,
    fast_time_absolute_seconds: Optional[float] = None,
    duplicate_result_min_group: Optional[int] = None,
    marker_min_assignments_for_ratios: Optional[int] = None,
    marker_rejected_ratio_above: Optional[float] = None,
    marker_expired_ratio_above: Optional[float] = None,
    marker_skipped_ratio_above: Optional[float] = None,
    detail_level: Literal['summary', 'full'] = 'summary',
    markers_summary_limit: int = 80,
    include_unflagged_markers: bool = False,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Эвристическая **сводка рисков** по одной задаче (назначения уже загружаются внутри).

    Когда вызывать: вопросы «кого проверить», «подозрительные паттерны», сводка сигналов по разметчикам
    (качество, согласованность, время, дубликаты ответов, доли отказов/пропусков и т.д.).
    `detail_level=summary` — компактно; `full` — с примерами и подсказками по факторам.

    Пороги по умолчанию **относительные к этой выборке** (см. ответ `thresholds`, `pool_baselines`,
    `effective_thresholds`): **quality** — среднее по маркеру: при ≥4 маркерах отсечка «медиана средних
    минус σ·pstdev» (`quality_peer_outlier_sigmas` в `fraud_thresholds`); при 2–3 — fallback «медиана×factor»;
    **consistency** — то же по среднему consistency: при ≥4 маркерах — «медиана средних минус σ·pstdev»
    (`consistency_peer_outlier_sigmas`); при 2–3 — fallback «медиана×factor»;
    **быстрое выполнение** — по **среднему** положительному `time_spent` маркера (сек): при ≥4 маркерах
    «медиана средних минус σ·pstdev» (`fast_time_peer_outlier_sigmas`), при 2–3 — среднее < медиана×ratio;
    устаревший параметр `fast_time_vs_pool_p10_ratio` задаёт тот же ratio; `pool_baselines.time_p10_positive_times` —
    справочно по назначениям; дубликаты — минимальный размер группы от доли объёма;
    доли REJECTED/EXPIRED/SKIPPED — от числа назначений маркера; минимальный объём маркера для долей —
    от средней нагрузки в отчёте. Абсолюты (фиксированные `quality_below`, секунды на время и т.д.)
    можно задать через `fraud_thresholds` и одноимённые параметры.

    Не вызывать для: полного разбора полей ответа и контроля → **analyze_task_results**; только дашборд
    задачи → **get_task_stats**; официальная таблица маркеров из статистики → **get_marker_performance_stats**.

    Возвращает: entity_type, task, risk_factor_catalog, filters, related_mcp_tools, executive_summary,
    markers_summary (в т.ч. per-marker ``factors``: среднее маркера, медиана средних по пулу маркеров,
    порог/правило; ``risk_score`` — число затронутых типов факторов), risk_factors, assignments_count,
    thresholds, pool_baselines, effective_thresholds, disclaimer, прочие поля отчёта fraud.
    """
    thr = FraudThresholds()
    update_fraud_thresholds_from_mapping(thr, fraud_thresholds)
    if quality_below is not None:
        thr.quality_below = quality_below
    if consistency_below is not None:
        thr.consistency_below = consistency_below
    if fast_time_vs_peer_median_ratio is not None:
        thr.fast_time_vs_peer_median_ratio = fast_time_vs_peer_median_ratio
    elif fast_time_vs_pool_p10_ratio is not None:
        thr.fast_time_vs_peer_median_ratio = fast_time_vs_pool_p10_ratio
    if fast_time_peer_outlier_sigmas is not None:
        thr.fast_time_peer_outlier_sigmas = fast_time_peer_outlier_sigmas
    if fast_time_absolute_seconds is not None:
        thr.fast_time_absolute_seconds = fast_time_absolute_seconds
    if duplicate_result_min_group is not None:
        thr.duplicate_result_min_group = duplicate_result_min_group
    if marker_min_assignments_for_ratios is not None:
        thr.marker_min_assignments_for_ratios = marker_min_assignments_for_ratios
    if marker_rejected_ratio_above is not None:
        thr.marker_rejected_ratio_above = marker_rejected_ratio_above
    if marker_expired_ratio_above is not None:
        thr.marker_expired_ratio_above = marker_expired_ratio_above
    if marker_skipped_ratio_above is not None:
        thr.marker_skipped_ratio_above = marker_skipped_ratio_above

    async with open_tagme_client(config_path) as client:
        task = await client.get_task(task_id=task_id, organization_id=organization_id)
        assignments = await client.get_task_assignments(
            task_id=task_id,
            date_from=date_from,
            date_to=date_to,
            updated_date_from=updated_date_from,
            updated_date_to=updated_date_to,
            marker_ids=marker_ids,
            item_types=list(item_types) if item_types else None,
            statuses=list(statuses) if statuses else None,
            consistency=consistency,
            consistency_filter=consistency_filter,
            organization_id=organization_id,
        )

        marker_profiles = await _compose_marker_profiles_for_task(
            client,
            task,
            assignments,
            organization_id,
            enrich_markers_from_export,
        )

    report = build_fraud_risk_report(
        assignments,
        marker_profiles=marker_profiles,
        sample_limit_per_factor=sample_limit_per_factor,
        thresholds=thr,
        detail_level=detail_level,
        markers_summary_limit=markers_summary_limit,
        include_unflagged_markers=include_unflagged_markers,
    )

    return {
        'entity_type': 'fraud_risk_analysis',
        'task': _task_metadata(task),
        'risk_factor_catalog': list(RISK_FACTOR_IDS),
        'filters': {
            'date_from': date_from,
            'date_to': date_to,
            'updated_date_from': updated_date_from,
            'updated_date_to': updated_date_to,
            'marker_ids': marker_ids,
            'item_types': list(item_types or []),
            'statuses': list(statuses or []),
            'consistency': consistency,
            'consistency_filter': consistency_filter,
            'enrich_markers_from_export': enrich_markers_from_export,
            'detail_level': detail_level,
            'markers_summary_limit': markers_summary_limit,
            'include_unflagged_markers': include_unflagged_markers,
            'fraud_thresholds': fraud_thresholds,
        },
        'related_mcp_tools': {
            'deep_dive_assignments': 'analyze_task_results',
            'marker_pool_stats': 'get_marker_performance_stats',
            'quality_breakdown': 'get_project_quality_stats',
        },
        **report,
    }


async def _enforce_project_analysis_guard(
    client: Any,
    project: Project,
    tasks: List[TaskData],
    organization_id: str,
    *,
    skip_guard: bool,
    guard_max_tasks: Optional[int],
    guard_max_assignments_estimate: Optional[int],
) -> Dict[str, Any]:
    """
    Block huge project-wide analysis before downloading assignments.

    Uses one TASKS-only statistics export; total is sum of count_assignments per task over
    rows in the inferred date window (approximate if the backend reports per-day slices).
    """
    if skip_guard:
        return {'skipped': True, 'reason': 'skip_project_analysis_guard=True'}
    if not tasks:
        return {'tasks_in_scope': 0, 'assignments_estimate_total': 0}

    max_tasks = guard_max_tasks if guard_max_tasks is not None else PROJECT_ANALYSIS_GUARD_DEFAULT_MAX_TASKS
    max_assign = (
        guard_max_assignments_estimate
        if guard_max_assignments_estimate is not None
        else PROJECT_ANALYSIS_GUARD_DEFAULT_MAX_ASSIGNMENTS_ESTIMATE
    )

    if len(tasks) > max_tasks:
        raise ValueError(
            '[project_analysis_guard] Слишком много задач для одного вызова analyze_project_results: '
            f'{len(tasks)} (лимит {max_tasks}). '
            'Сузьте список через task_ids или task_limit, увеличьте guard_max_tasks '
            'или отключите проверку: skip_project_analysis_guard=True.'
        )

    from_date, to_date = _infer_project_marker_stats_range(project, tasks)
    if not from_date or not to_date:
        return {
            'tasks_in_scope': len(tasks),
            'assignments_estimate_total': None,
            'note': 'inferred_export_range_unavailable',
        }

    try:
        task_rows, _ = await client.export_project_stats(
            project_id=project.uid,
            from_date=from_date,
            to_date=to_date,
            types=[ExportTypes.TASKS],
            organization_id=organization_id,
        )
    except (aiohttp.ClientError, ValueError, KeyError) as exc:
        logger.warning('project analysis guard: TASKS export failed: %s', exc, exc_info=True)
        return {
            'tasks_in_scope': len(tasks),
            'assignments_estimate_total': None,
            'export_error': str(exc),
        }

    uid_list = [t.uid for t in tasks]
    total_est, per_task = assignment_estimate_by_tasks_from_export(task_rows, uid_list)

    if total_est > max_assign:
        raise ValueError(
            '[project_analysis_guard] Оценка суммарного числа заданий по экспорту статистики (TASKS) '
            f'превышает лимит: ~{total_est} > {max_assign}. Период оценки: {from_date} … {to_date}. '
            'Сузьте task_ids, task_limit или окно дат, снизьте объём через фильтры назначений, '
            'увеличьте guard_max_assignments_estimate либо отключите проверку: '
            'skip_project_analysis_guard=True.'
        )

    return {
        'tasks_in_scope': len(tasks),
        'assignments_estimate_total': total_est,
        'assignments_estimate_by_task': per_task,
        'export_period': {'from_date': from_date, 'to_date': to_date},
        'guard_limits': {'max_tasks': max_tasks, 'max_assignments_estimate': max_assign},
    }


async def analyze_project_results(  # pylint: disable=R0913,R0914,R0915
    project_id: str,
    organization_id: Optional[str] = None,
    summary_mode: Literal['rollup', 'per_task'] = 'rollup',
    task_ids: Optional[Sequence[str]] = None,
    task_limit: Optional[int] = None,
    analyses: Optional[Sequence[str]] = None,
    output_fields: Optional[Sequence[str]] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    updated_date_from: Optional[str] = None,
    updated_date_to: Optional[str] = None,
    marker_ids: Optional[str] = None,
    item_types: Optional[Sequence[Literal['data', 'control', 'study']]] = None,
    statuses: Optional[Sequence[Literal['ACCEPTED', 'REJECTED', 'EXPIRED', 'SKIPPED', 'SUBMITTED']]] = None,
    consistency: Optional[float] = None,
    consistency_filter: Optional[Literal['lte', 'gte', 'gt', 'lt', 'eq']] = None,
    top_n: int = 10,
    sample_limit: int = 3,
    min_overlap: int = 2,
    enrich_markers_from_export: bool = True,
    summary_only: bool = False,
    max_result_preview_chars: Optional[int] = 2000,
    skip_project_analysis_guard: bool = False,
    guard_max_tasks: Optional[int] = None,
    guard_max_assignments_estimate: Optional[int] = None,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """То же семейство, что **analyze_task_results**, но для **проекта**: несколько задач, назначения загружаются по очереди.

    Когда вызывать: нужен совместный анализ ответов сразу по нескольким задачам одного project_id.
    `summary_mode=rollup` — одна сводка (item_id с префиксом task);\n    `per_task` — массив tasks[].analysis.
    Список `analyses` — те же канонические имена и синонимы, что у **analyze_task_results** (см. её докстринг).
    По умолчанию блоки: inspect, class_distribution, agreement_summary, marker_answer_summary.
    Дополнительные блоки (запрашивать явно): sample_results, generation_summary, compare_with_control.
    Перед полной загрузкой может сработать guard (ошибка при огромном объёме) — параметры guard_* / skip_*.

    Не вызывать для: обзора проекта без назначений → **get_project_stats**; одной задачи → **analyze_task_results**;
    только таблицы маркеров из экспорта → **get_marker_performance_stats**.

    **Советы для агента (экономия контекста):** (1) Начинай с ``summary_only=True`` и 1–2 блоками ``analyses``
    чтобы оценить объём данных. (2) Расширяй ``analyses`` по шагам — добавляй блоки только при явной необходимости.
    (3) Сужай ``output_fields`` под конкретные поля result. (4) Держи ``top_n`` (дефолт 10) и ``sample_limit``
    (дефолт 3) малыми — увеличивай только если нужна полная картина по маркерам или примеры ответов.
    (5) Используй ``task_ids`` или ``task_limit`` чтобы не грузить все задачи сразу.

    Возвращает: entity_type, project, summary_mode, tasks_processed, filters, project_analysis_guard;
    при rollup — те же ключи анализа, что у analyze_task_results; при per_task — tasks[] с вложенным analysis.
    """
    async with open_tagme_client(config_path) as client:
        project = await _get_project_with_organization(
            client,
            project_id=project_id,
            with_tasks_count=True,
            organization_id=organization_id,
        )
        org_id = organization_id or project.organization_id
        tasks = await _get_project_tasks_with_organization(client, project_id, org_id)
        if task_ids:
            selected = {str(t) for t in task_ids}
            tasks = [t for t in tasks if t.uid in selected]
        if task_limit is not None:
            if task_limit < 0:
                raise ValueError('task_limit must be non-negative')
            tasks = tasks[:task_limit]

        guard_info = await _enforce_project_analysis_guard(
            client,
            project,
            tasks,
            org_id,
            skip_guard=skip_project_analysis_guard,
            guard_max_tasks=guard_max_tasks,
            guard_max_assignments_estimate=guard_max_assignments_estimate,
        )

        selected_analyses = canonicalize_analyses(analyses)
        shared_filters = {
            'date_from': date_from,
            'date_to': date_to,
            'updated_date_from': updated_date_from,
            'updated_date_to': updated_date_to,
            'marker_ids': marker_ids,
            'item_types': list(item_types or []),
            'statuses': list(statuses or []),
            'consistency': consistency,
            'consistency_filter': consistency_filter,
            'enrich_markers_from_export': enrich_markers_from_export,
            'summary_only': summary_only,
            'max_result_preview_chars': max_result_preview_chars,
            'task_ids_filter': list(task_ids or []),
            'task_limit': task_limit,
            'skip_project_analysis_guard': skip_project_analysis_guard,
            'guard_max_tasks': guard_max_tasks,
            'guard_max_assignments_estimate': guard_max_assignments_estimate,
        }

        if summary_mode == 'rollup':
            merged_rows: List[Dict[str, Any]] = []
            tasks_summary: List[Dict[str, Any]] = []
            for task in tasks:
                ass = await client.get_task_assignments(
                    task_id=task.uid,
                    date_from=date_from,
                    date_to=date_to,
                    updated_date_from=updated_date_from,
                    updated_date_to=updated_date_to,
                    marker_ids=marker_ids,
                    item_types=list(item_types) if item_types else None,
                    statuses=list(statuses) if statuses else None,
                    consistency=consistency,
                    consistency_filter=consistency_filter,
                    organization_id=org_id,
                )
                tasks_summary.append(
                    normalize_for_mcp(
                        {
                            'task_id': task.uid,
                            'task_name': task.name,
                            'assignments_count': len(ass),
                        }
                    )
                )
                for assignment in ass:
                    row = _to_plain_dict(assignment)
                    if row.get('item_id') is not None:
                        row['item_id'] = f'{task.uid}:{row["item_id"]}'
                    row['_source_task_id'] = task.uid
                    merged_rows.append(row)

            marker_profiles = None
            if 'marker_answer_summary' in selected_analyses:
                marker_profiles = await _compose_marker_profiles_for_project(
                    client,
                    project,
                    tasks,
                    merged_rows,
                    org_id,
                    enrich_markers_from_export,
                )

            analysis = build_task_results_analysis(
                merged_rows,
                analyses=list(selected_analyses),
                output_fields=output_fields,
                top_n=top_n,
                sample_limit=sample_limit,
                min_overlap=min_overlap,
                marker_profiles=marker_profiles,
                summary_only=summary_only,
                max_result_preview_chars=max_result_preview_chars,
            )
            return {
                'entity_type': 'project_results_analysis',
                'project': _project_metadata(project),
                'summary_mode': 'rollup',
                'tasks_processed': len(tasks),
                'tasks_summary': tasks_summary,
                'filters': shared_filters,
                'project_analysis_guard': guard_info,
                **analysis,
            }

        task_payloads: List[Dict[str, Any]] = []
        for task in tasks:
            ass = await client.get_task_assignments(
                task_id=task.uid,
                date_from=date_from,
                date_to=date_to,
                updated_date_from=updated_date_from,
                updated_date_to=updated_date_to,
                marker_ids=marker_ids,
                item_types=list(item_types) if item_types else None,
                statuses=list(statuses) if statuses else None,
                consistency=consistency,
                consistency_filter=consistency_filter,
                organization_id=org_id,
            )
            marker_profiles = None
            if 'marker_answer_summary' in selected_analyses:
                marker_profiles = await _compose_marker_profiles_for_task(
                    client,
                    task,
                    ass,
                    org_id,
                    enrich_markers_from_export,
                )
            task_payloads.append(
                normalize_for_mcp(
                    {
                        'task': _task_metadata(task),
                        'assignments_count': len(ass),
                        'analysis': build_task_results_analysis(
                            ass,
                            analyses=list(selected_analyses),
                            output_fields=output_fields,
                            top_n=top_n,
                            sample_limit=sample_limit,
                            min_overlap=min_overlap,
                            marker_profiles=marker_profiles,
                            summary_only=summary_only,
                            max_result_preview_chars=max_result_preview_chars,
                        ),
                    }
                )
            )

        return {
            'entity_type': 'project_results_analysis',
            'project': _project_metadata(project),
            'summary_mode': 'per_task',
            'tasks_processed': len(tasks),
            'filters': shared_filters,
            'project_analysis_guard': guard_info,
            'tasks': task_payloads,
        }
