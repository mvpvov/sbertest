import logging
import os
from contextlib import asynccontextmanager
from dataclasses import is_dataclass
from datetime import date, datetime
from enum import Enum
from pathlib import Path
from typing import Any, AsyncIterator, Dict, Iterable, List, Optional, Sequence, Tuple

import jwt
import yaml
from mcp.server.auth.middleware.auth_context import get_access_token  # pylint: disable=import-error

from crowd_sdk import DEFAULT_CONFIG
from crowd_sdk.core.utils.common import chunks, dataclass_to_dict, envsubst
from crowd_sdk.tagme.config import STANDS_URLS_DICT, TagmeConfig
from crowd_sdk.tagme.http_client.base_client import TagmeClient
from crowd_sdk.tagme.http_client.client import TagmeClientAdvanced
from crowd_sdk.tagme.http_client.datacls import (
    MarkersStatistic,
    Project,
    ProjectStatistic,
    TaskData,
    TasksStatistic,
    TaskStatisticsItem,
    TaskStats,
)
from crowd_sdk.tagme.types import StatsOutputType

logger = logging.getLogger(__name__)
DEFAULT_CONFIG_ENV_VARS = ('CROWD_MCP_CONFIG', 'CROWD_CONFIG')
ENV_CONFIG_VARS = {
    'stand': ('CROWD_MCP_TAGME_STAND', 'TAGME_STAND'),
    'url': ('CROWD_MCP_TAGME_URL', 'TAGME_URL'),
    'auth_url': ('CROWD_MCP_TAGME_AUTH_URL', 'TAGME_AUTH_URL'),
    'realm': ('CROWD_MCP_TAGME_REALM', 'TAGME_REALM'),
    'client_id': ('CROWD_MCP_TAGME_CLIENT_ID', 'TAGME_CLIENT_ID'),
    'org': ('CROWD_MCP_TAGME_ORG', 'TAGME_ORG'),
}
QUALITY_OUTPUTS = {
    StatsOutputType.TASK.value: StatsOutputType.TASK,
    StatsOutputType.ITEM.value: StatsOutputType.ITEM,
}
MARKER_SORT_FIELDS = {
    'avg_quality',
    'avg_consistency',
    'marked',
    'accepted',
    'rejected',
    'submitted',
    'skipped',
    'expired',
    'count_quality',
    'avg_time',
    'overall_time',
    'sum_price',
    'blocked_price',
    'rejected_price',
    'bonus_plus_penalty',
}


def _mean(values: Iterable[Optional[float]]) -> Optional[float]:
    clean_values = [value for value in values if value is not None]
    if not clean_values:
        return None
    return round(sum(clean_values) / len(clean_values), 4)


def _sum_int(values: Iterable[Optional[float]]) -> int:
    return sum(int(value or 0) for value in values)


def _percent(numerator: Optional[int], denominator: Optional[int]) -> Optional[float]:
    if numerator is None or denominator is None:
        return None
    if denominator <= 0:
        return None
    return round(numerator / denominator * 100, 2)


def normalize_for_mcp(value: Any) -> Any:
    if is_dataclass(value):
        return normalize_for_mcp(dataclass_to_dict(value, serialize_nulls=True))
    if isinstance(value, dict):
        return {key: normalize_for_mcp(item) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize_for_mcp(item) for item in value]
    if isinstance(value, tuple):
        return [normalize_for_mcp(item) for item in value]
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    return value


def _env_value(*names: str) -> Optional[str]:
    for name in names:
        value = os.getenv(name)
        if value:
            return value
    return None


def _resolve_config_path(config_path: Optional[str] = None) -> Tuple[Path, bool]:
    raw_path = config_path
    explicit_path = config_path is not None
    if raw_path is None:
        for env_name in DEFAULT_CONFIG_ENV_VARS:
            raw_path = os.getenv(env_name)
            if raw_path:
                explicit_path = True
                break
    raw_path = raw_path or str(DEFAULT_CONFIG)

    return Path(raw_path).expanduser(), explicit_path


def resolve_config_path(config_path: Optional[str] = None) -> Path:
    path, _ = _resolve_config_path(config_path)
    if not path.is_file():
        raise ValueError(
            f'Config path does not exist: {path}. ' 'Set CROWD_MCP_CONFIG/CROWD_CONFIG or pass config_path explicitly.'
        )
    return path


def load_tagme_config_from_env() -> Dict[str, str]:
    config_data = {
        field: value for field, env_names in ENV_CONFIG_VARS.items() for value in [_env_value(*env_names)] if value
    }
    if config_data.get('stand') or (config_data.get('url') and config_data.get('auth_url')):
        return config_data

    raise ValueError(
        'Missing TagMe config for MCP. Set CROWD_MCP_CONFIG/CROWD_CONFIG, '
        'or set CROWD_MCP_TAGME_STAND/TAGME_STAND, '
        'or set CROWD_MCP_TAGME_URL and CROWD_MCP_TAGME_AUTH_URL.'
    )


def _token_subject(token: Optional[str]) -> Optional[str]:
    if not token:
        return None
    try:
        payload = jwt.decode(token, options={'verify_signature': False, 'verify_exp': False})
    except jwt.PyJWTError:
        return None
    return payload.get('sub')


def get_request_tagme_token() -> Optional[str]:
    try:
        access_token = get_access_token()
    except LookupError:
        logger.info('MCP auth context is not available for this request')
        return None

    token = access_token.token if access_token is not None else None
    logger.info('MCP request token present=%s subject=%s', bool(token), _token_subject(token))
    return token


def inspect_tagme_sdk_access(config_path: Optional[str] = None) -> Dict[str, Any]:
    path, explicit_path = _resolve_config_path(config_path)
    config_data: Dict[str, Any] = {}
    config_source = 'env'
    config_error = None

    if path.is_file():
        config_source = str(path)
        file_data = yaml.safe_load(envsubst(path.read_text(encoding='utf-8'))) or {}
        section = file_data.get('tagme')
        if isinstance(section, dict):
            config_data = dict(section)
        else:
            config_error = f'Missing "tagme" section in config: {path}'
    elif explicit_path:
        config_source = str(path)
        config_error = f'Config path does not exist: {path}'
    else:
        try:
            config_data = load_tagme_config_from_env()
        except ValueError as exp:
            config_error = str(exp)

    token = get_request_tagme_token()

    return {
        'sdk_import_ok': True,
        'tagme_client': 'TagmeClientAdvanced',
        'config_source': config_source,
        'config_error': config_error,
        'has_routing_config': bool(
            config_data.get('stand') or (config_data.get('url') and config_data.get('auth_url'))
        ),
        'stand': config_data.get('stand'),
        'url': config_data.get('url'),
        'auth_url': config_data.get('auth_url'),
        'org': config_data.get('org'),
        'request_token_present': bool(token),
        'request_token_subject': _token_subject(token),
        'available_stands_count': len(STANDS_URLS_DICT),
    }


def load_tagme_config(config_path: Optional[str] = None, token: Optional[str] = None) -> TagmeConfig:
    path, explicit_path = _resolve_config_path(config_path)
    if path.is_file():
        file_data = yaml.safe_load(envsubst(path.read_text(encoding='utf-8'))) or {}
        section = file_data.get('tagme')
        if not isinstance(section, dict):
            raise ValueError(f'Missing "tagme" section in config: {path}')
        config_data = dict(section)
    elif explicit_path:
        raise ValueError(
            f'Config path does not exist: {path}. ' 'Set CROWD_MCP_CONFIG/CROWD_CONFIG or pass config_path explicitly.'
        )
    else:
        config_data = load_tagme_config_from_env()

    if token:
        config_data['token'] = token
    if config_data.get('token'):
        config_data.setdefault('user', '__token__')
        config_data.setdefault('password', '__token__')
    elif not config_data.get('client_secret') and not config_data.get('client_cert_path'):
        config_data['user'] = config_data.get('user') or os.getenv('TAGME_USERNAME')
        config_data['password'] = config_data.get('password') or os.getenv('TAGME_PASSWORD')
        if not config_data.get('user') or not config_data.get('password'):
            raise ValueError(
                'Missing TagMe credentials for MCP. '
                'Provide tagme.user/password in config or TAGME_USERNAME/TAGME_PASSWORD env vars.'
            )

    config = TagmeConfig(**config_data)
    logger.info(
        'Loaded TagMe config source=%s stand=%s url=%s auth_url=%s token_present=%s',
        str(path) if path.is_file() else 'env',
        config.stand,
        config.url,
        config.auth_url,
        bool(config.token),
    )
    return config


@asynccontextmanager
async def open_tagme_client(config_path: Optional[str] = None) -> AsyncIterator[TagmeClientAdvanced]:
    logger.info('Opening TagMe client config_path=%s', config_path)
    client = TagmeClientAdvanced(config=load_tagme_config(config_path, token=get_request_tagme_token()))
    try:
        logger.info('TagMe client opened')
        yield client
    finally:
        logger.info('Closing TagMe client')
        await client.close()


def resolve_tagme_auth_credentials(
    config_path: Optional[str] = None,
    *,
    config: Optional[TagmeConfig] = None,
) -> Tuple[str, str]:
    """Return (auth_type, access_token) for Tagme HTTP APIs (LLM proxy, gen-ui, etc.).

    Uses MCP request bearer when HTTP transport provides it; otherwise marker token from
    Tagme config (stdio: user/password or token in CROWD_MCP_CONFIG / env).
    """
    if config is None:
        config = load_tagme_config(config_path, token=get_request_tagme_token())
    client = TagmeClient(config=config)
    auth_type = client.auth_type
    token = client.token_marker.get_access_token()
    logger.info(
        'Resolved Tagme auth credentials auth_type=%s token_present=%s subject=%s',
        auth_type,
        bool(token),
        _token_subject(token),
    )
    return auth_type, token


async def resolve_organization_id(
    client: TagmeClientAdvanced,
    organization_id: Optional[str] = None,
    project_ids: Optional[Sequence[str]] = None,
    task_ids: Optional[Sequence[str]] = None,
) -> Optional[str]:
    if organization_id:
        return organization_id
    if project_ids:
        project = await client.get_project(project_ids[0])
        return project.organization_id
    if task_ids:
        task = await client.get_task(task_ids[0])
        return task.organization_id
    return None


async def get_project_task_statistics(
    client: TagmeClientAdvanced,
    project_id: str,
    organization_id: Optional[str] = None,
) -> List[TaskStatisticsItem]:
    tasks = await client.get_tasks_advanced(
        project_ids=[project_id], organization_id=organization_id, with_payload=False
    )
    if not tasks:
        return []

    task_statistics: List[TaskStatisticsItem] = []
    for task_ids_chunk in chunks([task.uid for task in tasks], 100):
        task_statistics.extend(
            await client.client.get_list_task_statictics(
                task_ids=task_ids_chunk,
                organization_id=organization_id,
            )
        )
    return task_statistics


def summarize_quality_records(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        'records_count': len(records),
        'average_quality': _mean(record.get('quality') for record in records),
        'average_consistency': _mean(record.get('consistency') for record in records),
        'total_reward': round(sum((record.get('reward') or 0) for record in records), 4),
        'incomplete_records': sum(0 if record.get('complete_data', True) else 1 for record in records),
    }


def summarize_project_export_stats(task_rows: List[TasksStatistic]) -> Dict[str, Any]:
    return {
        'rows_count': len(task_rows),
        'count_items': _sum_int(row.count_items for row in task_rows),
        'completed_items': _sum_int(row.completed_items for row in task_rows),
        'count_assignments': _sum_int(row.count_assignments for row in task_rows),
        'completed_assignments': _sum_int(row.completed_assignments for row in task_rows),
        'accepted_assignments': _sum_int(row.accepted_assignments for row in task_rows),
        'rejected_assignments': _sum_int(row.rejected_assignments for row in task_rows),
        'submitted_assignments': _sum_int(row.submitted_assignments for row in task_rows),
        'skipped_assignments': _sum_int(row.skipped_assignments for row in task_rows),
        'expired_assignments': _sum_int(row.expired_assignments for row in task_rows),
        'average_quality': _mean(row.avg_quality for row in task_rows),
        'average_consistency': _mean(row.avg_consistency for row in task_rows),
        'average_time': _mean(row.avg_time for row in task_rows),
        'sum_price': round(sum((row.sum_price or 0) for row in task_rows), 4),
        'blocked_price': round(sum((row.blocked_price or 0) for row in task_rows), 4),
    }


def summarize_task_statistics_items(task_statistics: List[TaskStatisticsItem]) -> Dict[str, Any]:
    return {
        'tasks_count': len(task_statistics),
        'objects_count': _sum_int(item.objects_count for item in task_statistics),
        'marked_count': _sum_int(item.marked_count for item in task_statistics),
        'total_objects_count': _sum_int(item.total_objects_count for item in task_statistics),
        'total_marked_objects_count': _sum_int(item.total_marked_objects_count for item in task_statistics),
        'total_skipped_objects_count': _sum_int(item.total_skipped_objects_count for item in task_statistics),
        'total_expired_objects_count': _sum_int(item.total_expired_objects_count for item in task_statistics),
        'total_accepted_objects_count': _sum_int(item.total_accepted_objects_count for item in task_statistics),
        'total_rejected_objects_count': _sum_int(item.total_rejected_objects_count for item in task_statistics),
        'total_submitted_objects_count': _sum_int(item.total_submitted_objects_count for item in task_statistics),
        'total_marked_time': round(sum(item.total_marked_time for item in task_statistics), 4),
        'average_overlap': _mean(item.current_overlap for item in task_statistics),
    }


def parse_marker_sort_field(sort_by: str) -> str:
    if sort_by not in MARKER_SORT_FIELDS:
        raise ValueError(f'Unsupported marker sort field "{sort_by}". Use one of: {sorted(MARKER_SORT_FIELDS)}')
    return sort_by


def date_to_iso_day(value: Optional[Any]) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return str(value)[:10]


def marker_directory_from_stat_rows(rows: List[MarkersStatistic]) -> Dict[str, Dict[str, Optional[str]]]:
    """Map marker_id to fio/email from project statistics export rows."""
    directory: Dict[str, Dict[str, Optional[str]]] = {}
    for row in rows:
        marker_id = row.marker_id
        entry = directory.setdefault(marker_id, {'fio': None, 'email': None})
        if row.fio and not entry['fio']:
            entry['fio'] = row.fio
        if row.email and not entry['email']:
            entry['email'] = row.email
    for marker_id, entry in directory.items():
        entry['display_name'] = entry['fio'] or entry['email'] or marker_id
    return directory


def aggregate_marker_statistics(rows: List[MarkersStatistic]) -> List[Dict[str, Any]]:
    aggregated: Dict[str, Dict[str, Any]] = {}

    for row in rows:
        marker_id = row.marker_id
        entry = aggregated.setdefault(
            marker_id,
            {
                'marker_id': marker_id,
                'display_name': row.fio or row.email or marker_id,
                'fio': row.fio,
                'email': row.email,
                'rows_count': 0,
                'marked': 0,
                'accepted': 0,
                'rejected': 0,
                'submitted': 0,
                'skipped': 0,
                'expired': 0,
                'count_quality': 0,
                'overall_time': 0.0,
                'sum_price': 0.0,
                'blocked_price': 0.0,
                'rejected_price': 0.0,
                'bonus_plus_penalty': 0.0,
                'begin': None,
                'end': None,
                '_avg_time_sum': 0.0,
                '_avg_time_weight': 0,
                '_quality_sum': 0.0,
                '_quality_weight': 0,
                '_consistency_sum': 0.0,
                '_consistency_weight': 0,
            },
        )

        if row.fio and not entry['fio']:
            entry['fio'] = row.fio
        if row.email and not entry['email']:
            entry['email'] = row.email
        entry['display_name'] = entry['fio'] or entry['email'] or marker_id

        entry['rows_count'] += 1
        entry['marked'] += row.marked or 0
        entry['accepted'] += row.accepted or 0
        entry['rejected'] += row.rejected or 0
        entry['submitted'] += row.submitted or 0
        entry['skipped'] += row.skipped or 0
        entry['expired'] += row.expired or 0
        entry['count_quality'] += row.count_quality or 0
        entry['overall_time'] += row.overall_time or 0.0
        entry['sum_price'] += row.sum_price or 0.0
        entry['blocked_price'] += row.blocked_price or 0.0
        entry['rejected_price'] += row.rejected_price or 0.0
        entry['bonus_plus_penalty'] += row.bonus_plus_penalty or 0.0

        if row.begin and (entry['begin'] is None or row.begin < entry['begin']):
            entry['begin'] = row.begin
        if row.end and (entry['end'] is None or row.end > entry['end']):
            entry['end'] = row.end

        if row.avg_time is not None:
            avg_time_weight = row.marked or row.accepted or row.submitted or 1
            entry['_avg_time_sum'] += row.avg_time * avg_time_weight
            entry['_avg_time_weight'] += avg_time_weight

        if row.avg_quality is not None:
            quality_weight = row.count_quality or 1
            entry['_quality_sum'] += row.avg_quality * quality_weight
            entry['_quality_weight'] += quality_weight

        if row.avg_consistency is not None:
            entry['_consistency_sum'] += row.avg_consistency
            entry['_consistency_weight'] += 1

    result: List[Dict[str, Any]] = []
    for entry in aggregated.values():
        quality_weight = entry.pop('_quality_weight')
        quality_sum = entry.pop('_quality_sum')
        avg_time_weight = entry.pop('_avg_time_weight')
        avg_time_sum = entry.pop('_avg_time_sum')
        consistency_weight = entry.pop('_consistency_weight')
        consistency_sum = entry.pop('_consistency_sum')

        if entry['count_quality'] == 0 and quality_weight:
            entry['count_quality'] = quality_weight

        entry['avg_quality'] = round(quality_sum / quality_weight, 4) if quality_weight else None
        entry['avg_time'] = round(avg_time_sum / avg_time_weight, 4) if avg_time_weight else None
        entry['avg_consistency'] = round(consistency_sum / consistency_weight, 4) if consistency_weight else None
        entry['overall_time'] = round(entry['overall_time'], 4)
        entry['sum_price'] = round(entry['sum_price'], 4)
        entry['blocked_price'] = round(entry['blocked_price'], 4)
        entry['rejected_price'] = round(entry['rejected_price'], 4)
        entry['bonus_plus_penalty'] = round(entry['bonus_plus_penalty'], 4)
        entry['acceptance_rate'] = _percent(entry['accepted'], entry['marked'])
        entry['rejection_rate'] = _percent(entry['rejected'], entry['marked'])
        result.append(entry)

    return result


def filter_marker_statistics(
    marker_stats: List[Dict[str, Any]],
    marker_ids: Optional[Sequence[str]] = None,
    min_marked: int = 0,
    min_quality_count: int = 0,
    include_without_quality: bool = True,
) -> List[Dict[str, Any]]:
    allowed_marker_ids = set(marker_ids) if marker_ids else None
    filtered: List[Dict[str, Any]] = []

    for item in marker_stats:
        if (
            allowed_marker_ids is not None
            and item['marker_id'] not in allowed_marker_ids  # pylint: disable=unsupported-membership-test
        ):
            continue
        if item['marked'] < min_marked:
            continue
        if item['count_quality'] < min_quality_count:
            continue
        if not include_without_quality and item.get('avg_quality') is None:
            continue
        filtered.append(item)

    return filtered


def sort_marker_statistics(
    marker_stats: List[Dict[str, Any]],
    sort_by: str,
    sort_order: str = 'desc',
) -> List[Dict[str, Any]]:
    reverse = sort_order == 'desc'
    present = [item for item in marker_stats if item.get(sort_by) is not None]
    missing = [item for item in marker_stats if item.get(sort_by) is None]

    present.sort(
        key=lambda item: (
            item[sort_by],
            item.get('marked', 0),
            item.get('marker_id', ''),
        ),
        reverse=reverse,
    )
    missing.sort(key=lambda item: (item.get('marked', 0), item.get('marker_id', '')), reverse=True)
    return present + missing


def summarize_marker_statistics(marker_stats: List[Dict[str, Any]], sort_by: str) -> Dict[str, Any]:
    top_items = marker_stats[:3]
    summary = {
        'markers_count': len(marker_stats),
        'average_quality': _mean(item.get('avg_quality') for item in marker_stats),
        'average_consistency': _mean(item.get('avg_consistency') for item in marker_stats),
        'total_marked': _sum_int(item.get('marked') for item in marker_stats),
        'total_accepted': _sum_int(item.get('accepted') for item in marker_stats),
        'total_rejected': _sum_int(item.get('rejected') for item in marker_stats),
        'top_markers': [
            {
                'marker_id': item['marker_id'],
                'display_name': item['display_name'],
                sort_by: item.get(sort_by),
            }
            for item in top_items
        ],
    }

    if top_items:
        top_preview = ', '.join(f'{item["display_name"]} ({sort_by}={item.get(sort_by)})' for item in top_items)
        summary['text'] = f'Top markers by {sort_by}: {top_preview}'  # type: ignore[assignment]
    else:
        summary['text'] = 'No marker statistics matched the requested filters.'  # type: ignore[assignment]

    return summary


def build_project_alerts(
    project_stats: ProjectStatistic,
    task_statistics_summary: Dict[str, Any],
    quality_summary: Optional[Dict[str, Any]],
) -> List[str]:
    alerts: List[str] = []
    if (project_stats.objects_count or 0) == 0:
        alerts.append('project_empty')
    if (project_stats.marked_count or 0) == 0 and (project_stats.objects_count or 0) > 0:
        alerts.append('no_markup_yet')
    if quality_summary is None or quality_summary.get('average_quality') is None:
        alerts.append('no_quality_yet')
    elif quality_summary['average_quality'] < 0.8:
        alerts.append('low_quality')
    if task_statistics_summary.get('total_rejected_objects_count', 0) > 0:
        rejected_ratio = _percent(
            task_statistics_summary['total_rejected_objects_count'],
            task_statistics_summary.get('total_marked_objects_count'),
        )
        if rejected_ratio and rejected_ratio >= 20:
            alerts.append('many_rejections')
    return alerts


def build_task_alerts(task_stats: TaskStats, quality_summary: Optional[Dict[str, Any]]) -> List[str]:
    alerts: List[str] = []
    if task_stats.objects_count == 0:
        alerts.append('task_empty')
    if task_stats.marked_count == 0 and task_stats.objects_count > 0:
        alerts.append('no_markup_yet')
    if quality_summary is None or quality_summary.get('average_quality') is None:
        alerts.append('no_quality_yet')
    elif quality_summary['average_quality'] < 0.8:
        alerts.append('low_quality')
    rejected_ratio = _percent(task_stats.total_rejected_objects_count, task_stats.total_marked_objects_count)
    if rejected_ratio and rejected_ratio >= 20:
        alerts.append('many_rejections')
    return alerts


def build_project_summary_text(
    project: Project,
    project_stats: ProjectStatistic,
    task_statistics_summary: Dict[str, Any],
    quality_summary: Optional[Dict[str, Any]],
) -> str:
    progress_percent = _percent(project_stats.marked_count, project_stats.objects_count)
    progress_label = f'{progress_percent}%' if progress_percent is not None else 'n/a'
    parts = [
        f'Project "{project.name}" status={project_stats.status or "unknown"}',
        f'marked={project_stats.marked_count or 0}/{project_stats.objects_count or 0}',
        f'progress={progress_label}',
        f'tasks={project_stats.tasks_count or task_statistics_summary.get("tasks_count", 0)}',
        f'active_markers={project_stats.active_marker_count or 0}',
    ]
    if quality_summary and quality_summary.get('average_quality') is not None:
        parts.append(f'avg_quality={quality_summary["average_quality"]}')
    if quality_summary and quality_summary.get('average_consistency') is not None:
        parts.append(f'avg_consistency={quality_summary["average_consistency"]}')
    return ', '.join(parts)


def build_task_summary_text(
    task: TaskData,
    task_stats: TaskStats,
    quality_summary: Optional[Dict[str, Any]],
) -> str:
    progress_percent = _percent(task_stats.marked_count, task_stats.objects_count)
    progress_label = f'{progress_percent}%' if progress_percent is not None else 'n/a'
    parts = [
        f'Task "{task.name}" state={normalize_for_mcp(task.state)}',
        f'marked={task_stats.marked_count}/{task_stats.objects_count}',
        f'progress={progress_label}',
        f'overlap={task_stats.current_overlap}',
        f'active_markers={task_stats.active_markers}',
    ]
    if quality_summary and quality_summary.get('average_quality') is not None:
        parts.append(f'avg_quality={quality_summary["average_quality"]}')
    if quality_summary and quality_summary.get('average_consistency') is not None:
        parts.append(f'avg_consistency={quality_summary["average_consistency"]}')
    return ', '.join(parts)


def normalize_quality_output(
    quality_output: List[Any],
    output_type: StatsOutputType,
    limit: Optional[int] = None,
) -> Dict[str, Any]:
    if output_type == StatsOutputType.ITEM:
        flattened_records = [normalize_for_mcp(item) for item_group in quality_output for item in item_group]
    else:
        flattened_records = [normalize_for_mcp(item) for item in quality_output]

    limited_records = flattened_records[:limit] if limit is not None else flattened_records
    return {
        'results': limited_records,
        'total_results': len(flattened_records),
        'returned_results': len(limited_records),
        'summary': summarize_quality_records(flattened_records),
    }


def parse_quality_output(output: str) -> StatsOutputType:
    try:
        return QUALITY_OUTPUTS[output]
    except KeyError as exc:
        raise ValueError(f'Unsupported quality output "{output}". Use one of: {sorted(QUALITY_OUTPUTS)}') from exc
