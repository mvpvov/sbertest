# pylint: disable=line-too-long

import logging
import time
from datetime import datetime
from typing import Any, Dict, Literal, Optional, Sequence

from crowd_sdk.mcp.statistic._instruction_analysis import (
    load_marker_instruction_text,
    method_forms_for_mcp,
    summarize_marker_instruction,
    truncate_instruction,
)
from crowd_sdk.mcp.statistic._tagme_stats import (
    aggregate_marker_statistics,
    build_project_alerts,
    build_project_summary_text,
    build_task_alerts,
    build_task_summary_text,
    date_to_iso_day,
    filter_marker_statistics,
    normalize_for_mcp,
    normalize_quality_output,
    open_tagme_client,
    parse_marker_sort_field,
    parse_quality_output,
    resolve_organization_id,
    sort_marker_statistics,
    summarize_marker_statistics,
    summarize_project_export_stats,
    summarize_task_statistics_items,
)
from crowd_sdk.mcp.tools._helpers import (
    _get_project_stats_with_organization,
    _get_project_task_statistics_with_organization,
    _get_project_tasks_with_organization,
    _get_project_with_organization,
    _infer_project_marker_stats_range,
    _progress_block,
    _project_metadata,
    _task_metadata,
)

logger = logging.getLogger(__name__)


async def get_marker_performance_stats(  # pylint: disable=R0913
    task_id: Optional[str] = None,
    project_id: Optional[str] = None,
    organization_id: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    marker_ids: Optional[Sequence[str]] = None,
    sort_by: str = 'avg_quality',
    sort_order: str = 'desc',
    limit: int = 20,
    min_marked: int = 0,
    min_quality_count: int = 0,
    include_without_quality: bool = True,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Таблица разметчиков из **экспорта статистики MARKERS** (агрегаты по периоду).

    Когда вызывать: нужен рейтинг/сортировка исполнителей по avg_quality, объёму marked, avg_time и т.п.;
    ровно **один** из scope: `task_id` **или** `project_id`; даты можно не задавать (возьмутся из задачи/проекта).

    Не вызывать для: построчного разбора ответов и control → **analyze_task_results**; общего дашборда проекта
    → **get_project_stats** или **get_annotation_summary**.

    Возвращает: entity_type (task|project), task или project метаданные, organization_id, time_range, filters,
    sorting, total_rows, total_markers, matched_markers, returned_markers, summary, items[] (строки по маркеру).
    """
    if bool(task_id) == bool(project_id):
        raise ValueError('Specify exactly one of task_id or project_id')
    if bool(from_date) != bool(to_date):
        raise ValueError('Specify both from_date and to_date, or neither of them')
    if sort_order not in {'asc', 'desc'}:
        raise ValueError('sort_order must be "asc" or "desc"')
    if limit <= 0:
        raise ValueError('limit must be greater than 0')
    if min_marked < 0 or min_quality_count < 0:
        raise ValueError('min_marked and min_quality_count must be non-negative')

    sort_by = parse_marker_sort_field(sort_by)

    async with open_tagme_client(config_path) as client:
        inferred_range = False
        scope_metadata: Dict[str, Any]
        resolved_project_id = project_id
        resolved_organization_id = organization_id

        if task_id:
            task = await client.get_task(task_id=task_id, organization_id=organization_id)
            resolved_project_id = task.project_id
            resolved_organization_id = await resolve_organization_id(
                client,
                organization_id=organization_id,
                task_ids=(task_id,),
            )

            if not from_date and not to_date:
                inferred_range = True
                from_date = date_to_iso_day(task.start_date or task.created_date or task.update_date)
                to_date = date_to_iso_day(task.finished_date or task.update_date or datetime.utcnow())

            scope_metadata = {
                'entity_type': 'task',
                'task': _task_metadata(task),
                'project_id': resolved_project_id,
            }
        else:
            project = await _get_project_with_organization(
                client,
                project_id=project_id,  # type: ignore[arg-type]
                with_tasks_count=True,
                organization_id=organization_id,
            )
            resolved_organization_id = organization_id or project.organization_id

            if not from_date and not to_date:
                inferred_range = True
                tasks = await _get_project_tasks_with_organization(
                    client,
                    project_id=project_id,  # type: ignore[arg-type]
                    organization_id=resolved_organization_id,
                )
                from_date, to_date = _infer_project_marker_stats_range(project, tasks)

            scope_metadata = {
                'entity_type': 'project',
                'project': _project_metadata(project),
            }

        if not resolved_project_id or not from_date or not to_date:
            raise ValueError('Unable to resolve project_id and time range for marker statistics')

        _, marker_rows = await client.export_project_stats(
            project_id=resolved_project_id,
            from_date=from_date,
            to_date=to_date,
            organization_id=resolved_organization_id,
        )
        if task_id:
            marker_rows = [row for row in marker_rows if row.task_id == task_id]

        aggregated_rows = aggregate_marker_statistics(marker_rows)
        filtered_rows = filter_marker_statistics(
            aggregated_rows,
            marker_ids=marker_ids,
            min_marked=min_marked,
            min_quality_count=min_quality_count,
            include_without_quality=include_without_quality,
        )
        sorted_rows = sort_marker_statistics(filtered_rows, sort_by=sort_by, sort_order=sort_order)
        limited_rows = sorted_rows[:limit]

        return {
            **scope_metadata,
            'organization_id': resolved_organization_id,
            'time_range': {
                'from_date': from_date,
                'to_date': to_date,
                'inferred': inferred_range,
            },
            'filters': {
                'marker_ids': list(marker_ids or []),
                'min_marked': min_marked,
                'min_quality_count': min_quality_count,
                'include_without_quality': include_without_quality,
            },
            'sorting': {
                'sort_by': sort_by,
                'sort_order': sort_order,
                'limit': limit,
            },
            'total_rows': len(marker_rows),
            'total_markers': len(aggregated_rows),
            'matched_markers': len(filtered_rows),
            'returned_markers': len(limited_rows),
            'summary': summarize_marker_statistics(sorted_rows, sort_by=sort_by),
            'items': normalize_for_mcp(limited_rows),
        }


async def get_project_stats(
    project_id: str,
    organization_id: Optional[str] = None,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Агрегированная **статистика проекта** с API: прогресс, задачи, статусы объектов (без назначений).

    Когда вызывать: обзор проекта целиком, сколько задач, сколько принято/отклонено, сводка по задачам,
    текстовый summary без глубокого разбора.

    Не вызывать для: содержимого ответов разметчиков → **analyze_project_results** / **analyze_task_results**;
    качества по API quality stats → **get_project_quality_stats**; дашборд с алертами по одному scope →
    **get_annotation_summary** (если нужен именно смешанный срез с quality и периодом).

    Возвращает: entity_type, project, snapshot, progress, workload, status_breakdown, task_statistics_summary, summary.
    """
    async with open_tagme_client(config_path) as client:
        project = await _get_project_with_organization(
            client,
            project_id=project_id,
            with_tasks_count=True,
            organization_id=organization_id,
        )
        project_stats = await _get_project_stats_with_organization(
            client,
            project_id=project_id,
            organization_id=organization_id,
        )
        task_statistics = await _get_project_task_statistics_with_organization(client, project_id, organization_id)
        task_statistics_summary = summarize_task_statistics_items(task_statistics)

        return {
            'entity_type': 'project',
            'project': _project_metadata(project),
            'snapshot': normalize_for_mcp(project_stats),
            'progress': _progress_block(project_stats.marked_count, project_stats.objects_count),
            'workload': {
                'tasks_count': project_stats.tasks_count,
                'active_marker_count': project_stats.active_marker_count,
                'markers_count': project_stats.markers_count,
                'pools_count': project_stats.pools_count,
            },
            'status_breakdown': {
                'accepted_objects': task_statistics_summary['total_accepted_objects_count'],
                'rejected_objects': task_statistics_summary['total_rejected_objects_count'],
                'submitted_objects': task_statistics_summary['total_submitted_objects_count'],
                'expired_objects': task_statistics_summary['total_expired_objects_count'],
                'skipped_objects': task_statistics_summary['total_skipped_objects_count'],
            },
            'task_statistics_summary': task_statistics_summary,
            'summary': build_project_summary_text(project, project_stats, task_statistics_summary, None),
        }


async def analyze_project_instructions(  # pylint: disable=R0913
    project_id: str,
    organization_id: Optional[str] = None,
    download_brief: bool = True,
    try_api_brief_fallback: bool = True,
    return_full_instruction: bool = False,
    instruction_max_chars: int = 400_000,
    instruction_preview_chars: int = 12_000,
    forms_detail: Literal['summary', 'full'] = 'summary',
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """**Инструкция для разметчиков** проекта (method.marker_brief): загрузка текста + сводка структуры и forms.

    Когда вызывать: нужно прочитать или сжато разобрать инструкцию, интерфейсные forms (specification/config),
    без выгрузки назначений.

    Загрузка: ``TagmeClientAdvanced.get_method(..., download_brief=True)`` (в т.ч. `/files/...`), при необходимости
    HTTP GET по ссылке из ``marker_brief``, затем при ошибке — ``api/v0/method/{id}/brief``.

    Не вызывать для: статистики проекта → **get_project_stats**; разметочных ответов → **analyze_project_results**.

    **Советы для агента:** по умолчанию оставляй ``forms_detail='summary'``; ``'full'`` давай только если нужны
    полные html/css/js/spec — ответ может быть очень большим. ``return_full_instruction=True`` — только при явном
    запросе полного текста инструкции.

    Возвращает: entity_type, project (с method_id), method (метаданные), brief_load (как снят brief), instruction_analysis,
    instruction (preview или полный текст при ``return_full_instruction`` и лимите), forms (summary или full).
    """
    async with open_tagme_client(config_path) as client:
        project = await _get_project_with_organization(
            client,
            project_id=project_id,
            with_tasks_count=False,
            organization_id=organization_id,
        )
        text, method, brief_meta = await load_marker_instruction_text(
            client,
            project.method_id,
            organization_id or project.organization_id,
            download_brief=download_brief,
            try_api_brief_fallback=try_api_brief_fallback,
        )

    preview_or_full, truncated, trunc_meta = truncate_instruction(
        text, max_chars=instruction_max_chars, preview_chars=instruction_preview_chars
    )
    instruction_block: Dict[str, Any] = {
        'analysis': summarize_marker_instruction(text),
        'length': trunc_meta,
        'truncated': truncated,
    }
    if return_full_instruction and not truncated:
        instruction_block['instruction_text'] = text
    else:
        instruction_block['instruction_preview'] = preview_or_full
        if return_full_instruction and truncated:
            instruction_block['hint'] = (
                'Текст длиннее instruction_max_chars; в ответе только префикс instruction_preview_chars. '
                'Увеличьте лимиты или работайте с файлом инструкции отдельно.'
            )

    method_meta = normalize_for_mcp(
        {
            'uid': method.uid,
            'name': method.name,
            'is_brief_as_url': method.is_brief_as_url,
            'brief_update_date': method.brief_update_date,
            'forms_update_date': method.forms_update_date,
        }
    )

    return {
        'entity_type': 'project_marker_instruction',
        'project': {**_project_metadata(project), 'method_id': project.method_id},
        'method': method_meta,
        'brief_load': brief_meta,
        'forms': method_forms_for_mcp(method.forms, forms_detail),
        'instruction': instruction_block,
        'related_mcp_tools': {
            'project_overview': 'get_project_stats',
            'task_markup_content': 'analyze_project_results',
        },
    }


async def get_task_stats(
    task_id: str,
    organization_id: Optional[str] = None,
    include_advanced: bool = False,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """**Снимок одной задачи** с API Tagme: прогресс, средние метрики, нагрузка (без списка назначений).

    Когда вызывать: первичный вопрос о состоянии задачи (сколько сделано, средние quality/consistency,
    сколько маркеров, `include_advanced` — доп. блок API если поддерживается).

    Не вызывать для: кто что ответил в полях result → **analyze_task_results**; сводки рисков → **analyze_fraud_risk**;
    таблицы маркеров из экспорта → **get_marker_performance_stats**.

    Возвращает: entity_type, task, snapshot, progress, workload, quality, status_breakdown, summary; опционально advanced.
    """
    started_at = time.monotonic()
    logger.info(
        'get_task_stats started task_id=%s organization_id=%s include_advanced=%s config_path=%s',
        task_id,
        organization_id,
        include_advanced,
        config_path,
    )
    async with open_tagme_client(config_path) as client:
        logger.info('get_task_stats stage=get_task start task_id=%s', task_id)
        task = await client.get_task(task_id=task_id, organization_id=organization_id)
        logger.info('get_task_stats stage=get_task done elapsed=%.3fs', time.monotonic() - started_at)

        logger.info('get_task_stats stage=get_task_stats_api start task_id=%s', task_id)
        task_stats = await client.get_task_stats(task_id=task_id, organization_id=organization_id)
        logger.info('get_task_stats stage=get_task_stats_api done elapsed=%.3fs', time.monotonic() - started_at)

        result: Dict[str, Any] = {
            'entity_type': 'task',
            'task': _task_metadata(task),
            'snapshot': normalize_for_mcp(task_stats),
            'progress': _progress_block(task_stats.marked_count, task_stats.objects_count),
            'workload': {
                'current_overlap': task_stats.current_overlap,
                'active_markers': task_stats.active_markers,
                'total_markers': task_stats.total_markers,
                'avg_object_count_marker': task_stats.avg_object_count_marker,
                'one_object_avg_time': task_stats.one_object_avg_time,
                'total_marked_time': task_stats.total_marked_time,
            },
            'quality': {
                'average_quality': task_stats.avg_quality,
                'average_consistency': task_stats.avg_consistency,
                'average_hour_profit': task_stats.avg_hour_profit,
            },
            'status_breakdown': {
                'accepted_objects': task_stats.total_accepted_objects_count,
                'rejected_objects': task_stats.total_rejected_objects_count,
                'marked_objects': task_stats.total_marked_objects_count,
                'skipped_objects': task_stats.total_skipped_objects_count,
            },
            'summary': build_task_summary_text(
                task,
                task_stats,
                {
                    'average_quality': task_stats.avg_quality,
                    'average_consistency': task_stats.avg_consistency,
                },
            ),
        }

        if include_advanced:
            logger.info('get_task_stats stage=get_task_stats_advanced start task_id=%s', task_id)
            result['advanced'] = normalize_for_mcp(
                await client.get_task_stats_advanced(task_id=task_id, organization_id=organization_id)
            )
            logger.info(
                'get_task_stats stage=get_task_stats_advanced done elapsed=%.3fs',
                time.monotonic() - started_at,
            )

        logger.info('get_task_stats finished task_id=%s elapsed=%.3fs', task_id, time.monotonic() - started_at)
        return result


async def get_project_quality_stats(  # pylint: disable=R0913
    output: str = 'task',
    organization_id: Optional[str] = None,
    project_ids: Optional[Sequence[str]] = None,
    task_ids: Optional[Sequence[str]] = None,
    limit: int = 50,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Сводка **качества** через API `get_quality_stats` по списку проектов и/или задач.

    Когда вызывать: нужна выгрузка/сводка именно quality-статистики по множеству project_ids или task_ids;
    `output` задаёт гранулярность (например, по задаче или по объекту — см. параметры клиента).

    Не вызывать для: текстового дашборда с алертами → **get_annotation_summary**; сырых назначений →
    **analyze_task_results**.

    Возвращает: нормализованные summary/tasks/items (зависит от output), output, organization_id, project_ids, task_ids.
    """
    if not project_ids and not task_ids:
        raise ValueError('Specify project_ids or task_ids for quality statistics')

    async with open_tagme_client(config_path) as client:
        output_type = parse_quality_output(output)
        resolved_organization_id = organization_id
        if resolved_organization_id is None and project_ids:
            resolved_organization_id = (
                await _get_project_with_organization(
                    client,
                    project_id=project_ids[0],
                    organization_id=organization_id,
                )
            ).organization_id
        if resolved_organization_id is None and task_ids:
            resolved_organization_id = (await client.get_task(task_ids[0])).organization_id
        if not resolved_organization_id:
            raise ValueError('organization_id is required for quality statistics')

        quality_output = [
            item
            for item in await client.get_quality_stats(
                resolved_organization_id,
                output_type,
                tuple(task_ids) if task_ids else None,
                tuple(project_ids) if project_ids else None,
            )
            if item is not None
        ]
        result = normalize_quality_output(quality_output, output_type, limit=limit)
        result.update(
            {
                'output': output,
                'organization_id': resolved_organization_id,
                'project_ids': list(project_ids or []),
                'task_ids': list(task_ids or []),
            }
        )
        return result


async def get_annotation_summary(  # pylint: disable=R0913
    project_id: Optional[str] = None,
    task_id: Optional[str] = None,
    organization_id: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    include_quality: bool = True,
    quality_limit: int = 10,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Комбинированный **дашборд** по одному project_id **или** одному task_id: метрики + текст summary + алерты.

    Когда вызывать: нужен «одним ответом» срез по проекту/задаче (snapshot, progress, workload, статусы,
    опционально quality, при заданном from_date/to_date — вырезка export + time_range_stats).

    Не вызывать для: только quality API по многим сущностям → **get_project_quality_stats**; только таблицы
    маркеров из экспорта → **get_marker_performance_stats**; разбор полей ответа → **analyze_task_results**.

    Возвращает: entity_type (project|task), project или task, snapshot, progress, workload, status_breakdown,
    quality (если include_quality), time_range_stats (если задан период), alerts, summary.
    """
    if bool(project_id) == bool(task_id):
        raise ValueError('Specify exactly one of project_id or task_id')
    if bool(from_date) != bool(to_date):
        raise ValueError('Specify both from_date and to_date, or neither of them')

    async with open_tagme_client(config_path) as client:
        if project_id:
            project = await _get_project_with_organization(
                client,
                project_id=project_id,
                with_tasks_count=True,
                organization_id=organization_id,
            )
            project_stats = await _get_project_stats_with_organization(
                client,
                project_id=project_id,
                organization_id=organization_id,
            )
            task_statistics = await _get_project_task_statistics_with_organization(client, project_id, organization_id)
            task_statistics_summary = summarize_task_statistics_items(task_statistics)

            quality_data: Optional[Dict[str, Any]] = None
            if include_quality:
                quality_output = [
                    item
                    for item in await client.get_quality_stats(
                        project.organization_id,
                        parse_quality_output('task'),
                        project_ids=(project_id,),
                    )
                    if item is not None
                ]
                quality_data = normalize_quality_output(
                    quality_output, parse_quality_output('task'), limit=quality_limit
                )

            time_range_stats = None
            if from_date and to_date:
                task_rows, marker_rows = await client.export_project_stats(
                    project_id=project_id,
                    from_date=from_date,
                    to_date=to_date,
                    organization_id=organization_id,
                )
                time_range_stats = summarize_project_export_stats(task_rows)
                time_range_stats['marker_rows_count'] = len(marker_rows)

            quality_summary = quality_data['summary'] if quality_data else None
            alerts = build_project_alerts(project_stats, task_statistics_summary, quality_summary)

            return {
                'entity_type': 'project',
                'project': _project_metadata(project),
                'snapshot': normalize_for_mcp(project_stats),
                'progress': _progress_block(project_stats.marked_count, project_stats.objects_count),
                'workload': {
                    'tasks_count': project_stats.tasks_count,
                    'active_marker_count': project_stats.active_marker_count,
                    'markers_count': project_stats.markers_count,
                    'pools_count': project_stats.pools_count,
                    'total_marked_time': task_statistics_summary['total_marked_time'],
                    'average_overlap': task_statistics_summary['average_overlap'],
                },
                'status_breakdown': {
                    'accepted_objects': task_statistics_summary['total_accepted_objects_count'],
                    'rejected_objects': task_statistics_summary['total_rejected_objects_count'],
                    'submitted_objects': task_statistics_summary['total_submitted_objects_count'],
                    'expired_objects': task_statistics_summary['total_expired_objects_count'],
                    'skipped_objects': task_statistics_summary['total_skipped_objects_count'],
                },
                'quality': quality_data,
                'time_range_stats': time_range_stats,
                'alerts': alerts,
                'summary': build_project_summary_text(project, project_stats, task_statistics_summary, quality_summary),
            }

        task = await client.get_task(task_id=task_id, organization_id=organization_id)
        task_stats = await client.get_task_stats(task_id=task_id, organization_id=organization_id)

        quality_data = None
        if include_quality:
            quality_output = [
                item
                for item in await client.get_quality_stats(
                    task.organization_id,
                    parse_quality_output('task'),
                    task_ids=(task_id,),
                )
                if item is not None
            ]
            quality_data = normalize_quality_output(quality_output, parse_quality_output('task'), limit=quality_limit)

        time_range_stats = None
        if from_date and to_date:
            task_rows, marker_rows = await client.export_project_stats(
                project_id=task.project_id,
                from_date=from_date,
                to_date=to_date,
                organization_id=organization_id or task.organization_id,
            )
            filtered_rows = [row for row in task_rows if row.task_id == task_id]
            filtered_markers = [row for row in marker_rows if row.task_id == task_id]
            time_range_stats = summarize_project_export_stats(filtered_rows)
            time_range_stats['marker_rows_count'] = len(filtered_markers)

        quality_summary = (
            quality_data['summary']
            if quality_data
            else {
                'average_quality': task_stats.avg_quality,
                'average_consistency': task_stats.avg_consistency,
            }
        )
        alerts = build_task_alerts(task_stats, quality_summary)

        return {
            'entity_type': 'task',
            'task': _task_metadata(task),
            'snapshot': normalize_for_mcp(task_stats),
            'progress': _progress_block(task_stats.marked_count, task_stats.objects_count),
            'workload': {
                'current_overlap': task_stats.current_overlap,
                'active_markers': task_stats.active_markers,
                'total_markers': task_stats.total_markers,
                'avg_object_count_marker': task_stats.avg_object_count_marker,
                'one_object_avg_time': task_stats.one_object_avg_time,
                'total_marked_time': task_stats.total_marked_time,
            },
            'status_breakdown': {
                'accepted_objects': task_stats.total_accepted_objects_count,
                'rejected_objects': task_stats.total_rejected_objects_count,
                'marked_objects': task_stats.total_marked_objects_count,
                'skipped_objects': task_stats.total_skipped_objects_count,
            },
            'quality': quality_data
            or {
                'summary': {
                    'average_quality': task_stats.avg_quality,
                    'average_consistency': task_stats.avg_consistency,
                }
            },
            'time_range_stats': time_range_stats,
            'alerts': alerts,
            'summary': build_task_summary_text(task, task_stats, quality_summary),
        }
