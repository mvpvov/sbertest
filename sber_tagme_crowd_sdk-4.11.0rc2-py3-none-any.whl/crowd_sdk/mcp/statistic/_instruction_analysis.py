"""Загрузка текста инструкции разметчика (method.marker_brief) и лёгкая структурная сводка для MCP."""

import asyncio
import re
from typing import Any, Dict, Optional, Tuple

import aiohttp

from crowd_sdk.core.utils.jwt_client import ResponseType
from crowd_sdk.mcp.statistic._results_analysis import _to_plain_dict
from crowd_sdk.tagme.http_client.client import TagmeClientAdvanced
from crowd_sdk.tagme.http_client.datacls import MethodData, MethodForms

_PLAIN_FROM_HTML_RE = re.compile(r'<[^>]+>')
_WS_RE = re.compile(r'\s+')


def summarize_marker_instruction(raw: Optional[str]) -> Dict[str, Any]:
    """Объём и грубая структура HTML/текста инструкции (без внешних зависимостей)."""
    if not raw:
        return {
            'empty': True,
            'chars_total': 0,
            'plain_text_preview': '',
        }
    looks_html = bool(re.search(r'<[a-zA-Z][^>]*>', raw))
    plain = _WS_RE.sub(' ', _PLAIN_FROM_HTML_RE.sub(' ', raw)).strip()
    words = [w for w in plain.split(' ') if w]
    headings = {f'h{i}': len(re.findall(rf'<h{i}\b', raw, re.IGNORECASE)) for i in range(1, 7)}
    return {
        'empty': False,
        'looks_like_html': looks_html,
        'chars_total': len(raw),
        'chars_plain_approx': len(plain),
        'word_count_plain_approx': len(words),
        'line_breaks': raw.count('\n'),
        'heading_tag_counts': headings,
        'list_item_count_approx': len(re.findall(r'<li\b', raw, re.IGNORECASE)),
        'link_count_approx': len(re.findall(r'<a\b', raw, re.IGNORECASE)),
        'plain_text_preview': plain[:2000],
    }


def _scalar_len(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, str):
        return len(value)
    if isinstance(value, dict):
        return len(value)
    if isinstance(value, list):
        return len(value)
    return len(str(value))


def summarize_method_forms(forms: Optional[MethodForms]) -> Dict[str, Any]:
    """Компактное описание forms.method без отдачи огромных html/css/js в сводку."""
    data = _to_plain_dict(forms) if forms is not None else {}
    spec = data.get('specification')
    conf = data.get('config')
    ex = data.get('example')
    return {
        'keys': list(data.keys()),
        'specification_keys': list(spec.keys()) if isinstance(spec, dict) else None,
        'config_keys': list(conf.keys()) if isinstance(conf, dict) else None,
        'example_keys': list(ex.keys()) if isinstance(ex, dict) else None,
        'html_chars': _scalar_len(data.get('html')),
        'css_chars': _scalar_len(data.get('css')),
        'js_chars': _scalar_len(data.get('js')),
    }


def method_forms_for_mcp(forms: Optional[MethodForms], forms_detail: str) -> Dict[str, Any]:
    if forms_detail == 'full':
        return _to_plain_dict(forms) if forms is not None else {}
    return summarize_method_forms(forms)


def truncate_instruction(text: str, max_chars: int, preview_chars: int) -> Tuple[str, bool, Dict[str, Any]]:
    """Возвращает (фрагмент для отдачи, обрезан ли полный текст, диагностика длины)."""
    n = len(text)
    meta = {'chars_total': n, 'max_chars': max_chars, 'preview_chars': preview_chars}
    if n <= max_chars:
        return text, False, meta
    return text[:preview_chars], True, meta


async def load_marker_instruction_text(
    client: TagmeClientAdvanced,
    method_id: str,
    organization_id: Optional[str],
    *,
    download_brief: bool,
    try_api_brief_fallback: bool,
) -> Tuple[str, MethodData, Dict[str, Any]]:
    """Текст инструкции и актуальный ``MethodData`` после разрешения brief.

    ``client`` — ``TagmeClientAdvanced``.
    """
    meta: Dict[str, Any] = {'method_id': method_id}
    method = await client.get_method(method_id, organization_id=organization_id, download_brief=download_brief)
    meta['is_brief_as_url_after_get_method'] = method.is_brief_as_url
    meta['method_uid'] = method.uid
    meta['method_name'] = method.name
    meta['brief_update_date'] = method.brief_update_date
    meta['forms_update_date'] = method.forms_update_date
    text = method.marker_brief or ''

    if download_brief and method.is_brief_as_url and text:
        low = client.client
        path = text.strip()
        try:
            if path.startswith('http://') or path.startswith('https://'):
                fetch_url = path
            else:
                fetch_url = path.lstrip('/')
            text = await low.get(fetch_url, response_type=ResponseType.TEXT_RESPONSE)
            method.marker_brief = text
            method.is_brief_as_url = False
            meta['brief_resolved_via'] = 'http_get_marker_brief_reference'
            meta['is_brief_as_url_after_get_method'] = False
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError) as exc:
            meta['brief_http_error'] = str(exc)

    if try_api_brief_fallback and download_brief and (not (text or '').strip() or meta.get('brief_http_error')):
        try:
            text, _headers = await client.client.get_method_brief(method_id)
            method.marker_brief = text
            method.is_brief_as_url = False
            meta['brief_resolved_via'] = meta.get('brief_resolved_via') or 'api_v0_method_brief'
            meta['is_brief_as_url_after_get_method'] = False
        except (aiohttp.ClientError, asyncio.TimeoutError, OSError) as exc:
            meta['brief_api_fallback_error'] = str(exc)

    return text or '', method, meta
