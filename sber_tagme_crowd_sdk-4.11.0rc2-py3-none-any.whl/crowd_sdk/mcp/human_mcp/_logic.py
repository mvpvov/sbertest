# pylint: disable=line-too-long
"""Human MCP: мета human_mcp_task в inner_comment проекта и общие константы."""

import logging
import os
from datetime import date
from itertools import chain
from typing import Any, Dict, List, Literal, Optional, Sequence, Set, Tuple

import yaml

HUMAN_MCP_TASK_PREFIX = 'human_mcp_task:'

# Лимит поля ``inner_comment`` при создании проекта в Tagme (ошибка API при превышении).
HUMAN_MCP_INNER_COMMENT_MAX_LEN = 255

# Лимит поля ``description`` проекта при создании (то же ограничение ответа Tagme markup_project).
HUMAN_MCP_PROJECT_DESCRIPTION_MAX_LEN = 255

# Чтобы выбрать только шаблоны с категорией ``tagme`` в ``categories``, передайте: template_category_tags=list(DEFAULT_TEMPLATE_CATEGORY_TAGS).
DEFAULT_TEMPLATE_CATEGORY_TAGS = ('tagme',)

# Каталог для MCP: ``published`` — как ``TagmeClient.get_published_templates_list``; ``workspace`` — ``get_templates_list``.
TemplatesCatalogKind = Literal['published', 'workspace']

ENV_HUMAN_MCP_HINTS = 'CROWD_MCP_HUMAN_LABELING_HINTS'

# URL сервиса генерации интерфейсов tagme-x-genui.
# Переопределяется через переменную окружения CROWD_SDK_GENUI_URL.
# Если не задано — строится из базового URL Tagme + GENUI_URL_SUFFIX.
ENV_GENUI_URL = 'CROWD_SDK_GENUI_URL'
GENUI_URL_SUFFIX = '/x/gen-ui'

# Защита write-инструмента от случайно огромных загрузок.
HUMAN_MCP_MAX_UPLOAD_ITEMS = 5000

# summarize_projects_for_human_mcp: явный список id.
HUMAN_MCP_MAX_SUMMARY_PROJECT_IDS = 20

# Скан списка проектов с метой (пустой список project_ids).
HUMAN_MCP_DISCOVERY_MAX_PAGES = 5
HUMAN_MCP_DISCOVERY_PAGE_SIZE = 50

# Пулы для Human MCP: только имена с этим префиксом (см. get_human_mcp_markup_options).
HUMAN_MCP_POOL_NAME_PREFIX = 'human_mcp_'
HUMAN_MCP_POOLS_FETCH_PAGE_SIZE = 100
HUMAN_MCP_POOLS_FETCH_MAX_PAGES = 50

# Верхняя граница числа страниц get_templates_list при запросе «все шаблоны» (templates_fetch_max_pages <= 0).
HUMAN_MCP_TEMPLATES_FETCH_PAGE_HARD_CAP = 500


logger = logging.getLogger(__name__)


def _maybe_iso_dt(value: Any) -> Any:
    if value is None:
        return None
    if hasattr(value, 'isoformat'):
        return value.isoformat()
    return value


def template_row_for_human_mcp(template: Any) -> Dict[str, Any]:
    """Поля шаблона для MCP: категории, теги (из API), методика, даты."""
    categories = list(getattr(template, 'categories', None) or [])
    raw_tags = getattr(template, 'tags', None)
    tags_list = list(raw_tags) if raw_tags else []
    return {
        'template_id': getattr(template, 'uid', None),
        'name': getattr(template, 'name', None),
        'description': getattr(template, 'description', None) or '',
        'categories': categories,
        'tags': tags_list,
        'method_id': getattr(template, 'method_id', None),
        'status': getattr(template, 'status', None),
        'created_at': _maybe_iso_dt(getattr(template, 'created_at', None)),
        'updated_at': _maybe_iso_dt(getattr(template, 'updated_at', None)),
        'documentation_excerpt': (
            (getattr(template, 'documentation', None) or '')[:500] if getattr(template, 'documentation', None) else ''
        ),
        'contacts': getattr(template, 'contacts', None) or '',
    }


def template_matches_all_category_tags(template: Any, required: Sequence[str]) -> bool:
    """Каждый элемент ``required`` считается совпадающим, если есть в ``template.categories`` (без учёта регистра).

    Поле ``tags`` шаблона не учитывается — фильтр завязан на категории Tagme.
    """
    if not required:
        return True
    raw_cat = getattr(template, 'categories', None) or []
    cat_lo = {str(c).lower() for c in raw_cat}
    return all(str(r).strip().lower() in cat_lo for r in required if str(r).strip())


def resolve_template_fetch_page_limit(max_pages: int) -> Tuple[int, bool]:
    """Сколько страниц опросить у Tagme и включён ли режим «до опустошения».

    ``max_pages <= 0`` — идти по страницам, пока batch не пуст и не исчерпан total (не более
    :data:`HUMAN_MCP_TEMPLATES_FETCH_PAGE_HARD_CAP` страниц за один вызов MCP).
    """
    if max_pages <= 0:
        return HUMAN_MCP_TEMPLATES_FETCH_PAGE_HARD_CAP, True
    return min(max_pages, HUMAN_MCP_TEMPLATES_FETCH_PAGE_HARD_CAP), False


def merge_template_lists_unique_uid(first: Sequence[Any], second: Sequence[Any]) -> List[Any]:
    """Объединяет два списка шаблонов без дубликатов по ``uid``."""
    seen: Set[Any] = set()
    out: List[Any] = []
    for t in chain(first, second):
        uid = getattr(t, 'uid', None)
        if uid is None:
            out.append(t)
            continue
        if uid in seen:
            continue
        seen.add(uid)
        out.append(t)
    return out


async def fetch_templates_pages_for_human_mcp_active_and_archived(
    client: Any,
    organization_id: Optional[str],
    *,
    page_size: int,
    max_pages: int,
    categories: Optional[List[str]] = None,
) -> Tuple[List[Any], Dict[str, Any]]:
    """Два запроса — активные и архивные шаблоны — с объединением по ``uid``."""
    raw_active, meta_active = await fetch_templates_pages_for_human_mcp(
        client,
        organization_id,
        catalog='workspace',
        archived=False,
        page_size=page_size,
        max_pages=max_pages,
        categories=categories,
    )
    raw_archived, meta_archived = await fetch_templates_pages_for_human_mcp(
        client,
        organization_id,
        catalog='workspace',
        archived=True,
        page_size=page_size,
        max_pages=max_pages,
        categories=categories,
    )
    merged = merge_template_lists_unique_uid(raw_active, raw_archived)
    meta: Dict[str, Any] = {
        'include_archived_templates': True,
        'total_reported_active': meta_active.get('total_reported'),
        'total_reported_archived_only': meta_archived.get('total_reported'),
        'categories_filter': meta_active.get('categories_filter'),
        'fetch_until_exhausted': meta_active.get('fetch_until_exhausted'),
        'pages_upper_bound': meta_active.get('pages_upper_bound'),
        'active_fetch': meta_active,
        'archived_fetch': meta_archived,
        'merged_templates_count': len(merged),
    }
    return merged, meta


async def fetch_templates_pages_for_human_mcp(
    client: Any,
    organization_id: Optional[str],
    *,
    catalog: TemplatesCatalogKind = 'published',
    archived: bool = False,
    page_size: int,
    max_pages: int,
    categories: Optional[List[str]] = None,
) -> Tuple[List[Any], Dict[str, Any]]:
    """Постраничный запрос шаблонов.

    ``catalog published`` — endpoint опубликованных шаблонов (как ``get_published_templates_list`` в SDK); параметр
    ``categories`` в Tagme **не передаётся**, фильтр по ``template_category_tags`` делается в MCP после загрузки.

    ``catalog workspace`` — ``get_templates_list`` (черновики/архив по ``archived``, серверный фильтр ``categories``).
    ``max_pages <= 0`` — до опустошения или ``total`` (``resolve_template_fetch_page_limit``).
    """
    low = client.client
    acc: List[Any] = []
    meta: Dict[str, Any] = {
        'templates_catalog': catalog,
        'pages_fetched': 0,
        'total_reported': None,
        'categories_filter': categories,
        'categories_sent_to_api': categories if catalog == 'workspace' else None,
        'fetch_until_exhausted': False,
        'pages_upper_bound': 0,
    }
    total: Optional[int] = None

    page_upper, unbounded = resolve_template_fetch_page_limit(max_pages)
    meta['fetch_until_exhausted'] = unbounded
    meta['pages_upper_bound'] = page_upper
    meta['archived_filter'] = None if catalog == 'published' else archived

    for page in range(1, page_upper + 1):
        if catalog == 'published':
            batch, _page_out, total = await low.get_published_templates_list(
                organization_id=organization_id,
                page=page,
                size=page_size,
                categories=None,
            )
        else:
            batch, _page_out, total = await low.get_templates_list(
                organization_id=organization_id,
                archived=archived,
                page=page,
                size=page_size,
                categories=categories,
            )
        meta['pages_fetched'] = page
        meta['total_reported'] = total
        acc.extend(batch)
        if not batch:
            break
        if total is not None and page * page_size >= int(total):
            break

    return acc, meta


def parse_human_mcp_slug(inner_comment: Optional[str]) -> Optional[str]:
    """Парсит первую строку inner_comment; возвращает slug после human_mcp_task: или None."""
    if not inner_comment:
        return None
    first_line = inner_comment.split('\n', 1)[0].strip()
    if not first_line.startswith(HUMAN_MCP_TASK_PREFIX):
        return None
    slug = first_line[len(HUMAN_MCP_TASK_PREFIX) :].strip()
    return slug or None


def format_inner_comment_human_mcp(slug: str, trailing_note: Optional[str] = None) -> str:
    """Первая строка — мета; опционально текст после перевода строки.

    Полная строка не должна превышать :data:`HUMAN_MCP_INNER_COMMENT_MAX_LEN` — см. :func:`validate_human_mcp_inner_comment_length`.
    """
    head = f'{HUMAN_MCP_TASK_PREFIX}{slug.strip()}'
    if trailing_note and trailing_note.strip():
        return f'{head}\n{trailing_note.strip()}'
    return head


def validate_human_mcp_inner_comment_length(inner_comment: str, *, slug: Optional[str] = None) -> None:
    """Проверка до вызова API создания проекта: Tagme отклоняет ``inner_comment`` длиннее лимита."""
    n = len(inner_comment)
    if n <= HUMAN_MCP_INNER_COMMENT_MAX_LEN:
        return
    extra = ''
    if slug is not None:
        head_len = len(f'{HUMAN_MCP_TASK_PREFIX}{slug.strip()}')
        max_trailing = HUMAN_MCP_INNER_COMMENT_MAX_LEN - head_len - 1  # перевод строки перед хвостом
        if max_trailing < 0:
            max_trailing = max(max_trailing, 0)
        extra = f' Для текущего slug после первой строки остаётся не более ~{max_trailing} символов во inner_comment_trailing.'
    raise ValueError(
        f'Tagme: inner_comment не длиннее {HUMAN_MCP_INNER_COMMENT_MAX_LEN} символов (сейчас {n}). '
        f'Сократите inner_comment_trailing; полную инструкцию разместите в шаблоне методики или brief в Tagme '
        f'(description проекта тоже не длиннее {HUMAN_MCP_PROJECT_DESCRIPTION_MAX_LEN} символов).{extra}'
    )


def validate_human_mcp_project_description(description: Optional[str]) -> None:
    """Проверка до вызова API: Tagme отклоняет ``description`` проекта длиннее лимита."""
    if description is None:
        return
    n = len(description)
    if n <= HUMAN_MCP_PROJECT_DESCRIPTION_MAX_LEN:
        return
    raise ValueError(
        f'Tagme: description проекта не длиннее {HUMAN_MCP_PROJECT_DESCRIPTION_MAX_LEN} символов (сейчас {n}). '
        f'Сократите текст или опишите задачу кратко; развёрнутую инструкцию держите в шаблоне/brief в Tagme.'
    )


TAGME_UPLOAD_JSON_DOCS_URL = 'https://tagme.sberdevices.ru/docs/customer/uploading-data.html'


def resolve_genui_url(tagme_base_url: str) -> str:
    """Вернуть URL сервиса tagme-x-genui.

    Приоритет:
    1. Переменная окружения ``CROWD_SDK_GENUI_URL`` (явное значение).
    2. ``{tagme_base_url}/x/gen-ui`` (вычисляется из конфига Tagme).
    """
    env_url = os.environ.get(ENV_GENUI_URL)
    if env_url:
        return env_url.rstrip('/')
    return tagme_base_url.rstrip('/') + GENUI_URL_SUFFIX


def validate_human_mcp_json_upload_items(
    items: Sequence[Dict[str, Any]],
    interface_example: Optional[Dict[str, Any]] = None,
) -> None:
    """Проверка перед ``upload_json_data`` без ``base_path`` в MCP: у каждого элемента должен быть объект ``task``.

    Если передан ``interface_example`` — дополнительно проверяет что ключи в ``item["task"]`` совпадают с ключами примера.
    """
    if not items:
        raise ValueError(
            'items не может быть пустым: иначе в проекте создаётся задача без загруженных заданий. '
            'При ошибке вызова не создавайте проект заново — возьмите project_id из предыдущего ответа и повторите только загрузку.'
        )
    example_keys = set(interface_example.keys()) if interface_example else None
    for i, row in enumerate(items):
        if not isinstance(row, dict):
            raise ValueError(f'items[{i}] должен быть dict, сейчас {type(row).__name__}')
        payload = row.get('task')
        if not isinstance(payload, dict):
            raise ValueError(
                f'items[{i}] должен содержать ключ "task" с объектом входных полей методики шаблона '
                f'(см. Tagme upload_json_data в клиенте SDK и {TAGME_UPLOAD_JSON_DOCS_URL}). '
                'Без ключа "task" и без base_path загрузка приведёт к ошибке или к пустым файлам.'
            )
        if not payload:
            raise ValueError(
                f'items[{i}]["task"] не может быть пустым объектом — маркер не получит входные данные, UI может не открыться.'
            )
        if example_keys is not None:
            item_keys = set(payload.keys())
            extra = item_keys - example_keys
            missing = example_keys - item_keys
            if extra or missing:
                parts = []
                if missing:
                    parts.append(f'отсутствуют поля: {sorted(missing)}')
                if extra:
                    parts.append(f'лишние поля: {sorted(extra)}')
                raise ValueError(
                    f'items[{i}]["task"] не соответствует interface_example. {"; ".join(parts)}. '
                    f'Ожидаемые ключи: {sorted(example_keys)}.'
                )


def parse_deadline_optional(deadline: Optional[str]) -> Optional[date]:
    if deadline is None or not str(deadline).strip():
        return None
    raw = str(deadline).strip()
    try:
        return date.fromisoformat(raw)
    except ValueError as exc:
        raise ValueError(f'Invalid deadline (expected ISO date YYYY-MM-DD): {deadline!r}') from exc


def load_optional_labeling_hints(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Опциональный YAML с подсказками для агента.

    Путь: аргумент или переменная окружения CROWD_MCP_HUMAN_LABELING_HINTS.
    Формат — произвольный dict (например defaults.overlap, defaults.price_by_complexity_rub, task_types, notes).
    """
    path = config_path or os.getenv(ENV_HUMAN_MCP_HINTS)
    if not path:
        return {}
    p = os.path.expanduser(path)
    if not os.path.isfile(p):
        logger.warning('Human MCP hints file not found: %s', p)
        return {}
    try:
        with open(p, encoding='utf-8') as f:
            data = yaml.safe_load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, yaml.YAMLError, UnicodeDecodeError) as exc:
        logger.warning('Failed to load Human MCP hints %s: %s', p, exc)
        return {}


def normalized_pool_row(p: Any) -> Dict[str, Any]:
    return {
        'pool_id': getattr(p, 'uid', None),
        'name': getattr(p, 'name', None),
        'members_count': getattr(p, 'members_count', None),
        'group_type': getattr(p, 'group_type', None),
    }


def pool_name_has_human_mcp_prefix(pool: Any) -> bool:
    name = getattr(pool, 'name', None)
    return str(name or '').startswith(HUMAN_MCP_POOL_NAME_PREFIX)


async def fetch_pools_for_human_mcp(
    client: Any,
    organization_id: Optional[str],
    *,
    pools_limit: int,
    page_size: int = HUMAN_MCP_POOLS_FETCH_PAGE_SIZE,
) -> Tuple[List[Any], Dict[str, Any]]:
    """
    Страничный обход организационных пулов; возвращает до ``pools_limit`` пулов,
    у которых ``name`` начинается с :data:`HUMAN_MCP_POOL_NAME_PREFIX`.
    """
    lim = max(1, pools_limit)
    psize = max(1, page_size)
    acc: List[Any] = []
    meta: Dict[str, Any] = {
        'name_prefix': HUMAN_MCP_POOL_NAME_PREFIX,
        'pages_fetched': 0,
        'pools_scanned_total': 0,
        'pools_matched_returned': 0,
        'stopped_because_limit': False,
        'stopped_because_short_page': False,
        'stopped_because_empty_page': False,
        'stopped_because_max_pages': False,
    }

    for pages_done in range(1, HUMAN_MCP_POOLS_FETCH_MAX_PAGES + 1):
        batch = await client.get_organization_pools(
            organization_id=organization_id,
            page=pages_done,
            size=psize,
        )
        meta['pages_fetched'] = pages_done
        if not batch:
            meta['stopped_because_empty_page'] = True
            break
        meta['pools_scanned_total'] += len(batch)

        for p in batch:
            if pool_name_has_human_mcp_prefix(p):
                acc.append(p)
                if len(acc) >= lim:
                    meta['stopped_because_limit'] = True
                    meta['pools_matched_returned'] = len(acc)
                    return acc, meta

        if len(batch) < psize:
            meta['stopped_because_short_page'] = True
            break

    meta['stopped_because_max_pages'] = (
        len(acc) < lim
        and not meta['stopped_because_empty_page']
        and not meta['stopped_because_short_page']
        and meta['pages_fetched'] >= HUMAN_MCP_POOLS_FETCH_MAX_PAGES
    )

    meta['pools_matched_returned'] = len(acc)
    return acc, meta


async def discover_human_mcp_projects(
    client: Any,
    organization_id: Optional[str],
    *,
    max_pages: int = HUMAN_MCP_DISCOVERY_MAX_PAGES,
    page_size: int = HUMAN_MCP_DISCOVERY_PAGE_SIZE,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Пагинация get_projects; проекты с parse_human_mcp_slug is not None.

    Returns:
        rows, meta с полями scanned_pages, scanned_projects
    """
    rows: List[Dict[str, Any]] = []
    meta: Dict[str, Any] = {'scanned_pages': 0, 'scanned_projects': 0}

    for page_idx in range(max_pages):
        page = page_idx + 1
        chunk = await client.get_projects(
            organization_id=organization_id,
            archived=False,
            page=page,
            size=page_size,
        )
        meta['scanned_pages'] = page
        if not chunk:
            break
        meta['scanned_projects'] += len(chunk)
        for project in chunk:
            slug = parse_human_mcp_slug(getattr(project, 'inner_comment', None) or '')
            if not slug:
                continue
            rows.append(
                {
                    'project_id': project.uid,
                    'name': project.name,
                    'human_mcp_task': slug,
                    'template_id': getattr(project, 'template_id', None),
                }
            )

    return rows, meta
