# pylint: disable=line-too-long

import json
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Sequence

import aiohttp

from crowd_sdk.mcp.human_mcp._logic import (
    HUMAN_MCP_MAX_SUMMARY_PROJECT_IDS,
    HUMAN_MCP_MAX_UPLOAD_ITEMS,
    discover_human_mcp_projects,
    fetch_pools_for_human_mcp,
    fetch_templates_pages_for_human_mcp,
    fetch_templates_pages_for_human_mcp_active_and_archived,
    format_inner_comment_human_mcp,
    load_optional_labeling_hints,
    normalized_pool_row,
    parse_deadline_optional,
    parse_human_mcp_slug,
    resolve_genui_url,
    template_matches_all_category_tags,
    template_row_for_human_mcp,
    validate_human_mcp_inner_comment_length,
    validate_human_mcp_json_upload_items,
    validate_human_mcp_project_description,
)
from crowd_sdk.mcp.statistic._instruction_analysis import load_marker_instruction_text, summarize_marker_instruction
from crowd_sdk.mcp.statistic._tagme_stats import (
    get_request_tagme_token,
    load_tagme_config,
    normalize_for_mcp,
    open_tagme_client,
    resolve_organization_id,
    resolve_tagme_auth_credentials,
)
from crowd_sdk.mcp.tools._helpers import _get_project_with_organization, _project_metadata, _task_metadata
from crowd_sdk.tagme.http_client.datacls import MethodDataRequest, MethodFormsRequest, TaskDataRequest


async def get_human_mcp_markup_options(  # pylint: disable=R0913
    organization_id: Optional[str] = None,
    config_path: Optional[str] = None,
    hints_path: Optional[str] = None,
    templates_limit: int = 0,
    templates_fetch_page_size: int = 100,
    templates_fetch_max_pages: int = 0,
    templates_catalog: Literal['published', 'workspace'] = 'published',
    templates_include_archived: bool = False,
    template_category_tags: Optional[List[str]] = None,
    pools_limit: int = 200,
) -> Dict[str, Any]:
    """Справочник Human MCP: шаблоны Tagme (categories, tags из API), пулы, проекты с метой human_mcp_task:, hints YAML.

    **Каталог шаблонов: ``templates_catalog``**

    - ``published`` (по умолчанию) — как SDK ``get_published_templates_list``: все страницы
      ``/api/v0/templates/published``. На сервер **не передаётся** ``categories[]``; фильтр ``template_category_tags``
      выполняется в MCP по полю ``categories`` каждого шаблона (аналог подсчёта ``\"tagme\" in t.categories`` после загрузки).
    - ``workspace`` — ``get_templates_list`` (``/api/v0/templates``): фильтр ``categories[]`` уходит на Tagme вместе с
      ``archived``; число записей может **не совпадать** с опубликованным каталогом.

    При ``templates_catalog=workspace`` и ``templates_include_archived=true`` объединяются активные и архивные шаблоны.
    Для ``published`` параметр ``templates_include_archived`` не используется (опционально в мета — пометка).

    Пустой ``template_category_tags`` — после загрузки каталога не отбирать по категориям на стороне MCP.

    По умолчанию (удобный каталог): ``templates_fetch_max_pages=0`` — опросить все страницы Tagme в пределах hard cap;
    ``templates_limit=0`` — не обрезать результат после фильтра по категориям. Задайте положительный ``templates_limit``,
    если нужно усечь ответ по размеру.

    Лимиты списка шаблонов:
    - Сначала Tagme отдаёт постранично не более ``templates_fetch_max_pages`` страниц (размер страницы —
      ``templates_fetch_page_size``), но не более :data:`crowd_sdk.mcp.human_mcp.HUMAN_MCP_TEMPLATES_FETCH_PAGE_HARD_CAP`
      страниц за один вызов инструмента.
    - ``templates_fetch_max_pages <= 0`` — запрашивать страницы, пока API не вернёт пустую порцию или не будет
      достигнут общий ``total`` (режим «все доступные страницы», пока не упрёмся в hard cap страниц).
    - После выборки к результату применяется ``templates_limit``: если ``templates_limit > 0``, возвращаются только
      первые N записей после фильтра по ``template_category_tags``; если ``templates_limit <= 0`` — без этой обрезки
      (все загруженные шаблоны).

    **Пулы:** только те, у которых ``name`` начинается с префикса ``human_mcp_`` (константа ``HUMAN_MCP_POOL_NAME_PREFIX``); при нехватке подходящих пулов на первой странице обходятся дополнительные страницы до ``pools_limit`` или лимита страниц выборки.

    ``template_category_tags``: фильтр AND по полю **categories** шаблона (без учёта регистра). При ``published``
    фильтр только на стороне MCP; при ``workspace`` теги дополнительно передаются в Tagme как ``categories[]``.

    Сверка полноты: ``templates_fetch_meta.total_reported`` и ``templates_fetched_count``; если загрузились не все —
      увеличьте ``templates_fetch_page_size`` / ``templates_fetch_max_pages`` или используйте ``templates_fetch_max_pages=0``.
    Не вызывать для: загрузки заданий → **create_markup_task_with_items**.

    Поле ``hints`` — произвольный dict из YAML (см. пример ``human_mcp_labeling_hints.example.yaml``): часто задают
    ``defaults.overlap``, шкалу цены по сложности и правило не ставить ``start_after_upload`` без явной просьбы пользователя.

    Перед ``configure_human_mcp_project(operation='create')`` проверьте ``human_mcp_projects``: при ретрае после ошибки не создавайте дубликаты —
    переиспользуйте ``project_id`` подходящего проекта с нужным ``human_mcp_task`` slug.
    Если проект уже есть, а не подошёл только шаблон — ``configure_human_mcp_project(operation='apply_template', project_id=..., template_id=...)``, без второго create.
    Шаблоны со статусом DRAFT или «тест» часто ломают UI; отдавайте предпочтение PUBLISHED и проверенным именам из hints.
    """
    if template_category_tags is None:
        effective_category_tags: List[str] = []
    else:
        effective_category_tags = [str(x).strip() for x in template_category_tags if str(x).strip()]

    categories_for_api = effective_category_tags if effective_category_tags else None

    async with open_tagme_client(config_path) as client:
        resolved_org = organization_id or await resolve_organization_id(client, organization_id)

        if templates_catalog == 'workspace' and templates_include_archived:
            templates_loaded, tmpl_fetch_meta = await fetch_templates_pages_for_human_mcp_active_and_archived(
                client,
                resolved_org,
                page_size=max(1, templates_fetch_page_size),
                max_pages=templates_fetch_max_pages,
                categories=categories_for_api,
            )
        elif templates_catalog == 'published':
            templates_loaded, tmpl_fetch_meta = await fetch_templates_pages_for_human_mcp(
                client,
                resolved_org,
                catalog='published',
                archived=False,
                page_size=max(1, templates_fetch_page_size),
                max_pages=templates_fetch_max_pages,
                categories=None,
            )
            if templates_include_archived:
                tmpl_fetch_meta = {
                    **tmpl_fetch_meta,
                    'note_templates_include_archived_ignored': (
                        'templates_catalog=published: каталог опубликованных; отдельный опрос archived не выполняется.'
                    ),
                }
        else:
            templates_loaded, tmpl_fetch_meta = await fetch_templates_pages_for_human_mcp(
                client,
                resolved_org,
                catalog='workspace',
                archived=False,
                page_size=max(1, templates_fetch_page_size),
                max_pages=templates_fetch_max_pages,
                categories=categories_for_api,
            )
        templates_after_category_filter = [
            t for t in templates_loaded if template_matches_all_category_tags(t, effective_category_tags)
        ]
        capped = (
            templates_after_category_filter
            if templates_limit <= 0
            else templates_after_category_filter[: max(1, templates_limit)]
        )

        pools, pools_fetch_meta = await fetch_pools_for_human_mcp(
            client,
            resolved_org,
            pools_limit=max(1, pools_limit),
        )
        human_rows, disc_meta = await discover_human_mcp_projects(client, resolved_org)

    template_rows = [template_row_for_human_mcp(t) for t in capped]

    return {
        'entity_type': 'human_mcp_markup_options',
        'organization_id': resolved_org,
        'templates': template_rows,
        'templates_returned_count': len(template_rows),
        'templates_fetched_count': len(templates_loaded),
        'templates_after_category_filter_count': len(templates_after_category_filter),
        'templates_truncated_by_templates_limit': (
            templates_limit > 0 and len(capped) < len(templates_after_category_filter)
        ),
        'template_category_tags_effective': effective_category_tags,
        'templates_fetch_meta': tmpl_fetch_meta,
        'pools_fetch_meta': pools_fetch_meta,
        'pools': [normalized_pool_row(p) for p in pools],
        'human_mcp_projects': human_rows,
        'hints': load_optional_labeling_hints(hints_path),
        'discovery_meta': disc_meta,
        'related_mcp_tools': {
            'project_instruction_detail': 'analyze_project_instructions',
            'create_task_batch': 'create_markup_task_with_items',
            'configure_project': 'configure_human_mcp_project',
        },
    }


async def summarize_projects_for_human_mcp(  # pylint: disable=R0913
    project_ids: Optional[List[str]] = None,
    organization_id: Optional[str] = None,
    include_pool_ids: bool = True,
    download_brief: bool = True,
    try_api_brief_fallback: bool = True,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Сводка проектов для Human MCP: имя, slug из ``inner_comment``, полный текст инструкции (как instruction_analysis), template_id, pool_ids.

    Если ``project_ids`` пустой или None — выбираются проекты организации с метой ``human_mcp_task:`` (до лимита обзора).

    Когда вызывать: сопоставить тип задачи и инструкцию перед выбором проекта.

    Не вызывать для: произвольных проектов без меты при пустом списке (они не попадут в авто-режим).

    Возвращает: entity_type, projects (список записей), notes.
    """
    async with open_tagme_client(config_path) as client:
        resolved_org = organization_id or await resolve_organization_id(client, organization_id)
        ids = list(project_ids or [])
        notes: List[str] = []

        if not ids:
            discovered, disc_meta = await discover_human_mcp_projects(client, resolved_org)
            notes.append(
                f'project_ids не передан: найдено {len(discovered)} проектов с метой human_mcp_task: '
                f'(скан страниц={disc_meta.get("scanned_pages")}, проектов просмотрено={disc_meta.get("scanned_projects")}).'
            )
            ids = [row['project_id'] for row in discovered[:HUMAN_MCP_MAX_SUMMARY_PROJECT_IDS]]
            if len(discovered) > HUMAN_MCP_MAX_SUMMARY_PROJECT_IDS:
                notes.append(
                    f'Обработаны только первые {HUMAN_MCP_MAX_SUMMARY_PROJECT_IDS} id; уточните project_ids для остальных.'
                )
        else:
            if len(ids) > HUMAN_MCP_MAX_SUMMARY_PROJECT_IDS:
                ids = ids[:HUMAN_MCP_MAX_SUMMARY_PROJECT_IDS]
                notes.append(
                    f'Список обрезан до {HUMAN_MCP_MAX_SUMMARY_PROJECT_IDS} элементов '
                    '(см. HUMAN_MCP_MAX_SUMMARY_PROJECT_IDS).'
                )

        summaries: List[Dict[str, Any]] = []
        for pid in ids:
            project = await _get_project_with_organization(client, pid, resolved_org, with_tasks_count=False)
            slug = parse_human_mcp_slug(project.inner_comment or '')
            text, _method, brief_meta = await load_marker_instruction_text(
                client,
                project.method_id,
                resolved_org or project.organization_id,
                download_brief=download_brief,
                try_api_brief_fallback=try_api_brief_fallback,
            )
            pool_ids: Optional[List[str]] = None
            if include_pool_ids:
                pool_ids = await client.get_pools(project_id=project.uid, organization_id=resolved_org)
            summaries.append(
                normalize_for_mcp(
                    {
                        'project_id': project.uid,
                        'name': project.name,
                        'human_mcp_task': slug,
                        'template_id': project.template_id,
                        'inner_comment': project.inner_comment,
                        'instruction_text': text or '',
                        'instruction_analysis': summarize_marker_instruction(text or None),
                        'brief_load': brief_meta,
                        'pool_ids': pool_ids or [],
                    }
                )
            )

    return {
        'entity_type': 'human_mcp_projects_summary',
        'organization_id': resolved_org,
        'projects': summaries,
        'notes': notes,
        'related_mcp_tools': {
            'create_task_batch': 'create_markup_task_with_items',
            'catalog': 'get_human_mcp_markup_options',
            'configure_project': 'configure_human_mcp_project',
        },
    }


async def create_markup_task_with_items(  # pylint: disable=R0913
    project_id: str,
    task_name: str,
    items: Optional[List[Dict[str, Any]]] = None,
    price: float = 0.0,
    overlap: int = 1,
    deadline: Optional[str] = None,
    description: Optional[str] = None,
    organization_id: Optional[str] = None,
    start_after_upload: bool = False,
    interface_example: Optional[Dict[str, Any]] = None,
    items_file_path: Optional[str] = None,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Human MCP: создать задачу в проекте, загрузить элементы (формат ``upload_json_data``), опционально запустить.

    Параметры задачи: ``price``, ``overlap``, опционально ``deadline`` (ISO YYYY-MM-DD), ``description``. Поле filter не поддерживается.

    **Формат ``items`` — строго по ``example`` интерфейса проекта:**
    Каждый элемент ``items`` должен иметь вид ``{"task": <объект полей>}``, где объект полей **точно повторяет**
    структуру ключей из поля ``example`` интерфейса шаблона/проекта. Например, если ``example = {"text": "Пример"}``
    — каждый item должен быть ``{"task": {"text": "..."}}``; если ``example = {"image_url": "...", "label": "..."}``
    — ``{"task": {"image_url": "...", "label": "..."}}``.
    Брать структуру из ``interface.example`` результата ``generate_tagme_interface`` или ``apply_interface_to_project``.
    Нельзя добавлять лишние ключи, менять имена полей или убирать обязательные поля — иначе интерфейс разметки
    не отрендерится или задание будет пустым.

    ``items_file_path``: путь к локальному файлу ``.json`` (массив объектов) или ``.jsonl`` (по одному объекту на строку).
    Если передан — ``items`` игнорируется. Сервер читает файл самостоятельно, что позволяет работать с большими
    датасетами без ограничений контекста LLM. Формат каждого объекта — такой же как для ``items``.

    ``interface_example``: передайте значение ``interface.example`` из ``generate_tagme_interface`` /
    ``apply_interface_to_project`` — инструмент проверит что ключи в каждом ``item["task"]`` совпадают с ключами примера.

    ``start_after_upload``: по умолчанию ``False`` — задача не переводится в выполнение сразу после загрузки;
    запускайте только если пользователь явно попросил запустить задачу после создания.

    При повторе после частичной ошибки не создавайте новый проект: используйте тот же ``project_id``; не вызывайте инструмент
    повторно с пустым ``items`` — это даёт «пустую» задачу в том же проекте.

    Когда вызывать: есть ``project_id`` и готовый список заданий или путь к файлу.

    Возвращает: entity_type, task, upload, start_after_upload.
    """
    resolved_items: List[Dict[str, Any]]
    if items_file_path is not None:
        resolved_items = _load_items_from_file(items_file_path)
    elif items is not None:
        resolved_items = items
    else:
        raise ValueError('Необходимо передать items или items_file_path.')

    if len(resolved_items) > HUMAN_MCP_MAX_UPLOAD_ITEMS:
        raise ValueError(
            f'Too many items ({len(resolved_items)}); max is {HUMAN_MCP_MAX_UPLOAD_ITEMS}. Split into several calls.'
        )
    validate_human_mcp_json_upload_items(resolved_items, interface_example=interface_example)
    deadline_date = parse_deadline_optional(deadline)

    async with open_tagme_client(config_path) as client:
        project = await _get_project_with_organization(client, project_id, organization_id, with_tasks_count=False)
        org = organization_id or project.organization_id
        task_req = TaskDataRequest(
            project_id=project.uid,
            organization_id=org,
            name=task_name,
            price=price,
            overlap=overlap,
            deadline=deadline_date,
            description=description if description is not None else '',
        )
        task = await client.create_task(task_req, organization_id=org)
        await client.upload_json_data(
            task_id=task.uid,
            json_data=resolved_items,
            organization_id=org,
        )
        if start_after_upload:
            await client.start_task(task.uid, organization_id=org)

    return normalize_for_mcp(
        {
            'entity_type': 'human_mcp_task_created',
            'project_id': project.uid,
            'task': _task_metadata(task),
            'items_count': len(resolved_items),
            'items_source': items_file_path if items_file_path else 'inline',
            'start_after_upload': start_after_upload,
        }
    )


async def configure_human_mcp_project(  # pylint: disable=R0913
    operation: Literal['create', 'apply_template'],
    template_id: str,
    organization_id: Optional[str] = None,
    config_path: Optional[str] = None,
    name: Optional[str] = None,
    human_mcp_task_slug: Optional[str] = None,
    description: Optional[str] = None,
    instruction: Optional[str] = None,
    inner_comment_trailing: Optional[str] = None,
    pool_ids: Optional[Sequence[str]] = None,
    project_id: Optional[str] = None,
    autoupdate_params: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Human MCP: создание проекта из шаблона **или** применение другого шаблона к существующему проекту.

    Один инструмент вместо двух отдельных вызовов:

    - ``operation='create'`` — новый проект с метой ``human_mcp_task:<slug>`` в ``inner_comment``, как при создании
      из каталога: нужны ``name``, ``human_mcp_task_slug``, ``template_id``. Поле ``project_id`` не передают.
      Если передан ``instruction`` — текст сохраняется как инструкция для разметчиков (``marker_brief`` метода проекта).
    - ``operation='apply_template'`` — тот же проект, новый шаблон (``TagmeClientAdvanced.apply_template_to_project``):
      нужны ``project_id``, ``template_id``. Поля ``name`` / ``human_mcp_task_slug`` / ``instruction`` игнорируются.

    **Правило именования проекта (``name``):**
    Имя описывает **тип задачи**, а не конкретные данные. Примеры: «Оценка текста: грамотность и достоверность»,
    «Классификация изображений», «Разметка диалогов». Имя **не должно** содержать конкретные значения из размечаемых
    данных: названия моделей, продуктов, цитаты, числа — всё это меняется от задачи к задаче и не должно
    фиксироваться в имени проекта. Неправильно: «Оценка текста GLM-5 MoE: грамотность и достоверность».

    **ВАЖНО — защита от дублей (обязательно перед operation='create'):**
    Перед каждым вызовом ``operation='create'`` выполните ``get_human_mcp_markup_options`` и проверьте поле
    ``human_mcp_projects``. Если проект с нужным ``human_mcp_task`` slug уже существует — **не создавайте новый**,
    переиспользуйте ``project_id`` из списка. При ретрае после ошибки тоже сначала проверьте список: проект мог
    успешно создаться до того, как упало соединение. Создавать второй проект с тем же slug запрещено.
    Если проект есть, но шаблон не подошёл — используйте ``operation='apply_template'``.
    """
    if operation == 'create':
        if project_id:
            raise ValueError('operation=create does not accept project_id (omit it)')
        if not name or not str(name).strip():
            raise ValueError('operation=create requires name')
        slug_raw = human_mcp_task_slug or ''
        slug = slug_raw.strip()
        if not slug or '\n' in slug:
            raise ValueError('operation=create requires human_mcp_task_slug (non-empty single-line)')
        inner_comment = format_inner_comment_human_mcp(slug, inner_comment_trailing)
        validate_human_mcp_inner_comment_length(inner_comment, slug=slug)
        validate_human_mcp_project_description(description)

        async with open_tagme_client(config_path) as client:
            org = organization_id or await resolve_organization_id(client, organization_id)
            existing, _ = await discover_human_mcp_projects(client, org)
            duplicate = next((r for r in existing if r.get('human_mcp_task') == slug), None)
            if duplicate:
                raise ValueError(
                    f'Проект с human_mcp_task_slug={slug!r} уже существует: '
                    f'project_id={duplicate["project_id"]!r}. '
                    f'Используйте его или operation=\'apply_template\' для смены шаблона.'
                )
            project = await client.create_project(
                name=name,
                description=description,
                template_id=template_id,
                inner_comment=inner_comment,
                organization_id=org,
            )
            pools = list(pool_ids) if pool_ids else []
            if pools:
                await client.add_pools(project_id=project.uid, pools=pools, organization_id=org)
            if instruction is not None:
                with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as tmp:
                    tmp.write(instruction)
                    tmp_path = tmp.name
                await client.update_method_brief(
                    method_id=project.method_id,
                    file_path=tmp_path,
                    file_name='instruction.txt',
                )
                Path(tmp_path).unlink(missing_ok=True)

        return normalize_for_mcp(
            {
                'entity_type': 'human_mcp_project_created',
                'operation': 'create',
                'project': {**_project_metadata(project), 'template_id': project.template_id},
                'inner_comment': project.inner_comment,
                'pool_ids_added': pools,
                'instruction_set': instruction is not None,
            }
        )

    if operation == 'apply_template':
        if not project_id or not str(project_id).strip():
            raise ValueError('operation=apply_template requires project_id')
        async with open_tagme_client(config_path) as client:
            project = await _get_project_with_organization(
                client, project_id.strip(), organization_id, with_tasks_count=False
            )
            org = organization_id or project.organization_id
            await client.apply_template_to_project(
                template_id=template_id,
                project_id=project.uid,
                organization_id=org,
                autoupdate_params=autoupdate_params,
            )
            updated = await _get_project_with_organization(client, project.uid, organization_id, with_tasks_count=False)

        return normalize_for_mcp(
            {
                'entity_type': 'human_mcp_template_applied',
                'operation': 'apply_template',
                'project_id': updated.uid,
                'template_id_applied': template_id,
                'project': {**_project_metadata(updated), 'template_id': updated.template_id},
            }
        )

    raise ValueError(f'Unknown operation: {operation!r}')


async def generate_tagme_interface(  # pylint: disable=R0913
    prompt: str,
    generation_id: Optional[str] = None,
    answers: Optional[List[Dict[str, Any]]] = None,
    input_example: Optional[Dict[str, Any]] = None,
    input_schema: Optional[Dict[str, Any]] = None,
    conversation_id: Optional[str] = None,
    genui_url: Optional[str] = None,
    user_id: str = 'mcp-agent',
    user_locale: str = 'ru-RU',
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Генерация интерфейса TagMe через сервис tagme-x-genui.

    Многошаговый диалог. Первый вызов: передать ``prompt``. Сервис может вернуть
    уточняющие вопросы (``status=needs_input``) или сразу готовый интерфейс (``status=completed``).

    Если получены вопросы — вызвать инструмент повторно с тем же ``generation_id``
    и ``answers=[{"question_id": "...", "value": "..."}]`` для каждого ответа.

    Когда ``status=completed`` — поле ``interface`` содержит готовый код (html, js, css, config,
    specification, example), который можно передать в ``apply_interface_to_project``.

    URL сервиса определяется автоматически из конфига Tagme (``{base_url}/x/gen-ui``).
    Переопределяется через переменную окружения ``CROWD_SDK_GENUI_URL`` или параметр ``genui_url``.

    **Роль: ты веб-дизайнер, который описывает готовый макет — не программист, не аналитик.**

    Перед вызовом представь законченный экран в браузере и опиши его так, как будто показываешь
    коллеге мокап в Figma: что находится в каком месте, как выглядит, какие ощущения создаёт.
    Пиши от первого лица дизайнера, живо и образно.

    **Запрещено** в промпте:
    - списки требований в стиле «поле X — тип Y, обязательное»
    - технические названия компонентов (``tm-rating``, ``tm-block``, ``tm-radio`` и т.п.)
    - шаблонная фраза «входные данные: поле task.X»
    - синтаксис шаблонизатора (``{{{task.text}}}``, ``{{value}}``)

    **Обязательно включи:**
    1. **Общий вид страницы** — layout, фон, карточки, отступы, ощущение простора или компактности
    2. **Блок с заданием** — как выглядит текст/изображение/данные которые нужно оценить, размер шрифта,
       рамка, цвет фона блока. Укажи имена полей входных данных (они попадут в ``example``).
    3. **Каждый вопрос** — точную формулировку, как выглядит элемент управления визуально:
       «пять крупных звёзд», «три большие кнопки-плитки в ряд», «ползунок с засечками»,
       что написано на крайних значениях шкалы, цвет выбранного состояния
    4. **Кнопка отправки** — как выглядит, когда активна / неактивна, что написано на ней
    5. **Обязательность полей** — как визуально обозначены обязательные поля
    6. **Язык интерфейса**

    Пример хорошего промпта:
    «Открываю страницу — чистый белый фон, по центру одна карточка с лёгкой тенью, максимальная ширина 700px.
    Вверху карточки серый заголовок "Оцените утверждение". Под ним прямоугольный блок с чуть голубоватым фоном,
    внутри крупным (18px) текстом выводится само утверждение (поле ``text``). Ниже — два раздела:

    Раздел "Грамотность": подзаголовок полужирным, под ним ряд из 5 звёзд ~32px. Звёзды серые по умолчанию,
    при наведении и выборе — золотые. Под звёздами подписи по краям: "1 — много ошибок" слева, "5 — безупречно"
    справа. Обязательное поле — рядом с заголовком красная звёздочка.

    Раздел "Достоверность": три карточки-кнопки в ряд, одинаковой ширины: "Верно", "Частично верно",
    "Неверно". По умолчанию — белые с серой рамкой. Выбранная — синяя заливка, белый текст. Обязательное.

    Внизу по центру кнопка "Отправить ответ", 180px, синяя (#1976D2), белый текст, скруглённая. Пока не
    заполнены оба обязательных поля — кнопка серая и некликабельна. Язык: русский.»

    Args:
        prompt: Визуальное описание макета от лица дизайнера — как выглядит экран, а не список требований.
        generation_id: ID активной генерации. None на первом вызове.
        answers: Ответы на вопросы сервиса. Передавать только если получен статус ``needs_input``.
        input_example: Пример входных данных задания (dict). Передаётся сервису genui для точной генерации интерфейса.
        input_schema: JSON Schema входных данных. Передаётся сервису genui для точной генерации интерфейса.
        conversation_id: ID разговора для продолжения предыдущей генерации. Передавать значение ``conversation_id``
            из предыдущего ответа, если нужно продолжить диалог с сохранением контекста.
            None — начать новый разговор.
        genui_url: URL сервиса tagme-x-genui. Авто-определяется если не задан.
        user_id: Идентификатор пользователя для сервиса genui. По умолчанию ``mcp-agent``.
        user_locale: Локаль для вопросов сервиса. По умолчанию ``ru-RU``.
        config_path: Путь к конфигу Tagme. Использует дефолтный если не указан.
    """
    config = load_tagme_config(config_path, token=get_request_tagme_token())
    resolved_url = genui_url if genui_url is not None else resolve_genui_url(config.url or "")
    base_url = resolved_url.rstrip('/')
    auth_type, token = resolve_tagme_auth_credentials(config=config)
    headers = {'Authorization': f'{auth_type} {token}'}
    user_payload = {'id': user_id, 'locale': user_locale}
    return await _call_genui(
        base_url,
        headers,
        user_payload,
        prompt,
        generation_id,
        answers,
        input_example=input_example,
        input_schema=input_schema,
        conversation_id=conversation_id,
    )


async def _call_genui(
    base_url: str,
    headers: Dict[str, str],
    user_payload: Dict[str, str],
    prompt: str,
    generation_id: Optional[str],
    answers: Optional[List[Dict[str, Any]]],
    *,
    input_example: Optional[Dict[str, Any]] = None,
    input_schema: Optional[Dict[str, Any]] = None,
    conversation_id: Optional[str] = None,
    previous_interface: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    async with aiohttp.ClientSession(headers=headers) as session:
        if generation_id is None:
            request_body: Dict[str, Any] = {
                'user': user_payload,
                'prompt': prompt,
            }
            if input_example is not None:
                request_body['input_example'] = input_example
            if input_schema is not None:
                request_body['input_schema'] = input_schema
            if conversation_id is not None:
                request_body['conversation_id'] = conversation_id
            if previous_interface is not None:
                request_body['previous_interface'] = previous_interface
            async with session.post(f'{base_url}/v1/ui-generations', json=request_body, ssl=False) as resp:
                resp.raise_for_status()
                raw = await resp.text()
                if not raw or not raw.strip().startswith('{'):
                    raise ValueError(
                        f'Сервис genui вернул неожиданный ответ (статус {resp.status}): {raw[:200]!r}. '
                        f'Проверьте, что сервис доступен по адресу {base_url} '
                        f'или задайте переменную окружения CROWD_SDK_GENUI_URL.'
                    )
                data = json.loads(raw)
        else:
            answers_payload = [
                {'question_id': a.get('question_id', ''), 'value': a.get('value')} for a in (answers or [])
            ]
            request_body = {'user': user_payload, 'answers': answers_payload}
            async with session.post(
                f'{base_url}/v1/ui-generations/{generation_id}/answers',
                json=request_body,
                ssl=False,
            ) as resp:
                resp.raise_for_status()
                raw = await resp.text()
                if not raw or not raw.strip().startswith('{'):
                    raise ValueError(
                        f'Сервис genui вернул неожиданный ответ (статус {resp.status}): {raw[:200]!r}. '
                        f'Проверьте, что сервис доступен по адресу {base_url} '
                        f'или задайте переменную окружения CROWD_SDK_GENUI_URL.'
                    )
                data = json.loads(raw)

    status = data.get('status')
    gen_id = data.get('generation_id')
    conv_id = data.get('conversation_id')

    if status == 'needs_input':
        questions_block = data.get('questions') or {}
        return normalize_for_mcp(
            {
                'entity_type': 'genui_questions',
                'generation_id': gen_id,
                'conversation_id': conv_id,
                'status': status,
                'questions': questions_block.get('questions', []),
                'answer_endpoint': questions_block.get('answer_endpoint'),
            }
        )

    if status == 'completed':
        result = data.get('result') or {}
        interface_raw = result.get('interface') or {}
        interface = {
            'html': interface_raw.get('html'),
            'js': interface_raw.get('js'),
            'css': interface_raw.get('css'),
            'config': interface_raw.get('config'),
            'specification': interface_raw.get('spec'),
            'example': interface_raw.get('example'),
        }
        return normalize_for_mcp(
            {
                'entity_type': 'genui_interface_ready',
                'generation_id': gen_id,
                'conversation_id': conv_id,
                'status': status,
                'interface': interface,
                'summary': result.get('summary'),
            }
        )

    error_msg = data.get('error') or data.get('message') or 'unknown error'
    raise RuntimeError(f'genui generation failed (status={status!r}): {error_msg}')


async def edit_tagme_interface(  # pylint: disable=R0913
    prompt: str,
    conversation_id: Optional[str] = None,
    current_interface: Optional[Dict[str, Any]] = None,
    generation_id: Optional[str] = None,
    answers: Optional[List[Dict[str, Any]]] = None,
    genui_url: Optional[str] = None,
    user_id: str = 'mcp-agent',
    user_locale: str = 'ru-RU',
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Редактировать существующий интерфейс TagMe через сервис tagme-x-genui.

    Поддерживает два сценария:
    - Интерфейс сгенерирован через ``generate_tagme_interface``: передать ``conversation_id``
      из предыдущего ответа — genui восстановит контекст из истории.
    - Интерфейс создан вручную или ``conversation_id`` недоступен: передать ``current_interface``
      (dict с ключами ``html``, ``js``, ``css``, ``config``, ``example``, ``spec``) —
      genui использует его как базу для правок.

    Примеры правок: «сделай тёмную тему», «добавь фильтр», «убери поле комментария».

    Алгоритм:
    1. Первый вызов: передать ``prompt`` + ``conversation_id`` или ``current_interface``.
    2. Если сервис вернул ``status=needs_input`` — повторить с тем же ``generation_id`` и ``answers``.
    3. При ``status=completed`` — ``interface`` содержит обновлённый интерфейс,
       ``conversation_id`` — для следующих правок.

    Параметры:
        prompt: описание правки в стиле веб-дизайнера.
        conversation_id: ID из предыдущего ответа genui. None если интерфейс создан вручную.
        current_interface: текущий интерфейс для редактирования (если нет ``conversation_id``).
            Ожидается dict с полями ``html``, ``js``, ``css``, ``config``, ``example``, ``spec``.
        generation_id: ID текущего шага генерации. None на первом вызове.
        answers: ответы на уточняющие вопросы (если ``status=needs_input``).
        genui_url: URL сервиса tagme-x-genui. Авто-определяется если не задан.
    """
    if conversation_id is None and current_interface is None:
        raise ValueError('Необходимо передать conversation_id или current_interface.')
    config = load_tagme_config(config_path, token=get_request_tagme_token())
    resolved_url = genui_url if genui_url is not None else resolve_genui_url(config.url or "")
    base_url = resolved_url.rstrip('/')
    auth_type, token = resolve_tagme_auth_credentials(config=config)
    headers = {'Authorization': f'{auth_type} {token}'}
    user_payload = {'id': user_id, 'locale': user_locale}
    return await _call_genui(
        base_url,
        headers,
        user_payload,
        prompt,
        generation_id,
        answers,
        conversation_id=conversation_id,
        previous_interface=current_interface,
    )


async def apply_interface_to_project(  # pylint: disable=R0913
    project_id: str,
    html: Optional[str] = None,
    js: Optional[str] = None,
    css: Optional[str] = None,
    config: Optional[Dict[str, Any]] = None,
    specification: Optional[Dict[str, Any]] = None,
    example: Optional[Dict[str, Any]] = None,
    organization_id: Optional[str] = None,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Применяет сгенерированный интерфейс к существующему проекту TagMe.

    Обновляет поля ``html``, ``js``, ``css``, ``config``, ``specification``, ``example``
    в методе проекта. Передаются только те поля, которые не равны None.

    Обычно вызывается после ``generate_tagme_interface`` с содержимым поля ``interface``
    из результата генерации.

    Args:
        project_id: ID проекта TagMe.
        html: HTML-шаблон интерфейса.
        js: JavaScript-код интерфейса.
        css: CSS-стили интерфейса.
        config: Конфигурация интерфейса (dict).
        specification: Спецификация полей задачи (dict).
        example: Пример данных для задачи (dict).
        organization_id: ID организации. Определяется автоматически если не указан.
        config_path: Путь к конфигу Tagme. Использует дефолтный если не указан.
    """
    updated_fields = [
        key
        for key, val in [
            ('html', html),
            ('js', js),
            ('css', css),
            ('config', config),
            ('specification', specification),
            ('example', example),
        ]
        if val is not None
    ]
    if not updated_fields:
        raise ValueError('At least one interface field must be provided')

    forms = MethodFormsRequest(
        html=html,
        js=js,
        css=css,
        config=config,
        specification=specification,
        example=example,
    )

    async with open_tagme_client(config_path) as client:
        project = await _get_project_with_organization(client, project_id, organization_id, with_tasks_count=False)
        org = organization_id or project.organization_id
        await client.update_method(
            MethodDataRequest(uid=project.method_id, forms=forms),
            org,
        )

    return normalize_for_mcp(
        {
            'entity_type': 'human_mcp_interface_applied',
            'project_id': project_id,
            'updated_fields': updated_fields,
        }
    )


async def list_project_tasks(
    project_id: str,
    organization_id: Optional[str] = None,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Список задач проекта TagMe.

    Когда вызывать: нужно увидеть все задачи проекта (ID, название, статус, цена, overlap) перед
    добавлением новой задачи или обновлением существующей.
    Не вызывать для: содержимого ответов разметчиков → analyze_task_results / get_task_stats.
    Возвращает: project_id, tasks_count, tasks[].
    """
    async with open_tagme_client(config_path) as client:
        project = await _get_project_with_organization(client, project_id, organization_id, with_tasks_count=False)
        org = organization_id or project.organization_id
        tasks = await client.get_project_tasks(project_id, ignore_tasks=(), organization_id=org)

    return normalize_for_mcp(
        {
            'entity_type': 'human_mcp_tasks_list',
            'project_id': project_id,
            'tasks': [_task_metadata(t) for t in tasks],
            'tasks_count': len(tasks),
        }
    )


async def update_markup_task(  # pylint: disable=R0913
    task_id: str,
    name: Optional[str] = None,
    price: Optional[float] = None,
    overlap: Optional[int] = None,
    deadline: Optional[str] = None,
    description: Optional[str] = None,
    organization_id: Optional[str] = None,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Изменить параметры существующей задачи TagMe.

    Обновляет только переданные поля. Хотя бы одно поле должно быть указано.

    Когда вызывать: нужно поменять цену, количество разметчиков, дедлайн, название или описание задачи
    после её создания. Задачу не нужно останавливать для обновления параметров.
    Не вызывать для: загрузки новых элементов → create_markup_task_with_items;
    остановки задачи → stop_markup_task.
    Возвращает: task_id, task (обновлённые метаданные).
    """
    updatable = {'name': name, 'price': price, 'overlap': overlap, 'deadline': deadline, 'description': description}
    if not any(v is not None for v in updatable.values()):
        raise ValueError('At least one of name, price, overlap, deadline, description must be provided')

    parsed_deadline = parse_deadline_optional(deadline) if deadline is not None else None

    async with open_tagme_client(config_path) as client:
        task = await client.get_task(task_id, organization_id=organization_id)
        if name is not None:
            task.name = name
        if price is not None:
            task.price = price
        if overlap is not None:
            task.overlap = overlap
        if parsed_deadline is not None:
            task.deadline = parsed_deadline
        if description is not None:
            task.description = description
        updated = await client.update_task(task, organization_id=organization_id)

    return normalize_for_mcp(
        {
            'entity_type': 'human_mcp_task_updated',
            'task_id': task_id,
            'task': _task_metadata(updated),
        }
    )


async def stop_markup_task(
    task_id: str,
    organization_id: Optional[str] = None,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Остановить активную задачу TagMe.

    Когда вызывать: задача запущена и нужно её приостановить (набор данных завершён, ошибка в items,
    нужно поменять параметры). Инструмент ждёт пока задача полностью остановится.
    Не вызывать для: задач в статусе INITIAL или уже остановленных.
    Возвращает: task_id, task (статус после остановки).
    """
    async with open_tagme_client(config_path) as client:
        task = await client.stop_task(task_id, organization_id=organization_id)

    return normalize_for_mcp(
        {
            'entity_type': 'human_mcp_task_stopped',
            'task_id': task_id,
            'task': _task_metadata(task),
        }
    )


async def upload_project_instruction(
    project_id: str,
    instruction: str,
    organization_id: Optional[str] = None,
    config_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Загрузить или обновить инструкцию для разметчиков в проекте TagMe.

    Сохраняет текст инструкции как ``marker_brief`` метода проекта.
    Вызывать когда нужно обновить инструкцию у существующего проекта
    без изменения других настроек (шаблон, пулы, название).

    Параметры:
        project_id: ID проекта.
        instruction: текст инструкции для разметчиков.
        organization_id: ID организации (опционально).
    """
    async with open_tagme_client(config_path) as client:
        project = await _get_project_with_organization(
            client,
            project_id,
            organization_id,
            with_tasks_count=False,
        )
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as tmp:
            tmp.write(instruction)
            tmp_path = tmp.name
        try:
            await client.update_method_brief(
                method_id=project.method_id,
                file_path=tmp_path,
                file_name='instruction.txt',
            )
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    return normalize_for_mcp(
        {
            'entity_type': 'human_mcp_instruction_uploaded',
            'project_id': project.uid,
            'project_name': project.name,
            'instruction_length': len(instruction),
        }
    )


def _load_items_from_file(file_path: str) -> List[Dict[str, Any]]:
    """Read items from a local .json or .jsonl file."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f'items_file_path not found: {path}')
    text = path.read_text(encoding='utf-8').strip()
    suffix = path.suffix.lower()
    if suffix == '.jsonl':
        result = []
        for lineno, line in enumerate(text.splitlines(), start=1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f'Invalid JSON on line {lineno} of {path}: {exc}') from exc
            if not isinstance(obj, dict):
                raise ValueError(f'Line {lineno} of {path} must be a JSON object, got {type(obj).__name__}')
            result.append(obj)
        return result
    if suffix == '.json':
        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f'Invalid JSON in {path}: {exc}') from exc
        if not isinstance(data, list):
            raise ValueError(f'{path} must contain a JSON array, got {type(data).__name__}')
        return data
    raise ValueError(f'Unsupported file extension {suffix!r} for items_file_path. Use .json or .jsonl')
