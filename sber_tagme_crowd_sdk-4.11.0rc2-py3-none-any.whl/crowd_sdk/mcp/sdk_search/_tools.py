import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from crowd_sdk.mcp.sdk_search._index import get_or_build_index

_SDK_ROOT = Path(os.path.dirname(__file__)).parent.parent.parent


async def search_sdk(
    query: str,
    top_k: int = 10,
    type_filter: Optional[str] = None,
    section_filter: Optional[str] = None,
) -> Dict[str, Any]:
    """Поиск по SDK crowd-sdk: методы TagmeClient, примеры кода, документация.

    Когда вызывать: нужно найти метод для конкретной задачи, посмотреть пример кода,
    узнать как работает та или иная функция SDK.

    Стратегия поиска: формулируй запросы на английском — SDK написан на английском.
    Если задача не решается одним методом, ищи несколько раз с разными запросами
    (например, отдельно «get control items», отдельно «upload json data control»)
    и комбинируй найденные методы и примеры для построения многошагового решения.

    query: запрос на английском (upload data, get control items, create task и т.д.)
    top_k: количество результатов (дефолт 10, макс 20)
    type_filter: "method", "example", "readme" или None (все типы)
    section_filter: "task", "files", "results", "project" и т.д., или None

    Возвращает список результатов с полями: id, title, section, type, text (полный текст), score.
    Для примеров (type=example) text содержит полный код файла.
    Для методов (type=method) text содержит полный docstring.
    """
    top_k = min(max(1, top_k), 20)
    index = get_or_build_index(_SDK_ROOT)

    fetch_k = top_k * 10 if (type_filter or section_filter) else top_k
    raw_results: List[Dict[str, Any]] = index.search(query, top_k=fetch_k)

    filtered: List[Dict[str, Any]] = []
    for doc in raw_results:
        if type_filter and doc.get('type') != type_filter:
            continue
        if section_filter and doc.get('section') != section_filter:
            continue
        filtered.append(doc)
        if len(filtered) >= top_k:
            break

    output_items: List[Dict[str, Any]] = []
    for doc in filtered:
        output_items.append(
            {
                'id': doc.get('id', ''),
                'title': doc.get('title', ''),
                'section': doc.get('section', ''),
                'type': doc.get('type', ''),
                'text': doc.get('text', ''),
                'score': doc.get('score', 0.0),
            }
        )

    return {'results': output_items, 'total': len(output_items)}
