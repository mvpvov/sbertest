import ast
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_cache: Optional['SdkIndex'] = None


def _extract_section_from_decorator(decorator: ast.expr) -> Optional[str]:
    """Extract section name from @autodoc.section(...) decorator."""
    if not isinstance(decorator, ast.Call):
        return None
    func = decorator.func
    # Support autodoc.section("foo") or section("foo")
    if isinstance(func, ast.Attribute) and func.attr == 'section':
        pass
    elif isinstance(func, ast.Name) and func.id == 'section':
        pass
    else:
        return None
    if decorator.args and isinstance(decorator.args[0], ast.Constant):
        return str(decorator.args[0].value)
    return None


def _parse_methods(client_path: Path) -> List[Dict[str, Any]]:
    """Parse public async methods from TagmeClient using ast."""
    if not client_path.exists():
        logger.warning('TagmeClient not found at %s', client_path)
        return []

    source = client_path.read_text(encoding='utf-8')
    try:
        tree = ast.parse(source, filename=str(client_path))
    except SyntaxError as exc:
        logger.warning('Failed to parse %s: %s', client_path, exc)
        return []

    docs: List[Dict[str, Any]] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.ClassDef,)):
            continue
        for item in node.body:
            if not isinstance(item, ast.AsyncFunctionDef):
                continue
            if item.name.startswith('_'):
                continue

            docstring = ast.get_docstring(item) or ''
            section: Optional[str] = None
            for dec in item.decorator_list:
                s = _extract_section_from_decorator(dec)
                if s is not None:
                    section = s
                    break

            docs.append(
                {
                    'id': f'method:{item.name}',
                    'title': item.name,
                    'section': section or '',
                    'text': docstring,
                    'type': 'method',
                }
            )

    return docs


def _parse_examples(examples_root: Path) -> List[Dict[str, Any]]:
    """Parse .py files from first-level subfolders of examples/."""
    if not examples_root.exists():
        logger.warning('examples/ directory not found at %s', examples_root)
        return []

    docs: List[Dict[str, Any]] = []
    for folder in sorted(examples_root.iterdir()):
        if not folder.is_dir():
            continue
        for py_file in sorted(folder.glob('*.py')):
            text = py_file.read_text(encoding='utf-8', errors='replace')
            docs.append(
                {
                    'id': f'example:{folder.name}/{py_file.name}',
                    'title': py_file.stem,
                    'section': folder.name,
                    'text': text,
                    'type': 'example',
                }
            )
    return docs


def _parse_readmes(examples_root: Path) -> List[Dict[str, Any]]:
    """Parse README.md files from first-level subfolders of examples/."""
    if not examples_root.exists():
        return []

    docs: List[Dict[str, Any]] = []
    for folder in sorted(examples_root.iterdir()):
        if not folder.is_dir():
            continue
        readme = folder / 'README.md'
        if not readme.exists():
            continue
        content = readme.read_text(encoding='utf-8', errors='replace')
        # Extract title from first heading
        title = folder.name
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith('#'):
                title = stripped.lstrip('#').strip()
                break
        docs.append(
            {
                'id': f'readme:{folder.name}',
                'title': title,
                'section': folder.name,
                'text': content,
                'type': 'readme',
            }
        )
    return docs


def _tokenize(text: str) -> List[str]:
    return text.lower().split()


class SdkIndex:
    """BM25 index over crowd-sdk: methods, examples, readme docs."""

    def __init__(self) -> None:
        self._documents: List[Dict[str, Any]] = []
        self._corpus: List[List[str]] = []
        self._bm25: Any = None

    def build(self, sdk_root: Path) -> List[Dict[str, Any]]:
        """Build the index from sdk_root and cache it in memory."""
        try:
            from rank_bm25 import BM25Okapi  # pylint: disable=import-outside-toplevel
        except ImportError as exc:
            raise ImportError('rank-bm25 is required for SDK search. Install it with: pip install rank-bm25') from exc

        client_path = sdk_root / 'crowd_sdk' / 'tagme' / 'http_client' / 'client.py'
        examples_root = sdk_root / 'examples'

        all_docs: List[Dict[str, Any]] = []
        all_docs.extend(_parse_methods(client_path))
        all_docs.extend(_parse_examples(examples_root))
        all_docs.extend(_parse_readmes(examples_root))

        self._documents = all_docs
        self._corpus = [_tokenize(doc['text'] + ' ' + doc['title']) for doc in all_docs]
        self._bm25 = BM25Okapi(self._corpus)

        logger.info('SdkIndex built: %d documents', len(all_docs))
        return all_docs

    def search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """BM25 search over all indexed documents."""
        if self._bm25 is None:
            raise RuntimeError('Index not built. Call build() first.')

        tokens = _tokenize(query)
        scores: List[float] = self._bm25.get_scores(tokens).tolist()

        indexed: List[Tuple[int, float]] = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)[:top_k]

        results: List[Dict[str, Any]] = []
        for idx, score in indexed:
            doc = dict(self._documents[idx])
            doc['score'] = round(score, 4)
            results.append(doc)
        return results


def get_or_build_index(sdk_root: Path) -> SdkIndex:
    """Return the cached SdkIndex, building it on first call."""
    global _cache  # pylint: disable=global-statement
    if _cache is None:
        _cache = SdkIndex()
        _cache.build(sdk_root)
    return _cache
