"""
Shared workflow metadata for dataset builder MCP tools (agent guidance).
"""

from pathlib import Path
from typing import Any, Dict, List, Optional

WORKFLOW_STEPS = [
    "1. create_dataset(name, dataset_type)",
    "2. preview_dataset_setup(name) — show spec.md + config.yaml to the user; wait for approval",
    "3. Edit spec.md / config.yaml if the user requests changes",
    "4. generate_cases(name, n_cases=…) — required for diverse SFT/chat datasets",
    "5. generate_dataset(name, dry_run=True) — show plan; wait for user approval",
    "6. generate_dataset(name, n_samples=…) — actual LLM generation",
    "7. inspect_dataset(name) — statistics and sample records",
]

FORBIDDEN_ACTIONS = [
    "Do NOT write Python, shell, or notebook scripts to generate dataset.jsonl",
    "Do NOT call external LLM APIs directly from project code for dataset samples",
    "Do NOT skip generate_cases then loop topics manually in a custom script",
    "Do NOT call generate_dataset without dry_run=True until the user explicitly approves",
]

AGENT_CONFIRMATION_HINT = (
    "Stop after create_dataset or preview_dataset_setup: show full spec.md and config.yaml "
    "to the user and wait for explicit approval (e.g. 'ok', 'запускай') before generate_cases "
    "or generate_dataset."
)


def workflow_payload(stage: str, *, extra_steps: Optional[List[str]] = None) -> Dict[str, Any]:
    steps = list(WORKFLOW_STEPS)
    if extra_steps:
        steps.extend(extra_steps)
    return {
        "workflow": steps,
        "forbidden": list(FORBIDDEN_ACTIONS),
        "await_user_confirmation": stage in {"after_create", "after_preview", "before_generate"},
        "agent_hint": AGENT_CONFIRMATION_HINT,
        "stage": stage,
    }


def _cases_required(config: dict) -> bool:
    return bool(config.get("require_cases", False))


def cases_status(dataset_dir: Path) -> Dict[str, Any]:
    cases_path = dataset_dir / "cases.jsonl"
    if not cases_path.exists():
        return {"exists": False, "count": 0, "path": str(cases_path)}
    lines = [ln for ln in cases_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    return {"exists": True, "count": len(lines), "path": str(cases_path)}


def cases_gate_error(name: str, dataset_dir: Path, config: dict) -> Optional[Dict[str, Any]]:
    """Return an error dict if generation must not proceed without cases.jsonl."""
    if not _cases_required(config):
        return None
    status = cases_status(dataset_dir)
    if status["exists"] and status["count"] > 0:
        return None
    return {
        "error": (
            f"config.yaml has require_cases: true but cases.jsonl is missing or empty "
            f"for dataset '{name}'. Run generate_cases('{name}') first."
        ),
        "require_cases": True,
        "cases": status,
        "workflow": WORKFLOW_STEPS,
        "forbidden": FORBIDDEN_ACTIONS,
    }


def cases_warnings(name: str, dataset_dir: Path, config: dict) -> List[str]:
    """Non-blocking hints when cases are recommended but not required."""
    warnings: List[str] = []
    status = cases_status(dataset_dir)
    if _cases_required(config):
        if not status["exists"] or status["count"] == 0:
            warnings.append(f"require_cases is enabled: run generate_cases('{name}') before generate_dataset.")
        return warnings
    if not status["exists"]:
        warnings.append(
            f"No cases.jsonl — diversity will be weaker. Recommended: generate_cases('{name}') "
            f"before generate_dataset."
        )
    return warnings
