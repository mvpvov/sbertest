"""
create_dataset — creates folder structure and config files for a new dataset.
"""

import shutil
from pathlib import Path

from crowd_sdk.mcp.dataset_builder._llm_backend import default_generation_models, resolve_generation_backend
from crowd_sdk.mcp.dataset_builder._workflow import workflow_payload

VALID_TYPES = {"chat", "preference", "scored", "classification", "rag", "trajectory", "eval"}

# Templates live next to this file
_TEMPLATES_DIR = Path(__file__).parent / "templates"


def create_dataset(name: str, dataset_type: str) -> dict:
    """
    Create the folder structure and config files for a new dataset.

    Когда вызывать: пользователь просит новый датасет для дообучения (SFT, DPO, eval и т.д.).

    Не вызывать для: дополнения уже существующего output/dataset.jsonl скриптом на Python.

    После вызова: обязательно preview_dataset_setup(name), покажите spec.md и config.yaml
    пользователю и дождитесь подтверждения. Затем generate_cases → generate_dataset(dry_run=True)
    → generate_dataset.

    Запрещено агенту: писать Python/shell-скрипты для генерации jsonl; вызывать LLM из кода
    проекта вместо MCP generate_cases / generate_dataset.

    Args:
        name: Dataset name (used as directory name, e.g. 'my_sft_dataset')
        dataset_type: One of: chat, preference, scored, classification, rag, trajectory, eval

    Returns:
        dict with created file paths, workflow, forbidden actions, and next steps
    """
    if dataset_type not in VALID_TYPES:
        return {"error": f"Unknown dataset_type '{dataset_type}'. Valid types: {sorted(VALID_TYPES)}"}

    name = name.strip().replace(" ", "_")
    project_root = Path.cwd()
    dataset_dir = project_root / "datasets" / name

    if dataset_dir.exists():
        return {
            "error": f"Dataset '{name}' already exists at {dataset_dir}. "
            f"Delete it first or choose a different name."
        }

    (dataset_dir / "prompts").mkdir(parents=True, exist_ok=True)
    (dataset_dir / "output").mkdir(parents=True, exist_ok=True)

    created = []

    # Copy spec template
    spec_src = _TEMPLATES_DIR / f"spec_{dataset_type}.md"
    spec_dst = dataset_dir / "spec.md"
    if spec_src.exists():
        shutil.copy2(spec_src, spec_dst)
    else:
        spec_dst.write_text(f"# Dataset Spec — {dataset_type}\n\n<!-- Fill in your spec here -->\n")
    created.append(str(spec_dst))

    # Copy config template and substitute name/type
    config_src = _TEMPLATES_DIR / "config_default.yaml"
    config_dst = dataset_dir / "config.yaml"
    if config_src.exists():
        content = config_src.read_text()
        backend = resolve_generation_backend({})
        defaults = default_generation_models()[0]
        content = (
            content.replace("{{name}}", name)
            .replace("{{type}}", dataset_type)
            .replace("{{backend}}", backend)
            .replace("{{provider}}", defaults["provider"])
            .replace("{{model}}", defaults["model"])
        )
        config_dst.write_text(content)
    else:
        defaults = default_generation_models()[0]
        config_dst.write_text(
            f'name: "{name}"\ntype: "{dataset_type}"\nn_samples: 50\n'
            f'models:\n  - provider: {defaults["provider"]}\n'
            f'    model: {defaults["model"]}\n    weight: 1.0\n'
            f'generation:\n  temperature: 0.8\n  max_tokens: 1024\n  batch_size: 5\n'
            f'output:\n  format: jsonl\n  path: output/dataset.jsonl\n  append: false\n'
        )
    created.append(str(config_dst))

    # Copy tools.yaml template (enables agentic generation mode)
    tools_src = _TEMPLATES_DIR / "tools_default.yaml"
    tools_dst = dataset_dir / "tools.yaml"
    if tools_src.exists():
        shutil.copy2(tools_src, tools_dst)
        created.append(str(tools_dst))

    # For chat datasets create system_prompt.md — injected into samples after generation (no LLM tokens spent)
    if dataset_type == "chat":
        system_prompt_dst = dataset_dir / "system_prompt.md"
        system_prompt_src = _TEMPLATES_DIR / "system_prompt_chat.md"
        if system_prompt_src.exists():
            shutil.copy2(system_prompt_src, system_prompt_dst)
        else:
            system_prompt_dst.write_text("<!-- Системный промпт ассистента. Оставьте пустым если не нужен. -->\n")
        created.append(str(system_prompt_dst))

    return {
        "success": True,
        "dataset": name,
        "type": dataset_type,
        "created_files": created,
        "await_user_confirmation": True,
        "confirmation_prompt": (
            f"Call preview_dataset_setup('{name}'), show spec.md and config.yaml to the user, "
            "and wait for explicit approval before generate_cases or generate_dataset."
        ),
        **workflow_payload("after_create"),
        "next_steps": [
            f"preview_dataset_setup('{name}') — show spec.md + config.yaml; wait for user OK",
            f"Edit datasets/{name}/spec.md if needed — use case, output schema, case dimensions",
            f"generate_cases('{name}', n_cases=50) — do NOT replace with a custom Python script",
            f"generate_dataset('{name}', dry_run=True) — show plan; wait for user OK",
            f"generate_dataset('{name}', n_samples=100) — only after approval",
            f"inspect_dataset('{name}')",
        ],
    }
