"""
Pluggable LLM backends for dataset generation.

litellm is imported lazily so create_dataset / inspect_dataset work without it installed.
"""

import asyncio
import concurrent.futures
import os
from dataclasses import dataclass
from typing import Any, Coroutine, List, Optional, Protocol, Tuple, TypeVar

_T = TypeVar("_T")


class ToolsNotSupportedError(Exception):
    """The backend rejected a request that included tool schemas."""


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: str


@dataclass
class CompletionMessage:
    content: Any  # raw LLM response content — normalised to Optional[str] in __post_init__
    tool_calls: List[ToolCall]

    def __post_init__(self) -> None:
        if self.content is not None and not isinstance(self.content, str):
            if isinstance(self.content, list):
                parts = []
                for item in self.content:
                    if isinstance(item, str):
                        parts.append(item)
                    elif isinstance(item, dict):
                        if "text" in item and isinstance(item["text"], str):
                            parts.append(item["text"])
                        elif "content" in item and isinstance(item["content"], str):
                            parts.append(item["content"])
                self.content = "".join(parts)
            else:
                self.content = str(self.content)


@dataclass
class CompletionResult:
    message: CompletionMessage
    usage: dict


class GenerationBackend(Protocol):
    def complete(
        self,
        *,
        messages: list,
        model: str,
        provider: str,
        temperature: float,
        max_tokens: int,
        tools: Optional[list] = None,
    ) -> CompletionResult:
        """Run one chat completion. Pass tools=None for a plain completion."""


def _model_id(provider: str, model: str) -> str:
    return model if provider in ("openai",) else f"{provider}/{model}"


def _usage_from_response(response: Any) -> dict:
    if not response.usage:
        return {}
    return {
        "prompt_tokens": response.usage.prompt_tokens or 0,
        "completion_tokens": response.usage.completion_tokens or 0,
        "total_tokens": response.usage.total_tokens or 0,
    }


def _message_from_litellm(raw: Any) -> CompletionMessage:
    tool_calls: List[ToolCall] = []
    for tc in getattr(raw, "tool_calls", None) or []:
        fn = tc.function
        tool_calls.append(
            ToolCall(
                id=tc.id,
                name=fn.name,
                arguments=fn.arguments or "",
            )
        )
    return CompletionMessage(content=getattr(raw, "content", None), tool_calls=tool_calls)


_LITELLM_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=100)


class GenerationClient:
    """Facade over a GenerationBackend for dataset generation."""

    def __init__(self, backend: GenerationBackend) -> None:
        self.backend = backend

    @classmethod
    def from_config(
        cls,
        gen_config: dict,
        tagme_token: Optional[str] = None,
        tagme_auth: Optional[Tuple[str, str]] = None,
    ) -> "GenerationClient":
        name = resolve_generation_backend(gen_config)
        http_cfg = gen_config.get("http", {})
        if tagme_auth is None and tagme_token:
            tagme_auth = ("Bearer", tagme_token)
        return cls(get_generation_backend(name, tagme_auth=tagme_auth, **http_cfg))

    def complete_prompt(
        self,
        prompt: str,
        model: str,
        provider: str,
        temperature: float,
        max_tokens: int,
    ) -> CompletionResult:
        return self.backend.complete(
            messages=[{"role": "user", "content": prompt}],
            model=model,
            provider=provider,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    def complete_messages(
        self,
        messages: list,
        model: str,
        provider: str,
        temperature: float,
        max_tokens: int,
        *,
        tools: Optional[list] = None,
    ) -> CompletionResult:
        return self.backend.complete(
            messages=messages,
            model=model,
            provider=provider,
            temperature=temperature,
            max_tokens=max_tokens,
            tools=tools,
        )

    async def acomplete_prompt(
        self,
        prompt: str,
        model: str,
        provider: str,
        temperature: float,
        max_tokens: int,
    ) -> CompletionResult:
        """Async variant of complete_prompt."""
        return await self.acomplete_messages(
            messages=[{"role": "user", "content": prompt}],
            model=model,
            provider=provider,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    async def acomplete_messages(
        self,
        messages: list,
        model: str,
        provider: str,
        temperature: float,
        max_tokens: int,
        *,
        tools: Optional[list] = None,
    ) -> CompletionResult:
        """Async variant — uses _async_complete if backend supports it, else runs in executor."""
        if isinstance(self.backend, HttpBackend):
            return await self.backend._async_complete(  # pylint: disable=protected-access
                messages=messages,
                model=model,
                temperature=temperature,
                max_tokens=max_tokens,
                tools=tools,
            )
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            _LITELLM_EXECUTOR,
            lambda: self.backend.complete(
                messages=messages,
                model=model,
                provider=provider,
                temperature=temperature,
                max_tokens=max_tokens,
                tools=tools,
            ),
        )


class LiteLLMBackend:
    """Chat completions via litellm."""

    def complete(  # pylint: disable=no-self-use
        self,
        *,
        messages: list,
        model: str,
        provider: str,
        temperature: float,
        max_tokens: int,
        tools: Optional[list] = None,
    ) -> CompletionResult:
        try:
            import litellm  # pylint: disable=import-outside-toplevel
        except ImportError as exc:
            raise ImportError("litellm is not installed. Run: pip install litellm") from exc
        kwargs: dict = {
            "model": _model_id(provider, model),
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        base_url = os.environ.get("OPENAI_API_BASE") or os.environ.get("OPENAI_BASE_URL")
        if base_url:
            kwargs["base_url"] = base_url
        if tools:
            kwargs["tools"] = tools

        try:
            response = litellm.completion(**kwargs)
        except litellm.BadRequestError as exc:
            if tools:
                raise ToolsNotSupportedError(str(exc)) from exc
            raise
        return CompletionResult(
            message=_message_from_litellm(response.choices[0].message),
            usage=_usage_from_response(response),
        )


def _run_sync(coro: Coroutine[Any, Any, _T]) -> _T:
    """Run a coroutine from a synchronous context.

    If there is no running event loop, uses asyncio.run().
    If called from inside a running loop (e.g. nested asyncio.run in a thread),
    spins up a new thread to avoid "cannot run nested event loop" error.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(asyncio.run, coro)
        return future.result()


class HttpBackend:
    """OpenAI-compatible HTTP backend using aiohttp (no litellm)."""

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        auth_type: str = "Bearer",
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.auth_type = auth_type

    async def _async_complete(
        self,
        *,
        messages: list,
        model: str,
        temperature: float,
        max_tokens: int,
        tools: Optional[list] = None,
    ) -> CompletionResult:
        import aiohttp  # pylint: disable=import-outside-toplevel

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"{self.auth_type} {self.api_key}"

        body: dict = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if tools:
            body["tools"] = tools

        url = f"{self.base_url}/v1/chat/completions"
        async with aiohttp.ClientSession(headers=headers) as session:
            async with session.post(url, json=body, ssl=False) as resp:
                if resp.status == 400 and tools:
                    text = await resp.text()
                    raise ToolsNotSupportedError(text)
                if not resp.ok:
                    text = await resp.text()
                    raise aiohttp.ClientResponseError(
                        resp.request_info,
                        resp.history,
                        status=resp.status,
                        message=f"{text[:300]}",
                        headers=resp.headers,
                    )
                data = await resp.json()

        choice = data["choices"][0]["message"]
        tool_calls = []
        for tc in choice.get("tool_calls") or []:
            fn = tc["function"]
            tool_calls.append(ToolCall(id=tc["id"], name=fn["name"], arguments=fn.get("arguments", "")))

        usage_data = data.get("usage", {})
        return CompletionResult(
            message=CompletionMessage(content=choice.get("content"), tool_calls=tool_calls),
            usage={
                "prompt_tokens": usage_data.get("prompt_tokens", 0),
                "completion_tokens": usage_data.get("completion_tokens", 0),
                "total_tokens": usage_data.get("total_tokens", 0),
            },
        )

    def complete(
        self,
        *,
        messages: list,
        model: str,
        provider: str,  # pylint: disable=unused-argument
        temperature: float,
        max_tokens: int,
        tools: Optional[list] = None,
    ) -> CompletionResult:
        return _run_sync(
            self._async_complete(
                messages=messages,
                model=model,
                temperature=temperature,
                max_tokens=max_tokens,
                tools=tools,
            )
        )


TAGME_LLM_URL_DEFAULT = "https://tagme.sberdevices.ru/x/ai/llm"

ENV_GENERATION_BACKEND = "CROWD_MCP_GENERATION_BACKEND"
ENV_GENERATION_MODEL = "CROWD_MCP_GENERATION_MODEL"
ENV_GENERATION_PROVIDER = "CROWD_MCP_GENERATION_PROVIDER"
SUPPORTED_BACKENDS = ("tagme", "litellm", "http")

DEFAULT_GENERATION_MODEL = "z-ai/glm-5.1"
DEFAULT_GENERATION_PROVIDER = "openai"


def default_generation_model() -> str:
    return os.environ.get(ENV_GENERATION_MODEL, "").strip() or DEFAULT_GENERATION_MODEL


def default_generation_provider() -> str:
    return os.environ.get(ENV_GENERATION_PROVIDER, "").strip() or DEFAULT_GENERATION_PROVIDER


def default_generation_models() -> list:
    """Single-model list from env (if set) or built-in defaults."""
    return [
        {
            "provider": default_generation_provider(),
            "model": default_generation_model(),
            "weight": 1.0,
        }
    ]


def resolve_generation_backend(gen_config: Optional[dict] = None) -> str:
    """Resolve backend name from config. Default is tagme."""
    if gen_config and gen_config.get("backend"):
        backend = gen_config.get("backend")
        if backend not in SUPPORTED_BACKENDS:
            raise ValueError(f"Invalid generation.backend={backend!r}. Supported: {', '.join(SUPPORTED_BACKENDS)}")
        return backend
    env = os.environ.get(ENV_GENERATION_BACKEND, "").strip().lower()
    if env:
        if env not in SUPPORTED_BACKENDS:
            raise ValueError(f"Invalid {ENV_GENERATION_BACKEND}={env!r}. Supported: {', '.join(SUPPORTED_BACKENDS)}")
        return env
    return "tagme"


def resolve_generation_models(model_list: Optional[list]) -> list:
    """Resolve models list from config. Falls back to env-based defaults if not set in config."""
    if model_list:
        return list(model_list)
    return default_generation_models()


def get_generation_backend(
    name: str = "litellm",
    tagme_token: Optional[str] = None,
    tagme_auth: Optional[Tuple[str, str]] = None,
    **options: Any,
) -> GenerationBackend:
    if name == "litellm":
        return LiteLLMBackend()
    if name == "http":
        base_url = options.get("base_url")
        if not isinstance(base_url, str) or not base_url:
            raise ValueError("generation.http.base_url is required when backend is 'http'")
        return HttpBackend(base_url=base_url, api_key=options.get("api_key"))
    if name == "tagme":
        base_url = os.environ.get("CROWD_MCP_TAGME_LLM_URL") or TAGME_LLM_URL_DEFAULT
        auth_type, token = "Bearer", tagme_token
        if tagme_auth:
            auth_type, token = tagme_auth
        return HttpBackend(base_url=base_url, api_key=token, auth_type=auth_type)
    raise ValueError(f"Unknown generation backend: {name!r}. Supported: litellm, http, tagme")
