"""ToolRegistry — загрузка и выполнение инструментов из tools.yaml."""

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)

_SUPPORTED_PROVIDERS = ("duckduckgo", "tavily", "serpapi", "http", "python", "llm")


class ToolRegistry:
    """Registry of callable tools loaded from tools.yaml."""

    def __init__(self, tools: List[Dict[str, Any]]) -> None:
        self._tools = tools

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def load(cls, dataset_dir: "Path") -> "ToolRegistry":
        tools_path = Path(dataset_dir) / "tools.yaml"
        if not tools_path.exists():
            logger.info("[registry] tools.yaml not found at %s — agentic mode disabled", tools_path)
            return cls([])

        try:
            raw = yaml.safe_load(tools_path.read_text(encoding="utf-8")) or {}
        except Exception as exc:  # pylint: disable=W0703
            logger.warning("[registry] Failed to parse tools.yaml: %s", exc)
            return cls([])

        tools_raw = raw.get("tools") or []
        if not isinstance(tools_raw, list):
            logger.warning("[registry] tools.yaml: 'tools' must be a list, got %s", type(tools_raw).__name__)
            return cls([])

        tools: List[Dict[str, Any]] = []
        for entry in tools_raw:
            if not isinstance(entry, dict):
                logger.warning("[registry] Skipping non-dict tool entry: %r", entry)
                continue
            name = entry.get("name")
            provider = entry.get("provider")
            if not name or not provider:
                logger.warning("[registry] Tool entry missing 'name' or 'provider': %r", entry)
                continue
            if provider not in _SUPPORTED_PROVIDERS:
                logger.warning(
                    "[registry] Unknown provider %r for tool %r. Supported: %s",
                    provider,
                    name,
                    ", ".join(_SUPPORTED_PROVIDERS),
                )
                continue
            # Validate provider deps at load time so errors surface early.
            ok, reason = _check_provider_deps(provider)
            if not ok:
                logger.warning("[registry] Tool %r (provider=%r) skipped: %s", name, provider, reason)
                continue
            tools.append(entry)
            logger.debug("[registry] Loaded tool %r (provider=%r)", name, provider)

        if not tools:
            logger.info("[registry] No tools loaded from tools.yaml — agentic mode disabled")
        else:
            logger.info("[registry] Loaded %d tool(s): %s", len(tools), [t["name"] for t in tools])

        return cls(tools)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def is_empty(self) -> bool:
        return len(self._tools) == 0

    def tool_schemas(self) -> List[Dict[str, Any]]:
        """Return OpenAI-compatible function tool schemas."""
        schemas = []
        for tool in self._tools:
            schemas.append(_build_schema(tool))
        return schemas

    async def call(self, name: str, args: Dict[str, Any]) -> Any:
        """Execute a tool by name with given args. Returns result as JSON-serialisable value."""
        tool = self._find(name)
        if tool is None:
            logger.warning("[registry] Tool %r called but not found in registry", name)
            return {"error": f"Tool '{name}' not found"}
        provider = tool["provider"]
        config = tool.get("config") or {}
        logger.debug("[registry] Calling tool %r (provider=%r) args=%r", name, provider, args)
        try:
            return await _dispatch(provider, name, config, args)
        except Exception as exc:  # pylint: disable=W0703
            logger.warning("[registry] Tool %r raised: %s", name, exc)
            return {"error": str(exc)}

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _find(self, name: str) -> Optional[Dict[str, Any]]:
        for tool in self._tools:
            if tool["name"] == name:
                return tool
        return None


# ------------------------------------------------------------------
# Schema builder
# ------------------------------------------------------------------


def _build_schema(tool: Dict[str, Any]) -> Dict[str, Any]:
    provider = tool["provider"]
    config = tool.get("config") or {}
    name = tool["name"]
    description = config.get("description") or f"Tool: {name}"

    if provider == "duckduckgo":
        parameters: Dict[str, Any] = {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
            },
            "required": ["query"],
        }
    elif provider in ("tavily", "serpapi"):
        parameters = {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
            },
            "required": ["query"],
        }
    elif provider == "http":
        parameters = config.get("parameters") or {
            "type": "object",
            "properties": {
                "input": {"type": "string", "description": "Input text"},
            },
            "required": ["input"],
        }
    elif provider == "python":
        parameters = config.get("parameters") or {
            "type": "object",
            "properties": {
                "input": {"type": "string"},
            },
            "required": ["input"],
        }
    else:
        parameters = {
            "type": "object",
            "properties": {
                "input": {"type": "string"},
            },
            "required": ["input"],
        }

    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": parameters,
        },
    }


# ------------------------------------------------------------------
# Dispatcher
# ------------------------------------------------------------------


async def _dispatch(
    provider: str,
    name: str,  # pylint: disable=unused-argument
    config: Dict[str, Any],
    args: Dict[str, Any],
) -> Any:
    if provider == "duckduckgo":
        return await _call_duckduckgo(config, args)
    if provider == "tavily":
        return await _call_tavily(config, args)
    if provider == "serpapi":
        return await _call_serpapi(config, args)
    if provider == "http":
        return await _call_http(config, args)
    if provider == "python":
        return _call_python(config, args)
    return {"error": f"Provider {provider!r} dispatch not implemented"}


# ------------------------------------------------------------------
# DuckDuckGo
# ------------------------------------------------------------------


async def _call_duckduckgo(config: Dict[str, Any], args: Dict[str, Any]) -> Any:
    try:
        from duckduckgo_search import DDGS  # pylint: disable=import-outside-toplevel
    except ImportError:
        return {"error": "duckduckgo-search is not installed. Run: pip install duckduckgo-search"}

    query = args.get("query", "")
    max_results = int(config.get("max_results", 5))
    results = []
    with DDGS() as ddgs:
        for r in ddgs.text(query, max_results=max_results):
            results.append({"title": r.get("title"), "url": r.get("href"), "snippet": r.get("body")})
    return results


# ------------------------------------------------------------------
# Tavily
# ------------------------------------------------------------------


async def _call_tavily(config: Dict[str, Any], args: Dict[str, Any]) -> Any:
    try:
        from tavily import TavilyClient  # pylint: disable=import-outside-toplevel
    except ImportError:
        return {"error": "tavily-python is not installed. Run: pip install tavily-python"}

    api_key = _resolve_env(config.get("api_key", ""))
    if not api_key:
        return {"error": "Tavily API key not set. Provide 'api_key' in config or set TAVILY_API_KEY env var."}
    client = TavilyClient(api_key=api_key)
    query = args.get("query", "")
    max_results = int(config.get("max_results", 5))
    response = client.search(query, max_results=max_results)
    return response.get("results", response)


# ------------------------------------------------------------------
# SerpAPI
# ------------------------------------------------------------------


async def _call_serpapi(config: Dict[str, Any], args: Dict[str, Any]) -> Any:
    try:
        from serpapi import GoogleSearch  # pylint: disable=import-outside-toplevel
    except ImportError:
        return {"error": "google-search-results is not installed. Run: pip install google-search-results"}

    api_key = _resolve_env(config.get("api_key", ""))
    if not api_key:
        return {"error": "SerpAPI key not set."}
    query = args.get("query", "")
    max_results = int(config.get("max_results", 5))
    search = GoogleSearch({"q": query, "api_key": api_key, "num": max_results})
    results = search.get_dict().get("organic_results", [])
    return [{"title": r.get("title"), "url": r.get("link"), "snippet": r.get("snippet")} for r in results]


# ------------------------------------------------------------------
# HTTP
# ------------------------------------------------------------------


async def _call_http(config: Dict[str, Any], args: Dict[str, Any]) -> Any:
    import aiohttp  # pylint: disable=import-outside-toplevel

    url = config.get("url", "")
    if not url:
        return {"error": "HTTP tool missing 'url' in config"}
    method = config.get("method", "POST").upper()
    headers = config.get("headers") or {}
    payload = dict(config.get("body") or {})
    payload.update(args)

    async with aiohttp.ClientSession() as session:
        async with session.request(method, url, json=payload, headers=headers, ssl=False) as resp:
            if resp.content_type == "application/json":
                return await resp.json()
            return {"text": await resp.text(), "status": resp.status}


# ------------------------------------------------------------------
# Python callable
# ------------------------------------------------------------------


def _call_python(config: Dict[str, Any], args: Dict[str, Any]) -> Any:
    func_path = config.get("function", "")
    if not func_path or "." not in func_path:
        return {"error": f"Python tool: invalid 'function' path {func_path!r}. Expected 'module.func'."}
    module_path, func_name = func_path.rsplit(".", 1)
    import importlib  # pylint: disable=import-outside-toplevel

    try:
        mod = importlib.import_module(module_path)
    except ImportError as exc:
        return {"error": f"Cannot import {module_path!r}: {exc}"}
    func = getattr(mod, func_name, None)
    if func is None:
        return {"error": f"Function {func_name!r} not found in {module_path!r}"}
    return func(**args)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _resolve_env(value: str) -> str:
    """Resolve ${ENV_VAR} placeholders in config values."""
    if value.startswith("${") and value.endswith("}"):
        return os.environ.get(value[2:-1], "")
    return value


def _check_provider_deps(provider: str) -> tuple:
    """Return (ok, reason). Check import deps without raising."""
    if provider == "duckduckgo":
        try:
            import duckduckgo_search  # pylint: disable=import-outside-toplevel,unused-import
        except ImportError:
            return False, "duckduckgo-search not installed (pip install duckduckgo-search)"
    if provider == "tavily":
        try:
            import tavily  # pylint: disable=import-outside-toplevel,unused-import
        except ImportError:
            return False, "tavily-python not installed (pip install tavily-python)"
    if provider == "serpapi":
        try:
            import serpapi  # pylint: disable=import-outside-toplevel,unused-import
        except ImportError:
            return False, "google-search-results not installed (pip install google-search-results)"
    if provider == "http":
        try:
            import aiohttp  # pylint: disable=import-outside-toplevel,unused-import
        except ImportError:
            return False, "aiohttp not installed (pip install aiohttp)"
    return True, ""
