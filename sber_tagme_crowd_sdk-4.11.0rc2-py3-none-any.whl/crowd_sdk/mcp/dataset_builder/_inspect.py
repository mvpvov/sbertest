"""
inspect_dataset — reads output/dataset.jsonl and returns statistics and examples.
"""

import json
import random
from pathlib import Path
from typing import Optional


def _count_tokens_approx(text: str) -> int:
    return max(1, len(text) // 4)


def _get_text_content(sample: dict) -> str:
    parts = []
    if "messages" in sample:
        for msg in sample["messages"]:
            parts.append(msg.get("content", ""))
    for key in ("prompt", "chosen", "rejected", "response", "text", "question", "answer"):
        if key in sample and isinstance(sample[key], str):
            parts.append(sample[key])
    if "trajectory" in sample:
        for step in sample["trajectory"]:
            if isinstance(step, dict):
                parts.append(step.get("thought", ""))
                parts.append(str(step.get("tool_result", "")))
    if "context" in sample:
        for doc in sample["context"]:
            if isinstance(doc, dict):
                parts.append(doc.get("content", ""))
            elif isinstance(doc, str):
                parts.append(doc)
    return " ".join(p for p in parts if p)


def inspect_dataset(name: str, n_examples: int = 3) -> dict:
    """
    Show statistics and sample records from a generated dataset.

    Когда вызывать: после generate_dataset, когда output/dataset.jsonl уже создан.

    Не вызывать для: просмотра spec/config до генерации → preview_dataset_setup.

    Не вызывать для: создания сэмплов → generate_dataset.

    Args:
        name: Dataset name (must exist in datasets/ under current working directory)
        n_examples: Number of random examples to return

    Returns:
        dict with total count, token stats, field distribution, generation metadata, and examples
    """
    dataset_dir = Path.cwd() / "datasets" / name
    if not dataset_dir.exists():
        return {"error": f"Dataset '{name}' not found at {dataset_dir}. Run create_dataset first."}

    output_path = dataset_dir / "output" / "dataset.jsonl"
    if not output_path.exists():
        hints = []
        if not (dataset_dir / "cases.jsonl").exists():
            hints.append(f"Run generate_cases('{name}') for guaranteed diversity")
        hints.append(f"Run generate_dataset('{name}') to generate samples")
        return {
            "dataset": name,
            "status": "empty",
            "total_samples": 0,
            "hints": hints,
        }

    samples = []
    parse_errors = 0
    with open(output_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    samples.append(json.loads(line))
                except json.JSONDecodeError:
                    parse_errors += 1

    if not samples:
        return {
            "dataset": name,
            "status": "empty",
            "total_samples": 0,
            "parse_errors": parse_errors,
        }

    # Token stats
    token_counts = [_count_tokens_approx(_get_text_content(s)) for s in samples]
    total = len(samples)
    avg_tokens = round(sum(token_counts) / total)
    min_tokens = min(token_counts)
    max_tokens = max(token_counts)
    total_tokens = sum(token_counts)

    # Field distribution (exclude internal fields)
    all_keys: dict = {}
    for s in samples:
        for k in s:
            if k not in ("_generation", "metadata"):
                all_keys[k] = all_keys.get(k, 0) + 1

    # Label distribution (for classification datasets)
    label_distribution: Optional[dict] = None
    if "label" in all_keys:
        counts: dict = {}
        for s in samples:
            lbl = str(s.get("label", "unknown"))
            counts[lbl] = counts.get(lbl, 0) + 1
        label_distribution = dict(sorted(counts.items()))

    # Generation metadata
    models_used: dict = {}
    generation_modes: dict = {}
    tool_call_counts: dict = {}
    samples_with_tool_calls = 0
    total_tool_calls = 0

    for s in samples:
        gen = s.get("_generation", {})
        provider = gen.get("provider", "")
        model = gen.get("model", "unknown")
        model_key = f"{provider}/{model}" if provider else model
        models_used[model_key] = models_used.get(model_key, 0) + 1

        mode = gen.get("mode", "unknown")
        generation_modes[mode] = generation_modes.get(mode, 0) + 1

        tool_calls = gen.get("tool_calls", [])
        if tool_calls:
            samples_with_tool_calls += 1
            total_tool_calls += len(tool_calls)
            for tc in tool_calls:
                tool_name = tc.get("tool", "unknown")
                tool_call_counts[tool_name] = tool_call_counts.get(tool_name, 0) + 1

    result: dict = {
        "dataset": name,
        "total": total,
        "parse_errors": parse_errors,
        "output_path": str(output_path),
        "token_stats": {
            "avg": avg_tokens,
            "min": min_tokens,
            "max": max_tokens,
            "total": total_tokens,
        },
        "fields": all_keys,
        "generation": {
            "modes": generation_modes,
            "models": models_used,
            "tool_calls": {
                "samples_with_calls": samples_with_tool_calls,
                "total_calls": total_tool_calls,
                "avg_calls_per_sample": round(total_tool_calls / total, 2) if total else 0,
                "by_tool": tool_call_counts,
            },
        },
    }

    if label_distribution is not None:
        result["label_distribution"] = label_distribution

    # Generation runs stats from generation_stats.json
    stats_path = dataset_dir / "output" / "generation_stats.json"
    if stats_path.exists():
        try:
            runs = json.loads(stats_path.read_text(encoding="utf-8"))
            if not isinstance(runs, list):
                runs = [runs]
            if runs:
                total_prompt = sum(r.get("tokens", {}).get("prompt", 0) for r in runs)
                total_completion = sum(r.get("tokens", {}).get("completion", 0) for r in runs)
                result["generation_tokens"] = {
                    "runs": len(runs),
                    "total_prompt": total_prompt,
                    "total_completion": total_completion,
                    "total": total_prompt + total_completion,
                    "avg_prompt_per_sample": round(total_prompt / total, 1) if total else 0,
                    "avg_completion_per_sample": round(total_completion / total, 1) if total else 0,
                    "last_run": runs[-1],
                }
        except (OSError, json.JSONDecodeError, ValueError):
            pass

    if n_examples > 0 and samples:
        k = min(n_examples, total)
        indices = sorted(random.sample(range(total), k))
        result["examples"] = [samples[i] for i in indices]

    return result
