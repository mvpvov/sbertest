"""
preview_dataset_setup — return spec/config/tools for user review before generation.
"""

from pathlib import Path
from typing import Any, Dict

import yaml

from crowd_sdk.mcp.dataset_builder._workflow import (
    AGENT_CONFIRMATION_HINT,
    cases_status,
    cases_warnings,
    workflow_payload,
)


def preview_dataset_setup(name: str, include_tools: bool = True) -> Dict[str, Any]:
    """
    Return full spec.md, config.yaml, and optional tools.yaml for user review.

    Когда вызывать: сразу после create_dataset или перед generate_cases / generate_dataset;
    покажите пользователю содержимое и дождитесь явного подтверждения.

    Не вызывать для: уже сгенерированного output/dataset.jsonl → inspect_dataset.

    Не пишите Python-скрипты для генерации — используйте generate_cases и generate_dataset.

    Args:
        name: Dataset name under datasets/<name>/ (relative to cwd)
        include_tools: If True, include tools.yaml text when present

    Returns:
        dict with file paths, full text contents, cases status, workflow, and agent hints
    """
    name = name.strip().replace(" ", "_")
    dataset_dir = Path.cwd() / "datasets" / name
    if not dataset_dir.exists():
        return {
            "error": f"Dataset '{name}' not found at {dataset_dir}. Run create_dataset first.",
            **workflow_payload("missing_dataset"),
        }

    spec_path = dataset_dir / "spec.md"
    config_path = dataset_dir / "config.yaml"
    tools_path = dataset_dir / "tools.yaml"

    spec_text = spec_path.read_text(encoding="utf-8") if spec_path.exists() else ""
    config_text = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
    config: dict = {}
    if config_path.exists():
        config = yaml.safe_load(config_text) or {}

    files: Dict[str, Any] = {
        "spec.md": {"path": str(spec_path), "exists": spec_path.exists(), "content": spec_text},
        "config.yaml": {"path": str(config_path), "exists": config_path.exists(), "content": config_text},
    }
    if include_tools and tools_path.exists():
        files["tools.yaml"] = {
            "path": str(tools_path),
            "exists": True,
            "content": tools_path.read_text(encoding="utf-8"),
        }

    warnings = cases_warnings(name, dataset_dir, config)
    next_steps = [
        "Ask the user to confirm spec.md and config.yaml (or request edits).",
        f"Then run generate_cases('{name}', n_cases=…).",
        f"Then generate_dataset('{name}', dry_run=True) and show the plan.",
        "Only after user approval run generate_dataset without dry_run.",
    ]
    if warnings:
        next_steps.insert(1, warnings[0])

    return {
        "dataset": name,
        "dataset_dir": str(dataset_dir),
        "type": config.get("type"),
        "n_samples": config.get("n_samples"),
        "require_cases": config.get("require_cases", False),
        "files": files,
        "cases": cases_status(dataset_dir),
        "warnings": warnings,
        "await_user_confirmation": True,
        "confirmation_prompt": (
            "Review spec.md and config.yaml above. Reply 'ok' / 'запускай' to proceed, " "or describe edits needed."
        ),
        "agent_hint": AGENT_CONFIRMATION_HINT,
        "next_steps": next_steps,
        **workflow_payload("after_preview"),
    }
