"""
generate_dataset / generate_cases — read spec.md + config.yaml and generate dataset samples via LLMs.
"""

import asyncio
import json
import logging
import random
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from crowd_sdk.mcp.dataset_builder._llm_backend import (
    GenerationClient,
    ToolsNotSupportedError,
    default_generation_model,
    default_generation_models,
    default_generation_provider,
    resolve_generation_backend,
    resolve_generation_models,
)
from crowd_sdk.mcp.dataset_builder._workflow import cases_gate_error, cases_warnings, workflow_payload

logger = logging.getLogger(__name__)

# Load .env from cwd if present — before provider imports
_dotenv_path = Path.cwd() / ".env"
if _dotenv_path.exists():
    try:
        from dotenv import load_dotenv

        load_dotenv(_dotenv_path, override=False)
    except ImportError:
        pass


def _load_inputs_file(inputs_file: str, dataset_dir: Path) -> list:
    p = Path(inputs_file)
    if not p.is_absolute():
        p = dataset_dir / inputs_file
    if not p.exists():
        raise FileNotFoundError(f"inputs_file not found: {p}")
    text = p.read_text().strip()
    if text.startswith("["):
        return json.loads(text)
    return [json.loads(line) for line in text.splitlines() if line.strip()]


def _load_system_prompt(dataset_dir: Path) -> Optional[str]:
    """Load system_prompt.md for chat datasets. Returns None if file absent or empty/comment-only."""
    path = dataset_dir / "system_prompt.md"
    if not path.exists():
        return None
    content = path.read_text(encoding="utf-8").strip()
    if not content or content.startswith("<!--"):
        return None
    return content


def _load_dataset_config(name: str) -> tuple:
    dataset_dir = Path.cwd() / "datasets" / name
    if not dataset_dir.exists():
        raise FileNotFoundError(f"Dataset '{name}' not found at {dataset_dir}. Run create_dataset first.")
    spec_path = dataset_dir / "spec.md"
    config_path = dataset_dir / "config.yaml"
    spec = spec_path.read_text() if spec_path.exists() else ""
    config = yaml.safe_load(config_path.read_text()) if config_path.exists() else {}
    return spec, config


def _build_completion_prompt(spec: str, partial_sample: dict, existing_count: int = 0) -> str:
    return f"""You are a dataset generation assistant. Complete the partial training sample below.

DATASET SPEC:
{spec}

PARTIAL SAMPLE (already provided fields — do NOT change them):
{json.dumps(partial_sample, ensure_ascii=False, indent=2)}

INSTRUCTIONS:
- Fill in ALL missing fields required by the Output Schema in the spec
- Keep existing fields exactly as-is
- Return ONLY the complete JSON object (no markdown, no explanation)
- Sample #{existing_count + 1}

Respond with only the complete JSON object:"""


def _extract_spec_section(spec: str, heading: str) -> str:
    lines = spec.splitlines()
    in_section = False
    result = []
    for line in lines:
        if line.startswith(heading):
            in_section = True
            continue
        if in_section:
            if line.startswith("## "):
                break
            result.append(line)
    return "\n".join(result).strip()


def _extract_case_schema(spec: str) -> str:
    return _extract_spec_section(spec, "## Case Schema")


def _extract_case_field_names(spec: str) -> List[str]:
    """Field names from the Case Schema markdown table (first column)."""
    schema_text = _extract_case_schema(spec)
    fields: List[str] = []
    for line in schema_text.splitlines():
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.split("|") if c.strip()]
        if len(cells) < 2 or cells[0] in ("Поле", "Field") or set(cells) <= {"---"}:
            continue
        if all(c.replace("-", "") == "" for c in cells):
            continue
        fields.append(cells[0])
    return fields


def _extract_cases_prompt_context(spec: str) -> str:
    """Spec excerpt for generate_cases — excludes Output Schema and Generation Instructions."""
    parts = []
    for heading in ("## Use Case", "## Case Dimensions", "## Case Schema"):
        block = _extract_spec_section(spec, heading)
        if block:
            parts.append(f"{heading}\n{block}")
    return "\n\n".join(parts)


def _build_generation_prompt(
    spec: str,
    dataset_type: str,  # pylint: disable=unused-argument
    existing_count: int = 0,
    case: Optional[dict] = None,  # pylint: disable=unused-argument
    agentic: bool = False,
) -> str:
    case_block = ""
    case_hint = ""
    if case:
        group_idx = case.get("sample_index_in_group", 0)
        case_display = {k: v for k, v in case.items() if k != "sample_index_in_group"}
        schema_text = _extract_case_schema(spec)
        schema_block = f"\nCASE FIELD MEANINGS (from spec):\n{schema_text}\n" if schema_text else ""
        case_block = f"""
CASE FOR THIS SAMPLE (follow ALL fields strictly):
{json.dumps(case_display, ensure_ascii=False, indent=2)}
{schema_block}"""
        case_hint = (
            f"- This is variation #{group_idx + 1} within the topic_area '{case_display.get('topic_area', '')}' — "
            f"pick a DIFFERENT specific aspect, fact, or subtopic than previous variations\n"
            if group_idx > 0
            else f"- Pick a specific aspect within the topic_area '{case_display.get('topic_area', '')}'\n"
        )

    if agentic:
        return f"""You are a dataset generation assistant. Your task is to generate ONE realistic training sample.
{case_block}
DATASET SPEC:
{spec}

INSTRUCTIONS:
- You have access to tools (e.g. web search). Use them to gather real, accurate information relevant to the sample before writing the final JSON.
- After gathering enough information, return ONLY valid JSON matching the Output Schema defined in the spec.
- Do not include markdown fences, explanations, or any text outside the final JSON.
- Make this sample diverse compared to what may have been generated before (sample #{existing_count + 1})
{"- Follow ALL case field constraints as described in CASE FIELD MEANINGS above" if case else ""}
{case_hint}
Start by using the available tools to research the topic, then output the JSON object:"""

    return f"""You are a dataset generation assistant. Generate exactly ONE training sample based on the spec below.
{case_block}
DATASET SPEC:
{spec}

INSTRUCTIONS:
- Generate a single realistic, high-quality sample
- Return ONLY valid JSON matching the Output Schema defined in the spec
- Do not include markdown fences, explanations, or any text outside the JSON
- Make this sample diverse compared to what may have been generated before (sample #{existing_count + 1})
{"- Follow ALL case field constraints as described in CASE FIELD MEANINGS above" if case else ""}
{case_hint}
Respond with only the JSON object:"""


MAX_AGENTIC_STEPS = 15


def _accumulate_usage(total: dict, delta: dict) -> None:
    total["prompt_tokens"] = total.get("prompt_tokens", 0) + delta.get("prompt_tokens", 0)
    total["completion_tokens"] = total.get("completion_tokens", 0) + delta.get("completion_tokens", 0)
    total["total_tokens"] = total.get("total_tokens", 0) + delta.get("total_tokens", 0)


def _generation_client_from_config(gen_config: dict) -> GenerationClient:
    backend = resolve_generation_backend(gen_config)
    tagme_auth: Optional[Tuple[str, str]] = None
    if backend == "tagme":
        import sys  # pylint: disable=import-outside-toplevel

        # Import _tagme_stats directly bypassing statistic/__init__ to avoid circular import:
        # statistic/__init__ -> _analysis_tools -> tools/_helpers -> statistic/_tagme_stats
        _mod_key = "crowd_sdk.mcp.statistic._tagme_stats"
        if _mod_key not in sys.modules:
            import importlib.util  # pylint: disable=import-outside-toplevel
            import pathlib  # pylint: disable=import-outside-toplevel

            _path = pathlib.Path(__file__).parent.parent / "statistic" / "_tagme_stats.py"
            _spec = importlib.util.spec_from_file_location(_mod_key, _path)
            assert _spec is not None and _spec.loader is not None
            _m = importlib.util.module_from_spec(_spec)
            sys.modules[_mod_key] = _m
            _spec.loader.exec_module(_m)  # type: ignore[union-attr]
        _tagme_stats = sys.modules[_mod_key]
        tagme_auth = _tagme_stats.resolve_tagme_auth_credentials()
    return GenerationClient.from_config(gen_config, tagme_auth=tagme_auth)


def _load_registry(dataset_dir: Path) -> Any:
    """Load ToolRegistry from tools.yaml in the dataset directory. Returns None if not found."""
    tools_yaml = dataset_dir / "tools.yaml"
    if not tools_yaml.exists():
        return None
    try:
        from crowd_sdk.mcp.dataset_builder._registry import ToolRegistry  # pylint: disable=import-outside-toplevel
    except ImportError as exc:
        logger.warning("[generate] failed to import ToolRegistry: %s", exc)
        return None
    try:
        registry = ToolRegistry.load(dataset_dir)
    except Exception as exc:  # pylint: disable=W0703
        logger.warning("[generate] failed to load tools from %s: %s", tools_yaml, exc)
        return None
    if registry.is_empty():
        logger.warning("[generate] tools.yaml exists but no tools loaded from %s", tools_yaml)
        return None
    return registry


async def _run_agentic_sample(  # pylint: disable=R0913
    client: GenerationClient,
    spec: str,
    dataset_type: str,
    registry: Any,
    model: str,
    provider: str,
    temperature: float,
    max_tokens: int,
    sample_index: int,
    case: Optional[dict] = None,
    *,
    tools_fallback: bool = False,
) -> tuple:
    prompt = _build_generation_prompt(spec, dataset_type, sample_index, case=case, agentic=True)
    messages: List[Dict[str, Any]] = [{"role": "user", "content": prompt}]
    tool_schemas = registry.tool_schemas()
    total_usage: dict = {}
    tool_calls_log: list = []

    for _step in range(MAX_AGENTIC_STEPS):
        schemas_this_step = tool_schemas if _step < MAX_AGENTIC_STEPS - 1 else None
        if schemas_this_step:
            try:
                result = await client.acomplete_messages(
                    messages,
                    model,
                    provider,
                    temperature,
                    max_tokens,
                    tools=schemas_this_step,
                )
            except ToolsNotSupportedError as exc:
                if not tools_fallback:
                    raise RuntimeError(f"Tool calling rejected by provider={provider} model={model}: {exc}") from exc
                result = await client.acomplete_messages(messages, model, provider, temperature, max_tokens)
        else:
            result = await client.acomplete_messages(messages, model, provider, temperature, max_tokens)
        message, usage = result.message, result.usage
        _accumulate_usage(total_usage, usage)

        if not message.tool_calls:
            content = message.content or ""
            sample = _parse_json_response(content)
            return sample, total_usage, tool_calls_log

        tool_calls_encoded: Any = [
            {
                "id": tc.id,
                "type": "function",
                "function": {"name": tc.name, "arguments": tc.arguments},
            }
            for tc in message.tool_calls
        ]
        messages.append(
            {
                "role": "assistant",
                "content": message.content,
                "tool_calls": tool_calls_encoded,
            }
        )

        for tc in message.tool_calls:
            try:
                args = json.loads(tc.arguments)
            except (json.JSONDecodeError, ValueError):
                args = {}
            logger.info(
                "[generate] sample=%s step=%s tool_call=%s args=%s",
                sample_index,
                _step,
                tc.name,
                json.dumps(args, ensure_ascii=False)[:120],
            )
            tool_result = await registry.call(tc.name, args)
            result_preview = json.dumps(tool_result, ensure_ascii=False)[:200]
            logger.debug("[generate] sample=%s step=%s tool_result=%s", sample_index, _step, result_preview)
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": json.dumps(tool_result, ensure_ascii=False),
                }
            )
            tool_calls_log.append(
                {
                    "step": _step,
                    "tool": tc.name,
                    "args": args,
                    "result_preview": json.dumps(tool_result, ensure_ascii=False)[:200],
                }
            )

    last_content = ""
    for msg in reversed(messages):
        if isinstance(msg, dict) and msg.get("role") == "assistant" and msg.get("content"):
            last_content = msg["content"]
            break
    try:
        sample = _parse_json_response(last_content)
    except (json.JSONDecodeError, ValueError):
        sample = {"_raw": last_content}
    return sample, total_usage, tool_calls_log


def _strip_llm_json_text(text: str) -> str:
    text = text.strip()
    if not text.startswith("```"):
        return text
    lines = text.split("\n")
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    return "\n".join(lines).strip()


def _recover_json_array_objects(text: str) -> list:
    """Parse complete objects from a truncated or noisy JSON array."""
    start = text.find("[")
    if start < 0:
        return []
    fragment = text[start:]
    objects: list = []
    decoder = json.JSONDecoder()
    pos = 1
    while pos < len(fragment):
        while pos < len(fragment) and fragment[pos] in " \t\n\r,":
            pos += 1
        if pos >= len(fragment) or fragment[pos] == "]":
            break
        if fragment[pos] != "{":
            break
        try:
            obj, end = decoder.raw_decode(fragment, pos)
        except json.JSONDecodeError:
            break
        if isinstance(obj, dict):
            objects.append(obj)
        pos = end
    return objects


def _parse_json_array_response(text: str) -> list:
    """Parse a JSON array from LLM output; tolerate markdown fences and truncation."""
    text = _strip_llm_json_text(text)
    if not text:
        raise json.JSONDecodeError("empty LLM response", text, 0)
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        recovered = _recover_json_array_objects(text)
        if recovered:
            return recovered
        raise
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return [data]
    raise ValueError(f"LLM returned {type(data).__name__}, expected JSON array")


def _parse_json_response(text: str) -> dict:
    text = _strip_llm_json_text(text)
    data = json.loads(text)
    if isinstance(data, dict):
        return data
    raise ValueError(f"LLM returned {type(data).__name__}, expected JSON object")


async def generate_dataset(
    name: str,
    n_samples: Optional[int] = None,
    dry_run: bool = False,
    models: Optional[list] = None,
    inputs_file: Optional[str] = None,
) -> dict:
    """
    Generate dataset samples by reading spec.md and config.yaml, then calling LLMs.

    Когда вызывать: после create_dataset, правки spec/config, generate_cases и явного OK пользователя.
    Сначала всегда dry_run=True — покажите план; только потом dry_run=False.

    Не вызывать для: обхода через Python-скрипт, notebook или прямых вызовов LLM API в репозитории.

    Не вызывать dry_run=False, пока пользователь не подтвердил spec/config и план dry_run.

    Looks for datasets/<name>/ relative to the current working directory.

    Args:
        name: Dataset name (must exist in datasets/ under cwd)
        n_samples: Number of samples to generate (overrides config.yaml)
        dry_run: If True, show generation plan without calling any LLM
        models: Override models list (list of dicts with 'provider' and 'model' keys)
        inputs_file: Path to JSONL/JSON with partial samples — LLM completes missing fields

    Returns:
        dict with generation stats and output path
    """
    try:
        spec, config = _load_dataset_config(name)
    except FileNotFoundError as e:
        return {"error": str(e)}

    dataset_dir = Path.cwd() / "datasets" / name
    resolved_inputs_file = inputs_file or config.get("inputs", {}).get("file")
    gate = cases_gate_error(name, dataset_dir, config)
    if gate and not dry_run and not resolved_inputs_file:
        return gate

    dataset_type = config.get("type", "chat")
    gen_config = config.get("generation", {})
    temperature = gen_config.get("temperature", 0.8)
    max_tokens = gen_config.get("max_tokens", 1024)
    tools_fallback = gen_config.get("tools_fallback", False)
    registry = _load_registry(dataset_dir)
    use_agentic = registry is not None

    model_list = resolve_generation_models(models or config.get("models") or default_generation_models())

    partial_samples = None
    cases: list = []
    system_prompt: Optional[str] = _load_system_prompt(dataset_dir) if dataset_type == "chat" else None

    if resolved_inputs_file:
        mode = "completion"
        try:
            partial_samples = _load_inputs_file(resolved_inputs_file, dataset_dir)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            return {"error": str(e)}
        n = len(partial_samples)
    else:
        mode = "generation"
        n = n_samples or config.get("n_samples", 50)

        cases_path = dataset_dir / "cases.jsonl"
        if cases_path.exists():
            raw_cases = [l.strip() for l in cases_path.read_text().splitlines() if l.strip()]
            cases = [json.loads(l) for l in raw_cases]

    if dry_run:
        result = {
            "dry_run": True,
            "mode": mode,
            "dataset": name,
            "type": dataset_type,
            "models": model_list,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "backend": resolve_generation_backend(gen_config),
            "output_path": str(dataset_dir / "output" / "dataset.jsonl"),
            "generation_mode": "real" if use_agentic else "simulated",
        }
        if mode == "completion":
            result["n_inputs"] = n
            result["inputs_file"] = str(resolved_inputs_file)
            result["sample_prompt"] = (
                _build_completion_prompt(spec, partial_samples[0], 0)[:500] + "..." if partial_samples else ""
            )
        else:
            result["n_samples"] = n
            result["cases"] = f"{len(cases)} cases loaded" if cases else "no cases (random generation)"
            result["sample_prompt"] = (
                _build_generation_prompt(spec, dataset_type, 0, case=cases[0] if cases else None)[:500] + "..."
            )
        if use_agentic:
            result["active_tools"] = [s["function"]["name"] for s in registry.tool_schemas()]
        warn = cases_warnings(name, dataset_dir, config)
        if warn:
            result["warnings"] = warn
        result["await_user_confirmation"] = True
        result[
            "confirmation_prompt"
        ] = "Show this dry_run plan to the user. Run generate_dataset without dry_run only after explicit approval."
        result.update(workflow_payload("before_generate"))
        return result

    try:
        client = _generation_client_from_config(gen_config)
    except ValueError as e:
        return {"error": str(e)}

    output_dir = dataset_dir / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "dataset.jsonl"

    append = config.get("output", {}).get("append", False)
    write_mode = "a" if append else "w"

    generated = 0
    errors = 0
    error_details = []
    total_prompt_tokens = 0
    total_completion_tokens = 0
    start_time = time.time()

    total_weight = sum(m.get("weight", 1.0) for m in model_list)
    weights = [m.get("weight", 1.0) / total_weight for m in model_list]

    concurrency = gen_config.get("concurrency", 50)

    async def _generate_one(sem: asyncio.Semaphore, i: int) -> tuple:
        model_cfg = random.choices(model_list, weights=weights, k=1)[0]
        _provider = model_cfg.get("provider", "anthropic")
        _model = model_cfg.get("model", default_generation_model())

        current_case: Optional[Dict[str, Any]] = None
        if mode == "generation" and cases:
            case_idx = i % len(cases)
            current_case = dict(cases[case_idx])
            current_case["sample_index_in_group"] = i // len(cases)

        async with sem:
            logger.debug("[generate] sample %s start", i)
            try:
                if use_agentic:
                    _sample, _usage, _tool_calls_log = await _run_agentic_sample(
                        client,
                        spec,
                        dataset_type,
                        registry,
                        _model,
                        _provider,
                        temperature,
                        max_tokens,
                        i,
                        case=current_case,
                        tools_fallback=tools_fallback,
                    )
                    _gen_mode = "real"
                else:
                    _tool_calls_log = []
                    if mode == "completion":
                        if partial_samples is None:
                            raise RuntimeError("partial_samples must be loaded in completion mode")
                        _prompt = _build_completion_prompt(spec, partial_samples[i], i)
                    else:
                        _prompt = _build_generation_prompt(spec, dataset_type, i, case=current_case)
                    _completion = await client.acomplete_prompt(_prompt, _model, _provider, temperature, max_tokens)
                    _raw = (_completion.message.content or "").strip()
                    _usage = _completion.usage
                    _sample = _parse_json_response(_raw)
                    _gen_mode = "simulated"
            finally:
                logger.debug("[generate] sample %s done", i)

        return i, _sample, _usage, _tool_calls_log, _gen_mode, current_case, _model, _provider

    async def _generate_all() -> List[Any]:
        sem = asyncio.Semaphore(concurrency)
        tasks = [_generate_one(sem, i) for i in range(n)]
        return await asyncio.gather(*tasks, return_exceptions=True)

    results: List[Any] = await _generate_all()

    with open(output_path, write_mode, encoding="utf-8") as f:
        for result_item in sorted(
            (r for r in results if not isinstance(r, BaseException)),
            key=lambda r: r[0],
        ):
            i, sample, usage, tool_calls_log, gen_mode, current_case, model, provider = result_item

            total_prompt_tokens += usage.get("prompt_tokens", 0)
            total_completion_tokens += usage.get("completion_tokens", 0)

            if mode == "completion":
                if partial_samples is None:
                    raise RuntimeError("partial_samples must be loaded in completion mode")
                for k, v in partial_samples[i].items():
                    sample.setdefault(k, v)

            if system_prompt and isinstance(sample.get("messages"), list):
                if not any(m.get("role") == "system" for m in sample["messages"]):
                    sample["messages"] = [{"role": "system", "content": system_prompt}] + sample["messages"]

            if "_generation" not in sample:
                sample["_generation"] = {}
            sample["_generation"].update(
                {
                    "model": model,
                    "provider": provider,
                    "index": generated,
                    "mode": gen_mode,
                }
            )
            if current_case is not None:
                sample["_generation"]["case_id"] = current_case.get("id", i)
            if tool_calls_log:
                sample["_generation"]["tool_calls"] = tool_calls_log
            if mode == "completion":
                sample["_generation"]["input_index"] = i

            f.write(json.dumps(sample, ensure_ascii=False) + "\n")
            generated += 1

        for r in results:
            if isinstance(r, BaseException):
                errors += 1
                error_details.append({"error": str(r)[:200]})

    elapsed = round(time.time() - start_time, 1)

    stats_path = dataset_dir / "output" / "generation_stats.json"
    run_stats = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "generated": generated,
        "errors": errors,
        "elapsed_seconds": elapsed,
        "tokens": {
            "prompt": total_prompt_tokens,
            "completion": total_completion_tokens,
            "total": total_prompt_tokens + total_completion_tokens,
        },
        "mode": mode,
        "models": [m.get("model") for m in model_list],
    }
    existing_runs = []
    if stats_path.exists():
        try:
            existing_runs = json.loads(stats_path.read_text(encoding="utf-8"))
            if not isinstance(existing_runs, list):
                existing_runs = [existing_runs]
        except (OSError, json.JSONDecodeError, ValueError):
            existing_runs = []
    existing_runs.append(run_stats)
    stats_path.write_text(json.dumps(existing_runs, ensure_ascii=False, indent=2), encoding="utf-8")

    result = {
        "success": True,
        "dataset": name,
        "mode": mode,
        "generated": generated,
        "errors": errors,
        "elapsed_seconds": elapsed,
        "tokens": {
            "prompt": total_prompt_tokens,
            "completion": total_completion_tokens,
            "total": total_prompt_tokens + total_completion_tokens,
        },
        "output_path": str(output_path),
    }
    if errors > 0:
        result["error_details"] = error_details[:5]
    if generated > 0:
        with open(output_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            if lines:
                result["last_sample"] = json.loads(lines[-1])

    return result


async def generate_cases(
    name: str,
    n_cases: Optional[int] = None,
    overwrite: bool = False,
) -> dict:
    """
    Generate a cases.jsonl file for a dataset — a diverse list of topics/scenarios
    covering the full scenario space defined in spec.md.

    Когда вызывать: после create_dataset и подтверждения пользователем spec.md / config.yaml;
    обязательный шаг перед generate_dataset для chat/SFT с разнообразием.

    Не вызывать для: замены этим шагом Python-скрипта со списком тем вручную.

    Не путать с create_case_mock — это demo Human MCP, не dataset builder.

    Looks for datasets/<name>/ relative to the current working directory.

    Args:
        name: Dataset name
        n_cases: Number of cases to generate (default: n_samples from config.yaml)
        overwrite: If True, overwrite existing cases.jsonl

    Returns:
        dict with cases count and file path
    """
    try:
        spec, config = _load_dataset_config(name)
    except FileNotFoundError as e:
        return {"error": str(e)}

    dataset_dir = Path.cwd() / "datasets" / name
    cases_path = dataset_dir / "cases.jsonl"

    if cases_path.exists() and not overwrite:
        existing = [json.loads(l) for l in cases_path.read_text().splitlines() if l.strip()]
        return {
            "info": f"cases.jsonl already exists with {len(existing)} cases. Use overwrite=True to regenerate.",
            "cases_path": str(cases_path),
            "count": len(existing),
            "next_steps": [
                f"generate_dataset('{name}', dry_run=True)",
                f"generate_dataset('{name}') after user approval",
            ],
            **workflow_payload("cases_exist"),
        }

    n = n_cases or config.get("n_samples", 50)
    gen_config = config.get("generation", {})
    try:
        client = _generation_client_from_config(gen_config)
    except ValueError as e:
        return {"error": str(e)}
    model_list = resolve_generation_models(config.get("models") or default_generation_models())
    model_cfg = model_list[0]
    model = model_cfg.get("model", default_generation_model())
    provider = model_cfg.get("provider", default_generation_provider())
    temperature = gen_config.get("cases_temperature", gen_config.get("temperature", 0.9))
    # Scale batch_size and max_tokens with n when not explicitly set in config.
    # Target: ~2 batches for any n (1 batch for small n).
    # Caps: batch_size <= 50, max_tokens <= 16384.
    default_batch_size = min(50, max(10, n))
    default_max_tokens = min(16384, max(4096, n * 150))
    max_tokens = int(gen_config.get("cases_max_tokens", default_max_tokens))
    batch_size = int(gen_config.get("cases_batch_size", default_batch_size))
    max_parse_attempts = 3

    case_dimensions = _extract_case_dimensions(spec)
    case_schema = _extract_case_schema(spec)
    case_field_names = _extract_case_field_names(spec)
    cases_spec_context = _extract_cases_prompt_context(spec)
    required_case_keys = ", ".join(f'"{k}"' for k in case_field_names) if case_field_names else '"topic_area"'

    def _make_case_prompt(batch_n: int, existing_topic_areas: list) -> str:
        existing_block = ""
        if existing_topic_areas:
            existing_block = (
                "\nALREADY USED topic_areas (do NOT repeat):\n"
                + "\n".join(f"- {t}" for t in existing_topic_areas)
                + "\n"
            )
        schema_block = (
            f"\nCASE FIELD DESCRIPTIONS (follow these for each field):\n{case_schema}\n" if case_schema else ""
        )
        return f"""You are a dataset diversity expert. Generate exactly {batch_n} planning CASE records.

DATASET CONTEXT (cases only — NOT full training samples):
{cases_spec_context}

CASE DIMENSIONS (distribute cases evenly across all values in each dimension):
{json.dumps(case_dimensions, ensure_ascii=False, indent=2)}
{schema_block}{existing_block}
INSTRUCTIONS:
- Generate exactly {batch_n} case objects as a JSON array
- Each object is a lightweight CASE PLAN only: fields {required_case_keys}, plus "id" (int, placeholder 0)
- REQUIRED: "topic_area" (str) — BROAD theme, not a full dialog; one topic_area can yield many different samples later
- Do NOT include messages, metadata, system/user/assistant text, or any Output Schema / ChatML fields
- Do NOT write user complaints or assistant answers — only the case metadata rows above
- Vary ALL dimension fields evenly across the {batch_n} cases
- No two cases should have the same topic_area

Return ONLY a valid JSON array. No markdown fences, no commentary.
Keep each string field concise (one short phrase) so the full array fits in the response."""

    all_cases: list = []
    existing_topic_areas: list = []
    remaining = n
    parse_errors: List[str] = []
    try:
        while remaining > 0:
            batch_n = min(batch_size, remaining)
            batch: list = []
            for attempt in range(max_parse_attempts):
                attempt_batch_n = max(1, batch_n // (2**attempt))
                attempt_max_tokens = min(max_tokens * (attempt + 1), 16384)
                prompt = _make_case_prompt(attempt_batch_n, existing_topic_areas)
                result = await client.acomplete_prompt(prompt, model, provider, temperature, attempt_max_tokens)
                raw = (result.message.content or "").strip()
                try:
                    batch = _parse_json_array_response(raw)
                    batch_n = attempt_batch_n
                    break
                except (json.JSONDecodeError, ValueError) as exc:
                    parse_errors.append(str(exc)[:200])
                    if attempt == max_parse_attempts - 1:
                        raise
            if not batch:
                return {"error": "LLM returned empty cases batch", "parse_errors": parse_errors[-3:]}
            batch = batch[:batch_n]
            all_cases.extend(batch)
            existing_topic_areas.extend(s.get("topic_area", "") for s in batch)
            remaining -= len(batch)
    except (ValueError, json.JSONDecodeError) as e:
        return {
            "error": f"Failed to generate cases: {e}",
            "hint": (
                "Try generate_cases with a smaller n_cases, set generation.cases_batch_size: 2 and "
                "generation.cases_max_tokens: 8192 in config.yaml, or simplify Case Schema text fields."
            ),
            "parse_errors": parse_errors[-3:],
            "generated_so_far": len(all_cases),
        }

    for i, s in enumerate(all_cases):
        s["id"] = i

    with open(cases_path, "w", encoding="utf-8") as f:
        for s in all_cases:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")

    return {
        "success": True,
        "count": len(all_cases),
        "cases_path": str(cases_path),
        "sample_cases": all_cases[:3],
        "dimension_coverage": _check_case_coverage(all_cases, case_dimensions),
        "next_steps": [
            f"generate_dataset('{name}', dry_run=True) — show plan to user",
            f"generate_dataset('{name}') — only after user approves dry_run plan",
        ],
        **workflow_payload("after_cases"),
    }


def _extract_case_dimensions(spec: str) -> dict:
    dimensions: dict = {}
    lines = spec.splitlines()
    in_section = False
    current_subsection = None
    for line in lines:
        if line.startswith("## Case Dimensions"):
            in_section = True
            continue
        if in_section:
            if line.startswith("## "):
                break
            if line.startswith("### "):
                current_subsection = line[4:].strip()
                dimensions[current_subsection] = []
            elif line.startswith("- ") and current_subsection:
                dimensions[current_subsection].append(line[2:].strip())
    return dimensions


def _check_case_coverage(cases: list, dimensions: Optional[dict] = None) -> dict:
    case_keys = set(cases[0].keys()) if cases else set()
    excluded = {"id", "topic_area", "sample_index_in_group"}

    if dimensions:
        axes_keys = []
        for heading in dimensions.keys():
            normalized = heading.lower().replace(" ", "_")
            if normalized in case_keys:
                axes_keys.append(normalized)
            elif normalized.rstrip("s") in case_keys:
                axes_keys.append(normalized.rstrip("s"))
    else:
        axes_keys = [k for k in case_keys if k not in excluded]

    coverage: dict = {}
    for axis in axes_keys:
        counts: dict = {}
        for s in cases:
            val = str(s.get(axis, "unknown"))
            counts[val] = counts.get(val, 0) + 1
        if counts:
            coverage[axis] = dict(sorted(counts.items(), key=lambda x: -x[1]))
    return coverage
