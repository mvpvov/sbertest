"""
Dataset Builder MCP tools — create, generate, inspect datasets for LLM fine-tuning.

Register via CROWD_SDK_MCP_EXTRA_MODULES=crowd_sdk.mcp.dataset_builder
or call register_mcp_tools(mcp) directly from server.py.
"""

from typing import Any

from crowd_sdk.mcp.dataset_builder._create import create_dataset
from crowd_sdk.mcp.dataset_builder._generate import generate_cases, generate_dataset
from crowd_sdk.mcp.dataset_builder._inspect import inspect_dataset
from crowd_sdk.mcp.dataset_builder._preview import preview_dataset_setup

__all__ = [
    "create_dataset",
    "generate_dataset",
    "generate_cases",
    "inspect_dataset",
    "preview_dataset_setup",
    "register_mcp_tools",
]


def register_mcp_tools(mcp: Any) -> None:
    """Register all dataset builder tools into a FastMCP instance."""
    mcp.tool()(create_dataset)
    mcp.tool()(preview_dataset_setup)
    mcp.tool()(generate_cases)
    mcp.tool()(generate_dataset)
    mcp.tool()(inspect_dataset)
