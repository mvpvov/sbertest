from typing import Any, Dict, List, Optional

from crowd_sdk.mcp.statistic._tagme_stats import inspect_tagme_sdk_access
from crowd_sdk.version import __version__


def health_check() -> Dict[str, str]:
    """Живость сервиса MCP (без Tagme).

    Когда вызывать: проверка, что процесс crowd-sdk-mcp отвечает.
    Не вызывать для: данных разметки (используйте инструменты Tagme ниже).
    Возвращает: status, service.
    """
    return {
        'status': 'ok',
        'service': 'crowd-sdk-mcp',
    }


def get_platform_info() -> Dict[str, object]:
    """Метаданные сборки/SDK (без Tagme).

    Когда вызывать: нужны имя и версия Crowd SDK, флаг mcp_enabled.
    Не вызывать для: статистики задач или проектов.
    Возвращает: name, version, mcp_enabled.
    """
    return {
        'name': 'Crowd SDK',
        'version': __version__,
        'mcp_enabled': True,
    }


def check_tagme_sdk_access(config_path: Optional[str] = None) -> Dict[str, Any]:
    """Диагностика конфигурации Tagme и токена **до** остальных вызовов (лёгкий, без списков задач).

    Когда вызывать: ошибки доступа, пустой stand/url, проверка request token среды.
    Не вызывать для: прогресса разметки или назначений → get_task_stats / analyze_task_results.
    Возвращает: sdk_import_ok, config_source, config_error, has_routing_config, stand, url, auth_url, org,
    request_token_present, request_token_subject, available_stands_count.
    """
    return inspect_tagme_sdk_access(config_path)


def create_case_mock(case_type: str, goal: str) -> Dict[str, str]:
    """Демо: создание фиктивного кейса (не данные Tagme).

    Когда вызывать: только если пользователь явно играет с mock-демо.
    Не вызывать для: реальных project_id/task_id.
    Возвращает: case_id, case_type, goal, status.
    """
    return {
        'case_id': 'mock-case-001',
        'case_type': case_type,
        'goal': goal,
        'status': 'created_mock',
    }


def list_cases_mock() -> List[Dict[str, Any]]:
    """Демо: список фиктивных кейсов (не данные Tagme).

    Когда вызывать: только для mock-сценария.
    Не вызывать для: списка задач проекта → get_project_stats.
    Возвращает: список словарей с case_id, title, status.
    """
    return [
        {
            'case_id': 'mock-case-001',
            'title': 'Test case',
            'status': 'active',
        }
    ]
