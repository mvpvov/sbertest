import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from crowd_sdk.core.utils.common import cast_params, chunks
from crowd_sdk.core.utils.common import dataclass_from_dict as from_dict
from crowd_sdk.core.utils.http_client import HttpMethod
from crowd_sdk.mcp.statistic._tagme_stats import date_to_iso_day, normalize_for_mcp
from crowd_sdk.tagme.http_client.client import TagmeClientAdvanced
from crowd_sdk.tagme.http_client.datacls import Project, ProjectStatistic, TaskData, TaskStatisticsItem

logger = logging.getLogger(__name__)
MCP_PAGE_SIZE = 100

# Before analyze_project_results loads all assignments —
# quick guard via task export (see _enforce_project_analysis_guard).
PROJECT_ANALYSIS_GUARD_DEFAULT_MAX_TASKS = 50
PROJECT_ANALYSIS_GUARD_DEFAULT_MAX_ASSIGNMENTS_ESTIMATE = 50_000


def _clear_none(data: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in data.items() if value is not None}


async def _get_with_organization_param(
    client: TagmeClientAdvanced,
    url: str,
    organization_id: Optional[str],
    params: Optional[Dict[str, Any]] = None,
) -> Any:
    low_level_client = client.client
    resolved_organization_id = organization_id or await low_level_client.get_current_organization_id()
    token = await low_level_client.get_org_token(resolved_organization_id)
    request_params = dict(params or {})
    request_params['organization_id'] = resolved_organization_id

    return await low_level_client._request(  # pylint: disable=protected-access
        HttpMethod.GET,
        url,
        ssl_context=low_level_client.ssl_context,
        headers={
            'Authorization': f'{low_level_client.auth_type} {token.get_access_token()}',
            'X-User-Id': low_level_client.token_marker.user_id,
        },
        params=request_params,
    )


async def _get_project_with_organization(
    client: TagmeClientAdvanced,
    project_id: str,
    organization_id: Optional[str],
    with_tasks_count: bool = False,
) -> Project:
    response = await _get_with_organization_param(
        client,
        f'api/v0/markup_project/{project_id}',
        organization_id,
        params=cast_params(withTasksCount=with_tasks_count),
    )
    return from_dict(data_class=Project, data=response)


async def _get_project_stats_with_organization(
    client: TagmeClientAdvanced,
    project_id: str,
    organization_id: Optional[str],
) -> ProjectStatistic:
    response = await _get_with_organization_param(
        client,
        f'api/v0/statistics/project/{project_id}',
        organization_id,
    )
    return from_dict(data_class=ProjectStatistic, data=response)


async def _get_project_tasks_with_organization(
    client: TagmeClientAdvanced,
    project_id: str,
    organization_id: Optional[str],
) -> List[TaskData]:
    tasks: List[TaskData] = []
    page = 1
    total: Optional[int] = None

    while total is None or (page - 1) * MCP_PAGE_SIZE < total:
        response = await _get_with_organization_param(
            client,
            'api/v0/tasks',
            organization_id,
            params=cast_params(project_id=project_id, page=page, size=MCP_PAGE_SIZE),
        )
        tasks.extend(from_dict(data_class=TaskData, data=_clear_none(item)) for item in response['items'])
        total = response['total']
        page += 1

    return tasks


def _infer_project_marker_stats_range(project: Project, tasks: List[TaskData]) -> Tuple[str, str]:
    """
    Date window for export_project_stats when the caller did not pass from_date/to_date.

    Project-level created/update dates often lag behind task activity; align with per-task
    inference (start/finished/update, falling back to utc now for open tasks).
    """
    if not tasks:
        from_day = date_to_iso_day(project.created_date or project.update_date)
        to_day = date_to_iso_day(project.update_date or datetime.utcnow())
        if not from_day or not to_day:
            raise ValueError('Unable to infer marker stats date range from project metadata')
        return from_day, to_day

    from_days: List[str] = []
    to_days: List[str] = []

    proj_from = date_to_iso_day(project.created_date or project.update_date)
    if proj_from:
        from_days.append(proj_from)

    for task in tasks:
        task_from = date_to_iso_day(task.start_date or task.created_date or task.update_date)
        if task_from:
            from_days.append(task_from)
        task_to = date_to_iso_day(task.finished_date or task.update_date or datetime.utcnow())
        if task_to:
            to_days.append(task_to)

    from_day = min(from_days) if from_days else date_to_iso_day(project.created_date or project.update_date)
    to_day = max(to_days) if to_days else date_to_iso_day(project.update_date or datetime.utcnow())

    if not from_day or not to_day:
        raise ValueError('Unable to infer marker stats date range from project tasks')
    return from_day, to_day


async def _get_project_task_statistics_with_organization(
    client: TagmeClientAdvanced,
    project_id: str,
    organization_id: Optional[str],
) -> List[TaskStatisticsItem]:
    tasks = await _get_project_tasks_with_organization(client, project_id, organization_id)
    if not tasks:
        return []

    task_statistics: List[TaskStatisticsItem] = []
    for task_ids_chunk in chunks([task.uid for task in tasks], 100):
        response = await _get_with_organization_param(
            client,
            '/api/v0/statistics/tasks',
            organization_id,
            params=cast_params(task_ids=task_ids_chunk, map_keys=[('task_ids', 'taskId[]')]),
        )
        task_statistics.extend(
            from_dict(data_class=TaskStatisticsItem, data=_clear_none(task_stat_data)) for task_stat_data in response
        )
    return task_statistics


def _progress_block(marked_count: Optional[int], objects_count: Optional[int]) -> Dict[str, Optional[float]]:
    progress_percent: Optional[float] = None
    if marked_count is not None and objects_count:
        progress_percent = round(marked_count / objects_count * 100, 2)

    return {
        'marked_count': marked_count,
        'objects_count': objects_count,
        'progress_percent': progress_percent,
    }


def _project_metadata(project: Project) -> Dict[str, Any]:
    return normalize_for_mcp(
        {
            'uid': project.uid,
            'name': project.name,
            'organization_id': project.organization_id,
            'created_date': project.created_date,
            'update_date': project.update_date,
            'tasks_count': project.tasks_count,
            'running_tasks_count': project.running_tasks_count,
            'is_archived': project.is_archived,
        }
    )


def _task_metadata(task: TaskData) -> Dict[str, Any]:
    return normalize_for_mcp(
        {
            'uid': task.uid,
            'name': task.name,
            'project_id': task.project_id,
            'organization_id': task.organization_id,
            'created_date': task.created_date,
            'update_date': task.update_date,
            'start_date': task.start_date,
            'finished_date': task.finished_date,
            'state': task.state,
            'overlap': task.overlap,
            'price': task.price,
            'estimated_files_count': task.estimated_files_count,
            'markers_count_plan': task.markers_count_plan,
        }
    )
