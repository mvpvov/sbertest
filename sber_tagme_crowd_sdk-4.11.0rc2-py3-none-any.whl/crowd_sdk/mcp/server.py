import importlib
import os
from typing import Iterable, List, Literal, Optional, Sequence

import anyio  # pylint: disable=import-error
from mcp.server.auth.provider import AccessToken  # pylint: disable=import-error
from mcp.server.auth.settings import AuthSettings, ClientRegistrationOptions  # pylint: disable=import-error
from mcp.server.fastmcp import FastMCP  # pylint: disable=import-error

from crowd_sdk.mcp import tools

SERVICE_NAME = 'crowd-sdk-mcp'
DEFAULT_HTTP_HOST = '127.0.0.1'
DEFAULT_HTTP_PORT = 8000
DEFAULT_HTTP_PATH = '/mcp'
AUTH_SCOPE = 'tagme'
EXTRA_MODULES_ENV = 'CROWD_SDK_MCP_EXTRA_MODULES'
ENV_HUMAN_TOOLS = 'CROWD_SDK_MCP_HUMAN_TOOLS'
ENV_BASE_TOOLSET = 'CROWD_SDK_MCP_BASE_TOOLSET'
BaseToolsetMode = Literal['full', 'minimal']
LOCALHOST_CORS_ORIGIN_REGEX = r'https?://(localhost|127\.0\.0\.1|\[::1\])(:\d+)?'


class TagmeBearerTokenVerifier:
    async def verify_token(self, token: str) -> Optional[AccessToken]:  # pylint: disable=no-self-use
        if not token:
            return None
        return AccessToken(token=token, client_id='tagme', scopes=[AUTH_SCOPE])


def _create_auth_settings(issuer_url: str) -> AuthSettings:
    return AuthSettings(
        issuer_url=issuer_url,
        resource_server_url=issuer_url,
        client_registration_options=ClientRegistrationOptions(
            enabled=False,
            valid_scopes=[AUTH_SCOPE],
            default_scopes=[AUTH_SCOPE],
        ),
        required_scopes=[AUTH_SCOPE],
    )


def _split_extra_modules(raw_modules: Optional[str]) -> List[str]:
    if not raw_modules:
        return []
    modules: List[str] = []
    for chunk in raw_modules.replace(',', ':').split(':'):
        module_name = chunk.strip()
        if module_name:
            modules.append(module_name)
    return modules


def resolve_extra_modules(extra_modules: Optional[Iterable[str]] = None) -> List[str]:
    resolved = _split_extra_modules(os.getenv(EXTRA_MODULES_ENV))
    resolved.extend(module_name.strip() for module_name in extra_modules or [] if module_name.strip())
    return resolved


def resolve_human_mcp_enabled(explicit: Optional[bool] = None) -> bool:
    """Включены ли Human MCP инструменты (``CROWD_SDK_MCP_HUMAN_TOOLS=1``).

    По умолчанию выключено. Включается флагом ``--enable-human-mcp`` или env ``CROWD_SDK_MCP_HUMAN_TOOLS=1``.
    """
    if explicit is not None:
        return explicit
    return os.getenv(ENV_HUMAN_TOOLS, '0').strip() == '1'


def resolve_base_toolset(explicit: Optional[str] = None) -> BaseToolsetMode:
    """Базовый набор не-human инструментов (``CROWD_SDK_MCP_BASE_TOOLSET``).

    - ``full`` — аналитика, моки, статистика (как раньше без учёта Human MCP).
    - ``minimal`` — только health / platform / проверка доступа / справочник инструментов;
      удобно для отдельного инстанса «только Human MCP».
    """
    raw = (explicit if explicit is not None else os.getenv(ENV_BASE_TOOLSET, 'full')).strip().lower()
    if raw in ('full', 'minimal'):
        return raw  # type: ignore[return-value]
    raise ValueError(f'Invalid {ENV_BASE_TOOLSET}={raw!r}: expected full or minimal (CLI: tagme mcp --base-toolset …)')


def register_extra_mcp_tools(mcp: FastMCP, extra_modules: Optional[Iterable[str]] = None) -> None:
    for module_name in resolve_extra_modules(extra_modules):
        try:
            module = importlib.import_module(module_name)
        except ImportError as exp:
            raise ValueError(f'Failed to import MCP extra module "{module_name}": {exp}') from exp

        register = getattr(module, 'register_mcp_tools', None)
        if register is None:
            raise ValueError(f'MCP extra module "{module_name}" must define register_mcp_tools(mcp)')
        if not callable(register):
            raise ValueError(f'MCP extra module "{module_name}".register_mcp_tools must be callable')

        register(mcp)


def create_mcp_server(  # pylint: disable=R0913
    host: str = DEFAULT_HTTP_HOST,
    port: int = DEFAULT_HTTP_PORT,
    streamable_http_path: str = DEFAULT_HTTP_PATH,
    stateless_http: bool = False,
    require_auth: bool = False,
    auth_issuer_url: Optional[str] = None,
    extra_modules: Optional[Sequence[str]] = None,
    enable_human_mcp: Optional[bool] = None,
    base_toolset: Optional[str] = None,
) -> FastMCP:
    auth_kwargs = {}
    if require_auth:
        issuer_url = auth_issuer_url or f'http://localhost:{port}'
        auth_kwargs = {
            'auth': _create_auth_settings(issuer_url),
            'token_verifier': TagmeBearerTokenVerifier(),
        }

    mcp = FastMCP(
        SERVICE_NAME,
        host=host,
        port=port,
        streamable_http_path=streamable_http_path,
        stateless_http=stateless_http,
        **auth_kwargs,
    )

    human_enabled = resolve_human_mcp_enabled(enable_human_mcp)
    base_mode = resolve_base_toolset(base_toolset)

    minimal_suite = (tools.health_check, tools.get_platform_info, tools.check_tagme_sdk_access, tools.search_sdk)
    analytics_suite = (
        tools.create_case_mock,
        tools.list_cases_mock,
        tools.analyze_task_results,
        tools.analyze_fraud_risk,
        tools.analyze_project_results,
        tools.get_project_stats,
        tools.analyze_project_instructions,
        tools.get_task_stats,
        tools.get_marker_performance_stats,
        tools.get_project_quality_stats,
        tools.get_annotation_summary,
    )

    for fn in minimal_suite:
        mcp.tool()(fn)
    if base_mode == 'full':
        for fn in analytics_suite:
            mcp.tool()(fn)

    if human_enabled:
        mcp.tool()(tools.get_human_mcp_markup_options)
        mcp.tool()(tools.summarize_projects_for_human_mcp)
        mcp.tool()(tools.create_markup_task_with_items)
        mcp.tool()(tools.configure_human_mcp_project)
        mcp.tool()(tools.generate_tagme_interface)
        mcp.tool()(tools.edit_tagme_interface)
        mcp.tool()(tools.apply_interface_to_project)
        mcp.tool()(tools.list_project_tasks)
        mcp.tool()(tools.update_markup_task)
        mcp.tool()(tools.stop_markup_task)
        mcp.tool()(tools.upload_project_instruction)

    register_extra_mcp_tools(mcp, extra_modules)

    return mcp


async def _run_http_with_localhost_cors(mcp: FastMCP, transport: str) -> None:
    import uvicorn  # pylint: disable=import-outside-toplevel,import-error
    from starlette.middleware.cors import CORSMiddleware  # pylint: disable=import-outside-toplevel,import-error

    if transport == 'sse':
        starlette_app = mcp.sse_app()
    else:
        starlette_app = mcp.streamable_http_app()

    starlette_app.add_middleware(
        CORSMiddleware,
        allow_origin_regex=LOCALHOST_CORS_ORIGIN_REGEX,
        allow_methods=['GET', 'POST', 'DELETE', 'OPTIONS'],
        allow_headers=['mcp-protocol-version', 'mcp-session-id', 'Authorization', 'Content-Type'],
        expose_headers=['mcp-session-id'],
    )

    config = uvicorn.Config(
        starlette_app,
        host=mcp.settings.host,
        port=mcp.settings.port,
        log_level=mcp.settings.log_level.lower(),
    )
    server = uvicorn.Server(config)
    await server.serve()


def run(  # pylint: disable=R0913
    transport: str = 'stdio',
    host: str = DEFAULT_HTTP_HOST,
    port: int = DEFAULT_HTTP_PORT,
    streamable_http_path: str = DEFAULT_HTTP_PATH,
    stateless_http: bool = False,
    require_auth: Optional[bool] = None,
    auth_issuer_url: Optional[str] = None,
    extra_modules: Optional[Sequence[str]] = None,
    enable_human_mcp: Optional[bool] = None,
    base_toolset: Optional[str] = None,
    enable_dataset_builder: bool = False,
) -> None:
    if transport not in {'stdio', 'sse', 'streamable-http'}:
        raise ValueError('transport must be one of: stdio, sse, streamable-http')

    auth_enabled = transport != 'stdio' if require_auth is None else require_auth
    if enable_dataset_builder:
        extra_modules = list(extra_modules or []) + ['crowd_sdk.mcp.dataset_builder']
    mcp = create_mcp_server(
        host=host,
        port=port,
        streamable_http_path=streamable_http_path,
        stateless_http=stateless_http,
        require_auth=auth_enabled,
        auth_issuer_url=auth_issuer_url,
        extra_modules=extra_modules,
        enable_human_mcp=enable_human_mcp,
        base_toolset=base_toolset,
    )
    if transport == 'stdio':
        mcp.run(transport=transport)
    else:
        anyio.run(_run_http_with_localhost_cors, mcp, transport)


def main() -> None:
    run()


if __name__ == '__main__':
    main()
