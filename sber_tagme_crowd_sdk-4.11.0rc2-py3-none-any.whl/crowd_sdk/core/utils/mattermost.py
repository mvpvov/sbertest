import json
from dataclasses import dataclass
from typing import Any, Dict, Optional

from aiohttp import ClientResponse

from crowd_sdk.core.utils.http import HttpWrapper
from crowd_sdk.tagme.config import DEFAULT_CONFIG, CrowdConfig

SECTION_NAME = "mattermost"


@CrowdConfig.crowd_config_section(SECTION_NAME)
@dataclass
class MattermostConfig:
    token: str
    channel_id: str
    bot_url: str


class MattermostClient:
    def __init__(self, http: Optional[HttpWrapper] = None) -> None:
        self.http = http or HttpWrapper()
        crowd_config = CrowdConfig.from_path(DEFAULT_CONFIG)
        assert crowd_config.mattermost, "Fill mattermost section in crowd config"
        self.config: MattermostConfig = crowd_config.mattermost

    async def send_message(self, text: str, root_id: Optional[str] = None) -> ClientResponse:
        bot_api_headers = {'Authorization': 'Bearer ' + self.config.token}
        default_http_params = {'headers': bot_api_headers, 'raise_for_status': True}
        data = {'channel_id': self.config.channel_id, 'message': text}
        if root_id is not None:
            data['root_id'] = root_id
        url = f"{self.config.bot_url}/posts"
        response: ClientResponse = await self.http.request('POST', url, json=data, ssl=False, **default_http_params)
        return response

    async def post_with_comment(self, post_text: str, comment_text: str) -> None:
        response = await self.send_message(post_text)
        response_body: Dict[str, Any] = json.loads(await response.text())
        post_id = response_body["id"]
        await self.send_message(comment_text, root_id=post_id)
